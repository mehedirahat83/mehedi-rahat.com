<?php
/**
 * MR Commerce Pro uninstall handler.
 *
 * Phase 1 intentionally preserves all plugin data. A controlled
 * "delete data on uninstall" setting will be added in a later phase.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
