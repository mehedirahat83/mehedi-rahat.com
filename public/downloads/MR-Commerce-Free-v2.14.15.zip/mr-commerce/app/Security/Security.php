<?php

namespace MRBP\Security;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Support\Logger;

final class Security {

    private ?Logger $logger;

    public function __construct( ?Logger $logger = null ) {
        $this->logger = $logger;
    }

    public function require_capability( string $capability, string $message = '' ): void {
        if ( current_user_can( $capability ) ) {
            return;
        }

        $this->log_failure( 'Permission denied.', array( 'capability' => sanitize_key( $capability ) ) );
        do_action( 'mrbp/security/permission_denied', $capability );

        wp_die(
            esc_html( $message ?: __( 'You are not allowed to do this.', 'mr-commerce' ) ),
            esc_html__( 'Access denied', 'mr-commerce' ),
            array( 'response' => 403 )
        );
    }

    public function verify_admin_nonce( string $action, string $field = '_wpnonce' ): void {
        $nonce = isset( $_REQUEST[ $field ] ) ? sanitize_text_field( wp_unslash( $_REQUEST[ $field ] ) ) : '';

        if ( '' !== $nonce && wp_verify_nonce( $nonce, $action ) ) {
            return;
        }

        $this->log_failure( 'Invalid admin nonce.', array( 'action' => sanitize_key( $action ) ) );
        do_action( 'mrbp/security/failed_nonce', $action, $field );

        wp_die(
            esc_html__( 'Security verification failed. Please refresh the page and try again.', 'mr-commerce' ),
            esc_html__( 'Invalid request', 'mr-commerce' ),
            array( 'response' => 403 )
        );
    }

    public function verify_admin_action( string $capability, string $nonce_action, string $nonce_field = '_wpnonce' ): void {
        $this->require_capability( $capability );
        $this->verify_admin_nonce( $nonce_action, $nonce_field );
    }

    private function log_failure( string $message, array $context ): void {
        if ( null !== $this->logger ) {
            $this->logger->warning( '[Security] ' . $message, $context );
        }
    }
}
