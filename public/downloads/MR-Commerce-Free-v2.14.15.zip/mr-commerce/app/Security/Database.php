<?php

namespace MRBP\Security;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Database {

    public static function table_name( string $table ): string {
        global $wpdb;

        $prefix = preg_quote( $wpdb->prefix, '/' );
        if ( ! preg_match( '/^' . $prefix . '[A-Za-z0-9_]+$/', $table ) ) {
            throw new \InvalidArgumentException( 'Invalid database table identifier.' );
        }

        return $table;
    }
}
