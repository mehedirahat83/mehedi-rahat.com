<?php

namespace MRBP\Security;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Input {

    public static function post_array( string $key ): array {
        if ( ! isset( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) {
            return array();
        }

        return self::sanitize_array( wp_unslash( $_POST[ $key ] ) );
    }

    public static function post_text( string $key, string $default = '' ): string {
        return isset( $_POST[ $key ] )
            ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) )
            : $default;
    }

    public static function post_email( string $key ): string {
        return isset( $_POST[ $key ] )
            ? sanitize_email( wp_unslash( $_POST[ $key ] ) )
            : '';
    }

    public static function post_bool( string $key ): bool {
        return ! empty( $_POST[ $key ] );
    }

    public static function query_key( string $key, string $default = '' ): string {
        return isset( $_GET[ $key ] )
            ? sanitize_key( wp_unslash( $_GET[ $key ] ) )
            : $default;
    }

    public static function sanitize_array( array $input ): array {
        $safe = array();

        foreach ( $input as $key => $value ) {
            $safe_key = is_int( $key ) ? $key : sanitize_key( (string) $key );
            if ( is_array( $value ) ) {
                $safe[ $safe_key ] = self::sanitize_array( $value );
            } elseif ( is_scalar( $value ) || null === $value ) {
                $safe[ $safe_key ] = is_string( $value ) ? sanitize_text_field( $value ) : $value;
            }
        }

        return $safe;
    }
}
