<?php

namespace MRBP\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

interface EntitlementProviderInterface {

    public function current_plan(): string;

    public function allows( string $feature ): bool;

    public function level( string $feature ): string;

    public function limit( string $feature ): int;
}
