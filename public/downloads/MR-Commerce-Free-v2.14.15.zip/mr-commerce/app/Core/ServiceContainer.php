<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use InvalidArgumentException;

final class ServiceContainer {

    private array $services = array();

    public function set( string $id, object $service ): void {
        $this->services[ $id ] = $service;
    }

    public function has( string $id ): bool {
        return isset( $this->services[ $id ] );
    }

    public function get( string $id ): object {
        if ( ! $this->has( $id ) ) {
            throw new InvalidArgumentException( sprintf( 'Service "%s" is not registered.', $id ) );
        }

        return $this->services[ $id ];
    }

    public function all(): array {
        return $this->services;
    }
}
