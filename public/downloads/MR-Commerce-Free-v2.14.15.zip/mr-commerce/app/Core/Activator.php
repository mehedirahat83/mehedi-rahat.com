<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Activator {

    public static function activate(): void {
        if ( ! EditionManager::on_activation() ) {
            return;
        }

        $requirements = new Requirements();

        if ( ! $requirements->passes() ) {
            deactivate_plugins( MRBP_BASENAME );
            wp_die(
                wp_kses_post( $requirements->get_failure_message() ),
                esc_html__( 'MR Commerce activation failed', 'mr-commerce' ),
                array( 'back_link' => true )
            );
        }

        if ( false === get_option( 'mrbp_enabled_modules', false ) ) {
            add_option(
                'mrbp_enabled_modules',
                array(
                    'growth_suite' => true,
                    'physical_commerce' => true,
                    'customer_portal' => true,
                    'payment_pro'     => true,
                    'sequential_orders' => true,
                ),
                '',
                false
            );
        }

        if ( false === get_option( 'mrbp_general_settings', false ) ) {
            add_option(
                'mrbp_general_settings',
                array(
                    'company_name' => get_bloginfo( 'name' ),
                ),
                '',
                false
            );
        }


        if ( false === get_option( 'mrbp_advanced_settings', false ) ) {
            add_option(
                'mrbp_advanced_settings',
                array(
                    'debug_logging'            => false,
                    'delete_data_on_uninstall' => false,
                ),
                '',
                false
            );
        }

        if ( ( new BuildInfo() )->requires_license() && false === get_option( 'mrbp_license_data', false ) ) {
            add_option(
                'mrbp_license_data',
                array(
                    'key'          => '',
                    'status'       => 'not_activated',
                    'plan'         => '',
                    'domain'       => '',
                    'activated_at' => '',
                    'expires_at'   => '',
                    'last_checked' => '',
                ),
                '',
                false
            );
        }

        if ( ( new BuildInfo() )->requires_license() && false === get_option( 'mrbp_license_status', false ) ) {
            add_option( 'mrbp_license_status', 'not_activated', '', false );
        }

        if ( ( new BuildInfo() )->requires_license() && false === get_option( 'mrbp_license_last_check', false ) ) {
            add_option( 'mrbp_license_last_check', '', '', false );
        }

        if ( ( new BuildInfo() )->requires_license() && false === get_option( 'mrbp_license_activity', false ) ) {
            add_option( 'mrbp_license_activity', array(), '', false );
        }

        if ( false === get_option( 'mrbp_db_version', false ) ) {
            add_option( 'mrbp_db_version', '0.0.0', '', false );
        }

        if ( false === get_option( 'mrbp_db_versions', false ) ) {
            add_option( 'mrbp_db_versions', array(), '', false );
        }
        update_option( 'mrbp_version', MRBP_VERSION, false );

        $bundled_license = MRBP_PATH . 'license/customer-license.mrbp';
        if ( ( new BuildInfo() )->requires_license() && is_readable( $bundled_license ) ) {
            $result = ( new \MRBP\Licensing\LocalLicenseService() )->import_bundled_license();
            if ( empty( $result['valid'] ) ) {
                deactivate_plugins( MRBP_BASENAME );
                wp_die(
                    esc_html( (string) ( $result['message'] ?? __( 'This MR Commerce Pro license is not valid for the current domain.', 'mr-commerce' ) ) ),
                    esc_html__( 'MR Commerce Pro activation failed', 'mr-commerce' ),
                    array( 'back_link' => true )
                );
            }
        }

        self::optimize_option_autoloading();

        set_transient( 'mrbp_activation_redirect', true, 30 );

        do_action( 'mrbp/activated', MRBP_VERSION );
    }
    /**
     * Older builds may have created settings with autoload enabled. These
     * options are only needed on MR Commerce Pro requests, so keep them out of
     * WordPress' alloptions payload on every frontend page.
     */
    private static function optimize_option_autoloading(): void {
        global $wpdb;

        $option_names = array(
            'mrbp_enabled_modules',
            'mrbp_general_settings',
            'mrbp_email_settings',
            'mrbp_payment_settings',
            'mrbp_portal_settings',
            'mrbp_advanced_settings',
            'mrbp_license_data',
            'mrbp_license_status',
            'mrbp_license_last_check',
            'mrbp_license_activity',
            'mrbp_db_version',
            'mrbp_db_versions',
            'mrbp_payment_gateway_settings',
            'mrbp_dynamic_gateways',
            'mrbp_manual_gateway_settings',
            'mrbp_sequential_order_settings',
            'mrbp_sequential_order_counter',
        );

        $placeholders = implode( ', ', array_fill( 0, count( $option_names ), '%s' ) );
        $sql = "UPDATE {$wpdb->options} SET autoload = 'no' WHERE option_name IN ({$placeholders})";
        $wpdb->query( $wpdb->prepare( $sql, ...$option_names ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        wp_cache_delete( 'alloptions', 'options' );
        foreach ( $option_names as $option_name ) {
            wp_cache_delete( $option_name, 'options' );
        }
    }

}
