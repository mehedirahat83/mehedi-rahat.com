<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class GlobalHooks {

    public function register(): void {
        add_filter( 'plugin_action_links_' . MRBP_BASENAME, array( $this, 'add_plugin_action_links' ) );
        add_action( 'init', array( $this, 'register_runtime_hooks' ), 5 );
    }

    public function add_plugin_action_links( array $links ): array {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url( admin_url( 'admin.php?page=mrbp-settings' ) ),
            esc_html__( 'Settings', 'mr-commerce' )
        );

        array_unshift( $links, $settings_link );

        return $links;
    }

    public function register_runtime_hooks(): void {
        do_action( 'mrbp/core/init' );
    }
}
