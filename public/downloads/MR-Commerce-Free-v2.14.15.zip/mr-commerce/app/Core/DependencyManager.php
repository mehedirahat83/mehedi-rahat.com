<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class DependencyManager {

    public const MIN_PHP = '8.1';
    public const MIN_WP = '6.4';
    public const MIN_WOOCOMMERCE = '8.0';

    /** @var array<string,array{satisfied:bool,failures:array}> */
    private array $report_cache = array();

    public function core_requirements(): array {
        return array(
            array( 'type' => 'php', 'min_version' => self::MIN_PHP ),
            array( 'type' => 'wordpress', 'min_version' => self::MIN_WP ),
            array( 'type' => 'php_extension', 'name' => 'json' ),
        );
    }

    public function core_report(): array {
        return $this->check( $this->core_requirements() );
    }

    public function check( array $dependencies ): array {
        $cache_key = md5( serialize( $dependencies ) );
        if ( isset( $this->report_cache[ $cache_key ] ) ) {
            return $this->report_cache[ $cache_key ];
        }

        $failures = array();

        foreach ( $dependencies as $dependency ) {
            $normalized = $this->normalize( $dependency );

            if ( null === $normalized ) {
                continue;
            }

            $result = $this->evaluate( $normalized );

            if ( ! $result['satisfied'] ) {
                $failures[] = $result;
            }
        }

        $report = array(
            'satisfied' => empty( $failures ),
            'failures'  => $failures,
        );

        $this->report_cache[ $cache_key ] = $report;
        return $report;
    }

    public function satisfied( array $dependencies ): bool {
        return $this->check( $dependencies )['satisfied'];
    }

    public function failure_messages( array $dependencies ): array {
        return array_values(
            array_map(
                static fn( array $failure ): string => (string) $failure['message'],
                $this->check( $dependencies )['failures']
            )
        );
    }

    private function normalize( mixed $dependency ): ?array {
        if ( is_string( $dependency ) ) {
            return match ( $dependency ) {
                'php'                => array( 'type' => 'php', 'min_version' => self::MIN_PHP ),
                'wordpress'          => array( 'type' => 'wordpress', 'min_version' => self::MIN_WP ),
                'woocommerce'        => array( 'type' => 'woocommerce', 'min_version' => self::MIN_WOOCOMMERCE ),
                'wc_payment_gateway' => array( 'type' => 'class', 'name' => 'WC_Payment_Gateway', 'label' => 'WooCommerce payment gateway API' ),
                default              => array( 'type' => 'custom', 'name' => $dependency ),
            };
        }

        return is_array( $dependency ) && ! empty( $dependency['type'] ) ? $dependency : null;
    }

    private function evaluate( array $dependency ): array {
        $type = (string) $dependency['type'];

        return match ( $type ) {
            'php'           => $this->check_php( (string) ( $dependency['min_version'] ?? self::MIN_PHP ) ),
            'wordpress'     => $this->check_wordpress( (string) ( $dependency['min_version'] ?? self::MIN_WP ) ),
            'woocommerce'   => $this->check_woocommerce( (string) ( $dependency['min_version'] ?? self::MIN_WOOCOMMERCE ) ),
            'php_extension' => $this->check_extension( (string) ( $dependency['name'] ?? '' ) ),
            'class'         => $this->check_class( (string) ( $dependency['name'] ?? '' ), (string) ( $dependency['label'] ?? '' ) ),
            'custom'        => $this->check_custom( (string) ( $dependency['name'] ?? '' ), $dependency ),
            default         => $this->result( false, $type, __( 'An unknown dependency could not be verified.', 'mr-commerce' ) ),
        };
    }

    private function check_php( string $minimum ): array {
        $ok = version_compare( PHP_VERSION, $minimum, '>=' );
        $message = $ok ? '' : sprintf(
            /* translators: 1: required PHP version, 2: current PHP version */
            __( 'PHP %1$s or newer is required. This server is running PHP %2$s.', 'mr-commerce' ),
            $minimum,
            PHP_VERSION
        );

        return $this->result( $ok, 'php', $message, PHP_VERSION, $minimum );
    }

    private function check_wordpress( string $minimum ): array {
        global $wp_version;
        $current = isset( $wp_version ) ? (string) $wp_version : '0';
        $ok = version_compare( $current, $minimum, '>=' );
        $message = $ok ? '' : sprintf(
            /* translators: 1: required WordPress version, 2: current WordPress version */
            __( 'WordPress %1$s or newer is required. This site is running WordPress %2$s.', 'mr-commerce' ),
            $minimum,
            $current
        );

        return $this->result( $ok, 'wordpress', $message, $current, $minimum );
    }

    private function check_woocommerce( string $minimum ): array {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return $this->result( false, 'woocommerce', __( 'WooCommerce is not active.', 'mr-commerce' ), '', $minimum );
        }

        $current = defined( 'WC_VERSION' ) ? (string) WC_VERSION : '0';
        $ok = version_compare( $current, $minimum, '>=' );
        $message = $ok ? '' : sprintf(
            /* translators: 1: required WooCommerce version, 2: current WooCommerce version */
            __( 'WooCommerce %1$s or newer is required. This site is running WooCommerce %2$s.', 'mr-commerce' ),
            $minimum,
            $current
        );

        return $this->result( $ok, 'woocommerce', $message, $current, $minimum );
    }

    private function check_extension( string $extension ): array {
        $ok = '' !== $extension && extension_loaded( $extension );
        $message = $ok ? '' : sprintf(
            /* translators: %s: PHP extension name */
            __( 'The required PHP extension “%s” is not installed or enabled.', 'mr-commerce' ),
            $extension
        );

        return $this->result( $ok, 'php_extension', $message, $extension );
    }

    private function check_class( string $class, string $label ): array {
        $ok = '' !== $class && class_exists( $class );
        $name = '' !== $label ? $label : $class;
        $message = $ok ? '' : sprintf(
            /* translators: %s: dependency name */
            __( '%s is unavailable.', 'mr-commerce' ),
            $name
        );

        return $this->result( $ok, 'class', $message, $class );
    }

    private function check_custom( string $name, array $dependency ): array {
        $ok = (bool) apply_filters( 'mrbp/dependency_available', false, $name, $dependency, $this );
        $message = $ok ? '' : sprintf(
            /* translators: %s: dependency identifier */
            __( 'The required dependency “%s” is unavailable.', 'mr-commerce' ),
            $name
        );

        return $this->result( $ok, 'custom', $message, $name );
    }

    private function result( bool $satisfied, string $type, string $message = '', string $current = '', string $required = '' ): array {
        return array(
            'satisfied' => $satisfied,
            'type'      => $type,
            'message'   => $message,
            'current'   => $current,
            'required'  => $required,
        );
    }
}
