<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Makes an internal Owner installation unmistakable without exposing secrets.
 */
final class OwnerBuildGuard {

    public static function register(): void {
        if ( ! ( new BuildInfo() )->is_owner() ) {
            return;
        }

        add_action( 'admin_notices', array( self::class, 'render_notice' ) );
        add_action( 'network_admin_notices', array( self::class, 'render_notice' ) );
    }

    public static function render_notice(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        printf(
            '<div class="notice notice-warning"><p><strong>%s</strong> %s</p></div>',
            esc_html__( 'MR Commerce Pro — OWNER BUILD', 'mr-commerce' ),
            esc_html__( 'Internal use only. This build bypasses customer licensing and must never be distributed.', 'mr-commerce' )
        );
    }
}
