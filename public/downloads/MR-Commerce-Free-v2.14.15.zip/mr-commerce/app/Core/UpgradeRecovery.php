<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Repairs upgrade state that can otherwise leave existing installations with
 * disabled modules or stale dashboard rewrite rules.
 */
final class UpgradeRecovery {
    private const SCHEMA_VERSION = '1.1.6';
    private const NOTICE_TRANSIENT = 'mrbp_recovery_notice';
    private const HEALTH_TRANSIENT = 'mrbp_health_check_result';

    public function prepare(): void {
        $this->register_hooks();

        // Version recovery is an administrative maintenance concern. Avoid two
        // option lookups on every cacheable public request; the next admin load
        // will schedule and complete any pending upgrade safely.
        if ( ! is_admin() && ! RequestContext::is_cli() ) {
            return;
        }

        $installed = (string) get_option( 'mrbp_version', '' );
        $schema    = (string) get_option( 'mrbp_recovery_schema_version', '' );

        if ( MRBP_VERSION !== $installed || self::SCHEMA_VERSION !== $schema ) {
            update_option( 'mrbp_recovery_pending', 1, false );
        }
    }

    private function register_hooks(): void {
        add_action( 'init', array( $this, 'register_dashboard_rules' ), 4 );
        add_filter( 'query_vars', array( $this, 'register_dashboard_query_vars' ), 4 );
        add_action( 'admin_init', array( $this, 'maybe_run_automatic_recovery' ), 120 );
        add_action( 'admin_notices', array( $this, 'render_notices' ) );

        add_action( 'admin_post_mrbp_repair_routes', array( $this, 'handle_repair_routes' ) );
        add_action( 'admin_post_mrbp_reset_module_state', array( $this, 'handle_reset_module_state' ) );
        add_action( 'admin_post_mrbp_clear_cache', array( $this, 'handle_clear_cache' ) );
        add_action( 'admin_post_mrbp_run_health_check', array( $this, 'handle_health_check' ) );
    }

    public function register_dashboard_rules(): void {
        $routes = array(
            'orders'          => 'orders',
            'downloads'       => 'downloads',
            'invoices'        => 'invoices',
            'support'         => 'support',
            'activation'      => 'activation',
            'membership'      => 'membership',
            'account'         => 'account',
            'addresses'       => 'addresses',
            'payment-methods' => 'payment-methods',
            'wishlist'        => 'wishlist',
            'crm'             => 'crm',
            'crm/customers'   => 'crm-customers',
            'crm/orders'      => 'crm-orders',
            'crm/membership'  => 'crm-membership',
            'crm/products'    => 'crm-products',
            'crm/reports'     => 'crm-reports',
        );

        add_rewrite_rule( '^dashboard/?$', 'index.php?mrcp_dashboard=1', 'top' );
        add_rewrite_rule( '^dashboard/crm/customers/([0-9]+)/orders/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customer-orders&mrcp_customer_id=$matches[1]', 'top' );
        add_rewrite_rule( '^dashboard/crm/order/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-order-view&mrcp_order_id=$matches[1]', 'top' );
        add_rewrite_rule( '^dashboard/crm/customers/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customer-profile&mrcp_customer_id=$matches[1]', 'top' );

        foreach ( $routes as $path => $section ) {
            add_rewrite_rule( '^dashboard/' . $path . '/?$', 'index.php?mrcp_dashboard=1&mrcp_section=' . $section, 'top' );
        }

        add_rewrite_rule( '^dashboard/order/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=order&mrcp_order_id=$matches[1]', 'top' );
        add_rewrite_rule( '^dashboard/invoice/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=invoice&mrcp_order_id=$matches[1]', 'top' );
        add_rewrite_rule( '^dashboard/ticket/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=ticket-view&mrcp_ticket_id=$matches[1]', 'top' );
        add_rewrite_rule( '^dashboard/activation/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=activation-view&mrcp_activation_id=$matches[1]', 'top' );
    }

    public function register_dashboard_query_vars( array $vars ): array {
        foreach ( array( 'mrcp_dashboard', 'mrcp_section', 'mrcp_order_id', 'mrcp_ticket_id', 'mrcp_activation_id', 'mrcp_customer_id' ) as $var ) {
            if ( ! in_array( $var, $vars, true ) ) {
                $vars[] = $var;
            }
        }
        return $vars;
    }

    public function maybe_run_automatic_recovery(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $rules_missing = ! $this->dashboard_routes_exist();
        $pending       = (bool) get_option( 'mrbp_recovery_pending', false );

        if ( ! $pending && ! $rules_missing ) {
            return;
        }

        $this->repair_customer_portal_state();
        $routes_repaired = $this->rebuild_dashboard_routes();
        $cache_cleared   = $this->clear_plugin_cache();

        update_option( 'mrbp_version', MRBP_VERSION, false );
        update_option( 'mrbp_recovery_schema_version', self::SCHEMA_VERSION, false );
        delete_option( 'mrbp_recovery_pending' );

        set_transient(
            self::NOTICE_TRANSIENT,
            array(
                'type'    => $routes_repaired ? 'success' : 'warning',
                'message' => $routes_repaired
                    ? __( 'MR Commerce Pro upgrade recovery completed. Customer Portal modules, dashboard routes and plugin caches were repaired.', 'mr-commerce' )
                    : __( 'MR Commerce Pro repaired the module state, but dashboard routes could not be confirmed. Open Settings → Maintenance and run Repair Dashboard Routes.', 'mr-commerce' ),
                'cache'   => $cache_cleared,
            ),
            5 * MINUTE_IN_SECONDS
        );
    }

    public function repair_customer_portal_state(): bool {
        $modules = get_option( 'mrbp_enabled_modules', array() );
        $changed = false;

        if ( ! is_array( $modules ) ) {
            $modules = array();
            $changed = true;
        }

        // Add defaults only when a key does not exist. An explicit false value is
        // an administrator choice and must survive upgrades and normal requests.
        if ( array_key_exists( 'retention_suite', $modules ) ) {
            if ( ! empty( $modules['retention_suite'] ) ) {
                $modules['growth_suite']      = true;
                $modules['physical_commerce'] = true;
            }
            unset( $modules['retention_suite'] );
            $changed = true;
        }

        if ( ! array_key_exists( 'growth_suite', $modules ) ) {
            $modules['growth_suite'] = true;
            $changed = true;
        }

        if ( ! array_key_exists( 'physical_commerce', $modules ) ) {
            $modules['physical_commerce'] = true;
            $changed = true;
        }

        if ( ! array_key_exists( 'customer_portal', $modules ) ) {
            $modules['customer_portal'] = true;
            $changed = true;
        }

        if ( ! array_key_exists( 'payment_pro', $modules ) ) {
            $modules['payment_pro'] = false;
            $changed = true;
        }

        if ( ! array_key_exists( 'sequential_orders', $modules ) ) {
            $modules['sequential_orders'] = false;
            $changed = true;
        }

        if ( $changed ) {
            update_option( 'mrbp_enabled_modules', $modules, false );
        }

        return $changed;
    }

    public function rebuild_dashboard_routes(): bool {
        $this->register_dashboard_rules();

        if ( class_exists( '\\MRCP\\Core\\Router' ) ) {
            \MRCP\Core\Router::register_rewrite_rules();
        }

        flush_rewrite_rules( false );
        update_option( 'mrbp_customer_portal_rewrite_version', self::SCHEMA_VERSION, false );

        return $this->dashboard_routes_exist();
    }

    public function dashboard_routes_exist(): bool {
        $rules = get_option( 'rewrite_rules', array() );

        if ( ! is_array( $rules ) ) {
            return false;
        }

        foreach ( array_keys( $rules ) as $pattern ) {
            if ( '^dashboard/crm/?$' === $pattern || '^dashboard/crm/?$' === rtrim( (string) $pattern ) ) {
                return true;
            }
        }

        return false;
    }

    public function clear_plugin_cache(): bool {
        global $wpdb;

        $patterns = array(
            '_transient_mrbp_%',
            '_transient_timeout_mrbp_%',
            '_site_transient_mrbp_%',
            '_site_transient_timeout_mrbp_%',
            '_transient_mrcp_%',
            '_transient_timeout_mrcp_%',
        );

        foreach ( $patterns as $pattern ) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                    $pattern
                )
            );
        }

        if ( function_exists( 'wp_cache_flush_group' ) ) {
            wp_cache_flush_group( 'mrbp' );
            wp_cache_flush_group( 'mrcp' );
        }

        return true;
    }

    public function legacy_plugin_conflicts(): array {
        $active = (array) get_option( 'active_plugins', array() );
        if ( is_multisite() ) {
            $active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
        }

        $conflicts = array();
        foreach ( $active as $plugin_file ) {
            $normalized = strtolower( (string) $plugin_file );
            if ( str_contains( $normalized, 'mr-customer-portal' ) && ! str_contains( $normalized, 'mr-commerce' ) ) {
                $conflicts[] = (string) $plugin_file;
            }
        }

        if ( defined( 'MRCP_PLUGIN_FILE' ) && wp_normalize_path( (string) MRCP_PLUGIN_FILE ) !== wp_normalize_path( MRBP_FILE ) ) {
            $conflicts[] = (string) MRCP_PLUGIN_FILE;
        }

        return array_values( array_unique( $conflicts ) );
    }

    public function health_check(): array {
        $modules = get_option( 'mrbp_enabled_modules', array() );

        return array(
            'customer_portal_enabled' => is_array( $modules ) && ! empty( $modules['customer_portal'] ),
            'dashboard_routes'        => $this->dashboard_routes_exist(),
            'woocommerce'             => class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' ),
            'legacy_conflicts'        => $this->legacy_plugin_conflicts(),
            'plugin_version'          => MRBP_VERSION,
            'rewrite_version'         => (string) get_option( 'mrbp_customer_portal_rewrite_version', '' ),
        );
    }

    public function render_notices(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $conflicts = $this->legacy_plugin_conflicts();
        if ( $conflicts ) {
            ?>
            <div class="notice notice-error">
                <p><strong><?php esc_html_e( 'Legacy Customer Portal conflict detected.', 'mr-commerce' ); ?></strong> <?php esc_html_e( 'Deactivate the standalone MR Commerce Pro plugin. MR Commerce Pro already includes the portal and cannot safely load both copies together.', 'mr-commerce' ); ?></p>
            </div>
            <?php
        }

        $notice = get_transient( self::NOTICE_TRANSIENT );
        if ( is_array( $notice ) && ! empty( $notice['message'] ) ) {
            delete_transient( self::NOTICE_TRANSIENT );
            $class = 'success' === ( $notice['type'] ?? '' ) ? 'notice-success' : 'notice-warning';
            ?>
            <div class="notice <?php echo esc_attr( $class ); ?> is-dismissible"><p><?php echo esc_html( (string) $notice['message'] ); ?></p></div>
            <?php
        }
    }

    public function handle_repair_routes(): void {
        $this->authorize_action( 'mrbp_repair_routes' );
        $this->repair_customer_portal_state();
        $ok = $this->rebuild_dashboard_routes();
        $this->redirect_to_maintenance( $ok ? 'routes_repaired' : 'routes_failed' );
    }

    public function handle_reset_module_state(): void {
        $this->authorize_action( 'mrbp_reset_module_state' );
        $this->repair_customer_portal_state();
        update_option( 'mrbp_recovery_pending', 1, false );
        $this->redirect_to_maintenance( 'modules_repaired' );
    }

    public function handle_clear_cache(): void {
        $this->authorize_action( 'mrbp_clear_cache' );
        $this->clear_plugin_cache();
        $this->redirect_to_maintenance( 'cache_cleared' );
    }

    public function handle_health_check(): void {
        $this->authorize_action( 'mrbp_run_health_check' );
        set_transient( self::HEALTH_TRANSIENT, $this->health_check(), 10 * MINUTE_IN_SECONDS );
        $this->redirect_to_maintenance( 'health_checked' );
    }

    public static function get_health_result(): array {
        $result = get_transient( self::HEALTH_TRANSIENT );
        return is_array( $result ) ? $result : array();
    }

    private function authorize_action( string $action ): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to perform this maintenance action.', 'mr-commerce' ) );
        }
        check_admin_referer( $action );
    }

    private function redirect_to_maintenance( string $status ): void {
        wp_safe_redirect(
            add_query_arg(
                array(
                    'page'        => 'mrbp-settings',
                    'tab'         => 'maintenance',
                    'mrbp_status' => sanitize_key( $status ),
                ),
                admin_url( 'admin.php' )
            )
        );
        exit;
    }
}
