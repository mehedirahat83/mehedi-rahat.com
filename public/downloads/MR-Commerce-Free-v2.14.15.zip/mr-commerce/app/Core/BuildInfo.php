<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class BuildInfo {

    public function plan(): string {
        return defined( 'MRBP_BUILD_PLAN' ) ? (string) MRBP_BUILD_PLAN : PlanManager::PLAN_FREE;
    }

    public function edition(): string {
        return defined( 'MRBP_BUILD_EDITION' ) ? (string) MRBP_BUILD_EDITION : 'customer';
    }

    public function is_distribution(): bool {
        return in_array( $this->edition(), array( 'owner', 'customer' ), true );
    }

    public function is_owner(): bool {
        return 'owner' === $this->edition();
    }

    public function is_free(): bool {
        return PlanManager::PLAN_FREE === $this->plan();
    }

    public function is_pro(): bool {
        return PlanManager::PLAN_PRO === $this->plan();
    }

    public function requires_license(): bool {
        return $this->is_pro() && ! $this->is_owner();
    }
}
