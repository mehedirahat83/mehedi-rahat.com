<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Requirements {

    public const MIN_PHP = DependencyManager::MIN_PHP;
    public const MIN_WP  = DependencyManager::MIN_WP;

    private array $errors = array();
    private DependencyManager $dependencies;

    public function __construct( ?DependencyManager $dependencies = null ) {
        $this->dependencies = $dependencies ?? new DependencyManager();
    }

    public function passes(): bool {
        $report = $this->dependencies->core_report();
        $this->errors = array_values(
            array_map(
                static fn( array $failure ): string => (string) $failure['message'],
                $report['failures']
            )
        );

        return $report['satisfied'];
    }

    public function register_admin_notice(): void {
        add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
    }

    public function render_admin_notice(): void {
        if ( empty( $this->errors ) ) {
            $this->passes();
        }

        echo '<div class="notice notice-error"><p><strong>';
        echo esc_html__( 'MR Commerce Pro could not start.', 'mr-commerce' );
        echo '</strong></p><ul>';

        foreach ( $this->errors as $error ) {
            echo '<li>' . esc_html( $error ) . '</li>';
        }

        echo '</ul></div>';
    }

    public function get_failure_message(): string {
        if ( empty( $this->errors ) ) {
            $this->passes();
        }

        return '<strong>' . esc_html__( 'MR Commerce Pro could not be activated.', 'mr-commerce' ) . '</strong><br>'
            . implode( '<br>', array_map( 'esc_html', $this->errors ) );
    }
}
