<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class EditionManager {

    private const FREE_SLUGS = array(
        'mr-commerce/mr-commerce.php',
        'mr-business/mr-business.php',
        'mr-business-lite/mr-business-pro.php',
    );

    private const PRO_SLUGS = array(
        'mr-commerce-pro/mr-commerce-pro.php',
        'mr-business-pro/mr-business-pro.php',
    );

    public static function on_activation(): bool {
        if ( self::is_pro_build() ) {
            self::deactivate_free_editions();
            self::queue_notice( 'pro_replaced_free' );
            return true;
        }

        if ( self::is_any_plugin_active( self::PRO_SLUGS ) ) {
            deactivate_plugins( MRBP_BASENAME, true );
            self::queue_notice( 'free_blocked_by_pro' );
            return false;
        }

        return true;
    }

    public static function register_runtime_guards(): void {
        add_action( 'admin_init', array( self::class, 'enforce_single_edition' ), 1 );
        add_action( 'admin_notices', array( self::class, 'render_notice' ) );
        add_action( 'network_admin_notices', array( self::class, 'render_notice' ) );
    }

    public static function enforce_single_edition(): void {
        if ( self::is_pro_build() ) {
            self::deactivate_free_editions();
            return;
        }

        if ( self::is_any_plugin_active( self::PRO_SLUGS ) ) {
            deactivate_plugins( MRBP_BASENAME, true, is_network_admin() );
            self::queue_notice( 'free_blocked_by_pro' );
        }
    }

    public static function render_notice(): void {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        $notice = get_transient( 'mrbp_edition_notice' );

        if ( ! is_string( $notice ) || '' === $notice ) {
            return;
        }

        delete_transient( 'mrbp_edition_notice' );

        if ( 'pro_replaced_free' === $notice ) {
            printf(
                '<div class="notice notice-success is-dismissible"><p><strong>%s</strong> %s</p></div>',
                esc_html__( 'MR Commerce Pro activated successfully.', 'mr-commerce' ),
                esc_html__( 'The free edition was disabled automatically. Your existing settings and data were preserved.', 'mr-commerce' )
            );
            return;
        }

        if ( 'free_blocked_by_pro' === $notice ) {
            printf(
                '<div class="notice notice-warning is-dismissible"><p><strong>%s</strong> %s</p></div>',
                esc_html__( 'MR Commerce was not activated.', 'mr-commerce' ),
                esc_html__( 'MR Commerce Pro is already active. Free and Pro editions cannot run together.', 'mr-commerce' )
            );
        }
    }

    private static function deactivate_free_editions(): void {
        foreach ( self::FREE_SLUGS as $plugin ) {
            if ( self::is_plugin_active( $plugin ) ) {
                deactivate_plugins( $plugin, true, is_network_admin() );
            }
        }
    }

    private static function is_plugin_active( string $plugin ): bool {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        return is_plugin_active( $plugin ) || ( function_exists( 'is_plugin_active_for_network' ) && is_plugin_active_for_network( $plugin ) );
    }

    private static function is_any_plugin_active( array $plugins ): bool {
        foreach ( $plugins as $plugin ) {
            if ( self::is_plugin_active( (string) $plugin ) ) {
                return true;
            }
        }

        return false;
    }

    private static function queue_notice( string $notice ): void {
        set_transient( 'mrbp_edition_notice', $notice, MINUTE_IN_SECONDS * 5 );
    }

    private static function is_pro_build(): bool {
        return defined( 'MRBP_BUILD_PLAN' ) && 'pro' === MRBP_BUILD_PLAN;
    }
}
