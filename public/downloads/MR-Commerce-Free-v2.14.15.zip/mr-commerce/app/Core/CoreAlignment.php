<?php

namespace MRBP\Core;

defined( 'ABSPATH' ) || exit;

final class CoreAlignment {
    private const VERSION = '2.8.0';

    public function register(): void {
        add_action( 'init', array( $this, 'migrate' ), 6 );
        if ( is_admin() ) { add_action( 'admin_notices', array( $this, 'notice' ) ); }
    }

    public function migrate(): void {
        if ( self::VERSION === get_option( 'mrc_core_alignment_version' ) ) { return; }
        $physical = (array) get_option( 'mrc_physical_settings', array() );
        $growth = (array) get_option( 'mrc_growth_settings', array() );
        update_option( 'mrc_core_alignment_migration', array(
            'completed_at' => time(),
            'legacy_cod_toggle_preserved' => array_key_exists( 'cod_enabled', $physical ),
            'legacy_cart_discount_preserved' => array_key_exists( 'cart_enabled', $growth ),
            'fraud_window_preserved' => array_key_exists( 'risk_window_hours', $physical ),
        ), false );
        update_option( 'mrc_core_alignment_version', self::VERSION, false );
        set_transient( 'mrc_core_alignment_notice', 1, WEEK_IN_SECONDS );
    }

    public function notice(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) || ! get_transient( 'mrc_core_alignment_notice' ) ) { return; }
        delete_transient( 'mrc_core_alignment_notice' );
        echo '<div class="notice notice-info is-dismissible"><p><strong>' . esc_html__( 'MR Commerce Core Alignment complete.', 'mr-commerce' ) . '</strong> ' . esc_html__( 'WooCommerce now controls COD availability, standard coupons, refunds and stock restoration. Legacy MR settings were preserved for rollback; advanced MR rules remain active.', 'mr-commerce' ) . '</p></div>';
    }
}
