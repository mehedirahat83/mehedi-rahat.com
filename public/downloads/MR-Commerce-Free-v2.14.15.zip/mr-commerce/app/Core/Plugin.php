<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use LogicException;
use MRBP\Admin\AdminMenu;
use MRBP\Admin\Assets\AssetLoader;
use MRBP\Admin\Framework\AdminFramework;
use MRBP\Admin\Layout\PageRenderer;
use MRBP\Admin\Layout\Sidebar;
use MRBP\Admin\Layout\Header;
use MRBP\Admin\Layout\Breadcrumb;
use MRBP\Admin\Navigation\ActiveMenu;
use MRBP\Admin\Navigation\FlyoutMenu;
use MRBP\Admin\Navigation\NavigationRegistry;
use MRBP\Admin\OperationsUi;
use MRBP\Admin\Settings;
use MRBP\Integrations\WooCommerce\WooCommerceIntegration;
use MRBP\Modules\ModuleManager;
use MRBP\Modules\ModuleRegistry;
use MRBP\Support\Logger;
use MRBP\Support\FeatureGuard;
use MRBP\Entitlements\BuildEntitlementProvider;
use MRBP\Entitlements\LicenseEntitlementProvider;
use MRBP\Entitlements\FallbackNotice;
use MRBP\Contracts\EntitlementProviderInterface;
use MRBP\Licensing\LocalLicenseService;
use MRBP\Core\Database\MigrationManager;
use MRBP\Security\Security;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;
use MRBP\Updates\OnlineStatusService;
use MRBP\Updates\PluginUpdateClient;

final class Plugin {

    private static ?self $instance = null;
    private bool $booted = false;
    private ServiceContainer $container;

    private function __construct() {
        $this->container = new ServiceContainer();
    }

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function boot(): void {
        if ( $this->booted ) {
            return;
        }

        $this->booted = true;

        $this->load_textdomain();
        EditionManager::register_runtime_guards();
        OwnerBuildGuard::register();
        $this->register_core_services();
        $this->register_global_hooks();
        $this->upgrade_recovery()->prepare();
        $this->register_settings();
        $this->load_enabled_modules();
        $this->initialize_woocommerce();
        $this->register_admin();

        do_action( 'mrbp/core/booted', $this, $this->container );

        $this->logger()->info(
            mrbp_product_name() . ' core booted.',
            array(
                'version'           => MRBP_VERSION,
                'build_plan'        => $this->plan_manager()->current_plan(),
                'enabled_modules'   => array_keys( array_filter( $this->module_manager()->enabled() ) ),
                'woocommerce_ready' => $this->woocommerce()->is_available(),
            )
        );
    }

    public function container(): ServiceContainer {
        return $this->container;
    }
    public function plan(): PlanManager {
        return $this->plan_manager();
    }

    /**
     * Return the shared Payment Pro gateway catalogue.
     *
     * Example: mrbp()->gateways()->get( 'bkash' );
     */
    public function gateways(): GatewayCatalog {
        if ( $this->container->has( 'payment_gateways' ) ) {
            /** @var GatewayCatalog $service */
            $service = $this->container->get( 'payment_gateways' );
            return $service;
        }

        $service = new GatewayCatalog();
        $this->container->set( 'payment_gateways', $service );
        return $service;
    }

    public function features(): FeatureGuard {
        /** @var FeatureGuard $service */
        $service = $this->container->get( 'feature_guard' );
        return $service;
    }

    public function licenses(): LocalLicenseService {
        /** @var LocalLicenseService $service */
        $service = $this->container->get( 'license_service' );
        return $service;
    }


    private function register_core_services(): void {
        $logger               = new Logger();
        $settings             = new Settings();
        $license_service      = new LocalLicenseService();
        $build_info           = new BuildInfo();
        if ( $build_info->requires_license() ) {
            $license_service->maybe_import_bundled_license();
        }
        $online_status        = new OnlineStatusService();
        $entitlement_provider = $this->resolve_entitlement_provider( $license_service, $online_status );
        $plan_manager        = new PlanManager( $entitlement_provider );
        $feature_guard      = new FeatureGuard( $plan_manager );
        $module_registry    = new ModuleRegistry();
        $dependency_manager = new DependencyManager();
        $migration_manager  = new MigrationManager( $logger );
        $security           = new Security( $logger );
        $module_manager     = new ModuleManager( $settings, $logger, $plan_manager, $module_registry, $dependency_manager, $security );
        $woocommerce        = new WooCommerceIntegration( $logger );
        $global_hooks       = new GlobalHooks();
        $upgrade_recovery   = new UpgradeRecovery();

        $this->container->set( 'logger', $logger );
        $this->container->set( 'settings', $settings );
        $this->container->set( 'license_service', $license_service );
        $this->container->set( 'online_status', $online_status );
        $this->container->set( 'entitlement_provider', $entitlement_provider );
        $this->container->set( 'plan_manager', $plan_manager );
        $this->container->set( 'feature_guard', $feature_guard );
        $this->container->set( 'build_info', $build_info );
        $this->container->set( 'module_registry', $module_registry );
        $this->container->set( 'dependency_manager', $dependency_manager );
        $this->container->set( 'migration_manager', $migration_manager );
        $this->container->set( 'security', $security );
        $this->container->set( 'module_manager', $module_manager );
        $this->container->set( 'woocommerce', $woocommerce );
        $this->container->set( 'global_hooks', $global_hooks );
        $this->container->set( 'upgrade_recovery', $upgrade_recovery );
        ( new FallbackNotice() )->register();
        ( new CoreAlignment() )->register();
        if ( $build_info->is_pro() ) {
            $update_client = new PluginUpdateClient( $online_status, $license_service );
            $this->container->set( 'update_client', $update_client );
            $update_client->register();
        }

        // The admin framework is sizeable and has no role on frontend requests.
        if ( is_admin() ) {
            $navigation     = new NavigationRegistry();
            $assets          = new AssetLoader();
            $active_menu     = new ActiveMenu( $navigation );
            $flyout_menu     = new FlyoutMenu( $navigation, $active_menu );
            $sidebar         = new Sidebar( $navigation, $active_menu, $flyout_menu );
            $breadcrumb      = new Breadcrumb();
            $header          = new Header( $breadcrumb );
            $page_renderer   = new PageRenderer( $sidebar, $header );
            $admin_framework = new AdminFramework( $navigation, $assets, $module_manager );
            $admin_menu      = new AdminMenu( $settings, $module_manager, $plan_manager, $page_renderer );
            ( new OperationsUi() )->register();

            $this->container->set( 'navigation_registry', $navigation );
            $this->container->set( 'assets', $assets );
            $this->container->set( 'active_menu', $active_menu );
            $this->container->set( 'flyout_menu', $flyout_menu );
            $this->container->set( 'sidebar', $sidebar );
            $this->container->set( 'breadcrumb', $breadcrumb );
            $this->container->set( 'header', $header );
            $this->container->set( 'page_renderer', $page_renderer );
            $this->container->set( 'admin_framework', $admin_framework );
            $this->container->set( 'admin_menu', $admin_menu );
        }

        // Database checks are intentionally kept away from normal frontend traffic.
        if ( is_admin() || RequestContext::is_cron() || RequestContext::is_cli() ) {
            $migration_manager->migrate_core();
        }
        $woocommerce->register_compatibility();

        do_action( 'mrbp/core/services_registered', $this->container );
    }


    private function resolve_entitlement_provider( LocalLicenseService $licenses, OnlineStatusService $online_status ): EntitlementProviderInterface {
        $build    = new BuildEntitlementProvider();
        $provider = new LicenseEntitlementProvider( $build, $licenses, $online_status );

        /**
         * Filters the entitlement provider used by MR Commerce.
         *
         * A future LicenseEntitlementProvider can replace the build provider
         * without changing ModuleManager or feature consumers.
         */
        $provider = apply_filters( 'mrbp/entitlement_provider', $provider, $this->container );

        if ( ! $provider instanceof EntitlementProviderInterface ) {
            $provider = new LicenseEntitlementProvider( $build, $licenses, $online_status );
        }

        return $provider;
    }

    public function upgrade_recovery(): UpgradeRecovery {
        /** @var UpgradeRecovery $service */
        $service = $this->container->get( 'upgrade_recovery' );
        return $service;
    }

    private function register_global_hooks(): void {
        $this->global_hooks()->register();
        if ( ( new BuildInfo() )->requires_license() ) {
            $this->licenses()->register_admin_notice();
        }
    }

    private function register_settings(): void {
        if ( is_admin() ) {
            $this->settings()->register();
        }
    }

    private function load_enabled_modules(): void {
        $this->module_manager()->register();
        $this->module_manager()->boot_enabled_modules();
    }

    private function initialize_woocommerce(): void {
        $this->woocommerce()->initialize();
    }

    private function register_admin(): void {
        if ( ! is_admin() ) {
            return;
        }

        $this->admin_framework()->register();
        $this->admin_menu()->register();
    }

    private function load_textdomain(): void {
        load_plugin_textdomain(
            'mr-commerce',
            false,
            dirname( MRBP_BASENAME ) . '/languages'
        );
    }

    private function logger(): Logger {
        /** @var Logger $service */
        $service = $this->container->get( 'logger' );
        return $service;
    }

    private function settings(): Settings {
        /** @var Settings $service */
        $service = $this->container->get( 'settings' );
        return $service;
    }


    private function plan_manager(): PlanManager {
        /** @var PlanManager $service */
        $service = $this->container->get( 'plan_manager' );
        return $service;
    }

    private function module_manager(): ModuleManager {
        /** @var ModuleManager $service */
        $service = $this->container->get( 'module_manager' );
        return $service;
    }

    private function woocommerce(): WooCommerceIntegration {
        /** @var WooCommerceIntegration $service */
        $service = $this->container->get( 'woocommerce' );
        return $service;
    }

    private function global_hooks(): GlobalHooks {
        /** @var GlobalHooks $service */
        $service = $this->container->get( 'global_hooks' );
        return $service;
    }

    private function assets(): AssetLoader {
        /** @var AssetLoader $service */
        $service = $this->container->get( 'assets' );
        return $service;
    }


    private function admin_framework(): AdminFramework {
        /** @var AdminFramework $service */
        $service = $this->container->get( 'admin_framework' );
        return $service;
    }

    private function admin_menu(): AdminMenu {
        /** @var AdminMenu $service */
        $service = $this->container->get( 'admin_menu' );
        return $service;
    }

    private function __clone() {}

    public function __wakeup(): void {
        throw new LogicException( 'Cannot unserialize a singleton.' );
    }
}
