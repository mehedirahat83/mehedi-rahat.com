<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Cheap request-context checks used to avoid booting large module layers on
 * unrelated requests. The checks intentionally rely on request metadata and
 * do not execute WooCommerce customer/order queries.
 */
final class RequestContext {

    public static function path(): string {
        $uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        $path = (string) wp_parse_url( $uri, PHP_URL_PATH );
        return '/' . ltrim( strtolower( $path ), '/' );
    }

    public static function action(): string {
        return isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : '';
    }

    public static function is_ajax(): bool {
        return function_exists( 'wp_doing_ajax' ) && wp_doing_ajax();
    }

    public static function is_cron(): bool {
        return function_exists( 'wp_doing_cron' ) && wp_doing_cron();
    }

    public static function is_rest(): bool {
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return true;
        }
        return str_starts_with( self::path(), '/wp-json/' )
            || isset( $_GET['rest_route'] );
    }

    public static function is_cli(): bool {
        return defined( 'WP_CLI' ) && WP_CLI;
    }

    public static function is_admin_screen(): bool {
        return is_admin() && ! self::is_ajax();
    }

    public static function is_portal_frontend(): bool {
        $path = self::path();

        return self::path_matches(
            $path,
            array(
                '/dashboard',
                '/checkout',
                '/order-pay',
                '/order-received',
            )
        );
    }

    public static function needs_customer_portal_legacy(): bool {
        $customer_ajax = self::is_ajax() && str_starts_with( self::action(), 'mrcp_' );
        $customer_rest = self::is_customer_portal_rest();

        $needs = self::is_customer_portal_admin_screen()
            || $customer_ajax
            || $customer_rest
            || self::is_cli()
            || self::is_portal_frontend();

        /**
         * Allows integrations with custom portal/account slugs to opt in.
         */
        return (bool) apply_filters( 'mrbp/customer_portal/needs_legacy', $needs, self::path() );
    }

    /**
     * Restrict the legacy bridge to this plugin's REST namespaces. Loading the
     * complete CRM for every WordPress/WooCommerce REST request adds avoidable
     * latency and memory pressure to unrelated API traffic.
     */
    private static function is_customer_portal_rest(): bool {
        if ( ! self::is_rest() ) {
            return false;
        }

        $path = self::path();
        $route = isset( $_GET['rest_route'] ) ? '/' . ltrim( strtolower( sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ) ), '/' ) : '';

        return str_starts_with( $path, '/wp-json/mrbp/' )
            || str_starts_with( $path, '/wp-json/mrcp/' )
            || str_starts_with( $path, '/wp-json/mr-business-pro/' )
            || str_starts_with( $route, '/mrbp/' )
            || str_starts_with( $route, '/mrcp/' )
            || str_starts_with( $route, '/mr-business-pro/' );
    }


    /**
     * Load the large legacy CRM layer only on screens that can actually use it.
     * This avoids parsing hundreds of kilobytes of legacy PHP on unrelated
     * wp-admin pages such as Posts, Media, Plugins and Settings.
     */
    public static function is_customer_portal_admin_screen(): bool {
        if ( ! self::is_admin_screen() ) {
            return false;
        }

        $page      = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        $post_type = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( $_GET['post_type'] ) ) : '';
        $post_id   = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
        $action    = self::action();
        $path      = self::path();

        if ( '' !== $page && ( str_starts_with( $page, 'mrbp' ) || str_starts_with( $page, 'mrcp' ) || 'wc-orders' === $page ) ) {
            return true;
        }

        if ( str_starts_with( $action, 'mrcp_' ) || str_starts_with( $action, 'mrbp_' ) ) {
            return true;
        }

        if ( in_array( $post_type, array( 'shop_order', 'shop_order_refund', 'product', 'product_variation' ), true ) ) {
            return true;
        }

        if ( $post_id > 0 ) {
            $edited_type = get_post_type( $post_id );
            if ( in_array( $edited_type, array( 'shop_order', 'shop_order_refund', 'product', 'product_variation' ), true ) ) {
                return true;
            }
        }

        return str_contains( $path, '/wp-admin/user-edit.php' )
            || str_contains( $path, '/wp-admin/profile.php' )
            || str_contains( $path, '/wp-admin/users.php' );
    }

    public static function is_payment_admin_screen(): bool {
        if ( ! self::is_admin_screen() ) {
            return false;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        return str_starts_with( $page, 'mrbp-payment' );
    }

    public static function is_payment_ajax(): bool {
        if ( ! self::is_ajax() ) {
            return false;
        }

        return in_array(
            self::action(),
            array(
                'mrbp_submit_manual_payment',
                'mrbp_payment_request_details',
                'mrbp_payment_decision',
            ),
            true
        );
    }

    public static function is_payment_frontend(): bool {
        $path = self::path();

        return self::path_matches(
            $path,
            array(
                '/checkout',
                '/cart',
                '/order-pay',
                '/order-received',
                '/my-account/payment-history',
            )
        ) || isset( $_GET['pay_for_order'] );
    }

    private static function path_matches( string $path, array $prefixes ): bool {
        foreach ( $prefixes as $prefix ) {
            if ( $path === $prefix || str_starts_with( $path, $prefix . '/' ) ) {
                return true;
            }
        }
        return false;
    }
}
