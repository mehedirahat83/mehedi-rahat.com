<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Deactivator {

    public static function deactivate(): void {
        wp_clear_scheduled_hook( 'mrbp_daily_event' );
        wp_clear_scheduled_hook( 'mrc_recover_abandoned_carts' );
        delete_transient( 'mrbp_activation_redirect' );

        do_action( 'mrbp/deactivated', MRBP_VERSION );
    }
}
