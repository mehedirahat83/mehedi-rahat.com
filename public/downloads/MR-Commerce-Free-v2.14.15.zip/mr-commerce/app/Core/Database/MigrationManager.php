<?php

namespace MRBP\Core\Database;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Support\Logger;
use Throwable;

final class MigrationManager {

    private Logger $logger;
    private array $registered = array();
    private bool $core_migrated = false;

    public function __construct( Logger $logger ) {
        $this->logger = $logger;
    }

    public function migrate_core(): void {
        if ( $this->core_migrated ) {
            return;
        }

        $this->core_migrated = true;

        $this->register(
            'core',
            MRBP_DB_VERSION,
            array(
                '1.0.0' => static function (): void {
                    // Initial core schema contains options only. Module tables are lazy-created.
                    if ( false === get_option( 'mrbp_db_versions', false ) ) {
                        add_option( 'mrbp_db_versions', array(), '', false );
                    }
                },
            )
        );

        $this->migrate( 'core' );
    }

    /**
     * @param array<string, callable> $migrations Version => callback.
     */
    public function register( string $component, string $target_version, array $migrations ): void {
        $component = sanitize_key( $component );

        if ( '' === $component ) {
            return;
        }

        uksort( $migrations, 'version_compare' );

        $this->registered[ $component ] = array(
            'target'     => $target_version,
            'migrations' => $migrations,
        );

        do_action( 'mrbp/database/migrations_registered', $component, $target_version, $migrations, $this );
    }

    public function migrate( string $component ): bool {
        $component = sanitize_key( $component );
        $config    = $this->registered[ $component ] ?? null;

        if ( ! is_array( $config ) ) {
            return false;
        }

        $installed = $this->installed_version( $component );
        $target    = (string) $config['target'];

        if ( version_compare( $installed, $target, '>=' ) ) {
            return true;
        }

        foreach ( $config['migrations'] as $version => $callback ) {
            if ( version_compare( (string) $version, $installed, '<=' ) || version_compare( (string) $version, $target, '>' ) ) {
                continue;
            }

            try {
                do_action( 'mrbp/database/before_migration', $component, $version, $installed, $this );
                call_user_func( $callback );
                $this->set_installed_version( $component, (string) $version );
                $installed = (string) $version;
                do_action( 'mrbp/database/after_migration', $component, $version, $this );

                $this->logger->database(
                    'Database migration completed.',
                    array( 'component' => $component, 'version' => $version )
                );
            } catch ( Throwable $error ) {
                $this->logger->error(
                    'Database migration failed.',
                    array(
                        'component' => $component,
                        'version'   => $version,
                        'message'   => $error->getMessage(),
                    )
                );

                do_action( 'mrbp/database/migration_failed', $component, $version, $error, $this );
                return false;
            }
        }

        if ( version_compare( $installed, $target, '<' ) ) {
            $this->logger->database(
                'Database target version was not reached because a migration callback is missing.',
                array( 'component' => $component, 'installed' => $installed, 'target' => $target )
            );
            return false;
        }

        return true;
    }

    public function installed_version( string $component ): string {
        $component = sanitize_key( $component );

        if ( 'core' === $component ) {
            return (string) get_option( 'mrbp_db_version', '0.0.0' );
        }

        $versions = get_option( 'mrbp_db_versions', array() );
        return is_array( $versions ) && isset( $versions[ $component ] )
            ? (string) $versions[ $component ]
            : '0.0.0';
    }

    private function set_installed_version( string $component, string $version ): void {
        if ( 'core' === $component ) {
            update_option( 'mrbp_db_version', $version, false );
            return;
        }

        $versions = get_option( 'mrbp_db_versions', array() );
        $versions = is_array( $versions ) ? $versions : array();
        $versions[ $component ] = $version;
        update_option( 'mrbp_db_versions', $versions, false );
    }
}
