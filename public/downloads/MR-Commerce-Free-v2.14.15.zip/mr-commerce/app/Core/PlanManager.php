<?php

namespace MRBP\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Contracts\EntitlementProviderInterface;

final class PlanManager implements EntitlementProviderInterface {

    public const PLAN_FREE = 'free';
    public const PLAN_PRO  = 'pro';

    public function __construct( private EntitlementProviderInterface $provider ) {}

    public function provider(): EntitlementProviderInterface {
        return $this->provider;
    }

    public function current_plan(): string {
        return $this->provider->current_plan();
    }

    public function is_free(): bool {
        return self::PLAN_FREE === $this->current_plan();
    }

    public function is_pro(): bool {
        return self::PLAN_PRO === $this->current_plan();
    }

    public function feature_allowed( string $feature ): bool {
        $allowed = $this->provider->allows( $feature );

        return (bool) apply_filters(
            'mrbp/feature_allowed',
            $allowed,
            $feature,
            $this->current_plan(),
            $this
        );
    }

    public function allows( string $feature ): bool {
        return $this->feature_allowed( $feature );
    }

    public function module_available( string $module_id ): bool {
        return $this->feature_allowed( $module_id );
    }

    public function level( string $feature ): string {
        return $this->feature_level( $feature );
    }

    public function limit( string $feature ): int {
        $limit = $this->provider->limit( $feature );

        return (int) apply_filters(
            'mrbp/feature_limit',
            $limit,
            $feature,
            $this->current_plan(),
            $this
        );
    }

    public function feature_level( string $feature ): string {
        $level = $this->provider->level( $feature );

        return (string) apply_filters(
            'mrbp/feature_level',
            $level,
            $feature,
            $this->current_plan(),
            $this
        );
    }

    public function features(): array {
        $features = array();

        foreach ( $this->known_features() as $feature ) {
            $features[ $feature ] = $this->feature_allowed( $feature );
        }

        return $features;
    }

    public function feature_levels(): array {
        $levels = array();

        foreach ( $this->known_features() as $feature ) {
            $levels[ $feature ] = $this->feature_level( $feature );
        }

        return $levels;
    }

    private function known_features(): array {
        $catalogue = require MRBP_PATH . 'config/feature-catalogue.php';

        return (array) apply_filters(
            'mrbp/known_features',
            array_keys( is_array( $catalogue ) ? $catalogue : array() )
        );
    }
}
