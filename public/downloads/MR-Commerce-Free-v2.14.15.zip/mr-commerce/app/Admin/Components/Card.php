<?php

namespace MRBP\Admin\Components;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Card extends Component {

    private string $title;
    private string $description;
    private string $content;
    private string $footer = '';
    private string $badge = '';

    private function __construct( string $title, string $content = '', string $description = '' ) {
        $this->title       = $title;
        $this->content     = $content;
        $this->description = $description;
    }

    public static function make( string $title, string $content = '', string $description = '' ): self {
        return new self( $title, $content, $description );
    }

    public function footer( string $footer ): self {
        $this->footer = $footer;
        return $this;
    }

    public function badge( string $badge ): self {
        $this->badge = $badge;
        return $this;
    }

    public function render(): void {
        ?>
        <article class="mrbp-ui-card">
            <header class="mrbp-ui-card__header">
                <div>
                    <h2 class="mrbp-ui-card__title"><?php echo esc_html( $this->title ); ?></h2>
                    <?php if ( '' !== $this->description ) : ?>
                        <p class="mrbp-ui-card__description"><?php echo esc_html( $this->description ); ?></p>
                    <?php endif; ?>
                </div>
                <?php if ( '' !== $this->badge ) : ?>
                    <span class="mrbp-ui-badge mrbp-ui-badge--info"><?php echo esc_html( $this->badge ); ?></span>
                <?php endif; ?>
            </header>
            <div class="mrbp-ui-card__content"><?php echo wp_kses_post( $this->content ); ?></div>
            <?php if ( '' !== $this->footer ) : ?>
                <footer class="mrbp-ui-card__footer"><?php echo wp_kses_post( $this->footer ); ?></footer>
            <?php endif; ?>
        </article>
        <?php
    }
}
