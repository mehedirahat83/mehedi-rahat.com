<?php

namespace MRBP\Admin\Components;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Component {

    abstract public function render(): void;

    public function to_html(): string {
        ob_start();
        $this->render();
        return (string) ob_get_clean();
    }
}
