<?php

namespace MRBP\Admin\Components;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Form extends Component {

    private string $action;
    private string $method;
    private string $content;
    private string $nonce_action = '';
    private string $nonce_name = '_wpnonce';

    private function __construct( string $content, string $action = '', string $method = 'post' ) {
        $this->content = $content;
        $this->action  = $action;
        $this->method  = 'get' === strtolower( $method ) ? 'get' : 'post';
    }

    public static function make( string $content, string $action = '', string $method = 'post' ): self {
        return new self( $content, $action, $method );
    }

    public function nonce( string $action, string $name = '_wpnonce' ): self {
        $this->nonce_action = $action;
        $this->nonce_name   = $name;
        return $this;
    }

    public function render(): void {
        ?>
        <form class="mrbp-ui-form" method="<?php echo esc_attr( $this->method ); ?>" action="<?php echo esc_url( $this->action ); ?>">
            <?php if ( '' !== $this->nonce_action ) : ?>
                <?php wp_nonce_field( $this->nonce_action, $this->nonce_name ); ?>
            <?php endif; ?>
            <?php echo wp_kses( $this->content, self::allowed_html() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </form>
        <?php
    }

    /** @return array<string,array<string,bool>> */
    private static function allowed_html(): array {
        return array(
            'div'    => array( 'class' => true ),
            'p'      => array( 'class' => true ),
            'label'  => array( 'for' => true, 'class' => true ),
            'input'  => array( 'class' => true, 'type' => true, 'id' => true, 'name' => true, 'value' => true, 'placeholder' => true, 'checked' => true, 'disabled' => true, 'min' => true, 'max' => true, 'step' => true ),
            'select' => array( 'class' => true, 'id' => true, 'name' => true, 'disabled' => true ),
            'option' => array( 'value' => true, 'selected' => true ),
            'button' => array( 'class' => true, 'type' => true, 'name' => true, 'value' => true, 'data-*' => true ),
            'a'      => array( 'class' => true, 'href' => true, 'target' => true, 'rel' => true ),
            'span'   => array( 'class' => true, 'aria-hidden' => true ),
            'strong' => array(),
            'small'  => array( 'class' => true ),
        );
    }

    public static function field( string $label, string $name, string $value = '', string $type = 'text', string $description = '' ): string {
        $allowed = array( 'text', 'email', 'url', 'number', 'password', 'search' );
        $type    = in_array( $type, $allowed, true ) ? $type : 'text';
        $id      = 'mrbp-field-' . sanitize_html_class( $name );

        ob_start();
        ?>
        <div class="mrbp-ui-field">
            <label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
            <input class="mrbp-ui-input" type="<?php echo esc_attr( $type ); ?>" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo 'password' === $type ? '' : esc_attr( $value ); ?>">
            <?php if ( '' !== $description ) : ?><p class="mrbp-ui-field__description"><?php echo esc_html( $description ); ?></p><?php endif; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /** @param array<string,string> $options */
    public static function select( string $label, string $name, array $options, string $selected = '' ): string {
        $id = 'mrbp-field-' . sanitize_html_class( $name );
        ob_start();
        ?>
        <div class="mrbp-ui-field">
            <label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
            <select class="mrbp-ui-select" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>">
                <?php foreach ( $options as $value => $option_label ) : ?>
                    <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected, $value ); ?>><?php echo esc_html( $option_label ); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php
        return (string) ob_get_clean();
    }
}
