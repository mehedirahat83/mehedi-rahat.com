<?php

namespace MRBP\Admin\Components;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Table extends Component {

    /** @var array<string,string> */
    private array $columns;

    /** @var array<int,array<string,mixed>> */
    private array $rows;

    private string $empty_message;

    /**
     * @param array<string,string> $columns
     * @param array<int,array<string,mixed>> $rows
     */
    private function __construct( array $columns, array $rows, string $empty_message ) {
        $this->columns       = $columns;
        $this->rows          = $rows;
        $this->empty_message = $empty_message;
    }

    /**
     * @param array<string,string> $columns
     * @param array<int,array<string,mixed>> $rows
     */
    public static function make( array $columns, array $rows = array(), string $empty_message = '' ): self {
        return new self( $columns, $rows, '' !== $empty_message ? $empty_message : __( 'No records found.', 'mr-commerce' ) );
    }

    public function render(): void {
        ?>
        <div class="mrbp-ui-table-wrap">
            <table class="mrbp-ui-table">
                <thead><tr>
                    <?php foreach ( $this->columns as $label ) : ?>
                        <th scope="col"><?php echo esc_html( $label ); ?></th>
                    <?php endforeach; ?>
                </tr></thead>
                <tbody>
                    <?php if ( array() === $this->rows ) : ?>
                        <tr><td colspan="<?php echo esc_attr( (string) max( 1, count( $this->columns ) ) ); ?>" class="mrbp-ui-table__empty"><?php echo esc_html( $this->empty_message ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $this->rows as $row ) : ?>
                            <tr>
                                <?php foreach ( array_keys( $this->columns ) as $key ) : ?>
                                    <td><?php echo wp_kses( (string) ( $row[ $key ] ?? '' ), $this->allowed_cell_html() ); ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    /**
     * Allow the small set of interactive attributes used by MRBP admin tables.
     *
     * wp_kses_post() strips custom data-* attributes from action buttons. That
     * removed the payment request identifiers before the verification JavaScript
     * could read them, causing the drawer AJAX lookup to receive empty values.
     *
     * @return array<string,array<string,bool>>
     */
    private function allowed_cell_html(): array {
        $allowed = wp_kses_allowed_html( 'post' );

        if ( ! isset( $allowed['button'] ) || ! is_array( $allowed['button'] ) ) {
            $allowed['button'] = array();
        }

        $allowed['button'] = array_merge(
            $allowed['button'],
            array(
                'type'                => true,
                'id'                  => true,
                'name'                => true,
                'value'               => true,
                'class'               => true,
                'disabled'            => true,
                'aria-label'          => true,
                'aria-expanded'       => true,
                'data-request-id'     => true,
                'data-order-id'       => true,
                'data-transaction-id' => true,
                'data-request-token'  => true,
                'data-decision'       => true,
            )
        );

        return $allowed;
    }

}
