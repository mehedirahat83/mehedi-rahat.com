<?php

namespace MRBP\Admin\Components;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Button extends Component {

    private string $label;
    private string $url;
    private string $variant;
    private string $type;
    private array $attributes;

    private function __construct( string $label, string $variant = 'primary', string $url = '', string $type = 'button', array $attributes = array() ) {
        $this->label      = $label;
        $this->variant    = sanitize_key( $variant );
        $this->url        = $url;
        $this->type       = in_array( $type, array( 'button', 'submit', 'reset' ), true ) ? $type : 'button';
        $this->attributes = $attributes;
    }

    public static function make( string $label, string $variant = 'primary', string $url = '' ): self {
        return new self( $label, $variant, $url );
    }

    public static function primary( string $label, string $url = '' ): self {
        return new self( $label, 'primary', $url );
    }

    public static function secondary( string $label, string $url = '' ): self {
        return new self( $label, 'secondary', $url );
    }

    public static function danger( string $label, string $url = '' ): self {
        return new self( $label, 'danger', $url );
    }

    public static function success( string $label, string $url = '' ): self {
        return new self( $label, 'success', $url );
    }

    public function type( string $type ): self {
        $this->type = in_array( $type, array( 'button', 'submit', 'reset' ), true ) ? $type : 'button';
        return $this;
    }

    public function attributes( array $attributes ): self {
        $this->attributes = $attributes;
        return $this;
    }

    public function render(): void {
        $classes = 'mrbp-ui-button mrbp-ui-button--' . $this->variant;
        $attrs   = $this->render_attributes();

        if ( '' !== $this->url ) {
            printf(
                '<a class="%1$s" href="%2$s"%3$s>%4$s</a>',
                esc_attr( $classes ),
                esc_url( $this->url ),
                $attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes are escaped in render_attributes().
                esc_html( $this->label )
            );
            return;
        }

        printf(
            '<button class="%1$s" type="%2$s"%3$s>%4$s</button>',
            esc_attr( $classes ),
            esc_attr( $this->type ),
            $attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes are escaped in render_attributes().
            esc_html( $this->label )
        );
    }

    private function render_attributes(): string {
        $html = '';
        foreach ( $this->attributes as $name => $value ) {
            $name = sanitize_key( (string) $name );
            if ( '' === $name || in_array( $name, array( 'class', 'href', 'type' ), true ) ) {
                continue;
            }
            if ( true === $value ) {
                $html .= ' ' . esc_attr( $name );
                continue;
            }
            if ( false === $value || null === $value ) {
                continue;
            }
            $html .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( (string) $value ) );
        }
        return $html;
    }
}
