<?php

namespace MRBP\Admin\Components;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Tabs extends Component {

    /** @var array<string,array{label:string,content:string}> */
    private array $tabs;
    private string $active;
    private string $id;

    /**
     * @param array<string,array{label:string,content:string}> $tabs
     */
    private function __construct( array $tabs, string $active, string $id ) {
        $this->tabs   = $tabs;
        $this->active = isset( $tabs[ $active ] ) ? $active : (string) array_key_first( $tabs );
        $this->id     = sanitize_html_class( $id );
    }

    /**
     * @param array<string,array{label:string,content:string}> $tabs
     */
    public static function make( array $tabs, string $active = '', string $id = 'mrbp-tabs' ): self {
        return new self( $tabs, $active, $id );
    }

    /** @return array<string,array<string,bool>> */
    private static function allowed_html(): array {
        return array(
            'div' => array(
                'class' => true,
                'data-mrbp-tabs' => true,
                'data-mrbp-gateway-toolbar' => true,
                'data-mrbp-gateway-sortable' => true,
                'data-mrbp-media-field' => true,
                'data-media-kind' => true,
            ),
            'section' => array(
                'class' => true,
                'role' => true,
                'id' => true,
                'aria-labelledby' => true,
                'data-tab-panel' => true,
                'hidden' => true,
                'draggable' => true,
                'data-gateway-id' => true,
                'data-gateway-type' => true,
                'data-gateway-status' => true,
                'data-gateway-name' => true,
            ),
            'article' => array( 'class' => true ), 'header' => array( 'class' => true ), 'footer' => array( 'class' => true ),
            'img' => array( 'class' => true, 'src' => true, 'alt' => true, 'width' => true, 'height' => true, 'loading' => true, 'decoding' => true ),
            'details' => array( 'class' => true, 'open' => true ), 'summary' => array( 'class' => true ),
            'h2' => array( 'class' => true ), 'h3' => array( 'class' => true ),
            'table' => array( 'class' => true ), 'thead' => array(), 'tbody' => array(), 'tr' => array(),
            'th' => array( 'scope' => true, 'colspan' => true, 'class' => true ), 'td' => array( 'colspan' => true, 'class' => true ),
            'form' => array( 'class' => true, 'method' => true, 'action' => true, 'id' => true ),
            'label' => array( 'for' => true, 'class' => true ),
            'input' => array(
                'class' => true, 'type' => true, 'id' => true, 'name' => true, 'value' => true,
                'placeholder' => true, 'checked' => true, 'disabled' => true, 'required' => true,
                'inputmode' => true, 'min' => true, 'max' => true, 'step' => true,
                'data-mrbp-gateway-search' => true,
                'data-mrbp-media-id' => true,
                'data-mrbp-media-url' => true,
            ),
            'select' => array( 'class' => true, 'id' => true, 'name' => true ), 'option' => array( 'value' => true, 'selected' => true ),
            'textarea' => array( 'class' => true, 'id' => true, 'name' => true, 'rows' => true, 'cols' => true, 'placeholder' => true ),
            'button' => array(
                'class' => true, 'type' => true, 'name' => true, 'value' => true, 'form' => true,
                'aria-label' => true, 'aria-expanded' => true,
                'data-mrbp-gateway-filter' => true,
                'data-mrbp-edit-gateway' => true,
                'data-mrbp-media-choose' => true,
                'data-mrbp-media-remove' => true,
                'data-media-title' => true,
            ),
            'a' => array( 'class' => true, 'href' => true, 'target' => true, 'rel' => true ),
            'p' => array( 'class' => true ), 'small' => array( 'class' => true ), 'span' => array( 'class' => true, 'aria-hidden' => true, 'data-mrbp-edit-label' => true ), 'strong' => array(), 'code' => array( 'class' => true ),
        );
    }

    public function render(): void {
        if ( array() === $this->tabs ) {
            return;
        }
        ?>
        <div class="mrbp-ui-tabs" data-mrbp-tabs id="<?php echo esc_attr( $this->id ); ?>">
            <div class="mrbp-ui-tabs__list" role="tablist">
                <?php foreach ( $this->tabs as $key => $tab ) :
                    $tab_id   = $this->id . '-tab-' . sanitize_html_class( $key );
                    $panel_id = $this->id . '-panel-' . sanitize_html_class( $key );
                    $active   = $key === $this->active;
                    ?>
                    <button type="button" class="mrbp-ui-tabs__tab<?php echo $active ? ' is-active' : ''; ?>" role="tab" id="<?php echo esc_attr( $tab_id ); ?>" aria-controls="<?php echo esc_attr( $panel_id ); ?>" aria-selected="<?php echo $active ? 'true' : 'false'; ?>" data-tab-target="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $tab['label'] ); ?></button>
                <?php endforeach; ?>
            </div>
            <?php foreach ( $this->tabs as $key => $tab ) :
                $tab_id   = $this->id . '-tab-' . sanitize_html_class( $key );
                $panel_id = $this->id . '-panel-' . sanitize_html_class( $key );
                $active   = $key === $this->active;
                ?>
                <section class="mrbp-ui-tabs__panel<?php echo $active ? ' is-active' : ''; ?>" role="tabpanel" id="<?php echo esc_attr( $panel_id ); ?>" aria-labelledby="<?php echo esc_attr( $tab_id ); ?>" data-tab-panel="<?php echo esc_attr( $key ); ?>" <?php echo $active ? '' : 'hidden'; ?>><?php echo wp_kses( $tab['content'], self::allowed_html() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></section>
            <?php endforeach; ?>
        </div>
        <?php
    }
}
