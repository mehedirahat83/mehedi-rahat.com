<?php

namespace MRBP\Admin\Framework;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Assets\AssetLoader;
use MRBP\Admin\Navigation\NavigationRegistry;
use MRBP\Modules\ModuleManager;

final class AdminFramework {

    private NavigationRegistry $navigation;
    private AssetLoader $assets;
    private ModuleManager $modules;

    public function __construct( NavigationRegistry $navigation, AssetLoader $assets, ModuleManager $modules ) {
        $this->navigation = $navigation;
        $this->assets     = $assets;
        $this->modules    = $modules;
    }

    public function register(): void {
        $this->register_core_navigation();
        $this->register_module_navigation();
        $this->assets->register();

        do_action( 'mrbp/admin/framework_registered', $this, $this->navigation );
    }

    private function register_core_navigation(): void {
        $this->navigation->register( 'dashboard', array( 'label' => __( 'Dashboard', 'mr-commerce' ), 'slug' => 'mrbp-dashboard', 'icon' => 'dashicons-dashboard', 'position' => 10 ) );
        $this->navigation->register( 'modules', array( 'label' => __( 'Modules', 'mr-commerce' ), 'slug' => 'mrbp-modules', 'icon' => 'dashicons-screenoptions', 'position' => 20 ) );
        $this->navigation->register( 'settings', array( 'label' => __( 'Settings', 'mr-commerce' ), 'slug' => 'mrbp-settings', 'icon' => 'dashicons-admin-settings', 'position' => 900 ) );
        $this->navigation->register( 'license', array( 'label' => __( 'License', 'mr-commerce' ), 'slug' => 'mrbp-license', 'icon' => 'dashicons-lock', 'position' => 910 ) );
    }

    private function register_module_navigation(): void {
        $definitions = array(
            'customer_portal' => array( 'label' => __( 'MR Customer Dashboard', 'mr-commerce' ), 'slug' => 'mrbp-customer-portal', 'icon' => 'dashicons-groups', 'position' => 10 ),
            'physical_commerce' => array( 'label' => __( 'MR Commerce', 'mr-commerce' ), 'slug' => 'mrc-physical-commerce', 'icon' => 'dashicons-store', 'position' => 20 ),
            'growth_suite' => array( 'label' => __( 'MR Growth Suite', 'mr-commerce' ), 'slug' => 'mrc-growth-suite', 'icon' => 'dashicons-chart-line', 'position' => 30 ),
            'fraud_checker' => array( 'label' => __( 'MR Fraud Checker', 'mr-commerce' ), 'slug' => 'mrc-fraud-checker', 'icon' => 'dashicons-shield-alt', 'position' => 40 ),
            'sequential_orders' => array( 'label' => __( 'MR Sequential Orders', 'mr-commerce' ), 'slug' => 'mrbp-sequential-orders', 'icon' => 'dashicons-editor-ol', 'position' => 50 ),
            'payment_pro'     => array( 'label' => __( 'MR Payment Center', 'mr-commerce' ), 'slug' => 'mrbp-payment-center', 'icon' => 'dashicons-money-alt', 'position' => 60 ),
        );

        foreach ( $definitions as $module_id => $definition ) {
            /*
             * Navigation represents the administrator's saved module selection.
             * Runtime entitlement/dependency checks still control whether module
             * services boot, but must not silently remove enabled module links.
             */
            if ( ! $this->modules->is_enabled( $module_id ) || ! $this->modules->is_included( $module_id ) ) {
                continue;
            }
            $definition['parent'] = 'modules';
            $this->navigation->register( $module_id, $definition );

            if ( 'customer_portal' === $module_id ) {
                $this->register_customer_portal_navigation();
            } elseif ( 'growth_suite' === $module_id ) {
                $this->register_growth_navigation();
            } elseif ( 'physical_commerce' === $module_id ) {
                $this->register_physical_commerce_navigation();
            } elseif ( 'payment_pro' === $module_id ) {
                $this->register_payment_pro_navigation();
            }
        }
    }

    private function register_growth_navigation(): void {
        $items = array(
            'growth_settings' => array( 'label' => __( 'Growth Campaigns', 'mr-commerce' ), 'slug' => 'mrc-growth-suite', 'position' => 10 ),
            'growth_automation' => array( 'label' => __( 'Growth Automation', 'mr-commerce' ), 'slug' => 'mrc-retention', 'position' => 20 ),
        );
        foreach ( $items as $id => $item ) {
            $item['parent'] = 'growth_suite';
            $this->navigation->register( $id, $item );
        }
    }

    private function register_physical_commerce_navigation(): void {
        $items = array(
            'physical_settings' => array( 'label' => __( 'MR Commerce', 'mr-commerce' ), 'slug' => 'mrc-physical-commerce', 'position' => 10 ),
            'physical_shipping' => array( 'label' => __( 'Shipping Operations', 'mr-commerce' ), 'slug' => 'mrc-shipping-operations', 'position' => 20 ),
            'physical_stock' => array( 'label' => __( 'Stock Dashboard', 'mr-commerce' ), 'slug' => 'mrc-stock-dashboard', 'position' => 30 ),
            'physical_courier' => array( 'label' => __( 'Courier Integration', 'mr-commerce' ), 'slug' => 'mrc-courier-integration', 'position' => 40 ),
        );
        foreach ( $items as $id => $item ) {
            $item['parent'] = 'physical_commerce';
            $this->navigation->register( $id, $item );
        }
    }

    private function register_customer_portal_navigation(): void {
        $items = array(
            'cp_crm'        => array( 'label' => __( 'CRM Dashboard', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/' ), 'position' => 10 ),
            'cp_dashboard'  => array( 'label' => __( 'Customer Dashboard', 'mr-commerce' ), 'url' => home_url( '/dashboard/' ), 'position' => 20 ),
            'cp_products'   => array( 'label' => __( 'Products', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/products/' ), 'position' => 30 ),
            'cp_orders'     => array( 'label' => __( 'Orders', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/orders/' ), 'position' => 40 ),
            'cp_customers'  => array( 'label' => __( 'Customers', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/customers/' ), 'position' => 50 ),
            'cp_membership' => array( 'label' => __( 'Membership', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/membership/' ), 'position' => 60 ),
            'cp_reports'    => array( 'label' => __( 'Reports', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/reports/' ), 'position' => 70 ),
            'cp_activation' => array( 'label' => __( 'Activation Requests', 'mr-commerce' ), 'url' => home_url( '/dashboard/activation/' ), 'position' => 80 ),
            'cp_tickets'    => array( 'label' => __( 'Support Tickets', 'mr-commerce' ), 'url' => home_url( '/dashboard/support/' ), 'position' => 90 ),
        );

        foreach ( $items as $id => $item ) {
            $item['slug']   = $item['url'];
            $item['parent'] = 'customer_portal';
            $this->navigation->register( $id, $item );
        }
    }
    private function register_payment_pro_navigation(): void {
        $items = array(
            'payment_dashboard'    => array( 'label' => __( 'Dashboard', 'mr-commerce' ), 'slug' => 'mrbp-payment-center', 'position' => 10 ),
            'payment_requests'     => array( 'label' => __( 'Payment Requests', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-requests', 'position' => 20 ),
            'payment_transactions' => array( 'label' => __( 'Transactions', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-transactions', 'position' => 30 ),
            'payment_gateways'     => array( 'label' => __( 'Gateways', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-gateways', 'position' => 40 ),
            'payment_reports'      => array( 'label' => __( 'Reports', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-reports', 'position' => 50 ),
            'payment_settings'     => array( 'label' => __( 'Settings', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-settings', 'position' => 60 ),
            'payment_logs'         => array( 'label' => __( 'Logs', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-logs', 'position' => 70 ),
        );

        foreach ( $items as $id => $item ) {
            $item['parent'] = 'payment_pro';
            $this->navigation->register( $id, $item );
        }
    }

}
