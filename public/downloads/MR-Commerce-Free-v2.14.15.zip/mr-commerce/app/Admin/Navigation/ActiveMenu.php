<?php

namespace MRBP\Admin\Navigation;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ActiveMenu {

    private NavigationRegistry $navigation;

    public function __construct( NavigationRegistry $navigation ) {
        $this->navigation = $navigation;
    }

    public function current_page(): string {
        return isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'mrbp-dashboard';
    }

    public function item_is_active( string $id ): bool {
        $item = $this->navigation->get( $id );
        if ( null === $item ) {
            return false;
        }

        if ( $this->current_page() === (string) ( $item['slug'] ?? '' ) ) {
            return true;
        }

        foreach ( $this->navigation->children_of( $id ) as $child ) {
            if ( $this->current_page() === (string) ( $child['slug'] ?? '' )
                || $this->item_is_active( (string) ( $child['id'] ?? '' ) ) ) {
                return true;
            }
        }

        return false;
    }

    /** @return array<string,mixed>|null */
    public function current_item(): ?array {
        foreach ( $this->navigation->all() as $item ) {
            if ( $this->current_page() === (string) ( $item['slug'] ?? '' ) ) {
                return $item;
            }
        }

        return null;
    }
}
