<?php

namespace MRBP\Admin\Navigation;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class NavigationRegistry {

    /** @var array<string,array<string,mixed>> */
    private array $items = array();

    /**
     * Register or replace a navigation item.
     *
     * @param array<string,mixed> $item Navigation definition.
     */
    public function register( string $id, array $item ): void {
        $id = sanitize_key( $id );

        if ( '' === $id ) {
            return;
        }

        $defaults = array(
            'label'      => $id,
            'slug'       => '',
            'url'        => '',
            'icon'       => 'dashicons-admin-generic',
            'capability' => 'manage_options',
            'parent'     => '',
            'position'   => 10,
            'visible'    => true,
            'children'   => array(),
        );

        $definition = wp_parse_args( $item, $defaults );
        $definition['id']         = $id;
        $definition['label']      = sanitize_text_field( (string) $definition['label'] );
        $definition['slug']       = sanitize_key( (string) $definition['slug'] );
        $definition['icon']       = sanitize_html_class( (string) $definition['icon'] );
        $definition['capability'] = sanitize_key( (string) $definition['capability'] );
        $definition['parent']     = sanitize_key( (string) $definition['parent'] );
        $definition['position']   = (int) $definition['position'];
        $definition['visible']    = (bool) $definition['visible'];
        $definition['url']        = '' !== (string) $definition['url'] ? esc_url_raw( (string) $definition['url'] ) : '';

        $this->items[ $id ] = $definition;
    }

    public function remove( string $id ): void {
        unset( $this->items[ sanitize_key( $id ) ] );
    }

    /**
     * @return array<string,array<string,mixed>>
     */
    public function all(): array {
        $items = apply_filters( 'mrbp/admin/navigation_items', $this->items, $this );

        if ( ! is_array( $items ) ) {
            return array();
        }

        uasort(
            $items,
            static fn ( array $left, array $right ): int => (int) ( $left['position'] ?? 10 ) <=> (int) ( $right['position'] ?? 10 )
        );

        return $items;
    }

    /**
     * @return array<string,array<string,mixed>>
     */
    public function root_items(): array {
        return array_filter(
            $this->all(),
            static fn ( array $item ): bool => '' === (string) ( $item['parent'] ?? '' ) && ! empty( $item['visible'] )
        );
    }

    /**
     * @return array<string,array<string,mixed>>
     */
    public function children_of( string $parent ): array {
        $parent = sanitize_key( $parent );

        return array_filter(
            $this->all(),
            static fn ( array $item ): bool => $parent === (string) ( $item['parent'] ?? '' ) && ! empty( $item['visible'] )
        );
    }

    /**
     * @return array<string,mixed>|null
     */
    public function get( string $id ): ?array {
        $items = $this->all();
        $id    = sanitize_key( $id );

        return isset( $items[ $id ] ) && is_array( $items[ $id ] ) ? $items[ $id ] : null;
    }
}
