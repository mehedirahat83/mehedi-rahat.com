<?php

namespace MRBP\Admin\Navigation;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class FlyoutMenu {

    private NavigationRegistry $navigation;
    private ActiveMenu $active;

    public function __construct( NavigationRegistry $navigation, ActiveMenu $active ) {
        $this->navigation = $navigation;
        $this->active     = $active;
    }

    public function render_children( string $parent_id ): void {
        $children = $this->navigation->children_of( $parent_id );
        if ( empty( $children ) ) {
            return;
        }
        ?>
        <div class="mrbp-flyout" role="menu" aria-label="<?php esc_attr_e( 'Submenu', 'mr-commerce' ); ?>">
            <?php foreach ( $children as $child ) :
                if ( ! current_user_can( (string) $child['capability'] ) ) { continue; }
                $active = $this->active->item_is_active( (string) $child['id'] );
                ?>
                <a class="mrbp-flyout__item<?php echo $active ? ' is-active' : ''; ?>" role="menuitem" href="<?php echo esc_url( $this->item_url( $child ) ); ?>">
                    <span class="dashicons <?php echo esc_attr( (string) $child['icon'] ); ?>" aria-hidden="true"></span>
                    <span><?php echo esc_html( (string) $child['label'] ); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
        <?php
    }

    /** @param array<string,mixed> $item */
    private function item_url( array $item ): string {
        return ! empty( $item['url'] ) ? (string) $item['url'] : admin_url( 'admin.php?page=' . sanitize_key( (string) $item['slug'] ) );
    }
}
