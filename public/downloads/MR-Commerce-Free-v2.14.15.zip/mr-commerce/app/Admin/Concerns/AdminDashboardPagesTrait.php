<?php

namespace MRBP\Admin\Concerns;

use MRBP\Admin\Components\Button;
use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Form;
use MRBP\Admin\Components\Table;
use MRBP\Admin\Components\Tabs;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait AdminDashboardPagesTrait {
    public function render_dashboard(): void {
        $active_modules = array_filter(
            $this->module_manager->all(),
            static fn( array $module ): bool => ! empty( $module['will_load'] )
        );
        $plan = strtoupper( $this->plan_manager->current_plan() );

        $this->page_renderer->render(
            mrbp_product_name(),
            __( 'Manage your customers, payments and business tools from one connected workspace.', 'mr-commerce' ),
            function () use ( $active_modules, $plan ): void {
                $quick_actions = array(
                    array( 'label' => __( 'Manage Modules', 'mr-commerce' ), 'description' => __( 'Enable only the tools your business needs.', 'mr-commerce' ), 'icon' => 'dashicons-screenoptions', 'url' => admin_url( 'admin.php?page=mrbp-modules' ), 'tone' => 'teal' ),
                    array( 'label' => __( 'Plugin Settings', 'mr-commerce' ), 'description' => __( 'Control shared settings and module behaviour.', 'mr-commerce' ), 'icon' => 'dashicons-admin-settings', 'url' => admin_url( 'admin.php?page=mrbp-settings' ), 'tone' => 'blue' ),
                    array( 'label' => __( 'MR Customer Dashboard', 'mr-commerce' ), 'description' => __( 'Open the customer CRM and portal workspace.', 'mr-commerce' ), 'icon' => 'dashicons-groups', 'url' => home_url( '/dashboard/crm/' ), 'tone' => 'violet' ),
                    array( 'label' => __( 'MR Payment Center', 'mr-commerce' ), 'description' => __( 'Review manual payment requests and gateways.', 'mr-commerce' ), 'icon' => 'dashicons-money-alt', 'url' => admin_url( 'admin.php?page=mrbp-payment-center' ), 'tone' => 'amber' ),
                );
                ?>
                <section class="mrbp-dashboard-hero">
                    <div class="mrbp-dashboard-hero__content">
                        <span class="mrbp-dashboard-hero__eyebrow"><span class="dashicons dashicons-superhero-alt" aria-hidden="true"></span><?php esc_html_e( 'BUSINESS CONTROL CENTER', 'mr-commerce' ); ?></span>
                        <h2><?php esc_html_e( 'Build a smarter woocommerce business.', 'mr-commerce' ); ?></h2>
                        <p><?php esc_html_e( 'Customers, authentication and local payments—managed through one consistent dashboard.', 'mr-commerce' ); ?></p>
                        <div class="mrbp-dashboard-hero__actions">
                            <a class="mrbp-ui-button mrbp-ui-button--light" href="<?php echo esc_url( admin_url( 'admin.php?page=mrbp-modules' ) ); ?>"><span class="dashicons dashicons-screenoptions" aria-hidden="true"></span><?php esc_html_e( 'Manage Modules', 'mr-commerce' ); ?></a>
                            <a class="mrbp-ui-button mrbp-ui-button--glass" href="<?php echo esc_url( admin_url( 'admin.php?page=mrbp-settings' ) ); ?>"><span class="dashicons dashicons-admin-settings" aria-hidden="true"></span><?php esc_html_e( 'Open Settings', 'mr-commerce' ); ?></a>
                        </div>
                    </div>
                    <div class="mrbp-dashboard-hero__meta">
                        <div><span><?php esc_html_e( 'Version', 'mr-commerce' ); ?></span><strong><?php echo esc_html( MRBP_VERSION ); ?></strong></div>
                        <div><span><?php esc_html_e( 'Plan', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $plan ); ?></strong></div>
                        <div><span><?php esc_html_e( 'Active Modules', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) count( $active_modules ) ); ?></strong></div>
                    </div>
                </section>

                <div class="mrbp-dashboard-section-heading">
                    <div><span><?php esc_html_e( 'QUICK ACCESS', 'mr-commerce' ); ?></span><h2><?php esc_html_e( 'Run your business faster', 'mr-commerce' ); ?></h2></div>
                    <p><?php esc_html_e( 'Jump directly into your most-used workspaces.', 'mr-commerce' ); ?></p>
                </div>
                <div class="mrbp-dashboard-actions-grid">
                    <?php foreach ( $quick_actions as $action ) : ?>
                        <a class="mrbp-dashboard-action mrbp-dashboard-action--<?php echo esc_attr( $action['tone'] ); ?>" href="<?php echo esc_url( $action['url'] ); ?>">
                            <span class="mrbp-dashboard-action__icon dashicons <?php echo esc_attr( $action['icon'] ); ?>" aria-hidden="true"></span>
                            <span><strong><?php echo esc_html( $action['label'] ); ?></strong><small><?php echo esc_html( $action['description'] ); ?></small></span>
                            <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
                        </a>
                    <?php endforeach; ?>
                </div>

                <div class="mrbp-dashboard-section-heading">
                    <div><span><?php esc_html_e( 'SYSTEM STATUS', 'mr-commerce' ); ?></span><h2><?php echo esc_html( sprintf( __( 'Your %s setup', 'mr-commerce' ), mrbp_product_name() ) ); ?></h2></div>
                    <p><?php esc_html_e( 'A quick overview of the current installation.', 'mr-commerce' ); ?></p>
                </div>
                <div class="mrbp-dashboard-status-grid">
                    <article class="mrbp-dashboard-status-card is-teal"><span class="dashicons dashicons-update-alt" aria-hidden="true"></span><div><small><?php esc_html_e( 'Plugin Version', 'mr-commerce' ); ?></small><strong><?php echo esc_html( MRBP_VERSION ); ?></strong><em><?php esc_html_e( 'Current release', 'mr-commerce' ); ?></em></div></article>
                    <article class="mrbp-dashboard-status-card is-violet"><span class="dashicons dashicons-admin-plugins" aria-hidden="true"></span><div><small><?php esc_html_e( 'Enabled Modules', 'mr-commerce' ); ?></small><strong><?php echo esc_html( (string) count( $active_modules ) ); ?></strong><em><?php esc_html_e( 'Currently active', 'mr-commerce' ); ?></em></div></article>
                    <article class="mrbp-dashboard-status-card is-amber"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><div><small><?php esc_html_e( 'Design System', 'mr-commerce' ); ?></small><strong><?php esc_html_e( 'Unified', 'mr-commerce' ); ?></strong><em><?php esc_html_e( 'MR UI Kit 2.0', 'mr-commerce' ); ?></em></div></article>
                </div>
                <?php
            },
            array( mrbp_product_name(), __( 'Dashboard', 'mr-commerce' ) )
        );
    }

    public function render_modules(): void {
        $modules = $this->module_manager->all();
        $active  = 0;

        foreach ( $modules as $module ) {
            if ( ! empty( $module['enabled'] ) && ! empty( $module['available'] ) ) {
                ++$active;
            }
        }

        $this->page_renderer->render(
            __( 'MR Commerce Pro Modules', 'mr-commerce' ),
            __( 'Enable only the business tools your website needs. Dependencies and plan access are checked before a module can load.', 'mr-commerce' ),
            function () use ( $modules, $active ): void {
                settings_errors( 'mrbp_messages' );
                ?>
                <div class="mrbp-module-summary" aria-label="<?php esc_attr_e( 'Module summary', 'mr-commerce' ); ?>">
                    <div class="mrbp-module-summary__item"><span><?php esc_html_e( 'Build', 'mr-commerce' ); ?></span><strong><?php echo esc_html( strtoupper( $this->plan_manager->current_plan() ) ); ?></strong></div>
                    <div class="mrbp-module-summary__item"><span><?php esc_html_e( 'Available Modules', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) count( $modules ) ); ?></strong></div>
                    <div class="mrbp-module-summary__item"><span><?php esc_html_e( 'Active Modules', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) $active ); ?></strong></div>
                </div>
                <?php $this->render_module_form(); ?>
                <?php
            },
            array( mrbp_product_name(), __( 'Modules', 'mr-commerce' ) )
        );
    }
}
