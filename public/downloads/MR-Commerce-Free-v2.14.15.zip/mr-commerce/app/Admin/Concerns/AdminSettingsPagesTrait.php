<?php

namespace MRBP\Admin\Concerns;

use MRBP\Admin\Components\Button;
use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Form;
use MRBP\Admin\Components\Table;
use MRBP\Admin\Components\Tabs;
use MRBP\Core\UpgradeRecovery;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait AdminSettingsPagesTrait {
    public function render_settings(): void {
        $tabs = $this->settings_tabs();
        $active = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';

        if ( ! isset( $tabs[ $active ] ) ) {
            $active = 'general';
        }

        $enabled_modules = array_filter( $this->module_manager->enabled() );

        $this->page_renderer->render(
            __( 'MR Commerce Pro Settings', 'mr-commerce' ),
            __( 'Configure the core platform and every enabled module from one organized workspace.', 'mr-commerce' ),
            function () use ( $tabs, $active, $enabled_modules ): void {
                settings_errors();
                settings_errors( 'mrbp_messages' );
                ?>
                <div class="mrbp-settings-summary" aria-label="<?php esc_attr_e( 'Settings summary', 'mr-commerce' ); ?>">
                    <div><span><?php esc_html_e( 'Build', 'mr-commerce' ); ?></span><strong><?php echo esc_html( strtoupper( $this->plan_manager->current_plan() ) ); ?></strong></div>
                    <div><span><?php esc_html_e( 'Active Modules', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) count( $enabled_modules ) ); ?></strong></div>
                    <div><span><?php esc_html_e( 'Debug Logging', 'mr-commerce' ); ?></span><strong class="<?php echo $this->settings->is_debug_enabled() ? 'is-enabled' : ''; ?>"><?php echo $this->settings->is_debug_enabled() ? esc_html__( 'Enabled', 'mr-commerce' ) : esc_html__( 'Disabled', 'mr-commerce' ); ?></strong></div>
                </div>

                <div class="mrbp-settings-workspace">
                    <aside class="mrbp-settings-navigation" aria-label="<?php esc_attr_e( 'Settings sections', 'mr-commerce' ); ?>">
                        <div class="mrbp-settings-navigation__heading">
                            <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
                            <div><strong><?php esc_html_e( 'Configuration', 'mr-commerce' ); ?></strong><small><?php esc_html_e( 'Choose a settings area', 'mr-commerce' ); ?></small></div>
                        </div>
                        <nav>
                            <?php foreach ( $tabs as $tab_id => $tab ) : ?>
                                <a class="mrbp-settings-navigation__item<?php echo $active === $tab_id ? ' is-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=mrbp-settings&tab=' . $tab_id ) ); ?>" <?php echo $active === $tab_id ? 'aria-current="page"' : ''; ?>>
                                    <span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>" aria-hidden="true"></span>
                                    <span><strong><?php echo esc_html( $tab['label'] ); ?></strong><small><?php echo esc_html( $tab['summary'] ); ?></small></span>
                                    <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
                                </a>
                            <?php endforeach; ?>
                        </nav>
                    </aside>

                    <section class="mrbp-settings-panel">
                        <header class="mrbp-settings-panel__header">
                            <span class="mrbp-settings-panel__icon dashicons <?php echo esc_attr( $tabs[ $active ]['icon'] ); ?>" aria-hidden="true"></span>
                            <div>
                                <h2><?php echo esc_html( $tabs[ $active ]['title'] ); ?></h2>
                                <p><?php echo esc_html( $tabs[ $active ]['description'] ); ?></p>
                            </div>
                        </header>
                        <div class="mrbp-settings-panel__body">
                            <?php $this->render_settings_tab( $active ); ?>
                        </div>
                    </section>
                </div>
                <?php
            },
            array( mrbp_product_name(), __( 'Settings', 'mr-commerce' ), $tabs[ $active ]['label'] )
        );
    }

    private function settings_tabs(): array {
        $tabs = array(
            'general' => array(
                'label' => __( 'General', 'mr-commerce' ),
                'title' => __( 'General Settings', 'mr-commerce' ),
                'summary' => __( 'Business identity', 'mr-commerce' ),
                'description' => __( 'Set the business name and core identity used throughout MR Commerce Pro.', 'mr-commerce' ),
                'icon' => 'dashicons-admin-home',
            ),
            'modules' => array(
                'label' => __( 'Modules', 'mr-commerce' ),
                'title' => __( 'Module Configuration', 'mr-commerce' ),
                'summary' => __( 'Enable business tools', 'mr-commerce' ),
                'description' => __( 'Turn modules on or off without maintaining a second set of module preferences.', 'mr-commerce' ),
                'icon' => 'dashicons-screenoptions',
            ),
            'emails' => array(
                'label' => __( 'Emails', 'mr-commerce' ),
                'title' => __( 'Email Identity', 'mr-commerce' ),
                'summary' => __( 'Sender information', 'mr-commerce' ),
                'description' => __( 'Configure the sender name and address used by supported module emails.', 'mr-commerce' ),
                'icon' => 'dashicons-email-alt',
            ),
            'advanced' => array(
                'label' => __( 'Advanced', 'mr-commerce' ),
                'title' => __( 'Advanced Settings', 'mr-commerce' ),
                'summary' => __( 'Logging and cleanup', 'mr-commerce' ),
                'description' => __( 'Manage diagnostic logging and uninstall behaviour with extra care.', 'mr-commerce' ),
                'icon' => 'dashicons-admin-tools',
            ),
        );

        $tabs['maintenance'] = array(
            'label' => __( 'Maintenance', 'mr-commerce' ),
            'title' => __( 'Maintenance & Recovery', 'mr-commerce' ),
            'summary' => __( 'Repair and diagnostics', 'mr-commerce' ),
            'description' => __( 'Repair dashboard routes, recover module state, clear MR caches and run a focused health check.', 'mr-commerce' ),
            'icon' => 'dashicons-hammer',
        );

        if ( $this->settings->module_enabled( 'payment_pro' ) && $this->module_manager->should_load( 'payment_pro' ) ) {
            $tabs['payment'] = array(
                'label' => __( 'Payment', 'mr-commerce' ),
                'title' => __( 'Payment Environment', 'mr-commerce' ),
                'summary' => __( 'Gateway operating mode', 'mr-commerce' ),
                'description' => __( 'Set the shared payment environment. Individual gateways remain managed inside Payment Pro.', 'mr-commerce' ),
                'icon' => 'dashicons-money-alt',
            );
        }

        if ( $this->settings->module_enabled( 'customer_portal' ) && $this->module_manager->should_load( 'customer_portal' ) ) {
            $tabs['portal'] = array(
                'label' => __( 'Portal', 'mr-commerce' ),
                'title' => __( 'Customer Portal Settings', 'mr-commerce' ),
                'summary' => __( 'Portal identity', 'mr-commerce' ),
                'description' => __( 'Configure the customer-facing portal title while preserving existing portal data and routes.', 'mr-commerce' ),
                'icon' => 'dashicons-groups',
            );
        }

        return $tabs;
    }

    private function render_settings_tab( string $active ): void {
        if ( 'modules' === $active ) {
            $this->render_module_form( true );
            return;
        }

        if ( 'maintenance' === $active ) {
            $this->render_maintenance_tools();
            return;
        }

        $map = array(
            'general'  => 'mrbp_general_group',
            'emails'   => 'mrbp_email_group',
            'payment'  => 'mrbp_payment_group',
            'portal'   => 'mrbp_portal_group',
            'advanced' => 'mrbp_advanced_group',
        );

        if ( ! isset( $map[ $active ] ) ) {
            return;
        }

        $this->render_professional_settings_form( $active, $map[ $active ] );
    }

    private function render_maintenance_tools(): void {
        $status = isset( $_GET['mrbp_status'] ) ? sanitize_key( wp_unslash( $_GET['mrbp_status'] ) ) : '';
        $messages = array(
            'routes_repaired'  => __( 'Dashboard routes were rebuilt successfully.', 'mr-commerce' ),
            'routes_failed'    => __( 'Dashboard routes could not be confirmed. Check for a legacy plugin conflict and run the health check.', 'mr-commerce' ),
            'modules_repaired' => __( 'Customer Portal module state was repaired. Route recovery will run on the next admin request.', 'mr-commerce' ),
            'cache_cleared'    => __( 'MR Commerce Pro caches were cleared.', 'mr-commerce' ),
            'health_checked'   => __( 'Health check completed.', 'mr-commerce' ),
        );

        if ( isset( $messages[ $status ] ) ) {
            $notice_class = 'routes_failed' === $status ? 'notice-warning' : 'notice-success';
            echo '<div class="notice ' . esc_attr( $notice_class ) . ' inline"><p>' . esc_html( $messages[ $status ] ) . '</p></div>';
        }

        $health = UpgradeRecovery::get_health_result();
        ?>
        <div class="mrbp-maintenance-grid">
            <?php
            $tools = array(
                array( 'action' => 'mrbp_repair_routes', 'nonce' => 'mrbp_repair_routes', 'icon' => 'dashicons-admin-links', 'title' => __( 'Repair Dashboard Routes', 'mr-commerce' ), 'copy' => __( 'Re-register /dashboard/ and CRM routes, then safely flush rewrite rules once.', 'mr-commerce' ), 'button' => __( 'Repair Routes', 'mr-commerce' ) ),
                array( 'action' => 'mrbp_reset_module_state', 'nonce' => 'mrbp_reset_module_state', 'icon' => 'dashicons-screenoptions', 'title' => __( 'Reset Module State', 'mr-commerce' ), 'copy' => __( 'Restore missing Customer Portal and Payment Center module keys without deleting business data.', 'mr-commerce' ), 'button' => __( 'Repair Modules', 'mr-commerce' ) ),
                array( 'action' => 'mrbp_clear_cache', 'nonce' => 'mrbp_clear_cache', 'icon' => 'dashicons-update', 'title' => __( 'Clear MR Cache', 'mr-commerce' ), 'copy' => __( 'Remove only MR Commerce Pro and Customer Portal transients. Other WordPress caches are untouched.', 'mr-commerce' ), 'button' => __( 'Clear Cache', 'mr-commerce' ) ),
                array( 'action' => 'mrbp_run_health_check', 'nonce' => 'mrbp_run_health_check', 'icon' => 'dashicons-heart', 'title' => __( 'Run Health Check', 'mr-commerce' ), 'copy' => __( 'Check module state, WooCommerce availability, dashboard routes and standalone portal conflicts.', 'mr-commerce' ), 'button' => __( 'Run Check', 'mr-commerce' ) ),
            );
            foreach ( $tools as $tool ) :
                $url = wp_nonce_url( admin_url( 'admin-post.php?action=' . $tool['action'] ), $tool['nonce'] );
                ?>
                <article class="mrbp-maintenance-card">
                    <span class="dashicons <?php echo esc_attr( $tool['icon'] ); ?>" aria-hidden="true"></span>
                    <div><h3><?php echo esc_html( $tool['title'] ); ?></h3><p><?php echo esc_html( $tool['copy'] ); ?></p></div>
                    <a class="mrbp-ui-button mrbp-ui-button--primary" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $tool['button'] ); ?></a>
                </article>
            <?php endforeach; ?>
        </div>
        <?php if ( $health ) : ?>
            <div class="mrbp-health-results">
                <h3><?php esc_html_e( 'Latest Health Check', 'mr-commerce' ); ?></h3>
                <div class="mrbp-health-results__grid">
                    <div><span><?php esc_html_e( 'Customer Portal', 'mr-commerce' ); ?></span><strong><?php echo ! empty( $health['customer_portal_enabled'] ) ? esc_html__( 'Enabled', 'mr-commerce' ) : esc_html__( 'Needs repair', 'mr-commerce' ); ?></strong></div>
                    <div><span><?php esc_html_e( 'Dashboard Routes', 'mr-commerce' ); ?></span><strong><?php echo ! empty( $health['dashboard_routes'] ) ? esc_html__( 'Ready', 'mr-commerce' ) : esc_html__( 'Missing', 'mr-commerce' ); ?></strong></div>
                    <div><span><?php esc_html_e( 'WooCommerce', 'mr-commerce' ); ?></span><strong><?php echo ! empty( $health['woocommerce'] ) ? esc_html__( 'Available', 'mr-commerce' ) : esc_html__( 'Unavailable', 'mr-commerce' ); ?></strong></div>
                    <div><span><?php esc_html_e( 'Legacy Conflicts', 'mr-commerce' ); ?></span><strong><?php echo empty( $health['legacy_conflicts'] ) ? esc_html__( 'None', 'mr-commerce' ) : esc_html( (string) count( $health['legacy_conflicts'] ) ); ?></strong></div>
                </div>
            </div>
        <?php endif;
    }

    private function render_professional_settings_form( string $active, string $group ): void {
        ?>
        <form method="post" action="options.php" class="mrbp-professional-settings-form">
            <?php settings_fields( $group ); ?>
            <div class="mrbp-settings-fields">
                <?php if ( 'general' === $active ) :
                    $values = $this->settings->get_general_settings(); ?>
                    <?php $this->render_setting_field( __( 'Company Name', 'mr-commerce' ), __( 'Displayed across the MR Commerce Pro administration experience.', 'mr-commerce' ), '<input class="mrbp-ui-input" type="text" name="mrbp_general_settings[company_name]" value="' . esc_attr( (string) $values['company_name'] ) . '">' ); ?>

                <?php elseif ( 'emails' === $active ) :
                    $values = $this->settings->get_email_settings(); ?>
                    <?php $this->render_setting_field( __( 'From Name', 'mr-commerce' ), __( 'The sender name shown on supported customer emails.', 'mr-commerce' ), '<input class="mrbp-ui-input" type="text" name="mrbp_email_settings[from_name]" value="' . esc_attr( (string) $values['from_name'] ) . '">' ); ?>
                    <?php $this->render_setting_field( __( 'From Email', 'mr-commerce' ), __( 'Use an address from your website domain for better deliverability.', 'mr-commerce' ), '<input class="mrbp-ui-input" type="email" name="mrbp_email_settings[from_email]" value="' . esc_attr( (string) $values['from_email'] ) . '">' ); ?>

                <?php elseif ( 'payment' === $active ) :
                    $values = $this->settings->get_payment_settings();
                    ob_start(); ?>
                    <select class="mrbp-ui-select" name="mrbp_payment_settings[mode]">
                        <option value="sandbox" <?php selected( $values['mode'], 'sandbox' ); ?>><?php esc_html_e( 'Sandbox', 'mr-commerce' ); ?></option>
                        <option value="live" <?php selected( $values['mode'], 'live' ); ?>><?php esc_html_e( 'Live', 'mr-commerce' ); ?></option>
                    </select>
                    <?php $control = (string) ob_get_clean();
                    $this->render_setting_field( __( 'Gateway Mode', 'mr-commerce' ), __( 'Sandbox is recommended until a gateway integration has completed end-to-end verification.', 'mr-commerce' ), $control ); ?>
                    <div class="mrbp-settings-advisory"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><p><?php esc_html_e( 'Live API payment processing is not included in this release. Gateway-specific settings remain inside Payment Center.', 'mr-commerce' ); ?></p></div>

                <?php elseif ( 'portal' === $active ) :
                    $values = $this->settings->get_portal_settings(); ?>
                    <?php $this->render_setting_field( __( 'Portal Title', 'mr-commerce' ), __( 'Used as the customer portal identity. Existing /dashboard/ routes remain unchanged.', 'mr-commerce' ), '<input class="mrbp-ui-input" type="text" name="mrbp_portal_settings[portal_title]" value="' . esc_attr( (string) $values['portal_title'] ) . '">' ); ?>

                <?php elseif ( 'advanced' === $active ) :
                    $values = $this->settings->get_advanced_settings(); ?>
                    <?php $this->render_setting_toggle( __( 'Enable Debug Logging', 'mr-commerce' ), __( 'Write sanitized diagnostics to the WordPress/PHP error log. Secrets and credentials are always redacted.', 'mr-commerce' ), 'mrbp_advanced_settings[debug_logging]', ! empty( $values['debug_logging'] ) ); ?>
                    <?php $this->render_setting_toggle( __( 'Enable Developer Tools', 'mr-commerce' ), __( 'Expose additional diagnostic controls for troubleshooting. Keep disabled on normal production sites.', 'mr-commerce' ), 'mrbp_advanced_settings[developer_tools]', ! empty( $values['developer_tools'] ) ); ?>
                    <?php $this->render_setting_toggle( __( 'Delete Data on Uninstall', 'mr-commerce' ), __( 'Store the cleanup preference for a future controlled uninstall routine. Leave disabled to protect business data.', 'mr-commerce' ), 'mrbp_advanced_settings[delete_data_on_uninstall]', ! empty( $values['delete_data_on_uninstall'] ), true ); ?>
                <?php endif; ?>
            </div>

            <footer class="mrbp-settings-savebar">
                <div><strong><?php esc_html_e( 'Save this settings section', 'mr-commerce' ); ?></strong><span><?php esc_html_e( 'Only the currently selected section will be updated.', 'mr-commerce' ); ?></span></div>
                <button type="submit" class="mrbp-ui-button mrbp-ui-button--primary"><?php esc_html_e( 'Save Changes', 'mr-commerce' ); ?></button>
            </footer>
        </form>
        <?php
    }

    private function render_setting_field( string $label, string $description, string $control ): void {
        ?>
        <div class="mrbp-setting-row">
            <div class="mrbp-setting-row__copy"><label><?php echo esc_html( $label ); ?></label><p><?php echo esc_html( $description ); ?></p></div>
            <div class="mrbp-setting-row__control"><?php echo wp_kses( $control, array( 'input' => array( 'class' => true, 'type' => true, 'name' => true, 'value' => true, 'min' => true, 'max' => true ), 'select' => array( 'class' => true, 'name' => true ), 'option' => array( 'value' => true, 'selected' => true ) ) ); ?></div>
        </div>
        <?php
    }

    private function render_setting_toggle( string $label, string $description, string $name, bool $checked, bool $warning = false ): void {
        ?>
        <div class="mrbp-setting-row<?php echo $warning ? ' is-warning' : ''; ?>">
            <div class="mrbp-setting-row__copy"><label><?php echo esc_html( $label ); ?></label><p><?php echo esc_html( $description ); ?></p></div>
            <div class="mrbp-setting-row__control">
                <label class="mrbp-modern-toggle">
                    <input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $checked ); ?>>
                    <span class="mrbp-modern-toggle__track"><span class="mrbp-modern-toggle__thumb"></span></span>
                    <span class="mrbp-modern-toggle__label"><?php echo $checked ? esc_html__( 'On', 'mr-commerce' ) : esc_html__( 'Off', 'mr-commerce' ); ?></span>
                </label>
            </div>
        </div>
        <?php
    }

    private function render_module_form( bool $compact = false ): void {
        ?>
        <form method="post" class="mrbp-module-manager" data-mrbp-module-manager>
            <?php wp_nonce_field( 'mrbp_update_modules', 'mrbp_modules_nonce' ); ?>
            <div class="mrbp-professional-module-grid<?php echo $compact ? ' is-compact' : ''; ?>">
                <?php foreach ( $this->module_manager->all() as $module_id => $module ) :
                    $available       = ! empty( $module['available'] );
                    $included        = ! empty( $module['included'] );
                    $dependencies_ok = ! empty( $module['dependencies_ready'] );
                    $enabled         = ! empty( $module['enabled'] ) && $available;
                    $required_plan   = (string) ( $module['required_plan'] ?? 'free' );
                    $is_pro_locked   = 'pro' === $required_plan && ! $this->plan_manager->feature_allowed( $module_id );
                    $manage_url      = $this->module_manage_url( $module_id );
                    $state_class     = $enabled ? 'is-active' : 'is-inactive';

                    if ( $is_pro_locked || ! $included ) {
                        $state_class = 'is-locked';
                    } elseif ( ! $dependencies_ok ) {
                        $state_class = 'has-dependency-error';
                    }
                    ?>
                    <article class="mrbp-professional-module-card <?php echo esc_attr( $state_class ); ?>" data-module-card="<?php echo esc_attr( $module_id ); ?>">
                        <div class="mrbp-professional-module-card__top">
                            <div class="mrbp-professional-module-card__identity">
                                <span class="mrbp-professional-module-card__icon dashicons <?php echo esc_attr( $this->module_dashicon( $module_id ) ); ?>" aria-hidden="true"></span>
                                <div>
                                    <div class="mrbp-professional-module-card__title-row">
                                        <h2><?php echo esc_html( (string) $module['name'] ); ?></h2>
                                    </div>
                                    <p><?php echo esc_html( (string) $module['description'] ); ?></p>
                                </div>
                            </div>
                            <span class="mrbp-module-status-pill <?php echo esc_attr( $state_class ); ?>" data-module-status>
                                <?php echo esc_html( $this->module_status_label( $enabled, $available, $included, $dependencies_ok, $is_pro_locked ) ); ?>
                            </span>
                        </div>

                        <div class="mrbp-professional-module-card__meta">
                            <div><span><?php esc_html_e( 'Package', 'mr-commerce' ); ?></span><strong class="<?php echo $included ? 'is-ready' : 'is-warning'; ?>"><?php echo $included ? esc_html__( 'Included', 'mr-commerce' ) : esc_html__( 'Not Included', 'mr-commerce' ); ?></strong></div>
                            <div><span><?php esc_html_e( 'Dependencies', 'mr-commerce' ); ?></span><strong class="<?php echo $dependencies_ok ? 'is-ready' : 'is-warning'; ?>"><?php echo $dependencies_ok ? esc_html__( 'Ready', 'mr-commerce' ) : esc_html__( 'Action Needed', 'mr-commerce' ); ?></strong></div>
                            <div><span><?php esc_html_e( 'Feature Level', 'mr-commerce' ); ?></span><strong><?php echo esc_html( ucfirst( (string) ( $module['feature_level'] ?? 'disabled' ) ) ); ?></strong></div>
                        </div>

                        <?php if ( $is_pro_locked || ! $included ) : ?>
                            <div class="mrbp-module-inline-notice is-pro"><span class="dashicons dashicons-lock" aria-hidden="true"></span><span><?php esc_html_e( 'This module is available with MR Commerce Pro.', 'mr-commerce' ); ?></span></div>
                        <?php elseif ( ! $dependencies_ok && ! empty( $module['dependency_messages'] ) ) : ?>
                            <div class="mrbp-module-inline-notice is-warning"><span class="dashicons dashicons-warning" aria-hidden="true"></span><div><strong><?php esc_html_e( 'Dependency required', 'mr-commerce' ); ?></strong><ul><?php foreach ( $module['dependency_messages'] as $message ) : ?><li><?php echo esc_html( $message ); ?></li><?php endforeach; ?></ul></div></div>
                        <?php endif; ?>

                        <div class="mrbp-professional-module-card__footer">
                            <div class="mrbp-ui-actions">
                                <?php if ( $is_pro_locked || ! $included ) : ?>
                                    <a class="mrbp-ui-button mrbp-ui-button--primary" href="<?php echo esc_url( $this->upgrade_url( $module_id ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Upgrade to Pro', 'mr-commerce' ); ?></a>
                                <?php elseif ( '' !== $manage_url ) : ?>
                                    <a class="mrbp-ui-button mrbp-ui-button--secondary mrbp-module-manage-button" href="<?php echo esc_url( $manage_url ); ?>"><?php esc_html_e( 'Manage Module', 'mr-commerce' ); ?></a>
                                <?php endif; ?>
                            </div>

                            <?php if ( ! $is_pro_locked && $included ) : ?>
                                <label class="mrbp-modern-toggle<?php echo ! $available ? ' is-disabled' : ''; ?>">
                                    <input type="checkbox" name="modules[<?php echo esc_attr( $module_id ); ?>]" value="1" <?php checked( $enabled ); ?> <?php disabled( ! $available ); ?> data-module-toggle>
                                    <span class="mrbp-modern-toggle__track"><span class="mrbp-modern-toggle__thumb"></span></span>
                                    <span class="mrbp-modern-toggle__label" data-toggle-label><?php echo $enabled ? esc_html__( 'On', 'mr-commerce' ) : esc_html__( 'Off', 'mr-commerce' ); ?></span>
                                </label>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <div class="mrbp-module-savebar">
                <div><strong><?php esc_html_e( 'Save your module configuration', 'mr-commerce' ); ?></strong><span><?php esc_html_e( 'Changes are applied safely on the next request.', 'mr-commerce' ); ?></span></div>
                <button type="submit" name="mrbp_update_modules" value="1" class="mrbp-ui-button mrbp-ui-button--primary"><?php esc_html_e( 'Save Module Settings', 'mr-commerce' ); ?></button>
            </div>
        </form>
        <?php
    }

    private function module_manage_url( string $module_id ): string {
        return match ( $module_id ) {
            'fraud_checker' => admin_url( 'admin.php?page=mrc-fraud-checker' ),
            'growth_suite'    => admin_url( 'admin.php?page=mrc-growth-suite' ),
            'physical_commerce' => admin_url( 'admin.php?page=mrc-physical-commerce' ),
            'customer_portal' => admin_url( 'admin.php?page=mrbp-customer-portal' ),
            'payment_pro'     => admin_url( 'admin.php?page=mrbp-payment-center' ),
            'sequential_orders' => admin_url( 'admin.php?page=mrbp-sequential-orders' ),
            default           => '',
        };
    }

    private function module_dashicon( string $module_id ): string {
        return match ( $module_id ) {
            'fraud_checker' => 'dashicons-shield-alt',
            'growth_suite'    => 'dashicons-chart-line',
            'physical_commerce' => 'dashicons-store',
            'customer_portal' => 'dashicons-groups',
            'payment_pro'     => 'dashicons-money-alt',
            'sequential_orders' => 'dashicons-editor-ol',
            default           => 'dashicons-screenoptions',
        };
    }

    private function module_status_label( bool $enabled, bool $available, bool $included, bool $dependencies_ok, bool $is_pro_locked ): string {
        if ( $is_pro_locked || ! $included ) {
            return __( 'Pro Locked', 'mr-commerce' );
        }
        if ( ! $dependencies_ok ) {
            return __( 'Dependency Missing', 'mr-commerce' );
        }
        if ( ! $available ) {
            return __( 'Unavailable', 'mr-commerce' );
        }
        return $enabled ? __( 'Active', 'mr-commerce' ) : __( 'Inactive', 'mr-commerce' );
    }

    private function upgrade_url( string $module_id ): string {
        return add_query_arg(
            array(
                'utm_source'   => 'mr-business-lite',
                'utm_medium'   => 'plugin',
                'utm_campaign' => 'upgrade',
                'utm_content'  => sanitize_key( $module_id ),
            ),
            'https://mehedirahat.com/'
        );
    }
}
