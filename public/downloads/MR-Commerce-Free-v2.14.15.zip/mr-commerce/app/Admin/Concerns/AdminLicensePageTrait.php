<?php

namespace MRBP\Admin\Concerns;

use MRBP\Admin\Components\Button;
use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Form;
use MRBP\Admin\Components\Table;
use MRBP\Admin\Components\Tabs;
use MRBP\Licensing\LicenseRepository;
use MRBP\Licensing\LocalLicenseService;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait AdminLicensePageTrait {
    public function render_license(): void {
        $data   = $this->license_data();
        $status = sanitize_key( (string) ( $data['status'] ?? 'not_activated' ) );
        $active = 'active' === $status;
        $activity = ( new LicenseRepository() )->activity( 12 );

        $this->page_renderer->render(
            __( 'License Center', 'mr-commerce' ),
            __( 'Manage your MR Commerce Pro license, activation status and future product updates from one secure workspace.', 'mr-commerce' ),
            function () use ( $data, $status, $active, $activity ): void {
                settings_errors( 'mrbp_license_messages' );
                $status_label = $this->license_status_label( $status );
                $status_class = $this->license_status_class( $status );
                $domain       = '' !== (string) ( $data['domain'] ?? '' ) ? (string) $data['domain'] : $this->current_domain();
                ?>
                <div class="mrbp-license-summary" aria-label="<?php esc_attr_e( 'License overview', 'mr-commerce' ); ?>">
                    <article class="mrbp-license-summary__card">
                        <span class="mrbp-license-summary__icon dashicons dashicons-shield" aria-hidden="true"></span>
                        <div><span><?php esc_html_e( 'License Status', 'mr-commerce' ); ?></span><strong class="<?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_label ); ?></strong></div>
                    </article>
                    <article class="mrbp-license-summary__card">
                        <span class="mrbp-license-summary__icon dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
                        <div><span><?php esc_html_e( 'Site Activation', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $domain ); ?></strong></div>
                    </article>
                </div>

                <div class="mrbp-license-grid">
                    <section class="mrbp-license-primary">
                        <article class="mrbp-license-card mrbp-license-card--activation">
                            <header class="mrbp-license-card__header">
                                <span class="mrbp-license-card__icon dashicons dashicons-admin-network" aria-hidden="true"></span>
                                <div>
                                    <h2><?php echo $active ? esc_html__( 'Your License', 'mr-commerce' ) : esc_html__( 'Activate Your License', 'mr-commerce' ); ?></h2>
                                    <p><?php echo $active ? esc_html__( 'Review the signed activation associated with this website.', 'mr-commerce' ) : esc_html__( 'Enter your short license key. This website is detected and submitted securely in the background.', 'mr-commerce' ); ?></p>
                                </div>
                                <span class="mrbp-license-status-badge <?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_label ); ?></span>
                            </header>

                            <?php if ( $active ) : ?>
                                <div class="mrbp-license-details">
                                    <div><span><?php esc_html_e( 'License Key', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $this->mask_license_key( (string) ( $data['key'] ?? '' ) ) ); ?></strong></div>
                                    <div><span><?php esc_html_e( 'License ID', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) ( $data['license_id'] ?? '' ) ); ?></strong></div>
                                    <div><span><?php esc_html_e( 'Licensed To', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) ( $data['customer'] ?? '' ) ); ?></strong></div>
                                    <div><span><?php esc_html_e( 'Activated Domain', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $domain ); ?></strong></div>
                                    <?php if ( '' !== (string) ( $data['staging_domain'] ?? '' ) ) : ?>
                                        <div><span><?php esc_html_e( 'Staging Domain', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) $data['staging_domain'] ); ?></strong></div>
                                    <?php endif; ?>
                                    <div><span><?php esc_html_e( 'Activation Date', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $this->format_license_date( (string) ( $data['activated_at'] ?? '' ) ) ); ?></strong></div>
                                    <div><span><?php esc_html_e( 'Expiry Date', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $this->format_license_date( (string) ( $data['expires_at'] ?? '' ) ) ); ?></strong></div>
                                    <div><span><?php esc_html_e( 'Entitled Modules', 'mr-commerce' ); ?></span><strong><?php echo esc_html( implode( ', ', (array) ( $data['modules'] ?? array() ) ) ); ?></strong></div>
                                </div>
                                <form class="mrbp-license-actions" method="post" action="">
                                    <?php wp_nonce_field( 'mrbp_license_action', 'mrbp_license_nonce' ); ?>
                                    <button class="mrbp-ui-button mrbp-ui-button--secondary" type="submit" name="mrbp_license_action" value="refresh"><?php esc_html_e( 'Refresh Status', 'mr-commerce' ); ?></button>
                                    <button class="mrbp-ui-button mrbp-ui-button--danger" type="submit" name="mrbp_license_action" value="deactivate"><?php esc_html_e( 'Deactivate License', 'mr-commerce' ); ?></button>
                                </form>
                            <?php else : ?>
                                <form class="mrbp-license-form" method="post" action="" autocomplete="off">
                                    <?php wp_nonce_field( 'mrbp_license_action', 'mrbp_license_nonce' ); ?>
                                    <label for="mrbp-license-key"><?php esc_html_e( 'License Key', 'mr-commerce' ); ?></label>
                                    <div class="mrbp-license-key-control">
                                        <span class="dashicons dashicons-lock" aria-hidden="true"></span>
                                        <input id="mrbp-license-key" name="mrbp_license_key" type="text" inputmode="text" autocomplete="off" placeholder="MRCP-XXXX-XXXX-XXXX-XXXX" maxlength="4096" />
                                        <button class="mrbp-ui-button mrbp-ui-button--primary" type="submit" name="mrbp_license_action" value="activate"><?php esc_html_e( 'Activate License', 'mr-commerce' ); ?></button>
                                    </div>
                                    <p class="description"><?php esc_html_e( 'Your short key is verified securely through the official MR License Server.', 'mr-commerce' ); ?></p>
                                </form>
                            <?php endif; ?>

                            <div class="mrbp-license-advisory">
                                <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
                                <p><strong><?php esc_html_e( 'Offline signed activation', 'mr-commerce' ); ?></strong><br><?php esc_html_e( 'The signature, product, plan, expiry and current domain are verified locally. A copied license will not unlock Pro modules on another domain.', 'mr-commerce' ); ?></p>
                            </div>
                        </article>

                        <article class="mrbp-license-card">
                            <header class="mrbp-license-card__header">
                                <span class="mrbp-license-card__icon dashicons dashicons-backup" aria-hidden="true"></span>
                                <div><h2><?php esc_html_e( 'License Activity', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Recent local activation, refresh and deactivation events.', 'mr-commerce' ); ?></p></div>
                            </header>
                            <?php if ( empty( $activity ) ) : ?>
                                <div class="mrbp-license-empty-state">
                                    <span class="dashicons dashicons-clock" aria-hidden="true"></span>
                                    <strong><?php esc_html_e( 'No license activity yet', 'mr-commerce' ); ?></strong>
                                    <p><?php esc_html_e( 'Activate a signed license to create the first local activity record.', 'mr-commerce' ); ?></p>
                                </div>
                            <?php else : ?>
                                <div class="mrbp-license-activity">
                                    <?php foreach ( $activity as $event ) : ?>
                                        <div class="mrbp-license-activity__item">
                                            <strong><?php echo esc_html( ucfirst( (string) ( $event['action'] ?? 'check' ) ) ); ?> — <?php echo esc_html( $this->license_status_label( (string) ( $event['status'] ?? '' ) ) ); ?></strong>
                                            <span><?php echo esc_html( (string) ( $event['message'] ?? '' ) ); ?></span>
                                            <small><?php echo esc_html( (string) ( $event['domain'] ?? '' ) ); ?> · <?php echo esc_html( $this->format_license_date_time( (string) ( $event['created_at'] ?? '' ) ) ); ?></small>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </article>
                    </section>

                    <aside class="mrbp-license-secondary">
                        <article class="mrbp-license-card">
                            <header class="mrbp-license-card__header">
                                <span class="mrbp-license-card__icon dashicons dashicons-products" aria-hidden="true"></span>
                                <div><h2><?php esc_html_e( 'Current Plan', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Pro modules unlock only while the signed local license is valid for this domain.', 'mr-commerce' ); ?></p></div>
                            </header>
                            <div class="mrbp-license-plan">
                                <strong><?php echo esc_html( 'MR Business ' . ( $this->plan_manager->is_pro() ? 'Pro' : 'Lite' ) ); ?></strong>
                                <span><?php echo esc_html( strtoupper( $this->plan_manager->current_plan() ) ); ?></span>
                            </div>
                            <ul class="mrbp-license-feature-list">
                                <?php
                                $license_features = array(
                                    'customer_portal'   => __( 'MR Customer Dashboard', 'mr-commerce' ),
                                    'payment_pro'       => __( 'Payment Pro', 'mr-commerce' ),
                                    'sequential_orders' => __( 'MR Sequential Orders', 'mr-commerce' ),
                                );
                                foreach ( $license_features as $feature_id => $feature_label ) :
                                    $allowed = $this->plan_manager->feature_allowed( $feature_id );
                                    ?>
                                    <li class="<?php echo $allowed ? '' : 'is-disabled'; ?>"><span class="dashicons <?php echo $allowed ? 'dashicons-yes-alt' : 'dashicons-lock'; ?>" aria-hidden="true"></span><?php echo esc_html( $feature_label ); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php if ( ! $this->plan_manager->is_pro() ) : ?>
                                <a class="mrbp-ui-button mrbp-ui-button--primary mrbp-license-upgrade" href="<?php echo esc_url( $this->upgrade_url( 'license_center' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Upgrade to Pro', 'mr-commerce' ); ?></a>
                            <?php endif; ?>
                        </article>

                        <article class="mrbp-license-card">
                            <header class="mrbp-license-card__header">
                                <span class="mrbp-license-card__icon dashicons dashicons-admin-site" aria-hidden="true"></span>
                                <div><h2><?php esc_html_e( 'This Website', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Use this exact domain when creating the customer license.', 'mr-commerce' ); ?></p></div>
                            </header>
                            <dl class="mrbp-license-site-info">
                                <div><dt><?php esc_html_e( 'Website', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( home_url( '/' ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Domain', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( $this->current_domain() ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'WordPress', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( get_bloginfo( 'version' ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'PHP', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( PHP_VERSION ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Plugin', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( MRBP_VERSION ); ?></dd></div>
                            </dl>
                        </article>

                        <article class="mrbp-license-card mrbp-license-card--help">
                            <header class="mrbp-license-card__header">
                                <span class="mrbp-license-card__icon dashicons dashicons-sos" aria-hidden="true"></span>
                                <div><h2><?php esc_html_e( 'Need Help?', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Keep your purchase email and license key available when contacting support.', 'mr-commerce' ); ?></p></div>
                            </header>
                            <a class="mrbp-ui-button mrbp-ui-button--secondary" href="https://mehedirahat.com/contact/" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Contact Support', 'mr-commerce' ); ?></a>
                        </article>
                    </aside>
                </div>
                <?php
            },
            array( mrbp_product_name(), __( 'License Center', 'mr-commerce' ) )
        );
    }

    public function handle_license_action(): void {
        if ( ! isset( $_POST['mrbp_license_action'] ) ) {
            return;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'mrbp-license' !== $page ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to manage this license.', 'mr-commerce' ), esc_html__( 'Access denied', 'mr-commerce' ), array( 'response' => 403 ) );
        }

        check_admin_referer( 'mrbp_license_action', 'mrbp_license_nonce' );

        $action  = sanitize_key( wp_unslash( $_POST['mrbp_license_action'] ) );
        $type    = 'info';
        $message = __( 'No license action was performed.', 'mr-commerce' );
        $service = new LocalLicenseService();

        if ( 'activate' === $action ) {
            $key = isset( $_POST['mrbp_license_key'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['mrbp_license_key'] ) ) ) : '';

            if ( '' === $key || ( ! str_starts_with( $key, 'MRBP1.' ) && ! preg_match( '/^MR[A-Z0-9]{1,8}(?:-[A-Z0-9]{4}){4}$/', strtoupper( $key ) ) ) ) {
                $type    = 'error';
                $message = __( 'Enter a valid short license key or MRBP1 signed token before continuing.', 'mr-commerce' );
            } else {
                $result  = $service->activate( $key );
                $type    = ! empty( $result['valid'] ) ? 'success' : 'error';
                $message = (string) ( $result['message'] ?? __( 'The license could not be verified.', 'mr-commerce' ) );
            }
        } elseif ( 'refresh' === $action ) {
            $result  = $service->refresh();
            $type    = ! empty( $result['valid'] ) ? 'success' : 'error';
            $message = (string) ( $result['message'] ?? __( 'The license could not be refreshed.', 'mr-commerce' ) );
        } elseif ( 'deactivate' === $action ) {
            $result  = $service->deactivate();
            $type    = 'success';
            $message = (string) $result['message'];
        }

        add_settings_error( 'mrbp_license_messages', 'mrbp_license_' . $action, $message, $type );
        set_transient( 'settings_errors', get_settings_errors(), 30 );

        wp_safe_redirect( admin_url( 'admin.php?page=mrbp-license&settings-updated=true' ) );
        exit;
    }

    private function license_data(): array {
        $defaults = array(
            'key'          => '',
            'status'       => 'not_activated',
            'plan'         => '',
            'domain'       => '',
            'activated_at' => '',
            'expires_at'   => '',
            'last_checked' => '',
        );
        $data = wp_parse_args( ( new LicenseRepository() )->get(), $defaults );
        if ( '' !== trim( (string) $data['key'] ) ) {
            $runtime = ( new LocalLicenseService() )->runtime_status();
            $data['status'] = sanitize_key( (string) ( $runtime['status'] ?? $data['status'] ) );
        }
        return $data;
    }

    private function current_domain(): string {
        $host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
        return '' !== $host ? strtolower( $host ) : home_url( '/' );
    }

    private function mask_license_key( string $key ): string {
        $key = strtoupper( trim( $key ) );
        if ( '' === $key ) {
            return __( 'Not available', 'mr-commerce' );
        }
        $last = substr( preg_replace( '/[^A-Z0-9]/', '', $key ), -4 );
        return 'MRBP-****-****-' . ( '' !== $last ? $last : '****' );
    }

    private function format_license_date( string $date ): string {
        if ( '' === $date ) {
            return __( 'Not available', 'mr-commerce' );
        }
        $timestamp = strtotime( $date );
        return false === $timestamp ? __( 'Not available', 'mr-commerce' ) : wp_date( get_option( 'date_format' ), $timestamp );
    }

    private function format_license_date_time( string $date ): string {
        if ( '' === $date ) {
            return __( 'Not available', 'mr-commerce' );
        }
        $timestamp = strtotime( $date );
        return false === $timestamp ? __( 'Not available', 'mr-commerce' ) : wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
    }

    private function license_status_label( string $status ): string {
        $labels = array(
            'active'                   => __( 'Active', 'mr-commerce' ),
            'expired'                  => __( 'Expired', 'mr-commerce' ),
            'invalid'                  => __( 'Invalid', 'mr-commerce' ),
            'invalid_domain'           => __( 'Wrong Domain', 'mr-commerce' ),
            'suspended'                => __( 'Suspended', 'mr-commerce' ),
            'activation_limit_reached' => __( 'Activation Limit Reached', 'mr-commerce' ),
            'connection_error'         => __( 'Connection Error', 'mr-commerce' ),
            'grace_period'             => __( 'Grace Period', 'mr-commerce' ),
            'not_activated'            => __( 'Not Activated', 'mr-commerce' ),
        );
        return $labels[ $status ] ?? $labels['not_activated'];
    }

    private function license_status_class( string $status ): string {
        if ( 'active' === $status ) {
            return 'is-active';
        }
        if ( in_array( $status, array( 'expired', 'invalid', 'invalid_domain' ), true ) ) {
            return 'is-error';
        }
        if ( in_array( $status, array( 'suspended', 'grace_period', 'activation_limit_reached' ), true ) ) {
            return 'is-warning';
        }
        return 'is-neutral';
    }
}
