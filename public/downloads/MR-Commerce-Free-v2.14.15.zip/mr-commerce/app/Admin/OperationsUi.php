<?php

namespace MRBP\Admin;

defined( 'ABSPATH' ) || exit;

final class OperationsUi {
    private const PAGES = array(
        'mrc-physical-commerce', 'mrc-shipping-operations', 'mrc-stock-dashboard',
        'mrc-growth-suite', 'mrc-retention', 'mrc-courier-integration', 'mrc-fraud-checker',
    );

    public function register(): void {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function enqueue(): void {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        $order_screen = $screen && ( in_array( $screen->id, array( 'shop_order', 'woocommerce_page_wc-orders' ), true ) || 'shop_order' === $screen->post_type );
        if ( ! in_array( $page, self::PAGES, true ) && ! $order_screen ) { return; }
        wp_enqueue_style( 'mrbp-admin-typography', MRBP_URL . 'assets/admin/css/typography.css', array(), MRBP_VERSION );
        wp_enqueue_style( 'mrc-operations-ui', MRBP_URL . 'assets/admin/css/operations-ui.css', array( 'mrbp-admin-typography' ), MRBP_VERSION );
        if ( in_array( $page, array( 'mrc-shipping-operations', 'mrc-physical-commerce' ), true ) ) {
            wp_enqueue_script( 'mrc-shipping-builder', MRBP_URL . 'assets/admin/js/shipping-builder.js', array(), MRBP_VERSION, true );
        }
        if ( 'mrc-growth-suite' === $page ) {
            wp_enqueue_script( 'mrc-campaign-builder', MRBP_URL . 'assets/admin/js/campaign-builder.js', array(), MRBP_VERSION, true );
        }
    }

    public static function header( string $eyebrow, string $title, string $description, string $icon, array $badges = array() ): void {
        echo '<section class="mrc-ops-hero"><div class="mrc-ops-hero__icon"><span class="dashicons ' . esc_attr( $icon ) . '"></span></div><div class="mrc-ops-hero__copy">';
        echo '<span class="mrc-ops-eyebrow">' . esc_html( $eyebrow ) . '</span><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $description ) . '</p></div>';
        if ( $badges ) {
            echo '<div class="mrc-ops-hero__badges">';
            foreach ( $badges as $label => $value ) { echo '<div><span>' . esc_html( (string) $label ) . '</span><strong>' . esc_html( (string) $value ) . '</strong></div>'; }
            echo '</div>';
        }
        echo '</section>';
    }

    public static function classification( string $type ): void {
        $types = array(
            'core'        => array( __( 'WooCommerce Core', 'mr-commerce' ), 'dashicons-wordpress' ),
            'enhanced'    => array( __( 'Enhanced by MR Commerce', 'mr-commerce' ), 'dashicons-admin-tools' ),
            'exclusive'   => array( __( 'MR Exclusive', 'mr-commerce' ), 'dashicons-star-filled' ),
            'integration' => array( __( 'Integration', 'mr-commerce' ), 'dashicons-admin-links' ),
        );
        if ( ! isset( $types[ $type ] ) ) { return; }
        echo '<span class="mrc-capability-label mrc-capability-' . esc_attr( $type ) . '"><span class="dashicons ' . esc_attr( $types[ $type ][1] ) . '"></span>' . esc_html( $types[ $type ][0] ) . '</span>';
    }

    public static function guide( string $summary, array $steps, string $example = '', string $warning = '' ): void {
        echo '<aside class="mrc-help-guide"><div class="mrc-help-guide__intro"><span class="dashicons dashicons-lightbulb"></span><div><strong>' . esc_html__( 'সহজভাবে বুঝুন', 'mr-commerce' ) . '</strong><p>' . esc_html( $summary ) . '</p></div></div>';
        echo '<details><summary>' . esc_html__( 'ব্যবহারের নিয়ম দেখুন', 'mr-commerce' ) . '<span class="dashicons dashicons-arrow-down-alt2"></span></summary><div class="mrc-help-guide__details"><ol>';
        foreach ( array_slice( $steps, 0, 4 ) as $step ) { echo '<li>' . esc_html( (string) $step ) . '</li>'; }
        echo '</ol>';
        if ( $example ) { echo '<p class="mrc-help-guide__example"><strong>' . esc_html__( 'উদাহরণ:', 'mr-commerce' ) . '</strong> ' . esc_html( $example ) . '</p>'; }
        if ( $warning ) { echo '<p class="mrc-help-guide__warning"><span class="dashicons dashicons-warning"></span><span><strong>' . esc_html__( 'মনে রাখুন:', 'mr-commerce' ) . '</strong> ' . esc_html( $warning ) . '</span></p>'; }
        echo '</div></details></aside>';
    }
}
