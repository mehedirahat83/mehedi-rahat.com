<?php

namespace MRBP\Admin\Layout;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Header {

    private Breadcrumb $breadcrumb;

    public function __construct( Breadcrumb $breadcrumb ) {
        $this->breadcrumb = $breadcrumb;
    }

    /**
     * @param array<int,string|array<string,string>> $breadcrumbs
     * @param array<int,array<string,mixed>> $actions
     */
    public function render( string $title, string $description, array $breadcrumbs, array $actions ): void {
        ?>
        <header class="mrbp-framework__header">
            <div class="mrbp-framework__heading">
                <?php $this->breadcrumb->render( $breadcrumbs ); ?>
                <h1><?php echo esc_html( $title ); ?></h1>
                <?php if ( '' !== $description ) : ?><p><?php echo esc_html( $description ); ?></p><?php endif; ?>
            </div>
            <div class="mrbp-framework__header-tools">
                <button type="button" class="mrbp-icon-button" data-mrbp-sidebar-toggle aria-label="<?php esc_attr_e( 'Toggle navigation', 'mr-commerce' ); ?>">
                    <span class="dashicons dashicons-menu-alt" aria-hidden="true"></span>
                </button>
                <?php if ( ! empty( $actions ) ) : ?>
                    <div class="mrbp-framework__actions">
                        <?php foreach ( $actions as $action ) : ?>
                            <a class="button <?php echo ! empty( $action['primary'] ) ? 'button-primary' : 'button-secondary'; ?>" href="<?php echo esc_url( (string) ( $action['url'] ?? '#' ) ); ?>">
                                <?php echo esc_html( (string) ( $action['label'] ?? '' ) ); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </header>
        <?php
    }
}
