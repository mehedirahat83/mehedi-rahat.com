<?php

namespace MRBP\Admin\Layout;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class PageRenderer {

    private Sidebar $sidebar;
    private Header $header;

    public function __construct( Sidebar $sidebar, Header $header ) {
        $this->sidebar = $sidebar;
        $this->header  = $header;
    }

    /**
     * @param callable():void $content
     * @param array<int,string|array<string,string>> $breadcrumbs
     * @param array<int,array<string,mixed>> $actions
     */
    public function render(
        string $title,
        string $description,
        callable $content,
        array $breadcrumbs = array(),
        array $actions = array(),
        string $capability = 'manage_options'
    ): void {
        if ( ! current_user_can( $capability ) ) {
            wp_die( esc_html__( 'You are not allowed to view this page.', 'mr-commerce' ) );
        }
        ?>
        <div class="wrap mrbp-framework" data-mrbp-framework>
            <div class="mrbp-framework__shell">
                <?php $this->sidebar->render(); ?>
                <main class="mrbp-framework__main">
                    <?php $this->header->render( $title, $description, $breadcrumbs, $actions ); ?>
                    <section class="mrbp-framework__content"><?php $content(); ?></section>
                    <footer class="mrbp-framework__footer">
                        <?php echo esc_html( sprintf( '%s %s', mrbp_product_name(), MRBP_VERSION ) ); ?>
                    </footer>
                </main>
            </div>
        </div>
        <?php
    }
}
