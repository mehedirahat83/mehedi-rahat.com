<?php

namespace MRBP\Admin\Layout;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Breadcrumb {

    /** @param array<int,string|array<string,string>> $items */
    public function render( array $items ): void {
        if ( empty( $items ) ) {
            return;
        }
        ?>
        <nav class="mrbp-breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'mr-commerce' ); ?>">
            <ol>
                <?php foreach ( $items as $index => $item ) :
                    $label = is_array( $item ) ? (string) ( $item['label'] ?? '' ) : (string) $item;
                    $url   = is_array( $item ) ? (string) ( $item['url'] ?? '' ) : '';
                    ?>
                    <li>
                        <?php if ( '' !== $url && $index < count( $items ) - 1 ) : ?>
                            <a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?></a>
                        <?php else : ?>
                            <span<?php echo $index === count( $items ) - 1 ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ol>
        </nav>
        <?php
    }
}
