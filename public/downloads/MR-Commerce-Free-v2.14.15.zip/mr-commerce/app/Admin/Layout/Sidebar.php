<?php

namespace MRBP\Admin\Layout;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Navigation\ActiveMenu;
use MRBP\Admin\Navigation\FlyoutMenu;
use MRBP\Admin\Navigation\NavigationRegistry;

final class Sidebar {

    private NavigationRegistry $navigation;
    private ActiveMenu $active;
    private FlyoutMenu $flyout;

    public function __construct( NavigationRegistry $navigation, ActiveMenu $active, FlyoutMenu $flyout ) {
        $this->navigation = $navigation;
        $this->active     = $active;
        $this->flyout     = $flyout;
    }

    public function render(): void {
        ?>
        <aside class="mrbp-framework__sidebar" data-mrbp-sidebar aria-label="<?php echo esc_attr( mrbp_product_name() . ' navigation' ); ?>">
            <div class="mrbp-framework__brand">
                <span class="mrbp-framework__brand-mark">MR</span>
                <span class="mrbp-framework__brand-copy">
                    <span class="mrbp-framework__brand-text"><?php echo esc_html( mrbp_product_name() ); ?></span>
                    <span class="mrbp-framework__brand-meta"><?php echo esc_html( MRBP_VERSION . ' • ' . strtoupper( defined( 'MRBP_BUILD_PLAN' ) ? MRBP_BUILD_PLAN : 'free' ) ); ?></span>
                </span>
            </div>
            <nav><ul class="mrbp-framework__nav-list">
                <?php foreach ( $this->navigation->root_items() as $id => $item ) :
                    if ( ! current_user_can( (string) $item['capability'] ) ) { continue; }
                    $has_children = ! empty( $this->navigation->children_of( $id ) );
                    $active       = $this->active->item_is_active( $id );
                    ?>
                    <li class="mrbp-framework__nav-item<?php echo $active ? ' is-active' : ''; ?><?php echo $has_children ? ' has-flyout' : ''; ?>" data-mrbp-nav-item>
                        <a href="<?php echo esc_url( $this->item_url( $item ) ); ?>"<?php echo $has_children ? ' aria-haspopup="true" aria-expanded="false"' : ''; ?>>
                            <span class="dashicons <?php echo esc_attr( (string) $item['icon'] ); ?>" aria-hidden="true"></span>
                            <span class="mrbp-framework__nav-label"><?php echo esc_html( (string) $item['label'] ); ?></span>
                            <?php if ( $has_children ) : ?><span class="dashicons dashicons-arrow-right-alt2 mrbp-framework__nav-arrow" aria-hidden="true"></span><?php endif; ?>
                        </a>
                        <?php if ( $has_children ) { $this->flyout->render_children( $id ); } ?>
                    </li>
                <?php endforeach; ?>
            </ul></nav>
        </aside>
        <?php
    }

    /** @param array<string,mixed> $item */
    private function item_url( array $item ): string {
        return ! empty( $item['url'] ) ? (string) $item['url'] : admin_url( 'admin.php?page=' . sanitize_key( (string) $item['slug'] ) );
    }
}
