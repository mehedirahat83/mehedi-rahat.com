<?php

namespace MRBP\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Assets\AssetLoader;

/**
 * Backward-compatible alias for the v0.6 admin asset loader.
 */
final class Assets extends AssetLoader {}
