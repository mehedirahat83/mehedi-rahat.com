<?php

namespace MRBP\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Core\PlanManager;
use MRBP\Core\BuildInfo;
use MRBP\Modules\ModuleManager;
use MRBP\Admin\Layout\PageRenderer;
use MRBP\Admin\Components\Button;
use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Form;
use MRBP\Admin\Components\Table;
use MRBP\Admin\Components\Tabs;

final class AdminMenu {
    use Concerns\AdminDashboardPagesTrait;
    use Concerns\AdminSettingsPagesTrait;
    use Concerns\AdminLicensePageTrait;


    private Settings $settings;
    private ModuleManager $module_manager;
    private PlanManager $plan_manager;
    private PageRenderer $page_renderer;

    public function __construct( Settings $settings, ModuleManager $module_manager, PlanManager $plan_manager, PageRenderer $page_renderer ) {
        $this->settings       = $settings;
        $this->module_manager = $module_manager;
        $this->plan_manager   = $plan_manager;
        $this->page_renderer  = $page_renderer;
    }

    public function register(): void {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_init', array( $this, 'maybe_redirect_after_activation' ) );
        if ( ( new BuildInfo() )->requires_license() ) {
            add_action( 'admin_init', array( $this, 'handle_license_action' ) );
        }
    }

    public function register_menu(): void {
        $operations_capability = 'manage_woocommerce';
        $admin_capability      = 'manage_options';
        $slug       = 'mrbp-dashboard';

        add_menu_page(
            mrbp_product_name(),
            mrbp_product_name(),
            $operations_capability,
            $slug,
            array( $this, 'render_dashboard' ),
            'dashicons-screenoptions',
            56
        );

        add_submenu_page( $slug, __( 'Dashboard', 'mr-commerce' ), __( 'Dashboard', 'mr-commerce' ), $operations_capability, $slug, array( $this, 'render_dashboard' ) );
        add_submenu_page( $slug, __( 'Modules', 'mr-commerce' ), __( 'Modules', 'mr-commerce' ), $admin_capability, 'mrbp-modules', array( $this, 'render_modules' ) );
        add_submenu_page( $slug, __( 'Settings', 'mr-commerce' ), __( 'Settings', 'mr-commerce' ), $admin_capability, 'mrbp-settings', array( $this, 'render_settings' ) );
        if ( ( new BuildInfo() )->requires_license() ) {
            add_submenu_page( $slug, __( 'License', 'mr-commerce' ), __( 'License', 'mr-commerce' ), $admin_capability, 'mrbp-license', array( $this, 'render_license' ) );
        }
    }







    /** @return array<string,array{label:string,title:string,summary:string,description:string,icon:string}> */
























    /** @return array<string,string> */












    public function maybe_redirect_after_activation(): void {
        if ( ! get_transient( 'mrbp_activation_redirect' ) ) {
            return;
        }

        delete_transient( 'mrbp_activation_redirect' );

        if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) ) {
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=mrbp-dashboard' ) );
        exit;
    }

}
