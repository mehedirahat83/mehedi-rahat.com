<?php

namespace MRBP\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Settings {

    /** @var array<string,array<string,mixed>> */
    private array $option_cache = array();

    public function register(): void {
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    public function register_settings(): void {
        $this->register_group( 'mrbp_general_group', 'mrbp_general_settings', array( $this, 'sanitize_general_settings' ), $this->general_defaults() );
        $this->register_group( 'mrbp_email_group', 'mrbp_email_settings', array( $this, 'sanitize_email_settings' ), $this->email_defaults() );
        $this->register_group( 'mrbp_payment_group', 'mrbp_payment_settings', array( $this, 'sanitize_payment_settings' ), $this->payment_defaults() );
        $this->register_group( 'mrbp_portal_group', 'mrbp_portal_settings', array( $this, 'sanitize_portal_settings' ), $this->portal_defaults() );
        $this->register_group( 'mrbp_advanced_group', 'mrbp_advanced_settings', array( $this, 'sanitize_advanced_settings' ), $this->advanced_defaults() );

        add_settings_section( 'mrbp_general_section', __( 'General Settings', 'mr-commerce' ), '__return_false', 'mrbp_general' );
        add_settings_field( 'mrbp_company_name', __( 'Company Name', 'mr-commerce' ), array( $this, 'render_company_name_field' ), 'mrbp_general', 'mrbp_general_section' );

        add_settings_section( 'mrbp_email_section', __( 'Email Settings', 'mr-commerce' ), '__return_false', 'mrbp_emails' );
        add_settings_field( 'mrbp_from_name', __( 'From Name', 'mr-commerce' ), array( $this, 'render_from_name_field' ), 'mrbp_emails', 'mrbp_email_section' );
        add_settings_field( 'mrbp_from_email', __( 'From Email', 'mr-commerce' ), array( $this, 'render_from_email_field' ), 'mrbp_emails', 'mrbp_email_section' );

        add_settings_section( 'mrbp_payment_section', __( 'Payment Settings', 'mr-commerce' ), '__return_false', 'mrbp_payment' );
        add_settings_field( 'mrbp_payment_mode', __( 'Gateway Mode', 'mr-commerce' ), array( $this, 'render_payment_mode_field' ), 'mrbp_payment', 'mrbp_payment_section' );

        add_settings_section( 'mrbp_portal_section', __( 'Portal Settings', 'mr-commerce' ), '__return_false', 'mrbp_portal' );
        add_settings_field( 'mrbp_portal_title', __( 'Portal Title', 'mr-commerce' ), array( $this, 'render_portal_title_field' ), 'mrbp_portal', 'mrbp_portal_section' );

        add_settings_section( 'mrbp_advanced_section', __( 'Advanced Settings', 'mr-commerce' ), '__return_false', 'mrbp_advanced' );
        add_settings_field( 'mrbp_debug_logging', __( 'Enable Debug Logging', 'mr-commerce' ), array( $this, 'render_debug_logging_field' ), 'mrbp_advanced', 'mrbp_advanced_section' );
        add_settings_field( 'mrbp_delete_data', __( 'Delete Data on Uninstall', 'mr-commerce' ), array( $this, 'render_delete_data_field' ), 'mrbp_advanced', 'mrbp_advanced_section' );
    }

    private function register_group( string $group, string $option, callable $sanitize, array $default ): void {
        register_setting( $group, $option, array( 'type' => 'array', 'sanitize_callback' => $sanitize, 'default' => $default ) );
    }

    public function get_enabled_modules(): array {
        $defaults = array( 'fraud_checker' => true, 'growth_suite' => true, 'physical_commerce' => true, 'customer_portal' => true, 'payment_pro' => false, 'sequential_orders' => false );
        return $this->get_option( 'mrbp_enabled_modules', $defaults );
    }

    public function module_enabled( string $module_id ): bool {
        $modules = $this->get_enabled_modules();
        return ! empty( $modules[ $module_id ] );
    }

    public function get_general_settings(): array { return $this->get_option( 'mrbp_general_settings', $this->general_defaults() ); }
    public function get_email_settings(): array { return $this->get_option( 'mrbp_email_settings', $this->email_defaults() ); }
    public function get_payment_settings(): array { return $this->get_option( 'mrbp_payment_settings', $this->payment_defaults() ); }
    public function get_portal_settings(): array { return $this->get_option( 'mrbp_portal_settings', $this->portal_defaults() ); }
    public function get_advanced_settings(): array { return $this->get_option( 'mrbp_advanced_settings', $this->advanced_defaults() ); }
    public function is_debug_enabled(): bool { return ! empty( $this->get_advanced_settings()['debug_logging'] ); }

    private function get_option( string $name, array $defaults ): array {
        if ( isset( $this->option_cache[ $name ] ) ) {
            return $this->option_cache[ $name ];
        }

        $value = get_option( $name, array() );
        $this->option_cache[ $name ] = wp_parse_args( is_array( $value ) ? $value : array(), $defaults );
        return $this->option_cache[ $name ];
    }

    private function general_defaults(): array { return array( 'company_name' => get_bloginfo( 'name' ) ); }
    private function email_defaults(): array { return array( 'from_name' => get_bloginfo( 'name' ), 'from_email' => get_option( 'admin_email' ) ); }
    private function payment_defaults(): array { return array( 'mode' => 'sandbox' ); }
    private function portal_defaults(): array { return array( 'portal_title' => __( 'Customer Portal', 'mr-commerce' ) ); }
    private function advanced_defaults(): array { return array( 'debug_logging' => false, 'developer_tools' => false, 'delete_data_on_uninstall' => false ); }

    public function sanitize_general_settings( array $input ): array { return array( 'company_name' => sanitize_text_field( $input['company_name'] ?? '' ) ); }
    public function sanitize_email_settings( array $input ): array { return array( 'from_name' => sanitize_text_field( $input['from_name'] ?? '' ), 'from_email' => sanitize_email( $input['from_email'] ?? '' ) ); }
    public function sanitize_payment_settings( array $input ): array { $mode = $input['mode'] ?? 'sandbox'; return array( 'mode' => in_array( $mode, array( 'sandbox', 'live' ), true ) ? $mode : 'sandbox' ); }
    public function sanitize_portal_settings( array $input ): array { return array( 'portal_title' => sanitize_text_field( $input['portal_title'] ?? '' ) ); }
    public function sanitize_advanced_settings( array $input ): array { return array( 'debug_logging' => ! empty( $input['debug_logging'] ), 'developer_tools' => ! empty( $input['developer_tools'] ), 'delete_data_on_uninstall' => ! empty( $input['delete_data_on_uninstall'] ) ); }

    public function render_company_name_field(): void { $v = $this->get_general_settings(); printf( '<input type="text" class="regular-text" name="mrbp_general_settings[company_name]" value="%s">', esc_attr( $v['company_name'] ) ); }
    public function render_from_name_field(): void { $v = $this->get_email_settings(); printf( '<input type="text" class="regular-text" name="mrbp_email_settings[from_name]" value="%s">', esc_attr( $v['from_name'] ) ); }
    public function render_from_email_field(): void { $v = $this->get_email_settings(); printf( '<input type="email" class="regular-text" name="mrbp_email_settings[from_email]" value="%s">', esc_attr( $v['from_email'] ) ); }
    public function render_payment_mode_field(): void { $v = $this->get_payment_settings(); echo '<select name="mrbp_payment_settings[mode]"><option value="sandbox" ' . selected( $v['mode'], 'sandbox', false ) . '>' . esc_html__( 'Sandbox', 'mr-commerce' ) . '</option><option value="live" ' . selected( $v['mode'], 'live', false ) . '>' . esc_html__( 'Live', 'mr-commerce' ) . '</option></select>'; }
    public function render_portal_title_field(): void { $v = $this->get_portal_settings(); printf( '<input type="text" class="regular-text" name="mrbp_portal_settings[portal_title]" value="%s">', esc_attr( $v['portal_title'] ) ); }
    public function render_debug_logging_field(): void { $v = $this->get_advanced_settings(); printf( '<label><input type="checkbox" name="mrbp_advanced_settings[debug_logging]" value="1" %s> %s</label><p class="description">%s</p>', checked( ! empty( $v['debug_logging'] ), true, false ), esc_html__( 'Enable Debug Logging', 'mr-commerce' ), esc_html__( 'Writes sanitized diagnostic entries to the WordPress/PHP error log. Passwords, secrets, tokens and payment credentials are always redacted.', 'mr-commerce' ) ); }
    public function render_delete_data_field(): void { $v = $this->get_advanced_settings(); printf( '<label><input type="checkbox" name="mrbp_advanced_settings[delete_data_on_uninstall]" value="1" %s> %s</label>', checked( ! empty( $v['delete_data_on_uninstall'] ), true, false ), esc_html__( 'Remove plugin options when the plugin is deleted. This version only stores the preference; deletion logic remains disabled for safety.', 'mr-commerce' ) ); }
}
