<?php

namespace MRBP\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Core\BuildInfo;

final class ProFeature {

    public static function allowed( string $feature ): bool {
        return function_exists( 'mrc_can' ) && mrc_can( $feature );
    }

    public static function upgrade_url(): string {
        return ( new BuildInfo() )->requires_license()
            ? admin_url( 'admin.php?page=mrbp-license' )
            : 'https://mehedirahat.com/mr-commerce-pro/';
    }

    public static function action_label(): string {
        return ( new BuildInfo() )->requires_license()
            ? __( 'Activate or renew Pro', 'mr-commerce' )
            : __( 'Upgrade to Pro', 'mr-commerce' );
    }

    public static function render(
        string $feature,
        string $title,
        string $description,
        array $benefits = array()
    ): void {
        if ( self::allowed( $feature ) ) {
            return;
        }

        echo '<section class="mrbp-ui-card mrbp-pro-preview" data-mrbp-pro-feature="' . esc_attr( $feature ) . '">';
        echo '<header class="mrbp-ui-card__header"><div><span class="mrbp-ui-badge mrbp-ui-badge--warning">' . esc_html__( 'PRO', 'mr-commerce' ) . '</span>';
        echo '<h2 class="mrbp-ui-card__title">' . esc_html( $title ) . '</h2>';
        echo '<p class="mrbp-ui-card__description">' . esc_html( $description ) . '</p></div></header>';

        if ( ! empty( $benefits ) ) {
            echo '<div class="mrbp-ui-card__content"><ul class="mrbp-pro-preview__benefits">';
            foreach ( $benefits as $benefit ) {
                echo '<li><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>' . esc_html( (string) $benefit ) . '</li>';
            }
            echo '</ul></div>';
        }

        echo '<footer class="mrbp-ui-card__footer"><a class="mrbp-ui-button mrbp-ui-button--primary" href="' . esc_url( self::upgrade_url() ) . '">' . esc_html( self::action_label() ) . '</a>';
        echo '<span class="mrbp-ui-muted">' . esc_html__( 'Your existing settings and data stay preserved.', 'mr-commerce' ) . '</span></footer>';
        echo '</section>';
    }

    public static function deny_action( string $feature, string $message = '' ): void {
        if ( self::allowed( $feature ) ) {
            return;
        }

        wp_die(
            esc_html( '' !== $message ? $message : __( 'This action requires MR Commerce Pro.', 'mr-commerce' ) ),
            esc_html__( 'Pro feature', 'mr-commerce' ),
            array( 'response' => 403, 'back_link' => true )
        );
    }
}
