<?php

namespace MRBP\Admin\Assets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AssetLoader {

    /** @var array<string,bool> */
    private array $registered_pages = array();

    public function register(): void {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function register_page( string $page_slug ): void {
        $page_slug = sanitize_key( $page_slug );

        if ( '' !== $page_slug ) {
            $this->registered_pages[ $page_slug ] = true;
        }
    }

    public function enqueue( string $hook_suffix ): void {
        if ( ! $this->is_framework_screen( $hook_suffix ) ) {
            return;
        }

        wp_enqueue_style(
            'mrbp-design-tokens',
            MRBP_URL . 'assets/css/design-tokens.css',
            array(),
            MRBP_VERSION
        );

        wp_enqueue_style(
            'mrbp-admin-typography',
            MRBP_URL . 'assets/admin/css/typography.css',
            array(),
            MRBP_VERSION
        );

        wp_enqueue_style(
            'mrbp-admin-framework',
            MRBP_URL . 'assets/admin/css/framework.css',
            array( 'mrbp-design-tokens', 'mrbp-admin-typography' ),
            MRBP_VERSION
        );

        wp_enqueue_style(
            'mrbp-admin-components',
            MRBP_URL . 'assets/admin/css/components.css',
            array( 'mrbp-admin-framework' ),
            MRBP_VERSION
        );

        wp_enqueue_style(
            'mrbp-admin-design-system',
            MRBP_URL . 'assets/admin/css/design-system.css',
            array( 'mrbp-admin-components' ),
            MRBP_VERSION
        );

        wp_enqueue_script(
            'mrbp-admin-framework',
            MRBP_URL . 'assets/admin/js/framework.js',
            array(),
            MRBP_VERSION,
            true
        );

        wp_enqueue_script(
            'mrbp-admin-components',
            MRBP_URL . 'assets/admin/js/components.js',
            array( 'mrbp-admin-framework' ),
            MRBP_VERSION,
            true
        );

        wp_localize_script(
            'mrbp-admin-framework',
            'MRBPAdmin',
            array(
                'version' => MRBP_VERSION,
                'labels'  => array(
                    'openNavigation'  => __( 'Open navigation', 'mr-commerce' ),
                    'closeNavigation' => __( 'Close navigation', 'mr-commerce' ),
                ),
            )
        );
    }

    private function is_framework_screen( string $hook_suffix ): bool {
        if ( false !== strpos( $hook_suffix, 'mrbp' ) ) {
            return true;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

        return '' !== $page && ( str_starts_with( $page, 'mrbp-' ) || isset( $this->registered_pages[ $page ] ) );
    }
}
