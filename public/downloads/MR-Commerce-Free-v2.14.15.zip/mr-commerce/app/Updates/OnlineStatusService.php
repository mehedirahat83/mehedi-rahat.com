<?php

namespace MRBP\Updates;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class OnlineStatusService {

    private const CACHE_OPTION = 'mrbp_signed_update_status_cache';
    private const REFRESH_TTL  = DAY_IN_SECONDS;
    private const GRACE_TTL    = 7 * DAY_IN_SECONDS;

    public function __construct( private ?SignedEnvelopeVerifier $verifier = null ) {
        $this->verifier ??= new SignedEnvelopeVerifier();
    }

    public function feed_url(): string {
        $configured = defined( 'MRBP_UPDATE_FEED_URL' ) ? (string) MRBP_UPDATE_FEED_URL : '';
        return esc_url_raw( (string) apply_filters( 'mrbp/update_feed_url', $configured ) );
    }

    public function payload(): array {
        $cache = get_option( self::CACHE_OPTION, array() );
        $cache = is_array( $cache ) ? $cache : array();
        $age   = time() - (int) ( $cache['fetched_at'] ?? 0 );
        if ( ! empty( $cache['payload'] ) && $age < self::REFRESH_TTL ) {
            return (array) $cache['payload'];
        }

        $url = $this->feed_url();
        if ( '' === $url ) {
            return array();
        }
        $response = wp_safe_remote_get( $url, array( 'timeout' => 8, 'redirection' => 2 ) );
        if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
            $envelope = json_decode( (string) wp_remote_retrieve_body( $response ), true );
            $payload  = is_array( $envelope ) ? $this->verifier->verify( $envelope ) : array();
            if ( $payload ) {
                update_option(
                    self::CACHE_OPTION,
                    array( 'fetched_at' => time(), 'payload' => $payload ),
                    false
                );
                return $payload;
            }
        }

        // A verified cached response remains usable during a short outage.
        return ! empty( $cache['payload'] ) && $age < self::GRACE_TTL ? (array) $cache['payload'] : array();
    }

    public function is_revoked( string $license_id ): bool {
        if ( '' === $license_id ) {
            return false;
        }
        $revoked = array_map( 'strtoupper', (array) ( $this->payload()['revoked_license_ids'] ?? array() ) );
        return in_array( strtoupper( $license_id ), $revoked, true );
    }
}
