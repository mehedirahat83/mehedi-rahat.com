<?php

namespace MRBP\Updates;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Core\BuildInfo;
use MRBP\Licensing\LocalLicenseService;

final class PluginUpdateClient {

    public function __construct(
        private OnlineStatusService $status,
        private LocalLicenseService $licenses
    ) {}

    public function register(): void {
        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
        add_filter( 'plugins_api', array( $this, 'plugin_information' ), 20, 3 );
        add_filter( 'upgrader_pre_download', array( $this, 'verify_download' ), 10, 4 );
    }

    public function inject_update( mixed $transient ): mixed {
        if ( ! is_object( $transient ) ) {
            return $transient;
        }
        $release = $this->eligible_release();
        if ( ! $release || version_compare( (string) ( $release['version'] ?? '' ), MRBP_VERSION, '<=' ) ) {
            return $transient;
        }
        $transient->response[ MRBP_BASENAME ] = (object) array(
            'slug'        => 'mr-commerce-pro',
            'plugin'      => MRBP_BASENAME,
            'new_version' => sanitize_text_field( (string) $release['version'] ),
            'package'     => esc_url_raw( (string) $release['package_url'] ),
            'url'         => esc_url_raw( (string) ( $release['details_url'] ?? '' ) ),
            'tested'      => sanitize_text_field( (string) ( $release['tested'] ?? '' ) ),
            'requires_php'=> sanitize_text_field( (string) ( $release['requires_php'] ?? '8.1' ) ),
        );
        return $transient;
    }

    public function plugin_information( mixed $result, string $action, object $args ): mixed {
        if ( 'plugin_information' !== $action || ! in_array( (string) ( $args->slug ?? '' ), array( 'mr-commerce-pro', 'mr-commerce' ), true ) ) {
            return $result;
        }
        $release = $this->eligible_release();
        if ( ! $release ) {
            return $result;
        }
        return (object) array(
            'name'          => 'MR Commerce Pro',
            'slug'          => 'mr-commerce-pro',
            'version'       => (string) $release['version'],
            'download_link' => (string) $release['package_url'],
            'sections'      => array( 'changelog' => wp_kses_post( (string) ( $release['changelog'] ?? '' ) ) ),
        );
    }

    public function verify_download( mixed $reply, string $package, mixed $upgrader, array $hook_extra ): mixed {
        if ( false !== $reply || MRBP_BASENAME !== ( $hook_extra['plugin'] ?? '' ) ) {
            return $reply;
        }
        $release = $this->eligible_release();
        if ( ! $release || ! hash_equals( (string) ( $release['package_url'] ?? '' ), $package ) ) {
            return new \WP_Error( 'mrbp_update_url', __( 'The update package does not match the signed MR Commerce Pro release.', 'mr-commerce' ) );
        }
        $temporary = download_url( $package, 300 );
        if ( is_wp_error( $temporary ) ) {
            return $temporary;
        }
        $expected = strtoupper( sanitize_text_field( (string) ( $release['sha256'] ?? '' ) ) );
        $actual   = strtoupper( (string) hash_file( 'sha256', $temporary ) );
        if ( 64 !== strlen( $expected ) || ! hash_equals( $expected, $actual ) ) {
            wp_delete_file( $temporary );
            return new \WP_Error( 'mrbp_update_checksum', __( 'The downloaded MR Commerce Pro update failed its signed checksum check.', 'mr-commerce' ) );
        }
        return $temporary;
    }

    private function eligible_release(): array {
        $build = new BuildInfo();
        $data  = $this->licenses->runtime_status();
        if ( ! $build->is_owner() ) {
            if ( empty( $data['valid'] ) ) {
                return array();
            }
            $license_id = sanitize_text_field( (string) ( $data['payload']['license_id'] ?? '' ) );
            if ( $this->status->is_revoked( $license_id ) ) {
                return array();
            }
        }
        $channel = $build->is_owner()
            ? 'internal'
            : sanitize_key( defined( 'MRBP_UPDATE_CHANNEL' ) ? (string) MRBP_UPDATE_CHANNEL : 'stable' );
        return (array) ( $this->status->payload()['releases'][ $channel ] ?? array() );
    }
}
