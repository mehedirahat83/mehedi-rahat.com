<?php

namespace MRBP\Updates;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class SignedEnvelopeVerifier {

    private const CONTEXT = 'MRBP-UPDATES1';

    public function verify( array $envelope ): array {
        $payload_segment = (string) ( $envelope['payload'] ?? '' );
        $signature       = $this->decode( (string) ( $envelope['signature'] ?? '' ) );
        $payload_json    = $this->decode( $payload_segment );

        if ( false === $signature || false === $payload_json ) {
            return array();
        }

        $key_path = MRBP_PATH . 'app/Licensing/Keys/public-key.pem';
        if ( ! is_readable( $key_path ) || ! function_exists( 'openssl_verify' ) ) {
            return array();
        }

        $key = openssl_pkey_get_public( (string) file_get_contents( $key_path ) );
        if ( false === $key ) {
            return array();
        }

        $valid = openssl_verify(
            self::CONTEXT . '.' . $payload_segment,
            $signature,
            $key,
            OPENSSL_ALGO_SHA256
        );
        $payload = json_decode( $payload_json, true );

        $product_id = defined( 'MRBP_PRODUCT_ID' ) ? sanitize_key( (string) MRBP_PRODUCT_ID ) : 'mr-commerce';
        return 1 === $valid && is_array( $payload ) && $product_id === ( $payload['product'] ?? '' )
            ? $payload
            : array();
    }

    private function decode( string $value ): string|false {
        if ( '' === $value || ! preg_match( '/^[A-Za-z0-9_-]+$/', $value ) ) {
            return false;
        }
        $padding = strlen( $value ) % 4;
        if ( $padding ) {
            $value .= str_repeat( '=', 4 - $padding );
        }
        return base64_decode( strtr( $value, '-_', '+/' ), true );
    }
}
