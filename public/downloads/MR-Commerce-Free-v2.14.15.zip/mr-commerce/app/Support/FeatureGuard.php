<?php

namespace MRBP\Support;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Contracts\EntitlementProviderInterface;

final class FeatureGuard {
    public function __construct( private EntitlementProviderInterface $entitlements ) {}

    public function allows( string $feature ): bool {
        return $this->entitlements->allows( $feature );
    }

    public function denies( string $feature ): bool {
        return ! $this->allows( $feature );
    }

    public function level( string $feature ): string {
        return $this->entitlements->level( $feature );
    }

    public function limit( string $feature ): int {
        return $this->entitlements->limit( $feature );
    }
}
