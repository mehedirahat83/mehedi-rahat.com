<?php

namespace MRBP\Support;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Logger {

    public const TYPE_INFO           = 'info';
    public const TYPE_WARNING        = 'warning';
    public const TYPE_ERROR          = 'error';
    public const TYPE_PAYMENT        = 'payment';
    public const TYPE_AUTHENTICATION = 'authentication';
    public const TYPE_MODULE         = 'module';
    public const TYPE_DATABASE       = 'database';

    private const TYPES = array(
        self::TYPE_INFO,
        self::TYPE_WARNING,
        self::TYPE_ERROR,
        self::TYPE_PAYMENT,
        self::TYPE_AUTHENTICATION,
        self::TYPE_MODULE,
        self::TYPE_DATABASE,
    );

    public function info( string $message, array $context = array() ): void {
        $this->log( self::TYPE_INFO, $message, $context );
    }

    public function warning( string $message, array $context = array() ): void {
        $this->log( self::TYPE_WARNING, $message, $context );
    }

    public function error( string $message, array $context = array() ): void {
        $this->log( self::TYPE_ERROR, $message, $context );
    }

    public function payment( string $message, array $context = array() ): void {
        $this->log( self::TYPE_PAYMENT, $message, $context );
    }

    public function authentication( string $message, array $context = array() ): void {
        $this->log( self::TYPE_AUTHENTICATION, $message, $context );
    }

    public function module( string $message, array $context = array() ): void {
        $this->log( self::TYPE_MODULE, $message, $context );
    }

    public function database( string $message, array $context = array() ): void {
        $this->log( self::TYPE_DATABASE, $message, $context );
    }

    public function debug_enabled(): bool {
        $advanced = get_option( 'mrbp_advanced_settings', array() );
        $general  = get_option( 'mrbp_general_settings', array() );

        // Backward compatibility for installations upgraded from <= 0.5.18.
        return ! empty( $advanced['debug_logging'] ) || ! empty( $general['debug_mode'] );
    }

    public function log( string $type, string $message, array $context = array() ): void {
        $type = strtolower( sanitize_key( $type ) );

        if ( ! in_array( $type, self::TYPES, true ) ) {
            $type = self::TYPE_INFO;
        }

        // Errors remain visible in production; all other diagnostic logs require opt-in.
        if ( self::TYPE_ERROR !== $type && ! $this->debug_enabled() ) {
            return;
        }

        $entry = array(
            'timestamp' => gmdate( 'c' ),
            'type'      => $type,
            'message'   => sanitize_text_field( $message ),
            'context'   => $this->sanitize_value( $context ),
        );

        /**
         * Filters a fully sanitized MR Commerce Pro log entry.
         *
         * Returning an empty array suppresses the entry.
         */
        $entry = apply_filters( 'mrbp/log_entry', $entry, $type );

        if ( empty( $entry ) || ! is_array( $entry ) ) {
            return;
        }

        $line = sprintf(
            '[MRBP][%s] %s%s',
            strtoupper( $type ),
            (string) ( $entry['message'] ?? '' ),
            empty( $entry['context'] ) ? '' : ' ' . wp_json_encode( $entry['context'], JSON_UNESCAPED_SLASHES )
        );

        error_log( trim( $line ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        do_action( 'mrbp/logged', $entry );
    }

    private function sanitize_value( $value, string $key = '' ) {
        if ( $this->is_sensitive_key( $key ) ) {
            return '[redacted]';
        }

        if ( is_array( $value ) ) {
            $safe = array();
            foreach ( $value as $child_key => $child_value ) {
                $safe[ sanitize_key( (string) $child_key ) ] = $this->sanitize_value( $child_value, (string) $child_key );
            }
            return $safe;
        }

        if ( is_object( $value ) ) {
            return '[object:' . sanitize_text_field( get_class( $value ) ) . ']';
        }

        if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
            return $value;
        }

        $string = sanitize_text_field( (string) $value );

        // Redact credential-like values even when supplied inside a generic key.
        $string = preg_replace(
            '/(authorization|bearer|password|passwd|app[_-]?secret|api[_-]?secret|client[_-]?secret|license[_-]?secret|access[_-]?token|auth[_-]?token)\s*[:=]\s*[^\s,;]+/i',
            '$1=[redacted]',
            $string
        );

        return $string;
    }

    private function is_sensitive_key( string $key ): bool {
        return 1 === preg_match(
            '/(^|_)(password|passwd|pwd|secret|api_secret|app_secret|client_secret|license_secret|token|access_token|auth_token|authorization|credential|credentials|private_key|card_number|cvv|cvc|pin)($|_)/i',
            $key
        );
    }
}
