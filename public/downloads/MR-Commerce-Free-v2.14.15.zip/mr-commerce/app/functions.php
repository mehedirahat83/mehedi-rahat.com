<?php

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'mrbp' ) ) {
    function mrbp(): \MRBP\Core\Plugin {
        return \MRBP\Core\Plugin::instance();
    }
}

if ( ! function_exists( 'mrbp_feature_allowed' ) ) {
    function mrbp_feature_allowed( string $feature ): bool {
        return mrbp()->features()->allows( $feature );
    }
}

if ( ! function_exists( 'mrbp_feature_level' ) ) {
    function mrbp_feature_level( string $feature ): string {
        return mrbp()->features()->level( $feature );
    }
}

if ( ! function_exists( 'mrbp_feature_limit' ) ) {
    function mrbp_feature_limit( string $feature ): int {
        return mrbp()->plan()->limit( $feature );
    }
}

if ( ! function_exists( 'mrc_can' ) ) {
    function mrc_can( string $feature ): bool {
        return mrbp_feature_allowed( $feature );
    }
}

if ( ! function_exists( 'mrc_limit' ) ) {
    function mrc_limit( string $feature ): int {
        return mrbp_feature_limit( $feature );
    }
}

if ( ! function_exists( 'mrc_plan' ) ) {
    function mrc_plan(): string {
        return mrbp()->plan()->current_plan();
    }
}

if ( ! function_exists( 'mrbp_is_pro' ) ) {
    function mrbp_is_pro(): bool {
        return mrbp()->plan()->is_pro();
    }
}


if ( ! function_exists( 'mrbp_product_name' ) ) {
    function mrbp_product_name(): string {
        return defined( 'MRBP_PRODUCT_NAME' ) ? (string) MRBP_PRODUCT_NAME : 'MR Commerce';
    }
}
