<?php

namespace MRBP\Entitlements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\ProFeature;
use MRBP\Core\BuildInfo;

final class FallbackNotice {

    public function register(): void {
        if ( ! ( new BuildInfo() )->requires_license() ) {
            return;
        }

        add_action( 'admin_notices', array( $this, 'render' ) );
        add_action( 'network_admin_notices', array( $this, 'render' ) );
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'mrc_plan' ) || 'free' !== mrc_plan() ) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'MR Commerce Pro is running in Free fallback mode.', 'mr-commerce' ) . '</strong> ';
        echo esc_html__( 'Pro-only workflows are paused, while their settings and business data remain preserved.', 'mr-commerce' ) . ' ';
        echo '<a href="' . esc_url( ProFeature::upgrade_url() ) . '">' . esc_html__( 'Check license', 'mr-commerce' ) . '</a></p></div>';
    }
}
