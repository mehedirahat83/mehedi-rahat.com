<?php

namespace MRBP\Entitlements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Contracts\EntitlementProviderInterface;
use MRBP\Core\BuildInfo;
use MRBP\Core\PlanManager;
use MRBP\Licensing\LocalLicenseService;
use MRBP\Updates\OnlineStatusService;

final class LicenseEntitlementProvider implements EntitlementProviderInterface {

    public function __construct(
        private EntitlementProviderInterface $build,
        private LocalLicenseService $licenses,
        private ?OnlineStatusService $online_status = null,
        private ?FeatureCatalogue $catalogue = null
    ) {
        $this->catalogue ??= new FeatureCatalogue();
    }

    public function current_plan(): string {
        $build = new BuildInfo();

        if ( $build->is_free() ) {
            return PlanManager::PLAN_FREE;
        }

        if ( $build->is_owner() || $this->license_is_active() ) {
            return PlanManager::PLAN_PRO;
        }

        return PlanManager::PLAN_FREE;
    }

    public function allows( string $feature ): bool {
        if ( ! $this->catalogue->has( $feature ) ) {
            return false;
        }

        if ( PlanManager::PLAN_FREE === $this->current_plan() ) {
            return $this->catalogue->allowed_for_plan( $feature, PlanManager::PLAN_FREE );
        }

        if ( ( new BuildInfo() )->is_owner() ) {
            return $this->catalogue->allowed_for_plan( $feature, PlanManager::PLAN_PRO );
        }

        return $this->licensed_feature_allowed( $feature );
    }

    public function level( string $feature ): string {
        if ( ! $this->allows( $feature ) ) {
            return 'disabled';
        }

        return PlanManager::PLAN_PRO === $this->effective_feature_plan( $feature ) ? 'pro' : 'free';
    }

    public function limit( string $feature ): int {
        return $this->allows( $feature )
            ? $this->catalogue->limit_for_plan( $feature, $this->effective_feature_plan( $feature ) )
            : 0;
    }

    private function license_is_active(): bool {
        if ( ! $this->licenses->is_active() ) {
            return false;
        }

        $payload = (array) ( $this->licenses->runtime_status()['payload'] ?? array() );

        return ! $this->online_status
            || ! $this->online_status->is_revoked( (string) ( $payload['license_id'] ?? '' ) );
    }

    private function licensed_feature_allowed( string $feature ): bool {
        if ( ! $this->catalogue->allowed_for_plan( $feature, PlanManager::PLAN_PRO ) ) {
            return false;
        }

        return PlanManager::PLAN_FREE === $this->catalogue->minimum_plan( $feature )
            || $this->license_grants_feature( $feature );
    }

    private function effective_feature_plan( string $feature ): string {
        if ( PlanManager::PLAN_PRO !== $this->current_plan() ) {
            return PlanManager::PLAN_FREE;
        }

        if ( ( new BuildInfo() )->is_owner() || $this->license_grants_feature( $feature ) ) {
            return PlanManager::PLAN_PRO;
        }

        return PlanManager::PLAN_FREE;
    }

    private function license_grants_feature( string $feature ): bool {
        $payload      = (array) ( $this->licenses->runtime_status()['payload'] ?? array() );
        $product      = sanitize_key( (string) ( $payload['product'] ?? '' ) );
        $plan         = sanitize_key( (string) ( $payload['plan'] ?? '' ) );

        /*
         * A signed, active MR Commerce Pro product license represents the full
         * commercial suite. Older licenses predate newer module IDs, so treating
         * their historic module list as a deny-list incorrectly locks features
         * added in later releases. Signature, product, plan, domain, expiry,
         * remote suspension and revocation have already been validated before
         * this method is reached.
         */
        $full_suite = 'mr-commerce-pro' === $product && PlanManager::PLAN_PRO === $plan;
        $full_suite = (bool) apply_filters( 'mrbp/license_full_suite', $full_suite, $payload, $feature, $this );
        if ( $full_suite ) {
            return true;
        }

        $entitlements = array_values(
            array_filter(
                array_map(
                    'sanitize_key',
                    array_merge(
                        (array) ( $payload['modules'] ?? array() ),
                        (array) ( $payload['entitlements'] ?? array() )
                    )
                )
            )
        );

        if ( in_array( 'commerce_pro', $entitlements, true ) || in_array( 'mr_commerce_pro', $entitlements, true ) ) {
            return true;
        }

        $required = $this->catalogue->license_entitlement( $feature );

        return ( '' !== $required && in_array( $required, $entitlements, true ) )
            || in_array( $feature, $entitlements, true );
    }
}
