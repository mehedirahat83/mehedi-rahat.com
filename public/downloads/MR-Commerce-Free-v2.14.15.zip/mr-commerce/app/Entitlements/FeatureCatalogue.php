<?php

namespace MRBP\Entitlements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Core\PlanManager;

final class FeatureCatalogue {
    private ?array $features = null;

    public function all(): array {
        if ( null === $this->features ) {
            $catalogue      = require MRBP_PATH . 'config/feature-catalogue.php';
            $this->features = is_array( $catalogue ) ? $catalogue : array();
        }

        return $this->features;
    }

    public function has( string $feature ): bool {
        return isset( $this->all()[ $feature ] );
    }

    public function get( string $feature ): array {
        return $this->all()[ $feature ] ?? array();
    }

    public function minimum_plan( string $feature ): string {
        $plan = (string) ( $this->get( $feature )['minimum_plan'] ?? PlanManager::PLAN_PRO );

        return in_array( $plan, array( PlanManager::PLAN_FREE, PlanManager::PLAN_PRO ), true )
            ? $plan
            : PlanManager::PLAN_PRO;
    }

    public function allowed_for_plan( string $feature, string $plan ): bool {
        return $this->has( $feature )
            && ( PlanManager::PLAN_FREE === $this->minimum_plan( $feature ) || PlanManager::PLAN_PRO === $plan );
    }

    public function level_for_plan( string $feature, string $plan ): string {
        if ( ! $this->allowed_for_plan( $feature, $plan ) ) {
            return 'disabled';
        }

        return PlanManager::PLAN_PRO === $plan ? 'pro' : 'free';
    }

    public function limit_for_plan( string $feature, string $plan ): int {
        if ( ! $this->allowed_for_plan( $feature, $plan ) ) {
            return 0;
        }

        $limits = (array) ( $this->get( $feature )['limits'] ?? array() );
        $limit  = $limits[ $plan ] ?? -1;

        return is_numeric( $limit ) ? (int) $limit : -1;
    }

    public function license_entitlement( string $feature ): string {
        return sanitize_key( (string) ( $this->get( $feature )['license_entitlement'] ?? '' ) );
    }
}
