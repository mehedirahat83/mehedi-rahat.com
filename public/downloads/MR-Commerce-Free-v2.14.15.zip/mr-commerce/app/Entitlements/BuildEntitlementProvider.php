<?php

namespace MRBP\Entitlements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Contracts\EntitlementProviderInterface;
use MRBP\Core\PlanManager;

final class BuildEntitlementProvider implements EntitlementProviderInterface {

    public function __construct( private ?FeatureCatalogue $catalogue = null ) {
        $this->catalogue ??= new FeatureCatalogue();
    }

    public function current_plan(): string {
        $plan = defined( 'MRBP_BUILD_PLAN' ) ? (string) MRBP_BUILD_PLAN : PlanManager::PLAN_FREE;

        return in_array( $plan, array( PlanManager::PLAN_FREE, PlanManager::PLAN_PRO ), true )
            ? $plan
            : PlanManager::PLAN_FREE;
    }

    public function allows( string $feature ): bool {
        return $this->catalogue->allowed_for_plan( $feature, $this->current_plan() );
    }

    public function level( string $feature ): string {
        return $this->catalogue->level_for_plan( $feature, $this->current_plan() );
    }

    public function limit( string $feature ): int {
        return $this->catalogue->limit_for_plan( $feature, $this->current_plan() );
    }

    public function features(): array {
        $features = array();

        foreach ( array_keys( $this->catalogue->all() ) as $feature ) {
            $features[ $feature ] = $this->allows( $feature );
        }

        return $features;
    }

    public function feature_levels(): array {
        $levels = array();

        foreach ( array_keys( $this->catalogue->all() ) as $feature ) {
            $levels[ $feature ] = $this->level( $feature );
        }

        return $levels;
    }
}
