<?php

namespace MRBP\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class SignedLicenseVerifier {

    private const TOKEN_VERSION = 'MRBP1';

    public function __construct( private ?DomainNormalizer $domains = null ) {
        $this->domains ??= new DomainNormalizer();
    }

    /**
     * @return array{valid:bool,status:string,message:string,payload:array<string,mixed>}
     */
    public function verify( string $token, string $current_domain = '' ): array {
        $token = trim( $token );
        $parts = explode( '.', $token );

        if ( 3 !== count( $parts ) || self::TOKEN_VERSION !== $parts[0] ) {
            return $this->failure( 'invalid', __( 'The license token format is invalid.', 'mr-commerce' ) );
        }

        $payload_json = $this->base64url_decode( $parts[1] );
        $signature    = $this->base64url_decode( $parts[2] );

        if ( false === $payload_json || false === $signature ) {
            return $this->failure( 'invalid', __( 'The license token could not be decoded.', 'mr-commerce' ) );
        }

        $payload = json_decode( $payload_json, true );
        if ( ! is_array( $payload ) ) {
            return $this->failure( 'invalid', __( 'The license payload is invalid.', 'mr-commerce' ) );
        }

        $public_key_path = MRBP_PATH . 'app/Licensing/Keys/public-key.pem';
        if ( ! is_readable( $public_key_path ) || ! function_exists( 'openssl_verify' ) ) {
            return $this->failure( 'invalid', __( 'The local license verifier is unavailable.', 'mr-commerce' ), $payload );
        }

        $public_key = openssl_pkey_get_public( (string) file_get_contents( $public_key_path ) );
        if ( false === $public_key ) {
            return $this->failure( 'invalid', __( 'The license verification key is invalid.', 'mr-commerce' ), $payload );
        }

        $verified = openssl_verify(
            self::TOKEN_VERSION . '.' . $parts[1],
            $signature,
            $public_key,
            OPENSSL_ALGO_SHA256
        );

        if ( 1 !== $verified ) {
            return $this->failure( 'invalid', __( 'The license signature is invalid or the token was modified.', 'mr-commerce' ), $payload );
        }

        $product_id = defined( 'MRBP_PRODUCT_ID' ) ? sanitize_key( (string) MRBP_PRODUCT_ID ) : 'mr-commerce';
        if ( $product_id !== sanitize_key( (string) ( $payload['product'] ?? '' ) ) ) {
            return $this->failure( 'invalid', __( 'This license belongs to a different product.', 'mr-commerce' ), $payload );
        }

        $license_id = strtoupper( sanitize_text_field( (string) ( $payload['license_id'] ?? '' ) ) );
        $license_prefix = 'mr-commerce-pro' === $product_id ? 'MRCP' : 'MRBP';
        if ( ! preg_match( '/^' . preg_quote( $license_prefix, '/' ) . '-[A-Z0-9-]{4,40}$/', $license_id ) ) {
            return $this->failure( 'invalid', __( 'The license ID is invalid.', 'mr-commerce' ), $payload );
        }

        if ( 'pro' !== sanitize_key( (string) ( $payload['plan'] ?? '' ) ) ) {
            return $this->failure( 'invalid', __( 'This license does not include the PRO plan.', 'mr-commerce' ), $payload );
        }

        $manifest = require MRBP_PATH . 'config/module-manifest.php';
        $modules  = array_values(
            array_intersect(
                array_keys( is_array( $manifest ) ? $manifest : array() ),
                array_unique( array_filter( array_map( 'sanitize_key', (array) ( $payload['modules'] ?? array() ) ) ) )
            )
        );
        if ( empty( $modules ) ) {
            return $this->failure( 'invalid', __( 'This legacy license has no recognized module entitlements. Ask the owner to reissue it with the current license builder.', 'mr-commerce' ), $payload );
        }

        $production = $this->domains->normalize( (string) ( $payload['domain'] ?? '' ) );
        $staging    = $this->domains->normalize( (string) ( $payload['staging_domain'] ?? '' ) );
        if ( '' === $production ) {
            return $this->failure( 'invalid', __( 'The licensed production domain is invalid.', 'mr-commerce' ), $payload );
        }

        $expires_at = sanitize_text_field( (string) ( $payload['expires_at'] ?? '' ) );
        if ( '' !== $expires_at ) {
            $expiry = strtotime( $expires_at . ' 23:59:59 UTC' );
            if ( false === $expiry || $expiry < time() ) {
                return $this->failure( 'expired', __( 'This license has expired.', 'mr-commerce' ), $payload );
            }
        }

        $current_domain = '' !== $current_domain ? $this->domains->normalize( $current_domain ) : $this->domains->current();
        if ( ! $this->domains->matches( $current_domain, $production )
            && ( '' === $staging || ! $this->domains->matches( $current_domain, $staging ) ) ) {
            return $this->failure(
                'invalid_domain',
                sprintf(
                    /* translators: 1: licensed domain, 2: current domain. */
                    __( 'This license is registered for %1$s and cannot be used on %2$s.', 'mr-commerce' ),
                    $production,
                    $current_domain ?: __( 'this website', 'mr-commerce' )
                ),
                $payload
            );
        }

        $payload['license_id']     = $license_id;
        $payload['domain']         = $production;
        $payload['staging_domain'] = $staging;
        $payload['plan']           = 'pro';
        $payload['modules']        = $modules;

        return array(
            'valid'   => true,
            'status'  => 'active',
            'message' => __( 'The license is active for this domain.', 'mr-commerce' ),
            'payload' => $payload,
        );
    }

    /**
     * @param array<string,mixed> $payload
     * @return array{valid:bool,status:string,message:string,payload:array<string,mixed>}
     */
    private function failure( string $status, string $message, array $payload = array() ): array {
        return array(
            'valid'   => false,
            'status'  => sanitize_key( $status ),
            'message' => $message,
            'payload' => $payload,
        );
    }

    private function base64url_decode( string $value ): string|false {
        if ( '' === $value || ! preg_match( '/^[A-Za-z0-9_-]+$/', $value ) ) {
            return false;
        }

        $padding = strlen( $value ) % 4;
        if ( $padding > 0 ) {
            $value .= str_repeat( '=', 4 - $padding );
        }

        return base64_decode( strtr( $value, '-_', '+/' ), true );
    }
}
