<?php

namespace MRBP\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LocalLicenseService {

    private const BUNDLED_LICENSE = 'license/customer-license.mrbp';
    private const ACTIVATION_ENDPOINT = 'https://mehedirahat.com/wp-json/mrlm/v1/activate';
    private const STATUS_ENDPOINT = 'https://mehedirahat.com/wp-json/mrlm/v1/status';
    private static array $runtime_results = array();

    public function __construct(
        private ?LicenseRepository $repository = null,
        private ?SignedLicenseVerifier $verifier = null,
        private ?DomainNormalizer $domains = null
    ) {
        $this->repository ??= new LicenseRepository();
        $this->domains    ??= new DomainNormalizer();
        $this->verifier   ??= new SignedLicenseVerifier( $this->domains );
    }

    public function repository(): LicenseRepository {
        return $this->repository;
    }

    public function activate( string $token, string $source = 'manual' ): array {
        $token  = trim( $token );
        if ( ! str_starts_with( $token, 'MRBP1.' ) ) {
            $resolved = $this->resolve_short_key( $token );
            if ( empty( $resolved['token'] ) ) {
                $result = array(
                    'valid' => false,
                    'status' => 'invalid',
                    'message' => (string) ( $resolved['message'] ?? __( 'The short license key could not be activated.', 'mr-commerce' ) ),
                    'payload' => array(),
                );
                $this->repository->add_activity( 'activate', 'invalid', $result['message'], array( 'source' => 'short_key' ) );
                return $result;
            }
            $token = (string) $resolved['token'];
            $source = 'short_key';
        }
        $result = $this->verifier->verify( $token, $this->domains->current() );
        $result = $this->apply_remote_status( $token, $result );

        if ( ! empty( $result['valid'] ) ) {
            $this->repository->save_verification( $token, $result, true );
        }

        $this->repository->add_activity(
            'activate',
            (string) $result['status'],
            (string) $result['message'],
            array( 'source' => $source )
        );
        self::$runtime_results = array();

        return $result;
    }

    private function resolve_short_key( string $short_key ): array {
        $response = wp_safe_remote_post(
            self::ACTIVATION_ENDPOINT,
            array(
                'timeout' => 12,
                'redirection' => 1,
                'body' => array(
                    'license_key' => strtoupper( sanitize_text_field( $short_key ) ),
                    'product' => defined( 'MRBP_PRODUCT_ID' ) ? sanitize_key( (string) MRBP_PRODUCT_ID ) : 'mr-commerce',
                    'site_url' => home_url( '/' ),
                ),
            )
        );
        if ( is_wp_error( $response ) ) {
            return array( 'message' => __( 'The License Manager could not be reached. Try again later.', 'mr-commerce' ) );
        }
        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( 200 !== wp_remote_retrieve_response_code( $response ) || ! is_array( $body ) || empty( $body['token'] ) ) {
            return array( 'message' => __( 'The short license key is invalid for this product or domain.', 'mr-commerce' ) );
        }
        return array( 'token' => sanitize_textarea_field( (string) $body['token'] ) );
    }

    public function refresh(): array {
        $data = $this->repository->get();
        $token = trim( (string) $data['key'] );
        if ( '' === $token ) {
            return array(
                'valid'   => false,
                'status'  => 'not_activated',
                'message' => __( 'No local license token is stored.', 'mr-commerce' ),
                'payload' => array(),
            );
        }

        $result = $this->verifier->verify( $token, $this->domains->current() );
        $result = $this->apply_remote_status( $token, $result );
        $this->repository->save_verification( $token, $result, false );
        $this->repository->add_activity( 'refresh', (string) $result['status'], (string) $result['message'] );
        self::$runtime_results = array();

        return $result;
    }

    public function deactivate(): array {
        $this->repository->clear();
        $message = __( 'The local license was deactivated on this website.', 'mr-commerce' );
        $this->repository->add_activity( 'deactivate', 'not_activated', $message );
        self::$runtime_results = array();

        return array(
            'valid'   => false,
            'status'  => 'not_activated',
            'message' => $message,
            'payload' => array(),
        );
    }

    public function import_bundled_license(): array {
        $path = MRBP_PATH . self::BUNDLED_LICENSE;
        if ( ! is_readable( $path ) ) {
            return array(
                'valid'   => false,
                'status'  => 'not_activated',
                'message' => __( 'No bundled customer license was found.', 'mr-commerce' ),
                'payload' => array(),
            );
        }

        $token = trim( (string) file_get_contents( $path ) );
        return $this->activate( $token, 'bundled' );
    }

    public function maybe_import_bundled_license(): void {
        $data = $this->repository->get();
        $path = MRBP_PATH . self::BUNDLED_LICENSE;
        if ( '' !== trim( (string) $data['key'] ) || ! is_readable( $path ) ) {
            return;
        }

        $attempt_key = 'mrbp_bundled_license_attempt_' . md5( $this->domains->current() );
        if ( get_transient( $attempt_key ) ) {
            return;
        }

        $result = $this->import_bundled_license();
        if ( empty( $result['valid'] ) ) {
            set_transient( $attempt_key, 1, 5 * MINUTE_IN_SECONDS );
        }
    }

    /**
     * Runtime checks are cached by both signed token and current domain.
     * A copied database therefore cannot reuse the source site's cache.
     */
    public function runtime_status(): array {
        $data   = $this->repository->get();
        $token  = trim( (string) $data['key'] );
        $domain = $this->domains->current();
        $key    = hash( 'sha256', $token . '|' . $domain );

        if ( isset( self::$runtime_results[ $key ] ) ) {
            return self::$runtime_results[ $key ];
        }

        if ( '' === $token ) {
            return self::$runtime_results[ $key ] = array(
                'valid'   => false,
                'status'  => 'not_activated',
                'message' => __( 'MR Commerce Pro is not activated for this website.', 'mr-commerce' ),
                'payload' => array(),
            );
        }

        $transient_key = 'mrbp_license_runtime_' . md5( $token . '|' . $domain );
        $cached = get_transient( $transient_key );
        if ( is_array( $cached ) && isset( $cached['valid'], $cached['status'] ) ) {
            return self::$runtime_results[ $key ] = $cached;
        }

        $result = $this->verifier->verify( $token, $domain );
        $result = $this->apply_remote_status( $token, $result );
        set_transient( $transient_key, $result, ! empty( $result['valid'] ) ? 15 * MINUTE_IN_SECONDS : 5 * MINUTE_IN_SECONDS );

        return self::$runtime_results[ $key ] = $result;
    }

    private function apply_remote_status( string $token, array $result ): array {
        if ( empty( $result['valid'] ) ) {
            return $result;
        }
        $response = wp_safe_remote_post(
            self::STATUS_ENDPOINT,
            array(
                'timeout' => 8,
                'redirection' => 1,
                'body' => array(
                    'token_hash' => hash( 'sha256', $token ),
                    'product' => defined( 'MRBP_PRODUCT_ID' ) ? sanitize_key( (string) MRBP_PRODUCT_ID ) : 'mr-commerce',
                    'site_url' => home_url( '/' ),
                ),
            )
        );
        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
            return $result;
        }
        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $body ) || ! array_key_exists( 'active', $body ) ) {
            return $result;
        }
        if ( empty( $body['active'] ) ) {
            $result['valid'] = false;
            $result['status'] = 'suspended';
            $result['message'] = __( 'This license has been remotely deactivated by the license owner.', 'mr-commerce' );
        }
        return $result;
    }

    public function is_active(): bool {
        return ! empty( $this->runtime_status()['valid'] );
    }

    public function register_admin_notice(): void {
        add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
    }

    public function render_admin_notice(): void {
        if ( ! current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
            return;
        }

        $result = $this->runtime_status();
        if ( ! empty( $result['valid'] ) ) {
            return;
        }

        $license_url = admin_url( 'admin.php?page=mrbp-license' );
        printf(
            '<div class="notice notice-warning"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a></p></div>',
            esc_html__( 'MR Commerce Pro license:', 'mr-commerce' ),
            esc_html( (string) $result['message'] ),
            esc_url( $license_url ),
            esc_html__( 'Open License Center', 'mr-commerce' )
        );
    }
}
