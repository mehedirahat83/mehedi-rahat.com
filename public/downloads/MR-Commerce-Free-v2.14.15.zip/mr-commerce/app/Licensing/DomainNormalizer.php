<?php

namespace MRBP\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class DomainNormalizer {

    public function current(): string {
        return $this->normalize( home_url( '/' ) );
    }

    public function normalize( string $value ): string {
        $value = strtolower( trim( $value ) );
        if ( '' === $value ) {
            return '';
        }

        if ( false === strpos( $value, '://' ) ) {
            $value = 'https://' . $value;
        }

        $host = (string) wp_parse_url( $value, PHP_URL_HOST );
        $host = strtolower( rtrim( trim( $host ), '.' ) );

        if ( str_starts_with( $host, 'www.' ) ) {
            $host = substr( $host, 4 );
        }

        if ( function_exists( 'idn_to_ascii' ) && '' !== $host ) {
            $variant = defined( 'INTL_IDNA_VARIANT_UTS46' ) ? INTL_IDNA_VARIANT_UTS46 : 0;
            $ascii = idn_to_ascii( $host, IDNA_DEFAULT, $variant );
            if ( false !== $ascii ) {
                $host = strtolower( $ascii );
            }
        }

        return preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/', $host )
            ? $host
            : '';
    }

    public function matches( string $current, string $licensed ): bool {
        $current  = $this->normalize( $current );
        $licensed = $this->normalize( $licensed );

        return '' !== $current && hash_equals( $licensed, $current );
    }
}
