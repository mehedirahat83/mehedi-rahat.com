<?php

namespace MRBP\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LicenseRepository {

    private const DATA_OPTION     = 'mrbp_license_data';
    private const STATUS_OPTION   = 'mrbp_license_status';
    private const CHECK_OPTION    = 'mrbp_license_last_check';
    private const ACTIVITY_OPTION = 'mrbp_license_activity';

    public function get(): array {
        $defaults = array(
            'key'            => '',
            'license_id'     => '',
            'customer'       => '',
            'email'          => '',
            'status'         => 'not_activated',
            'plan'           => '',
            'modules'        => array(),
            'entitlements'   => array(),
            'domain'         => '',
            'staging_domain' => '',
            'activated_at'   => '',
            'expires_at'     => '',
            'last_checked'   => '',
            'verified_domain'=> '',
            'token_hash'     => '',
        );
        $data = get_option( self::DATA_OPTION, array() );

        return wp_parse_args( is_array( $data ) ? $data : array(), $defaults );
    }

    public function save_verification( string $token, array $result, bool $activation = false ): void {
        $existing = $this->get();
        $old_token = (string) $existing['key'];
        $payload  = is_array( $result['payload'] ?? null ) ? $result['payload'] : array();
        $now      = current_time( 'mysql', true );
        $active   = ! empty( $result['valid'] );

        $data = array(
            'key'             => $token,
            'license_id'      => sanitize_text_field( (string) ( $payload['license_id'] ?? $existing['license_id'] ) ),
            'customer'        => sanitize_text_field( (string) ( $payload['customer'] ?? $existing['customer'] ) ),
            'email'           => sanitize_email( (string) ( $payload['email'] ?? $existing['email'] ) ),
            'status'          => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'plan'            => sanitize_key( (string) ( $payload['plan'] ?? $existing['plan'] ) ),
            'modules'         => array_values( array_filter( array_map( 'sanitize_key', (array) ( $payload['modules'] ?? $existing['modules'] ) ) ) ),
            'entitlements'    => array_values( array_filter( array_map( 'sanitize_key', (array) ( $payload['entitlements'] ?? $existing['entitlements'] ) ) ) ),
            'domain'          => sanitize_text_field( (string) ( $payload['domain'] ?? $existing['domain'] ) ),
            'staging_domain'  => sanitize_text_field( (string) ( $payload['staging_domain'] ?? $existing['staging_domain'] ) ),
            'activated_at'    => $activation && $active ? $now : (string) $existing['activated_at'],
            'expires_at'      => sanitize_text_field( (string) ( $payload['expires_at'] ?? $existing['expires_at'] ) ),
            'last_checked'    => $now,
            'verified_domain' => $active ? ( new DomainNormalizer() )->current() : '',
            'token_hash'      => hash( 'sha256', $token ),
        );

        update_option( self::DATA_OPTION, $data, false );
        update_option( self::STATUS_OPTION, $data['status'], false );
        update_option( self::CHECK_OPTION, $now, false );
        $this->clear_runtime_cache( $old_token );
        $this->clear_runtime_cache( $token );
    }

    public function clear(): void {
        $data = $this->get();
        $old_token = (string) $data['key'];
        $data = array_merge(
            $data,
            array(
                'key'             => '',
                'status'          => 'not_activated',
                'activated_at'    => '',
                'last_checked'    => current_time( 'mysql', true ),
                'verified_domain' => '',
                'token_hash'      => '',
            )
        );
        update_option( self::DATA_OPTION, $data, false );
        update_option( self::STATUS_OPTION, 'not_activated', false );
        update_option( self::CHECK_OPTION, $data['last_checked'], false );
        $this->clear_runtime_cache( $old_token );
    }

    public function add_activity( string $action, string $status, string $message, array $context = array() ): void {
        $activity = get_option( self::ACTIVITY_OPTION, array() );
        $activity = is_array( $activity ) ? $activity : array();
        array_unshift(
            $activity,
            array(
                'action'     => sanitize_key( $action ),
                'status'     => sanitize_key( $status ),
                'message'    => sanitize_text_field( $message ),
                'domain'     => sanitize_text_field( (string) ( $context['domain'] ?? ( new DomainNormalizer() )->current() ) ),
                'user_id'    => get_current_user_id(),
                'created_at' => current_time( 'mysql', true ),
            )
        );
        update_option( self::ACTIVITY_OPTION, array_slice( $activity, 0, 50 ), false );
    }

    public function activity( int $limit = 20 ): array {
        $activity = get_option( self::ACTIVITY_OPTION, array() );
        return array_slice( is_array( $activity ) ? $activity : array(), 0, max( 1, min( 50, $limit ) ) );
    }

    public function clear_runtime_cache( ?string $token = null ): void {
        $data   = $this->get();
        $domain = ( new DomainNormalizer() )->current();
        $token  = null === $token ? (string) $data['key'] : $token;
        delete_transient( 'mrbp_license_runtime_' . md5( $token . '|' . $domain ) );
    }
}
