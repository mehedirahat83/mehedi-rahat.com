<?php

namespace MRBP\Modules;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

interface ModuleInterface {

    public function id(): string;

    public function name(): string;

    public function description(): string;

    /**
     * @return array<int, string>
     */
    public function dependencies(): array;

    public function is_available(): bool;

    public function register(): void;

    public function boot(): void;
}
