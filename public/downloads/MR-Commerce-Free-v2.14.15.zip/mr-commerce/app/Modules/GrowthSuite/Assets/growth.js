(function($){
  const get=(k)=>{try{return JSON.parse(localStorage.getItem('mrc_'+k)||'[]')}catch(e){return[]}};
  const set=(k,v)=>localStorage.setItem('mrc_'+k,JSON.stringify(v));
  function render(kind){let a=get(kind),el=$('[data-mrc-saved-list="'+kind+'"]');if(!a.length){el.text('No saved products yet.');return}el.html('<table><tbody>'+a.map(x=>'<tr><td><a href="'+x.url+'">'+x.title+'</a></td><td>'+x.price+'</td></tr>').join('')+'</tbody></table>')}
  function toggle(kind,item,limit){let a=get(kind),i=a.findIndex(x=>String(x.id)===String(item.id));if(i>=0)a.splice(i,1);else{if(limit>0&&a.length>=limit)a.shift();a.push(item)}set(kind,a);render(kind)}
  $(document).on('click','.mrc-wishlist-toggle',function(){toggle('wishlist',{id:$(this).data('product'),title:$(this).data('title'),url:$(this).data('url'),price:$(this).data('price')},mrcGrowth.wishlistLimit)});
  $(document).on('click','.mrc-compare-toggle',function(){toggle('compare',{id:$(this).data('product'),title:$(this).data('title'),url:$(this).data('url'),price:$(this).data('price')},mrcGrowth.compareLimit)});
  $('[data-mrc-saved-list]').each(function(){render($(this).data('mrc-saved-list'))});
  $(document).on('click','.mrc-quick-view',function(){$.post(mrcGrowth.ajaxUrl,{action:'mrc_quick_view',nonce:mrcGrowth.quickNonce,product_id:$(this).data('product')},function(r){if(r.success){$('.mrc-modal-body').html(r.data.html);$('.mrc-quick-modal').attr('aria-hidden','false').addClass('is-open')}})});
  $(document).on('click','.mrc-modal-close',()=>$('.mrc-quick-modal').attr('aria-hidden','true').removeClass('is-open'));
  $(document).on('click','.mrc-side-cart-open',()=>$('.mrc-side-cart').attr('aria-hidden','false').addClass('is-open'));
  $(document).on('click','.mrc-side-cart-close',()=>$('.mrc-side-cart').attr('aria-hidden','true').removeClass('is-open'));
  $(document).on('click','[data-mrc-scroll-cart]',()=>document.querySelector('form.cart')?.scrollIntoView({behavior:'smooth'}));
  $(document).on('click','.mrc-growth-add-set',function(){let b=$(this);$.post(mrcGrowth.ajaxUrl,{action:'mrc_growth_add_products',nonce:b.data('nonce'),products:b.data('products')},function(r){if(r.success){$(document.body).trigger('wc_fragment_refresh');if(mrcGrowth.sideCartAdvanced)$('.mrc-side-cart').addClass('is-open').attr('aria-hidden','false')}})});
  if(mrcGrowth.swatchesAdvanced)$('select[data-mrc-swatches="1"]').each(function(){let s=$(this),w=$('<div class="mrc-swatches"/>');s.find('option[value!=""]').each(function(){let o=$(this),b=$('<button type="button"/>').text(o.text()).on('click',()=>{s.val(o.val()).trigger('change');w.find('button').removeClass('is-active');b.addClass('is-active')});w.append(b)});s.after(w)});
})(jQuery);
