<?php

namespace MRBP\Modules\GrowthSuite;

defined( 'ABSPATH' ) || exit;

final class MerchandisingManager {
    public function register(): void {
        add_action( 'woocommerce_product_options_related', array( $this, 'fields' ) );
        add_action( 'woocommerce_process_product_meta', array( $this, 'save' ) );
        add_action( 'woocommerce_after_single_product_summary', array( $this, 'product_offers' ), 18 );
        add_action( 'woocommerce_review_order_before_payment', array( $this, 'order_bump' ) );
        add_action( 'wp_ajax_mrc_growth_add_products', array( $this, 'add_products' ) );
        add_action( 'wp_ajax_nopriv_mrc_growth_add_products', array( $this, 'add_products' ) );
    }

    public function fields(): void {
        echo '<div class="options_group"><p class="form-field"><strong>' . esc_html__( 'MR Growth merchandising', 'mr-commerce' ) . '</strong></p>';
        woocommerce_wp_text_input( array( 'id' => '_mrc_bundle_products', 'label' => __( 'Bundle product IDs', 'mr-commerce' ), 'description' => __( 'Comma-separated IDs. Free uses the first item; Pro supports multiple.', 'mr-commerce' ), 'desc_tip' => true ) );
        woocommerce_wp_text_input( array( 'id' => '_mrc_fbt_products', 'label' => __( 'Frequently bought IDs', 'mr-commerce' ) ) );
        woocommerce_wp_text_input( array( 'id' => '_mrc_order_bump_product', 'label' => __( 'Order bump product ID', 'mr-commerce' ), 'type' => 'number' ) );
        echo '</div>';
    }

    public function save( int $id ): void {
        if ( ! current_user_can( 'edit_post', $id ) ) { return; }
        foreach ( array( '_mrc_bundle_products' => 'product_bundle', '_mrc_fbt_products' => 'frequently_bought_together' ) as $key => $feature ) {
            $ids = array_values( array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) ) ) ) ) );
            if ( ! mrc_can( 'growth.' . $feature . '.advanced' ) ) { $ids = array_slice( $ids, 0, 1 ); }
            update_post_meta( $id, $key, implode( ',', $ids ) );
        }
        update_post_meta( $id, '_mrc_order_bump_product', absint( $_POST['_mrc_order_bump_product'] ?? 0 ) );
    }

    private function ids( int $product_id, string $key ): array {
        return array_values( array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $product_id, $key, true ) ) ) ) );
    }

    public function product_offers(): void {
        global $product; if ( ! $product instanceof \WC_Product ) { return; }
        $offers = array(
            array( '_mrc_bundle_products', 'product_bundle', __( 'Bundle & save', 'mr-commerce' ) ),
            array( '_mrc_fbt_products', 'frequently_bought_together', __( 'Frequently bought together', 'mr-commerce' ) ),
        );
        foreach ( $offers as [ $key, $feature, $title ] ) {
            if ( ! mrc_can( 'growth.' . $feature . '.basic' ) ) { continue; }
            $ids = $this->ids( $product->get_id(), $key ); if ( ! $ids ) { continue; }
            echo '<section class="mrc-growth-offer"><h3>' . esc_html( $title ) . '</h3><div class="mrc-growth-products">';
            foreach ( $ids as $id ) { $related = wc_get_product( $id ); if ( ! $related || ! $related->is_purchasable() ) { continue; } echo '<label><input type="checkbox" checked value="' . esc_attr( (string) $id ) . '"> ' . esc_html( $related->get_name() ) . ' — ' . wp_kses_post( $related->get_price_html() ) . '</label>'; }
            echo '</div><button type="button" class="button mrc-growth-add-set" data-products="' . esc_attr( implode( ',', $ids ) ) . '" data-nonce="' . esc_attr( wp_create_nonce( 'mrc_growth_add_products' ) ) . '">' . esc_html__( 'Add selected items', 'mr-commerce' ) . '</button></section>';
        }
    }

    public function order_bump(): void {
        if ( ! mrc_can( 'growth.order_bump.basic' ) || ! WC()->cart ) { return; }
        foreach ( WC()->cart->get_cart() as $item ) {
            $id = absint( get_post_meta( $item['product_id'], '_mrc_order_bump_product', true ) );
            $bump = $id ? wc_get_product( $id ) : false;
            if ( $bump && $bump->is_purchasable() && ! $this->in_cart( $id ) ) {
                echo '<div class="mrc-order-bump"><strong>' . esc_html__( 'Special add-on', 'mr-commerce' ) . '</strong><p>' . esc_html( $bump->get_name() ) . ' — ' . wp_kses_post( $bump->get_price_html() ) . ' <button type="button" class="button mrc-growth-add-set" data-products="' . esc_attr( (string) $id ) . '" data-nonce="' . esc_attr( wp_create_nonce( 'mrc_growth_add_products' ) ) . '">' . esc_html__( 'Add to order', 'mr-commerce' ) . '</button></p></div>';
                break;
            }
        }
    }

    private function in_cart( int $id ): bool { foreach ( WC()->cart->get_cart() as $item ) { if ( (int) $item['product_id'] === $id ) { return true; } } return false; }

    public function add_products(): void {
        check_ajax_referer( 'mrc_growth_add_products', 'nonce' );
        if ( ! mrc_can( 'growth.product_bundle.basic' ) && ! mrc_can( 'growth.frequently_bought_together.basic' ) && ! mrc_can( 'growth.order_bump.basic' ) ) { wp_send_json_error( array( 'message' => __( 'Growth merchandising is unavailable.', 'mr-commerce' ) ), 403 ); }
        $ids = array_values( array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_POST['products'] ?? '' ) ) ) ) ) );
        $advanced = mrc_can( 'growth.product_bundle.advanced' ) || mrc_can( 'growth.frequently_bought_together.advanced' );
        $ids = array_slice( $ids, 0, $advanced ? 20 : 1 );
        $added = 0; foreach ( $ids as $id ) { $product = wc_get_product( $id ); if ( $product && $product->is_purchasable() && WC()->cart->add_to_cart( $id ) ) { $added++; } }
        wp_send_json_success( array( 'added' => $added, 'cart_url' => wc_get_cart_url() ) );
    }
}
