<?php

namespace MRBP\Modules\GrowthSuite;

defined( 'ABSPATH' ) || exit;

use MRBP\Modules\ModuleInterface;
use MRBP\Modules\RetentionSuite\ProviderManager;
use MRBP\Modules\RetentionSuite\RetentionAdmin;
use MRBP\Modules\RetentionSuite\RetentionPrivacy;
use MRBP\Modules\RetentionSuite\RetentionWorkflows;

final class GrowthSuiteModule implements ModuleInterface {
    private bool $registered = false;
    private bool $booted = false;
    public function id(): string { return 'growth_suite'; }
    public function name(): string { return __( 'MR Growth Suite', 'mr-commerce' ); }
    public function description(): string { return __( 'WooCommerce discounts, merchandising and conversion tools.', 'mr-commerce' ); }
    public function dependencies(): array { return array( 'woocommerce' ); }
    public function is_available(): bool { return class_exists( 'WooCommerce' ) && function_exists( 'WC' ); }
    public function register(): void {
        if ( $this->registered ) { return; } $this->registered = true;
        ( new DiscountEngine() )->register();
        ( new MerchandisingManager() )->register();
        ( new StorefrontExperience() )->register();
        ( new RetentionWorkflows() )->register();
        ( new ProviderManager() )->register_messaging();
        ( new RetentionPrivacy() )->register();
        if ( is_admin() ) {
            ( new GrowthAdmin() )->register();
            ( new RetentionAdmin() )->register();
        }
    }
    public function boot(): void { if ( $this->booted ) { return; } $this->booted = true; do_action( 'mrc/growth_suite/booted', $this ); }
}
