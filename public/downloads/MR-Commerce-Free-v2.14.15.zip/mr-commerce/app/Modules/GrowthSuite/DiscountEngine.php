<?php

namespace MRBP\Modules\GrowthSuite;

defined( 'ABSPATH' ) || exit;

final class DiscountEngine {
    private bool $calculating = false;

    public function register(): void {
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'discounts' ), 30 );
        add_action( 'woocommerce_before_calculate_totals', array( $this, 'auto_coupon' ), 20 );
    }

    private function settings(): array {
        return wp_parse_args( get_option( 'mrc_growth_settings', array() ), array(
            'quantity_enabled' => 'yes', 'quantity_min' => 3, 'quantity_percent' => 5,
            'bogo_enabled' => 'no', 'bogo_buy' => 2, 'bogo_free' => 1,
            'cart_enabled' => 'no', 'cart_min' => 1000, 'cart_percent' => 5,
            'auto_coupon_enabled' => 'no', 'auto_coupon_code' => '',
            'advanced_discount_rules' => '[]',
        ) );
    }

    public function discounts( $cart ): void {
        if ( $this->calculating || is_admin() && ! wp_doing_ajax() || ! $cart instanceof \WC_Cart ) { return; }
        $this->calculating = true; $s = $this->settings();
        $quantity_discount = 0.0; $bogo_discount = 0.0;
        foreach ( $cart->get_cart() as $item ) {
            $qty = max( 0, (int) $item['quantity'] ); $line = (float) $item['line_subtotal'];
            if ( 'yes' === $s['quantity_enabled'] && mrc_can( 'growth.quantity_discount.basic' ) && $qty >= max( 2, (int) $s['quantity_min'] ) ) {
                $quantity_discount += $line * min( 100, max( 0, (float) $s['quantity_percent'] ) ) / 100;
            }
            if ( 'yes' === $s['bogo_enabled'] && mrc_can( 'growth.bogo.basic' ) ) {
                $buy = max( 1, (int) $s['bogo_buy'] ); $free = max( 1, (int) $s['bogo_free'] ); $group = $buy + $free;
                $free_units = intdiv( $qty, $group ) * $free;
                if ( $free_units > 0 && $qty > 0 ) { $bogo_discount += ( $line / $qty ) * $free_units; }
            }
        }
        if ( $quantity_discount > 0 ) { $cart->add_fee( __( 'Quantity discount', 'mr-commerce' ), -$quantity_discount, false ); }
        if ( $bogo_discount > 0 ) { $cart->add_fee( __( 'BOGO discount', 'mr-commerce' ), -$bogo_discount, false ); }
        if ( mrc_can( 'growth.cart_discount.advanced' ) ) { $this->advanced_rules( $cart, (string) $s['advanced_discount_rules'] ); }
        $this->calculating = false;
    }

    private function advanced_rules( \WC_Cart $cart, string $json ): void {
        $rules = json_decode( $json, true ); if ( ! is_array( $rules ) ) { return; }
        foreach ( $rules as $rule ) {
            if ( ! is_array( $rule ) || ( array_key_exists( 'enabled', $rule ) && empty( $rule['enabled'] ) ) ) { continue; }
            $subtotal = (float) $cart->get_subtotal(); $qty = (int) $cart->get_cart_contents_count();
            if ( ! empty( $rule['min_value'] ) && $subtotal < (float) $rule['min_value'] ) { continue; }
            if ( ! empty( $rule['min_quantity'] ) && $qty < (int) $rule['min_quantity'] ) { continue; }
            if ( ! empty( $rule['role'] ) ) {
                $user = wp_get_current_user();
                if ( ! $user->exists() || ! in_array( sanitize_key( $rule['role'] ), (array) $user->roles, true ) ) { continue; }
            }
            if ( ! empty( $rule['category'] ) && ! $this->cart_has_category( $cart, absint( $rule['category'] ) ) ) { continue; }
            $type = 'fixed' === ( $rule['type'] ?? '' ) ? 'fixed' : 'percent';
            $configured = isset( $rule['amount'] ) ? (float) $rule['amount'] : (float) ( $rule['percent'] ?? 0 );
            $amount = 'fixed' === $type ? min( $subtotal, max( 0, $configured ) ) : $subtotal * min( 100, max( 0, $configured ) ) / 100;
            if ( ! empty( $rule['max_discount'] ) ) { $amount = min( $amount, (float) $rule['max_discount'] ); }
            if ( $amount > 0 ) { $cart->add_fee( sanitize_text_field( $rule['label'] ?? __( 'Promotional discount', 'mr-commerce' ) ), -$amount, false ); }
        }
    }

    private function cart_has_category( \WC_Cart $cart, int $category_id ): bool {
        foreach ( $cart->get_cart() as $item ) {
            $product_id = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
            if ( $product_id && has_term( $category_id, 'product_cat', $product_id ) ) { return true; }
        }
        return false;
    }

    public function auto_coupon( $cart ): void {
        if ( ! $cart instanceof \WC_Cart || ! mrc_can( 'growth.auto_coupon.basic' ) ) { return; }
        $s = $this->settings();
        $codes = array_filter( array_map( 'wc_format_coupon_code', explode( ',', (string) $s['auto_coupon_code'] ) ) );
        if ( ! mrc_can( 'growth.auto_coupon.advanced' ) ) { $codes = array_slice( $codes, 0, 1 ); }
        if ( 'yes' === $s['auto_coupon_enabled'] ) { foreach ( $codes as $code ) { if ( ! $cart->has_discount( $code ) && wc_get_coupon_id_by_code( $code ) ) { $cart->apply_coupon( $code ); } } }
    }
}
