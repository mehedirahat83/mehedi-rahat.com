<?php

namespace MRBP\Modules\GrowthSuite;

defined( 'ABSPATH' ) || exit;

final class StorefrontExperience {
    public function register(): void {
        add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
        add_action( 'wp_footer', array( $this, 'footer_ui' ) );
        add_action( 'woocommerce_after_shop_loop_item', array( $this, 'product_actions' ), 25 );
        add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'single_actions' ) );
        add_filter( 'woocommerce_dropdown_variation_attribute_options_html', array( $this, 'swatch_class' ), 20 );
        add_action( 'template_redirect', array( $this, 'remember_view' ) );
        add_shortcode( 'mrc_wishlist', array( $this, 'wishlist_shortcode' ) );
        add_shortcode( 'mrc_compare', array( $this, 'compare_shortcode' ) );
        add_shortcode( 'mrc_recently_viewed', array( $this, 'recent_shortcode' ) );
        add_action( 'wp_ajax_mrc_quick_view', array( $this, 'quick_view' ) );
        add_action( 'wp_ajax_nopriv_mrc_quick_view', array( $this, 'quick_view' ) );
    }

    public function assets(): void {
        if ( is_admin() ) { return; }
        wp_enqueue_style( 'mrc-growth', MRBP_URL . 'app/Modules/GrowthSuite/Assets/growth.css', array(), MRBP_VERSION );
        wp_enqueue_script( 'mrc-growth', MRBP_URL . 'app/Modules/GrowthSuite/Assets/growth.js', array( 'jquery', 'wc-cart-fragments' ), MRBP_VERSION, true );
        wp_localize_script( 'mrc-growth', 'mrcGrowth', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'quickNonce' => wp_create_nonce( 'mrc_quick_view' ),
            'wishlistLimit' => mrc_can( 'growth.wishlist.advanced' ) ? -1 : 10,
            'compareLimit' => mrc_can( 'growth.compare.advanced' ) ? 8 : 2,
            'swatchesAdvanced' => mrc_can( 'growth.variation_swatches.advanced' ),
            'sideCartAdvanced' => mrc_can( 'growth.side_cart.advanced' ),
        ) );
    }

    public function product_actions(): void {
        global $product; if ( ! $product instanceof \WC_Product ) { return; }
        $id = $product->get_id();
        $saved_data = ' data-product="' . esc_attr( (string) $id ) . '" data-title="' . esc_attr( $product->get_name() ) . '" data-url="' . esc_url( $product->get_permalink() ) . '" data-price="' . esc_attr( wp_strip_all_tags( $product->get_price_html() ) ) . '"';
        if ( mrc_can( 'growth.wishlist.basic' ) ) { echo '<button type="button" class="button mrc-wishlist-toggle"' . $saved_data . '>' . esc_html__( 'Wishlist', 'mr-commerce' ) . '</button>'; }
        if ( mrc_can( 'growth.compare.basic' ) ) { echo '<button type="button" class="button mrc-compare-toggle"' . $saved_data . '>' . esc_html__( 'Compare', 'mr-commerce' ) . '</button>'; }
        if ( mrc_can( 'growth.quick_view.basic' ) ) { echo '<button type="button" class="button mrc-quick-view" data-product="' . esc_attr( (string) $id ) . '">' . esc_html__( 'Quick view', 'mr-commerce' ) . '</button>'; }
    }

    public function single_actions(): void { $this->product_actions(); }

    public function swatch_class( string $html ): string {
        return mrc_can( 'growth.variation_swatches.basic' ) ? str_replace( '<select', '<select data-mrc-swatches="1"', $html ) : $html;
    }

    public function remember_view(): void {
        if ( ! is_product() || ! mrc_can( 'growth.recently_viewed.basic' ) ) { return; }
        $id = get_queried_object_id(); if ( ! $id ) { return; }
        $ids = array_values( array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_COOKIE['mrc_recent_products'] ?? '' ) ) ) ) ) );
        $ids = array_values( array_unique( array_merge( array( $id ), $ids ) ) );
        $limit = mrc_can( 'growth.recently_viewed.advanced' ) ? 30 : 6;
        setcookie( 'mrc_recent_products', implode( ',', array_slice( $ids, 0, $limit ) ), time() + MONTH_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
    }

    public function footer_ui(): void {
        if ( mrc_can( 'growth.side_cart.basic' ) ) {
            echo '<aside class="mrc-side-cart" aria-hidden="true"><button type="button" class="mrc-side-cart-close" aria-label="' . esc_attr__( 'Close cart', 'mr-commerce' ) . '">×</button><h2>' . esc_html__( 'Your cart', 'mr-commerce' ) . '</h2><div class="widget_shopping_cart_content">'; woocommerce_mini_cart(); echo '</div></aside><button type="button" class="mrc-side-cart-open">' . esc_html__( 'Cart', 'mr-commerce' ) . '</button>';
        }
        if ( mrc_can( 'growth.free_shipping_bar.basic' ) && WC()->cart ) {
            $target = mrc_can( 'growth.free_shipping_bar.advanced' ) ? max( 1, (float) get_option( 'mrc_growth_free_shipping_target', 2000 ) ) : 2000; $subtotal = (float) WC()->cart->get_subtotal(); $percent = min( 100, ( $subtotal / $target ) * 100 );
            echo '<div class="mrc-shipping-progress"><span style="width:' . esc_attr( (string) $percent ) . '%"></span><p>' . ( $subtotal >= $target ? esc_html__( 'You unlocked free shipping!', 'mr-commerce' ) : wp_kses_post( sprintf( __( 'Add %s more for free shipping.', 'mr-commerce' ), wc_price( $target - $subtotal ) ) ) ) . '</p></div>';
        }
        if ( is_product() && mrc_can( 'growth.sticky_add_to_cart.basic' ) ) { global $product; if ( $product instanceof \WC_Product ) { echo '<div class="mrc-sticky-cart"><strong>' . esc_html( $product->get_name() ) . '</strong><span>' . wp_kses_post( $product->get_price_html() ) . '</span><button type="button" data-mrc-scroll-cart>' . esc_html__( 'Add to cart', 'mr-commerce' ) . '</button></div>'; } }
        echo '<div class="mrc-quick-modal" aria-hidden="true"><button type="button" class="mrc-modal-close">×</button><div class="mrc-modal-body"></div></div>';
    }

    public function wishlist_shortcode(): string { return '<div class="mrc-saved-products" data-mrc-saved-list="wishlist"></div>'; }
    public function compare_shortcode(): string { return '<div class="mrc-saved-products" data-mrc-saved-list="compare"></div>'; }
    public function recent_shortcode(): string { return $this->products_html( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( $_COOKIE['mrc_recent_products'] ?? '' ) ) ) ) ); }

    private function products_html( array $ids ): string {
        ob_start(); echo '<ul class="products columns-4">';
        foreach ( array_filter( $ids ) as $id ) { $post = get_post( $id ); if ( ! $post || 'product' !== $post->post_type ) { continue; } setup_postdata( $GLOBALS['post'] = $post ); wc_get_template_part( 'content', 'product' ); }
        wp_reset_postdata(); echo '</ul>'; return (string) ob_get_clean();
    }

    public function quick_view(): void {
        check_ajax_referer( 'mrc_quick_view', 'nonce' );
        if ( ! mrc_can( 'growth.quick_view.basic' ) ) { wp_send_json_error(); }
        $product = wc_get_product( absint( $_POST['product_id'] ?? 0 ) ); if ( ! $product ) { wp_send_json_error(); }
        $action = '<a class="button" href="' . esc_url( $product->get_permalink() ) . '">' . esc_html__( 'View product', 'mr-commerce' ) . '</a>';
        if ( mrc_can( 'growth.quick_view.advanced' ) && $product->is_type( 'simple' ) && $product->is_purchasable() ) { $action = '<a class="button add_to_cart_button ajax_add_to_cart" data-product_id="' . esc_attr( (string) $product->get_id() ) . '" href="' . esc_url( $product->add_to_cart_url() ) . '">' . esc_html__( 'Add to cart', 'mr-commerce' ) . '</a> ' . $action; }
        wp_send_json_success( array( 'html' => '<div class="mrc-quick-product">' . $product->get_image( 'woocommerce_single' ) . '<div><h2>' . esc_html( $product->get_name() ) . '</h2>' . wp_kses_post( $product->get_price_html() ) . '<p>' . wp_kses_post( wp_trim_words( $product->get_short_description(), 35 ) ) . '</p>' . $action . '</div></div>' ) );
    }
}
