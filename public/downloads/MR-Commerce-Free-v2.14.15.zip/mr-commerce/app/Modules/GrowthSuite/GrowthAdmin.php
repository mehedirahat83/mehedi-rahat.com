<?php

namespace MRBP\Modules\GrowthSuite;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;
use MRBP\Modules\RetentionSuite\RetentionAdmin;

final class GrowthAdmin {
    private const FEATURES = array(
        'quantity_discount' => 'Quantity Discount', 'bogo' => 'BOGO',
        'cart_discount' => 'Cart Discount Rules', 'product_bundle' => 'Product Bundle / Combo',
        'frequently_bought_together' => 'Frequently Bought Together', 'order_bump' => 'Order Bump',
        'auto_coupon' => 'Auto Coupon', 'side_cart' => 'Side Cart',
        'free_shipping_bar' => 'Free Shipping Progress Bar', 'sticky_add_to_cart' => 'Sticky Add to Cart',
        'variation_swatches' => 'Variation Swatches', 'wishlist' => 'Wishlist',
        'compare' => 'Compare', 'quick_view' => 'Quick View', 'recently_viewed' => 'Recently Viewed',
    );

    public function register(): void {
        add_action( 'admin_menu', array( $this, 'menu' ), 40 );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_filter( 'option_page_capability_mrc_growth_group', static fn(): string => 'manage_woocommerce' );
    }
    public function menu(): void { add_submenu_page( 'mrbp-dashboard', __( 'MR Growth Suite', 'mr-commerce' ), __( 'MR Growth Suite', 'mr-commerce' ), 'manage_woocommerce', 'mrc-growth-suite', array( $this, 'render' ) ); }
    public function settings(): void { register_setting( 'mrc_growth_group', 'mrc_growth_settings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize' ), 'default' => array() ) ); }
    private function defaults(): array { return array( 'quantity_enabled' => 'yes', 'quantity_min' => 3, 'quantity_percent' => 5, 'bogo_enabled' => 'no', 'bogo_buy' => 2, 'bogo_free' => 1, 'cart_enabled' => 'no', 'cart_min' => 1000, 'cart_percent' => 5, 'auto_coupon_enabled' => 'no', 'auto_coupon_code' => '', 'free_shipping_target' => 2000, 'advanced_discount_rules' => '[]' ); }
    public function sanitize( array $in ): array {
        $old = wp_parse_args( get_option( 'mrc_growth_settings', array() ), $this->defaults() );
        $out = array(
            'quantity_enabled' => ! empty( $in['quantity_enabled'] ) ? 'yes' : 'no', 'quantity_min' => max( 2, absint( $in['quantity_min'] ?? 3 ) ), 'quantity_percent' => min( 100, max( 0, (float) ( $in['quantity_percent'] ?? 5 ) ) ),
            'bogo_enabled' => ! empty( $in['bogo_enabled'] ) ? 'yes' : 'no', 'bogo_buy' => max( 1, absint( $in['bogo_buy'] ?? 2 ) ), 'bogo_free' => max( 1, absint( $in['bogo_free'] ?? 1 ) ),
            // Deprecated basic cart discount values remain stored for rollback; Core coupons are authoritative.
            'cart_enabled' => $old['cart_enabled'], 'cart_min' => $old['cart_min'], 'cart_percent' => $old['cart_percent'],
            'auto_coupon_enabled' => ! empty( $in['auto_coupon_enabled'] ) ? 'yes' : 'no', 'auto_coupon_code' => implode( ',', array_filter( array_map( 'wc_format_coupon_code', explode( ',', (string) ( $in['auto_coupon_code'] ?? '' ) ) ) ) ),
            'free_shipping_target' => mrc_can( 'growth.free_shipping_bar.advanced' ) ? max( 1, (float) ( $in['free_shipping_target'] ?? 2000 ) ) : (float) $old['free_shipping_target'],
            'advanced_discount_rules' => (string) $old['advanced_discount_rules'],
        );
        if ( mrc_can( 'growth.cart_discount.advanced' ) ) {
            $decoded = json_decode( wp_unslash( (string) ( $in['advanced_discount_rules'] ?? '[]' ) ), true );
            if ( is_array( $decoded ) ) { $out['advanced_discount_rules'] = wp_json_encode( $this->clean_campaigns( $decoded ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ); }
        }
        update_option( 'mrc_growth_free_shipping_target', $out['free_shipping_target'], false );
        return $out;
    }
    private function clean_campaigns( array $rules ): array {
        $clean = array(); $roles = array_keys( wp_roles()->roles );
        foreach ( array_slice( $rules, 0, 100 ) as $rule ) {
            if ( ! is_array( $rule ) ) { continue; }
            $type = 'fixed' === ( $rule['type'] ?? '' ) ? 'fixed' : 'percent';
            $amount = isset( $rule['amount'] ) ? (float) $rule['amount'] : (float) ( $rule['percent'] ?? 0 );
            $role = sanitize_key( $rule['role'] ?? '' );
            $clean[] = array(
                'enabled'=>! array_key_exists( 'enabled', $rule ) || ! empty( $rule['enabled'] ),
                'label'=>sanitize_text_field( $rule['label'] ?? __( 'Promotional discount', 'mr-commerce' ) ),
                'type'=>$type, 'amount'=>max( 0, 'percent' === $type ? min( 100, $amount ) : $amount ),
                'min_value'=>max( 0, (float) ( $rule['min_value'] ?? 0 ) ), 'min_quantity'=>max( 0, absint( $rule['min_quantity'] ?? 0 ) ),
                'max_discount'=>max( 0, (float) ( $rule['max_discount'] ?? 0 ) ), 'category'=>max( 0, absint( $rule['category'] ?? 0 ) ),
                'role'=>in_array( $role, $roles, true ) ? $role : '',
            );
        }
        return $clean;
    }
    public function render(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; } $s = wp_parse_args( get_option( 'mrc_growth_settings', array() ), $this->defaults() );
        $campaigns = json_decode( (string) $s['advanced_discount_rules'], true ); $campaigns = is_array( $campaigns ) ? $campaigns : array();
        $categories = get_terms( array( 'taxonomy'=>'product_cat', 'hide_empty'=>false ) ); if ( is_wp_error( $categories ) ) { $categories = array(); }
        $roles = array(); foreach ( wp_roles()->roles as $key=>$role ) { $roles[ $key ] = translate_user_role( $role['name'] ); }
        ?><div class="wrap mrc-ops-wrap mrc-ops-growth"><?php \MRBP\Admin\OperationsUi::header( __( 'REVENUE GROWTH CENTER', 'mr-commerce' ), __( 'MR Growth Suite', 'mr-commerce' ), __( 'Launch smarter offers, merchandising tools and storefront conversion experiences from one dashboard.', 'mr-commerce' ), 'dashicons-chart-line', array( __( 'Offers', 'mr-commerce' ) => __( 'Smart', 'mr-commerce' ), __( 'Experience', 'mr-commerce' ) => __( 'Optimized', 'mr-commerce' ) ) ); ?><form method="post" action="options.php"><?php settings_fields( 'mrc_growth_group' ); ?>
        <div class="card"><?php \MRBP\Admin\OperationsUi::classification( 'enhanced' ); ?><h2><?php esc_html_e( 'Advanced discount campaigns', 'mr-commerce' ); ?></h2><table class="form-table">
        <tr><th><?php esc_html_e( 'Quantity discount', 'mr-commerce' ); ?></th><td><label><input type="checkbox" name="mrc_growth_settings[quantity_enabled]" value="1" <?php checked( 'yes', $s['quantity_enabled'] ); ?>> <?php esc_html_e( 'Enabled', 'mr-commerce' ); ?></label> <input type="number" min="2" name="mrc_growth_settings[quantity_min]" value="<?php echo esc_attr( (string) $s['quantity_min'] ); ?>"> items → <input type="number" min="0" max="100" step=".01" name="mrc_growth_settings[quantity_percent]" value="<?php echo esc_attr( (string) $s['quantity_percent'] ); ?>">%</td></tr>
        <tr><th>BOGO</th><td><div class="mrc-inline-campaign-controls mrc-bogo-controls"><label><input type="checkbox" name="mrc_growth_settings[bogo_enabled]" value="1" <?php checked( 'yes', $s['bogo_enabled'] ); ?>> <?php esc_html_e( 'Enabled', 'mr-commerce' ); ?></label><span><?php esc_html_e( 'Buy', 'mr-commerce' ); ?></span><input class="mrc-compact-number" type="number" min="1" name="mrc_growth_settings[bogo_buy]" value="<?php echo esc_attr( (string) $s['bogo_buy'] ); ?>"><span><?php esc_html_e( 'get', 'mr-commerce' ); ?></span><input class="mrc-compact-number" type="number" min="1" name="mrc_growth_settings[bogo_free]" value="<?php echo esc_attr( (string) $s['bogo_free'] ); ?>"><span><?php esc_html_e( 'free', 'mr-commerce' ); ?></span></div></td></tr>
        <tr><th><?php esc_html_e( 'Core cart discounts', 'mr-commerce' ); ?></th><td><div class="mrc-core-status"><span class="dashicons dashicons-tickets-alt"></span><div><strong><?php esc_html_e( 'Powered by WooCommerce coupons', 'mr-commerce' ); ?></strong><span><?php esc_html_e( 'Create percentage, fixed-cart, minimum-spend and usage-limit rules in WooCommerce.', 'mr-commerce' ); ?> <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=shop_coupon' ) ); ?>"><?php esc_html_e( 'Manage coupons', 'mr-commerce' ); ?></a></span></div></div></td></tr>
        <tr><th><?php esc_html_e( 'Auto-apply coupon', 'mr-commerce' ); ?></th><td><label><input type="checkbox" name="mrc_growth_settings[auto_coupon_enabled]" value="1" <?php checked( 'yes', $s['auto_coupon_enabled'] ); ?>> <?php esc_html_e( 'Automatically apply an existing WooCommerce coupon', 'mr-commerce' ); ?></label> <input type="text" name="mrc_growth_settings[auto_coupon_code]" value="<?php echo esc_attr( (string) $s['auto_coupon_code'] ); ?>" placeholder="Coupon code"></td></tr>
        <tr><th><?php esc_html_e( 'Free shipping target', 'mr-commerce' ); ?></th><td><input type="number" min="1" step=".01" name="mrc_growth_settings[free_shipping_target]" value="<?php echo esc_attr( (string) $s['free_shipping_target'] ); ?>"></td></tr></table>
        <?php \MRBP\Admin\OperationsUi::guide( 'Quantity Discount, BOGO, coupon automation এবং free-shipping progress দিয়ে cart value বাড়াতে সাহায্য করে।', array( 'প্রয়োজনীয় campaign-এর Enabled option চালু করুন।', 'Quantity, discount অথবা coupon value ঠিক করুন।', 'Save করে storefront cart-এ একটি test order দিয়ে যাচাই করুন।' ), 'Buy 2 Get 1 Free campaign দিয়ে একই product-এর প্রতি ৩টি item-এ ১টি free দেওয়া যায়।', 'একাধিক discount একসঙ্গে চালু করলে মোট discount পরীক্ষা করুন।' ); ?></div>
        <?php if ( mrc_can( 'growth.cart_discount.advanced' ) ) : ?><div class="card mrc-builder-card mrc-campaign-builder"><?php \MRBP\Admin\OperationsUi::classification( 'enhanced' ); ?><div class="mrc-builder-head"><div><h2><?php esc_html_e( 'Advanced campaign rules', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Build targeted cart campaigns without editing JSON. Rules run from top to bottom and may stack.', 'mr-commerce' ); ?></p></div><button type="button" class="button button-primary" data-mrc-add-campaign><?php esc_html_e( 'Add campaign rule', 'mr-commerce' ); ?></button></div><input type="hidden" name="mrc_growth_settings[advanced_discount_rules]" id="mrc-campaigns-json" value="<?php echo esc_attr( wp_json_encode( $campaigns ) ); ?>"><div id="mrc-campaign-rules" class="mrc-builder-list"></div><div class="mrc-campaigns-empty"><?php esc_html_e( 'No campaign rules yet. Add a targeted discount campaign.', 'mr-commerce' ); ?></div><?php \MRBP\Admin\OperationsUi::guide( 'নির্দিষ্ট cart value, quantity, category বা customer role-এর জন্য targeted discount তৈরি করে।', array( 'Add campaign rule দিয়ে campaign name ও discount type দিন।', 'Minimum value/quantity এবং targeting condition নির্বাচন করুন।', 'Maximum discount দিয়ে খরচ নিয়ন্ত্রণ করে rule চালু করুন।' ), 'শুধু Wholesale Customer role-এর ৫,০০০ টাকার cart-এ ১০% discount দেওয়া যায়।', 'Matching একাধিক rule stack করতে পারে; priority ও সর্বোচ্চ discount পরীক্ষা করুন।' ); ?></div><?php else : ProFeature::render( 'growth.cart_discount.advanced', __( 'Visual Campaign Rule Builder', 'mr-commerce' ), __( 'Build targeted cart campaigns with value, quantity, category and customer-role conditions.', 'mr-commerce' ) ); endif; ?>
        <script type="application/json" id="mrc-campaign-builder-data"><?php echo wp_json_encode( array( 'categories'=>array_values( array_map( static fn( $term ): array => array( 'id'=>$term->term_id, 'name'=>$term->name ), $categories ) ), 'roles'=>$roles ) ); ?></script>
        <?php submit_button(); ?></form>
        <?php ( new RetentionAdmin() )->render_embedded(); ?>
        <h2><?php esc_html_e( 'Growth capability matrix', 'mr-commerce' ); ?></h2><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Module', 'mr-commerce' ); ?></th><th>Free</th><th>Pro</th></tr></thead><tbody><?php foreach ( self::FEATURES as $id => $name ) : ?><tr><td><?php echo esc_html( $name ); ?></td><td><?php echo 'cart_discount' === $id ? esc_html__( 'WooCommerce Core', 'mr-commerce' ) : ( mrc_can( 'growth.' . $id . '.basic' ) ? esc_html__( 'Basic active', 'mr-commerce' ) : esc_html__( 'Disabled', 'mr-commerce' ) ); ?></td><td><?php echo mrc_can( 'growth.' . $id . '.advanced' ) ? esc_html__( 'Advanced active', 'mr-commerce' ) : '<span class="mrbp-ui-badge mrbp-ui-badge--warning">PRO</span>'; ?></td></tr><?php endforeach; ?></tbody></table></div><?php
    }
}
