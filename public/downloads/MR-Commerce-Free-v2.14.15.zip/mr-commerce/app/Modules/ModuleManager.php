<?php

namespace MRBP\Modules;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Settings;
use MRBP\Core\DependencyManager;
use MRBP\Core\PlanManager;
use MRBP\Support\Logger;
use MRBP\Security\Input;
use MRBP\Security\Security;

final class ModuleManager {

    private Settings $settings;
    private Logger $logger;
    private PlanManager $plan_manager;
    private ModuleRegistry $registry;
    private DependencyManager $dependency_manager;
    private Security $security;
    private array $enabled_modules = array();
    private array $instances = array();
    private bool $registered = false;
    private bool $booted = false;

    public function __construct(
        Settings $settings,
        Logger $logger,
        PlanManager $plan_manager,
        ModuleRegistry $registry,
        DependencyManager $dependency_manager,
        ?Security $security = null
    ) {
        $this->settings           = $settings;
        $this->logger             = $logger;
        $this->plan_manager       = $plan_manager;
        $this->registry           = $registry;
        $this->dependency_manager = $dependency_manager;
        $this->security           = $security ?? new Security( $logger );
    }

    public function register(): void {
        if ( $this->registered ) {
            return;
        }

        $this->registered      = true;
        $this->enabled_modules = $this->settings->get_enabled_modules();

        add_action( 'admin_init', array( $this, 'process_toggle_request' ) );
        do_action( 'mrbp/modules/settings_loaded', $this->enabled_modules, $this );
    }

    public function all(): array {
        $modules = array();

        foreach ( $this->registry->all() as $module_id => $config ) {
            $report                          = $this->dependency_report( $config );
            $config['required_plan']         = $config['plan'] ?? PlanManager::PLAN_FREE;
            $config['included']              = $this->is_included( $module_id, $config );
            $config['entitled']              = $this->plan_manager->feature_allowed( $module_id );
            $config['dependencies_ready']    = $report['satisfied'];
            $config['dependency_failures']   = $report['failures'];
            $config['dependency_messages']   = array_values( array_map( static fn( array $failure ): string => (string) $failure['message'], $report['failures'] ) );
            $config['available']             = $this->is_available( $module_id, $config );
            $config['enabled']               = $this->is_enabled( $module_id );
            $config['will_load']             = $this->should_load( $module_id, $config );
            $config['feature_level']         = $this->plan_manager->feature_level( $module_id );
            $modules[ $module_id ]           = $config;
        }

        return $modules;
    }

    public function enabled(): array {
        if ( empty( $this->enabled_modules ) ) {
            $this->enabled_modules = $this->settings->get_enabled_modules();
        }

        return $this->enabled_modules;
    }

    public function is_included( string $module_id, ?array $config = null ): bool {
        $config ??= $this->registry->get( $module_id );

        return ! empty( $config['class'] ) && class_exists( $config['class'] );
    }

    public function dependency_report( array $config ): array {
        return $this->dependency_manager->check( $config['dependencies'] ?? array() );
    }

    public function dependencies_satisfied( array $config ): bool {
        return $this->dependency_report( $config )['satisfied'];
    }

    public function dependency_messages( array $config ): array {
        return $this->dependency_manager->failure_messages( $config['dependencies'] ?? array() );
    }

    public function is_available( string $module_id, ?array $config = null ): bool {
        $config ??= $this->registry->get( $module_id );

        if ( null === $config ) {
            return false;
        }

        return $this->is_included( $module_id, $config )
            && $this->plan_manager->feature_allowed( $module_id )
            && $this->dependencies_satisfied( $config );
    }

    public function is_enabled( string $module_id ): bool {
        $enabled = $this->enabled();

        return ! empty( $enabled[ $module_id ] );
    }

    public function should_load( string $module_id, ?array $config = null ): bool {
        $config ??= $this->registry->get( $module_id );

        if ( null === $config ) {
            return false;
        }

        // Respect the inexpensive saved toggle before autoloading module classes
        // or evaluating environment dependencies on unrelated public requests.
        if ( ! $this->is_enabled( $module_id ) ) {
            return false;
        }

        if ( ! $this->is_included( $module_id, $config ) ) {
            return false;
        }

        if ( ! $this->plan_manager->feature_allowed( $module_id ) ) {
            return false;
        }

        if ( ! $this->dependencies_satisfied( $config ) ) {
            return false;
        }

        return true;
    }

    public function boot_enabled_modules(): void {
        if ( $this->booted ) {
            return;
        }

        $this->booted = true;

        foreach ( $this->registry->all() as $module_id => $config ) {
            if ( ! $this->should_load( $module_id, $config ) ) {
                do_action( "mrbp/module/{$module_id}/skipped", $config, $this );
                continue;
            }

            $module_started = microtime( true );
            $memory_started = memory_get_usage( true );
            $class    = $config['class'];
            $instance = new $class();

            if ( ! $instance instanceof ModuleInterface ) {
                $this->logger->error( 'Module does not implement ModuleInterface.', array( 'module' => $module_id, 'class' => $class ) );
                continue;
            }

            if ( $module_id !== $instance->id() ) {
                $this->logger->error(
                    'Module registry ID does not match the module contract ID.',
                    array( 'registry_id' => $module_id, 'contract_id' => $instance->id(), 'class' => $class )
                );
                continue;
            }

            if ( ! $instance->is_available() ) {
                $this->logger->module(
                    'Enabled module could not boot because a runtime dependency is unavailable.',
                    array( 'module' => $module_id, 'dependencies' => $instance->dependencies() )
                );
                do_action( "mrbp/module/{$module_id}/unavailable", $instance, $config, $this );
                continue;
            }

            $this->instances[ $module_id ] = $instance;
            $instance->register();
            do_action( "mrbp/module/{$module_id}/registered", $instance, $config, $this );

            $instance->boot();
            do_action( "mrbp/module/{$module_id}/boot", $instance, $config, $this );

            $duration_ms = round( ( microtime( true ) - $module_started ) * 1000, 2 );
            $memory_kb  = round( max( 0, memory_get_usage( true ) - $memory_started ) / 1024, 2 );

            $this->logger->module(
                'Module booted after package, plan, dependency and toggle checks.',
                array(
                    'module'       => $module_id,
                    'plan'         => $this->plan_manager->current_plan(),
                    'class'        => $class,
                    'dependencies' => $instance->dependencies(),
                    'boot_ms'      => $duration_ms,
                    'memory_kb'    => $memory_kb,
                )
            );

            do_action( 'mrbp/performance/module_booted', $module_id, $duration_ms, $memory_kb, $instance );
        }

        do_action( 'mrbp/modules/booted', $this );
    }

    public function process_toggle_request(): void {
        if ( empty( $_POST['mrbp_modules_nonce'] ) || empty( $_POST['mrbp_update_modules'] ) ) {
            return;
        }

        $this->security->verify_admin_action(
            'manage_options',
            'mrbp_update_modules',
            'mrbp_modules_nonce'
        );

        $submitted = Input::post_array( 'modules' );

        $enabled = array();

        foreach ( $this->registry->all() as $module_id => $config ) {
            $requested = isset( $submitted[ $module_id ] );
            $available = $this->is_available( $module_id, $config );
            $enabled[ $module_id ] = $available && $requested;

            if ( $requested && ! $available && $this->is_included( $module_id, $config ) && $this->plan_manager->feature_allowed( $module_id ) ) {
                $messages = $this->dependency_messages( $config );
                $reason = $messages[0] ?? __( 'A required dependency is unavailable.', 'mr-commerce' );
                $module_name = (string) ( $config['name'] ?? $module_id );

                add_settings_error(
                    'mrbp_messages',
                    'mrbp_module_dependency_' . $module_id,
                    sprintf(
                        /* translators: 1: module name, 2: dependency failure reason */
                        __( '%1$s could not be enabled because %2$s', 'mr-commerce' ),
                        $module_name,
                        $reason
                    ),
                    'error'
                );
            }
        }

        update_option( 'mrbp_enabled_modules', $enabled, false );
        $this->enabled_modules = $enabled;

        do_action( 'mrbp/modules/toggles_updated', $enabled, $this );

        add_settings_error(
            'mrbp_messages',
            'mrbp_modules_saved',
            __( 'Module settings saved. Only included, entitled modules with satisfied dependencies can load on the next request.', 'mr-commerce' ),
            'updated'
        );
    }

    public function instance( string $module_id ): ?ModuleInterface {
        return $this->instances[ $module_id ] ?? null;
    }
}
