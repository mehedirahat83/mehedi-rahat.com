<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

final class PhoneNormalizer {
    public static function normalize( string $phone ): string {
        $phone = strtr( $phone, array( '০'=>'0', '১'=>'1', '২'=>'2', '৩'=>'3', '৪'=>'4', '৫'=>'5', '৬'=>'6', '৭'=>'7', '৮'=>'8', '৯'=>'9' ) );
        $digits = preg_replace( '/\D+/', '', $phone ) ?: '';
        if ( str_starts_with( $digits, '00880' ) ) { $digits = substr( $digits, 4 ); }
        if ( str_starts_with( $digits, '880' ) ) { $digits = substr( $digits, 3 ); }
        if ( 10 === strlen( $digits ) && '1' === $digits[0] ) { $digits = '0' . $digits; }
        return $digits;
    }

    public static function valid_bd_mobile( string $phone ): bool {
        return 1 === preg_match( '/^01[3-9]\d{8}$/', self::normalize( $phone ) );
    }

    public static function variants( string $phone ): array {
        $normalized = self::normalize( $phone );
        if ( ! $normalized ) { return array(); }
        return array_values( array_unique( array( $normalized, '+88' . $normalized, '88' . $normalized ) ) );
    }
}
