<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

final class CourierRiskRegistry {
    /** @return CourierRiskProviderInterface[] */
    public function providers(): array {
        $providers = apply_filters( 'mrc_fraud_checker_courier_providers', array() );
        return array_values( array_filter( is_array( $providers ) ? $providers : array(), static fn( $provider ): bool => $provider instanceof CourierRiskProviderInterface ) );
    }

    public function intelligence( string $phone, \WC_Order $order ): array {
        $result = array( 'delivered'=>0, 'failed'=>0, 'returned'=>0, 'total'=>0, 'providers'=>array() );
        if ( ! mrc_can( 'fraud.courier_intelligence' ) ) { return $result; }
        foreach ( $this->providers() as $provider ) {
            if ( ! $provider->is_configured() ) { continue; }
            $data = wp_parse_args( $provider->lookup( $phone, $order ), array( 'delivered'=>0, 'failed'=>0, 'returned'=>0, 'total'=>0 ) );
            foreach ( array( 'delivered','failed','returned','total' ) as $key ) { $result[ $key ] += absint( $data[ $key ] ); }
            $result['providers'][] = $provider->id();
        }
        return $result;
    }
}
