<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

final class OrderRiskPanel {
    public function register(): void {
        add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'render' ) );
        add_filter( 'manage_edit-shop_order_columns', array( $this, 'column' ) );
        add_action( 'manage_shop_order_posts_custom_column', array( $this, 'column_value' ), 20, 2 );
        add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'column' ) );
        add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'hpos_column_value' ), 20, 2 );
        add_action( 'admin_post_mrc_fraud_rescore', array( $this, 'rescore' ) );
        add_action( 'admin_post_mrc_fraud_trust', array( $this, 'trust' ) );
    }

    public function column( array $columns ): array {
        $result = array();
        foreach ( $columns as $key => $label ) {
            $result[ $key ] = $label;
            if ( 'order_status' === $key ) { $result['mrc_fraud_risk'] = __( 'Risk', 'mr-commerce' ); }
        }
        return $result;
    }

    public function column_value( string $column, int $post_id ): void {
        if ( 'mrc_fraud_risk' === $column ) { $this->badge( wc_get_order( $post_id ) ); }
    }

    public function hpos_column_value( string $column, $order ): void {
        if ( 'mrc_fraud_risk' === $column ) { $this->badge( $order instanceof \WC_Order ? $order : wc_get_order( $order ) ); }
    }

    private function badge( $order ): void {
        if ( ! $order instanceof \WC_Order ) { return; }
        $score = absint( $order->get_meta( '_mrc_fraud_score', true ) );
        $level = sanitize_key( $order->get_meta( '_mrc_fraud_level', true ) ?: 'unchecked' );
        echo '<span class="mrc-risk-badge mrc-risk-' . esc_attr( $level ) . '">' . esc_html( ucfirst( $level ) . ( 'unchecked' === $level ? '' : ' · ' . $score ) ) . '</span>';
    }

    public function render( $order ): void {
        if ( ! $order instanceof \WC_Order || ! mrc_can( 'fraud.basic' ) ) { return; }
        $score = absint( $order->get_meta( '_mrc_fraud_score', true ) );
        $level = sanitize_key( $order->get_meta( '_mrc_fraud_level', true ) ?: 'unchecked' );
        $reasons = array_filter( array_map( 'sanitize_text_field', (array) $order->get_meta( '_mrc_fraud_reasons', true ) ) );
        $checked = absint( $order->get_meta( '_mrc_fraud_checked_at', true ) );
        echo '<div class="mrc-order-risk-panel"><h3>' . esc_html__( 'MR Fraud Checker', 'mr-commerce' ) . ' <span class="mrc-risk-badge mrc-risk-' . esc_attr( $level ) . '">' . esc_html( ucfirst( $level ) . ( 'unchecked' === $level ? '' : ' · ' . $score . '/100' ) ) . '</span></h3>';
        if ( $reasons ) { echo '<ul>'; foreach ( $reasons as $reason ) { echo '<li>' . esc_html( $reason ) . '</li>'; } echo '</ul>'; }
        if ( $checked ) { echo '<p class="description">' . esc_html( sprintf( __( 'Last checked: %s', 'mr-commerce' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $checked ) ) ) . '</p>'; }
        $rescore = wp_nonce_url( admin_url( 'admin-post.php?action=mrc_fraud_rescore&order_id=' . $order->get_id() ), 'mrc_fraud_order_' . $order->get_id() );
        $trust = wp_nonce_url( admin_url( 'admin-post.php?action=mrc_fraud_trust&order_id=' . $order->get_id() ), 'mrc_fraud_order_' . $order->get_id() );
        echo '<p><a class="button" href="' . esc_url( $rescore ) . '">' . esc_html__( 'Recheck risk', 'mr-commerce' ) . '</a> <a class="button" href="' . esc_url( $trust ) . '">' . esc_html__( 'Mark customer trusted', 'mr-commerce' ) . '</a></p></div>';
    }

    public function rescore(): void {
        $order = $this->authorized_order();
        if ( ! $order ) { return; }
        $order->delete_meta_data( '_mrc_fraud_checked_at' );
        $order->save();
        ( new RiskEngine() )->score( $order );
        $order->add_order_note( sprintf( __( 'MR Fraud Checker: Risk manually rechecked by %s.', 'mr-commerce' ), wp_get_current_user()->display_name ) );
        $this->redirect( $order );
    }

    public function trust(): void {
        $order = $this->authorized_order();
        if ( ! $order ) { return; }
        $settings = RiskEngine::settings();
        $phone = PhoneNormalizer::normalize( $order->get_billing_phone() );
        $email = sanitize_email( $order->get_billing_email() );
        $settings['whitelist'] = trim( (string) $settings['whitelist'] . "\n" . $phone . "\n" . $email );
        update_option( 'mrc_fraud_checker_settings', $settings, false );
        $order->update_meta_data( '_mrc_fraud_score', 0 );
        $order->update_meta_data( '_mrc_fraud_level', 'low' );
        $order->update_meta_data( '_mrc_fraud_reasons', array( __( 'Trusted manually by an administrator', 'mr-commerce' ) ) );
        $order->delete_meta_data( '_mrc_risk_flag' );
        $order->add_order_note( sprintf( __( 'MR Fraud Checker: Customer marked trusted by %s.', 'mr-commerce' ), wp_get_current_user()->display_name ) );
        $order->save();
        $this->redirect( $order );
    }

    private function authorized_order(): ?\WC_Order {
        $id = absint( $_GET['order_id'] ?? 0 );
        if ( ! current_user_can( 'manage_woocommerce' ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), 'mrc_fraud_order_' . $id ) ) { wp_die( esc_html__( 'Unauthorized request.', 'mr-commerce' ) ); }
        $order = wc_get_order( $id );
        return $order instanceof \WC_Order ? $order : null;
    }

    private function redirect( \WC_Order $order ): void {
        wp_safe_redirect( $order->get_edit_order_url() );
        exit;
    }
}
