<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

final class RiskEngine {
    public function register(): void {
        add_action( 'woocommerce_checkout_order_created', array( $this, 'score' ), 30 );
        add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'score' ), 30 );
    }

    public static function settings(): array {
        $legacy = wp_parse_args( get_option( 'mrc_physical_settings', array() ), array( 'risk_window_hours' => 24, 'risk_threshold' => 2 ) );
        return wp_parse_args( get_option( 'mrc_fraud_checker_settings', array() ), array(
            'enabled' => 'yes', 'window_hours' => absint( $legacy['risk_window_hours'] ), 'medium_score' => 25,
            'high_score' => max( 50, absint( $legacy['risk_threshold'] ) * 25 ), 'critical_score' => 80,
            'high_value_cod' => 10000, 'action' => 'flag', 'blacklist' => '', 'whitelist' => '',
        ) );
    }

    public function score( $order ): void {
        if ( is_numeric( $order ) ) { $order = wc_get_order( $order ); }
        if ( ! $order instanceof \WC_Order || 'yes' !== self::settings()['enabled'] || ! mrc_can( 'fraud.basic' ) ) { return; }
        if ( absint( $order->get_meta( '_mrc_fraud_checked_at', true ) ) > time() - 10 ) { return; }
        if ( 'yes' === $order->get_meta( '_mrc_fraud_scoring_lock', true ) ) { return; }
        $order->update_meta_data( '_mrc_fraud_scoring_lock', 'yes' );
        $result = $this->evaluate( $order );
        $order->update_meta_data( '_mrc_fraud_score', $result['score'] );
        $order->update_meta_data( '_mrc_fraud_level', $result['level'] );
        $order->update_meta_data( '_mrc_fraud_reasons', $result['reasons'] );
        $order->update_meta_data( '_mrc_fraud_checked_at', time() );
        $order->update_meta_data( '_mrc_fraud_version', MRBP_VERSION );
        $order->delete_meta_data( '_mrc_fraud_scoring_lock' );
        $settings = self::settings();
        if ( in_array( $result['level'], array( 'high', 'critical' ), true ) ) {
            $order->update_meta_data( '_mrc_risk_flag', 'review' );
            if ( mrc_can( 'fraud.automation' ) && 'hold' === $settings['action'] && ! $order->has_status( array( 'cancelled', 'refunded', 'failed' ) ) ) {
                $order->set_status( 'on-hold', __( 'MR Fraud Checker: High-risk order held for manual verification.', 'mr-commerce' ) );
            } else {
                $order->add_order_note( __( 'MR Fraud Checker: Risk signals detected. Review before fulfilment.', 'mr-commerce' ) );
            }
        }
        $order->save();
        do_action( 'mrc_fraud_checker_scored', $order, $result );
    }

    public function evaluate( \WC_Order $order ): array {
        $settings = self::settings();
        $score = 0; $reasons = array();
        $phone = PhoneNormalizer::normalize( $order->get_billing_phone() );
        $email = strtolower( trim( $order->get_billing_email() ) );
        $whitelist = $this->list_values( (string) $settings['whitelist'] );
        if ( in_array( $phone, $whitelist, true ) || in_array( $email, $whitelist, true ) ) {
            return array( 'score' => 0, 'level' => 'low', 'reasons' => array( __( 'Trusted customer whitelist match', 'mr-commerce' ) ) );
        }
        $blacklist = $this->list_values( (string) $settings['blacklist'] );
        if ( in_array( $phone, $blacklist, true ) || in_array( $email, $blacklist, true ) ) { $score += 80; $reasons[] = __( 'Phone or email is on the store blacklist', 'mr-commerce' ); }
        if ( $phone && ! PhoneNormalizer::valid_bd_mobile( $phone ) ) { $score += 20; $reasons[] = __( 'Invalid Bangladesh mobile number format', 'mr-commerce' ); }
        if ( ! $phone ) { $score += 15; $reasons[] = __( 'Billing phone is missing', 'mr-commerce' ); }

        $after = gmdate( 'Y-m-d H:i:s', time() - max( 1, absint( $settings['window_hours'] ) ) * HOUR_IN_SECONDS );
        $args = array( 'limit'=>20, 'exclude'=>array( $order->get_id() ), 'date_created'=>'>' . $after );
        $email_orders = $email ? wc_get_orders( $args + array( 'billing_email'=>$email ) ) : array();
        if ( $email_orders ) { $score += min( 30, 15 + count( $email_orders ) * 5 ); $reasons[] = sprintf( __( '%d recent order(s) use the same email', 'mr-commerce' ), count( $email_orders ) ); }
        $phone_ids = array();
        foreach ( PhoneNormalizer::variants( $phone ) as $variant ) {
            foreach ( wc_get_orders( $args + array( 'billing_phone'=>$variant, 'return'=>'ids' ) ) as $id ) { $phone_ids[ $id ] = true; }
        }
        if ( $phone_ids ) { $score += min( 35, 20 + count( $phone_ids ) * 5 ); $reasons[] = sprintf( __( '%d recent order(s) use the same phone', 'mr-commerce' ), count( $phone_ids ) ); }

        if ( mrc_can( 'fraud.advanced_scoring' ) ) {
            if ( 'cod' === $order->get_payment_method() && (float) $order->get_total() >= (float) $settings['high_value_cod'] ) { $score += 20; $reasons[] = __( 'High-value cash-on-delivery order', 'mr-commerce' ); }
            $address = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() );
            if ( strlen( $address ) < 12 ) { $score += 15; $reasons[] = __( 'Shipping address appears incomplete', 'mr-commerce' ); }
            $ip = (string) $order->get_customer_ip_address();
            if ( $ip ) {
                $ip_matches = wc_get_orders( $args + array( 'customer_ip_address'=>$ip, 'return'=>'ids' ) );
                if ( count( $ip_matches ) >= 2 ) { $score += min( 20, count( $ip_matches ) * 5 ); $reasons[] = __( 'Multiple recent orders originate from the same IP address', 'mr-commerce' ); }
            }
            $history = $this->customer_history( $phone_ids, $email_orders );
            if ( $history['failed'] >= 2 && $history['failed'] > $history['delivered'] ) { $score += 25; $reasons[] = __( 'Customer history has more failed/returned orders than delivered orders', 'mr-commerce' ); }
            $courier = ( new CourierRiskRegistry() )->intelligence( $phone, $order );
            if ( $courier['total'] >= 2 && ( $courier['failed'] + $courier['returned'] ) > $courier['delivered'] ) { $score += 30; $reasons[] = __( 'Connected courier history shows a high failed/return ratio', 'mr-commerce' ); }
        }
        $score = min( 100, max( 0, $score ) );
        return array( 'score'=>$score, 'level'=>$this->level( $score, $settings ), 'reasons'=>$reasons ?: array( __( 'No significant risk signal detected', 'mr-commerce' ) ) );
    }

    private function level( int $score, array $settings ): string {
        if ( $score >= absint( $settings['critical_score'] ) ) { return 'critical'; }
        if ( $score >= absint( $settings['high_score'] ) ) { return 'high'; }
        if ( $score >= absint( $settings['medium_score'] ) ) { return 'medium'; }
        return 'low';
    }

    private function list_values( string $raw ): array {
        $values = preg_split( '/[\r\n,]+/', strtolower( $raw ) ) ?: array();
        return array_values( array_filter( array_unique( array_map( static function( $value ) {
            $value = trim( $value ); return str_contains( $value, '@' ) ? sanitize_email( $value ) : PhoneNormalizer::normalize( $value );
        }, $values ) ) ) );
    }

    private function customer_history( array $phone_ids, array $email_orders ): array {
        $orders = array();
        foreach ( array_keys( $phone_ids ) as $id ) { $orders[ $id ] = wc_get_order( $id ); }
        foreach ( $email_orders as $order ) { if ( $order instanceof \WC_Order ) { $orders[ $order->get_id() ] = $order; } }
        $result = array( 'delivered'=>0, 'failed'=>0 );
        foreach ( $orders as $order ) {
            if ( ! $order ) { continue; }
            if ( $order->has_status( array( 'completed', 'mrc-delivered' ) ) ) { $result['delivered']++; }
            if ( $order->has_status( array( 'failed', 'cancelled', 'refunded', 'mrc-failed', 'mrc-returned' ) ) ) { $result['failed']++; }
        }
        return $result;
    }
}
