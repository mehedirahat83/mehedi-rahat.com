<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;

final class FraudCheckerAdmin {
    public function register(): void {
        add_action( 'admin_menu', array( $this, 'menu' ), 32 );
        add_action( 'admin_init', array( $this, 'settings' ) );
    }

    public function menu(): void {
        add_submenu_page( 'mrbp-dashboard', __( 'MR Fraud Checker', 'mr-commerce' ), __( 'MR Fraud Checker', 'mr-commerce' ), 'manage_woocommerce', 'mrc-fraud-checker', array( $this, 'render' ) );
    }

    public function settings(): void {
        register_setting( 'mrc_fraud_checker_group', 'mrc_fraud_checker_settings', array( 'type'=>'array', 'sanitize_callback'=>array( $this, 'sanitize' ), 'default'=>RiskEngine::settings() ) );
    }

    public function sanitize( array $input ): array {
        $old = RiskEngine::settings();
        $out = array(
            'enabled' => ! empty( $input['enabled'] ) ? 'yes' : 'no',
            'window_hours' => max( 1, min( 2160, absint( $input['window_hours'] ?? 24 ) ) ),
            'medium_score' => max( 1, min( 100, absint( $input['medium_score'] ?? 25 ) ) ),
            'high_score' => max( 1, min( 100, absint( $input['high_score'] ?? 50 ) ) ),
            'critical_score' => max( 1, min( 100, absint( $input['critical_score'] ?? 80 ) ) ),
            'high_value_cod' => max( 0, (float) ( $input['high_value_cod'] ?? 10000 ) ),
            'action' => in_array( $input['action'] ?? 'flag', array( 'flag', 'hold' ), true ) ? $input['action'] : 'flag',
            'blacklist' => sanitize_textarea_field( $input['blacklist'] ?? '' ),
            'whitelist' => sanitize_textarea_field( $input['whitelist'] ?? '' ),
        );
        if ( ! mrc_can( 'fraud.advanced_scoring' ) ) {
            foreach ( array( 'medium_score','high_score','critical_score','high_value_cod','action' ) as $key ) { $out[ $key ] = $old[ $key ]; }
        }
        return $out;
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $s = RiskEngine::settings();
        $counts = array( 'low'=>0, 'medium'=>0, 'high'=>0, 'critical'=>0 );
        foreach ( wc_get_orders( array( 'limit'=>100, 'return'=>'objects', 'orderby'=>'date', 'order'=>'DESC' ) ) as $order ) {
            $level = sanitize_key( $order->get_meta( '_mrc_fraud_level', true ) );
            if ( isset( $counts[ $level ] ) ) { $counts[ $level ]++; }
        }
        ?>
        <div class="wrap mrc-ops-wrap mrc-ops-fraud">
            <?php \MRBP\Admin\OperationsUi::header( __( 'COD RISK INTELLIGENCE', 'mr-commerce' ), __( 'MR Fraud Checker', 'mr-commerce' ), __( 'Screen WooCommerce orders using Bangladesh-aware identity checks, customer history and explainable risk scoring.', 'mr-commerce' ), 'dashicons-shield-alt', array( __( 'Engine', 'mr-commerce' )=>__( 'Active', 'mr-commerce' ), __( 'Scoring', 'mr-commerce' )=>__( '0–100', 'mr-commerce' ) ) ); ?>
            <div class="mrc-ops-kpis mrc-fraud-kpis">
                <?php foreach ( $counts as $level => $count ) : ?><div class="mrc-ops-kpi mrc-risk-card-<?php echo esc_attr( $level ); ?>"><span><?php echo esc_html( ucfirst( $level ) . ' risk' ); ?></span><strong><?php echo esc_html( (string) $count ); ?></strong><small><?php esc_html_e( 'Last 100 orders', 'mr-commerce' ); ?></small></div><?php endforeach; ?>
            </div>
            <form method="post" action="options.php"><?php settings_fields( 'mrc_fraud_checker_group' ); ?>
                <div class="card"><h2><?php esc_html_e( 'Core screening', 'mr-commerce' ); ?></h2>
                    <p><label><input type="checkbox" name="mrc_fraud_checker_settings[enabled]" value="1" <?php checked( 'yes', $s['enabled'] ); ?>> <?php esc_html_e( 'Check new WooCommerce orders automatically', 'mr-commerce' ); ?></label></p>
                    <table class="form-table"><tr><th><?php esc_html_e( 'Duplicate window', 'mr-commerce' ); ?></th><td><input type="number" min="1" max="2160" name="mrc_fraud_checker_settings[window_hours]" value="<?php echo esc_attr( (string) $s['window_hours'] ); ?>"> <?php esc_html_e( 'hours', 'mr-commerce' ); ?></td></tr></table>
                    <p class="description"><?php esc_html_e( 'Free screening includes Bangladesh phone validation, duplicate phone/email checks and manual trust/block lists.', 'mr-commerce' ); ?></p>
                    <?php \MRBP\Admin\OperationsUi::guide( 'প্রতিটি নতুন order স্বয়ংক্রিয়ভাবে যাচাই করে ০–১০০ risk score তৈরি করে।', array( 'Automatic checking চালু রাখুন।', 'কত ঘণ্টার আগের order তুলনা করবে তা ঠিক করুন।', 'Order list বা order details থেকে risk badge ও কারণ দেখুন।' ), 'একই ফোন বা email দিয়ে বারবার order করলে duplicate signal তৈরি হবে।', 'Score বেশি মানেই নিশ্চিত fraud নয়। Customer-এর সঙ্গে যোগাযোগ করে যাচাই করুন।' ); ?>
                </div>
                <div class="card"><h2><?php esc_html_e( 'Trust and block lists', 'mr-commerce' ); ?></h2>
                    <p><label><strong><?php esc_html_e( 'Blacklist', 'mr-commerce' ); ?></strong><textarea class="large-text" rows="5" name="mrc_fraud_checker_settings[blacklist]"><?php echo esc_textarea( (string) $s['blacklist'] ); ?></textarea></label><span class="description"><?php esc_html_e( 'One phone or email per line.', 'mr-commerce' ); ?></span></p>
                    <p><label><strong><?php esc_html_e( 'Whitelist', 'mr-commerce' ); ?></strong><textarea class="large-text" rows="5" name="mrc_fraud_checker_settings[whitelist]"><?php echo esc_textarea( (string) $s['whitelist'] ); ?></textarea></label></p>
                    <?php \MRBP\Admin\OperationsUi::guide( 'সন্দেহজনক customer block এবং বিশ্বস্ত customer-এর false alert বন্ধ করতে সাহায্য করে।', array( 'প্রতি লাইনে একটি phone বা email লিখুন।', 'সন্দেহজনক পরিচয় Blacklist-এ রাখুন।', 'নিশ্চিত বিশ্বস্ত customer Whitelist-এ রাখুন।' ), 'বারবার ভুয়া order করা নম্বর Blacklist-এ রাখলে পরের order Critical risk পাবে।', 'ভুল ব্যক্তিকে Blacklist করলে বৈধ order প্রভাবিত হতে পারে।' ); ?>
                </div>
                <?php if ( mrc_can( 'fraud.advanced_scoring' ) ) : ?>
                <div class="card"><h2><?php esc_html_e( 'Advanced scoring', 'mr-commerce' ); ?></h2><table class="form-table">
                    <tr><th><?php esc_html_e( 'Risk thresholds', 'mr-commerce' ); ?></th><td><input type="number" min="1" max="100" name="mrc_fraud_checker_settings[medium_score]" value="<?php echo esc_attr( (string) $s['medium_score'] ); ?>" aria-label="Medium"> <input type="number" min="1" max="100" name="mrc_fraud_checker_settings[high_score]" value="<?php echo esc_attr( (string) $s['high_score'] ); ?>" aria-label="High"> <input type="number" min="1" max="100" name="mrc_fraud_checker_settings[critical_score]" value="<?php echo esc_attr( (string) $s['critical_score'] ); ?>" aria-label="Critical"><p class="description"><?php esc_html_e( 'Medium, High and Critical scores.', 'mr-commerce' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'High-value COD', 'mr-commerce' ); ?></th><td><input type="number" min="0" step="1" name="mrc_fraud_checker_settings[high_value_cod]" value="<?php echo esc_attr( (string) $s['high_value_cod'] ); ?>"></td></tr>
                    <tr><th><?php esc_html_e( 'High-risk action', 'mr-commerce' ); ?></th><td><select name="mrc_fraud_checker_settings[action]"><option value="flag" <?php selected( $s['action'], 'flag' ); ?>><?php esc_html_e( 'Flag for review', 'mr-commerce' ); ?></option><option value="hold" <?php selected( $s['action'], 'hold' ); ?>><?php esc_html_e( 'Move order to On hold', 'mr-commerce' ); ?></option></select></td></tr>
                </table><?php \MRBP\Admin\OperationsUi::guide( 'COD value, IP, address এবং customer history মিলিয়ে আরও নির্ভুল weighted score তৈরি করে।', array( 'Medium, High ও Critical threshold ঠিক করুন।', 'High-value COD সীমা নির্ধারণ করুন।', 'High-risk order শুধু flag হবে নাকি On hold হবে তা নির্বাচন করুন।' ), 'Risk score ৫০ ছাড়ালে order review-এর জন্য High দেখানো যেতে পারে।', 'Automatic cancellation ব্যবহার করা হয় না; On hold order admin যাচাই করবেন।' ); ?></div>
                <div class="card"><h2><?php esc_html_e( 'Pro intelligence', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Adds high-value COD, incomplete-address, repeated-IP and failed-versus-delivered customer-history signals.', 'mr-commerce' ); ?></p><p><strong><?php esc_html_e( 'Safety policy:', 'mr-commerce' ); ?></strong> <?php esc_html_e( 'Orders are never cancelled automatically. High-risk automation only places orders On hold for human verification.', 'mr-commerce' ); ?></p></div>
                <?php else : ProFeature::render( 'fraud.advanced_scoring', __( 'Advanced Fraud Intelligence', 'mr-commerce' ), __( 'Add weighted scoring, IP/address/history signals and automatic On-hold review workflow.', 'mr-commerce' ) ); endif; ?>
                <?php submit_button( __( 'Save Fraud Checker Settings', 'mr-commerce' ) ); ?>
            </form>
        </div>
        <?php
    }
}
