<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

use MRBP\Modules\ModuleInterface;

final class FraudCheckerModule implements ModuleInterface {
    private bool $registered = false;
    private bool $booted = false;

    public function id(): string { return 'fraud_checker'; }
    public function name(): string { return __( 'MR Fraud Checker', 'mr-commerce' ); }
    public function description(): string { return __( 'Bangladesh-focused COD order risk intelligence and review workflow.', 'mr-commerce' ); }
    public function dependencies(): array { return array( 'woocommerce' ); }
    public function is_available(): bool { return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' ); }

    public function register(): void {
        if ( $this->registered ) { return; }
        $this->registered = true;
        ( new RiskEngine() )->register();
        ( new OrderRiskPanel() )->register();
        if ( is_admin() ) { ( new FraudCheckerAdmin() )->register(); }
    }

    public function boot(): void {
        if ( $this->booted ) { return; }
        $this->booted = true;
        do_action( 'mrbp/fraud_checker/booted', $this );
    }
}
