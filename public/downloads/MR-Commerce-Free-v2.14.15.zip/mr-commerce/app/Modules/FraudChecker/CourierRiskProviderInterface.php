<?php

namespace MRBP\Modules\FraudChecker;

defined( 'ABSPATH' ) || exit;

interface CourierRiskProviderInterface {
    public function id(): string;
    public function is_configured(): bool;

    /**
     * Return provider-neutral delivery intelligence.
     *
     * @return array{delivered:int,failed:int,returned:int,total:int}
     */
    public function lookup( string $normalized_phone, \WC_Order $order ): array;
}
