<?php

namespace MRBP\Modules\SequentialOrders;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\ModuleInterface;
use MRBP\Modules\SequentialOrders\Admin\SequentialOrdersAdmin;

final class SequentialOrdersModule implements ModuleInterface {
    private bool $registered = false;
    private bool $booted = false;

    public function id(): string { return 'sequential_orders'; }
    public function name(): string { return __( 'MR Sequential Orders', 'mr-commerce' ); }
    public function description(): string { return __( 'Sequential WooCommerce order numbers with prefix.', 'mr-commerce' ); }
    public function dependencies(): array { return array( 'woocommerce' ); }
    public function is_available(): bool { return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_order' ); }

    public function register(): void {
        if ( $this->registered ) { return; }
        $this->registered = true;
        ( new OrderNumberService() )->register();
        if ( is_admin() ) {
            ( new SequentialOrdersAdmin() )->register();
        }
        do_action( 'mrbp/sequential_orders/registered', $this );
    }

    public function boot(): void {
        if ( $this->booted ) { return; }
        $this->booted = true;
        do_action( 'mrbp/sequential_orders/booted', $this );
    }
}
