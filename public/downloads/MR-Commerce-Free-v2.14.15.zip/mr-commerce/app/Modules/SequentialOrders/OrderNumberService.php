<?php

namespace MRBP\Modules\SequentialOrders;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class OrderNumberService {
    public const META_NUMBER = '_mrbp_order_number';
    public const META_SEQUENCE = '_mrbp_order_sequence';
    private const COUNTER_OPTION = 'mrbp_sequential_order_counter';
    private const SETTINGS_OPTION = 'mrbp_sequential_order_settings';

    public function register(): void {
        add_action( 'woocommerce_new_order', array( $this, 'assign' ), 20, 2 );
        add_filter( 'woocommerce_order_number', array( $this, 'display_number' ), 10, 2 );
        add_filter( 'woocommerce_shop_order_search_fields', array( $this, 'legacy_search_fields' ) );
        add_filter( 'woocommerce_order_table_search_query_meta_keys', array( $this, 'hpos_search_fields' ) );
        add_filter( 'woocommerce_shortcode_order_tracking_order_id', array( $this, 'tracking_order_id' ), 5 );
    }

    public function assign( int $order_id, $order = null ): void {
        $order = $order instanceof \WC_Order ? $order : wc_get_order( $order_id );
        if ( ! $order instanceof \WC_Order || $order instanceof \WC_Order_Refund || '' !== (string) $order->get_meta( self::META_NUMBER, true ) ) {
            return;
        }

        $sequence = $this->next_sequence();
        if ( $sequence < 1 ) {
            return;
        }

        $settings = self::settings();
        $number   = (string) $settings['prefix'] . str_pad( (string) $sequence, (int) $settings['padding'], '0', STR_PAD_LEFT );
        $order->update_meta_data( self::META_SEQUENCE, $sequence );
        $order->update_meta_data( self::META_NUMBER, $number );
        $order->save_meta_data();

        do_action( 'mrbp/sequential_orders/assigned', $order_id, $number, $sequence );
    }

    public function display_number( $number, $order ): string {
        if ( $order instanceof \WC_Order ) {
            $custom = (string) $order->get_meta( self::META_NUMBER, true );
            if ( '' !== $custom ) {
                return $custom;
            }
        }
        return (string) $number;
    }

    public function legacy_search_fields( array $fields ): array {
        if ( self::settings()['search_enabled'] && ! in_array( self::META_NUMBER, $fields, true ) ) {
            $fields[] = self::META_NUMBER;
        }
        return $fields;
    }

    public function hpos_search_fields( array $fields ): array {
        return $this->legacy_search_fields( $fields );
    }

    public function tracking_order_id( $submitted ) {
        if ( ! self::settings()['tracking_enabled'] || '' === trim( (string) $submitted ) ) {
            return $submitted;
        }

        $orders = wc_get_orders(
            array(
                'limit'      => 1,
                'return'     => 'ids',
                'meta_key'   => self::META_NUMBER,
                'meta_value' => wc_clean( (string) $submitted ),
            )
        );
        return ! empty( $orders ) ? (int) reset( $orders ) : $submitted;
    }

    public static function settings(): array {
        $settings = self::stored_settings();

        if ( function_exists( 'mrc_can' ) && ! mrc_can( 'orders.custom_sequence' ) ) {
            $settings['prefix']           = '';
            $settings['padding']          = 1;
            $settings['search_enabled']   = false;
            $settings['tracking_enabled'] = false;
        }

        return $settings;
    }

    public static function stored_settings(): array {
        return wp_parse_args(
            get_option( self::SETTINGS_OPTION, array() ),
            array( 'prefix' => 'MR-', 'padding' => 4, 'start_number' => 2000, 'search_enabled' => true, 'tracking_enabled' => true )
        );
    }

    public static function has_started(): bool {
        return false !== get_option( self::COUNTER_OPTION, false );
    }

    private function next_sequence(): int {
        global $wpdb;
        $settings = self::settings();

        if ( false === get_option( self::COUNTER_OPTION, false ) ) {
            add_option( self::COUNTER_OPTION, max( 0, (int) $settings['start_number'] - 1 ), '', false );
        }

        $option = self::COUNTER_OPTION;
        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$wpdb->options} SET option_value = LAST_INSERT_ID(CAST(option_value AS UNSIGNED) + 1) WHERE option_name = %s",
                $option
            )
        );
        if ( 1 !== $updated ) {
            return 0;
        }

        wp_cache_delete( $option, 'options' );
        return (int) $wpdb->get_var( 'SELECT LAST_INSERT_ID()' );
    }
}
