<?php

namespace MRBP\Modules\SequentialOrders\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Form;
use MRBP\Admin\Layout\PageRenderer;
use MRBP\Admin\ProFeature;
use MRBP\Modules\SequentialOrders\OrderNumberService;

final class SequentialOrdersAdmin {
    private const SLUG = 'mrbp-sequential-orders';

    public function register(): void {
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_menu', array( $this, 'register_menu' ), 61 );
    }

    public function register_menu(): void {
        add_submenu_page( 'mrbp-dashboard', __( 'MR Sequential Orders', 'mr-commerce' ), __( 'MR Sequential Orders', 'mr-commerce' ), 'manage_woocommerce', self::SLUG, array( $this, 'render' ) );
    }

    public function register_settings(): void {
        register_setting( 'mrbp_sequential_orders_group', 'mrbp_sequential_order_settings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize' ), 'default' => array() ) );
    }

    public function sanitize( $input ): array {
        $input   = is_array( $input ) ? $input : array();
        $current = OrderNumberService::stored_settings();
        if ( ! ProFeature::allowed( 'orders.custom_sequence' ) ) {
            return $current;
        }
        $prefix  = sanitize_text_field( (string) ( $input['prefix'] ?? 'MR-' ) );
        $prefix  = substr( $prefix, 0, 20 );

        return array(
            'prefix'           => $prefix,
            'padding'          => max( 1, min( 12, absint( $input['padding'] ?? 4 ) ) ),
            'start_number'     => OrderNumberService::has_started() ? (int) $current['start_number'] : max( 1, absint( $input['start_number'] ?? 2000 ) ),
            'search_enabled'   => ! empty( $input['search_enabled'] ),
            'tracking_enabled' => ! empty( $input['tracking_enabled'] ),
        );
    }

    public function render(): void {
        $renderer = mrbp()->container()->get( 'page_renderer' );
        if ( ! $renderer instanceof PageRenderer ) {
            wp_die( esc_html__( 'The admin page renderer is unavailable.', 'mr-commerce' ) );
        }

        $renderer->render(
            __( 'MR Sequential Orders', 'mr-commerce' ),
            __( 'Create clear, predictable WooCommerce order numbers without changing internal order IDs.', 'mr-commerce' ),
            array( $this, 'render_content' ),
            array(
                array( 'label' => __( 'MR Commerce Pro', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=mrbp-dashboard' ) ),
                array( 'label' => __( 'Modules', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=mrbp-modules' ) ),
                __( 'MR Sequential Orders', 'mr-commerce' ),
            )
        );
    }

    public function render_content(): void {
        $settings = OrderNumberService::stored_settings();
        $started  = OrderNumberService::has_started();
        $preview  = (string) $settings['prefix'] . str_pad( (string) $settings['start_number'], (int) $settings['padding'], '0', STR_PAD_LEFT );
        settings_errors();
        ?>
        <?php if ( ProFeature::allowed( 'orders.custom_sequence' ) ) : ?>
        <article class="mrbp-ui-card">
            <header class="mrbp-ui-card__header"><div><h2 class="mrbp-ui-card__title"><?php esc_html_e( 'Order Number Format', 'mr-commerce' ); ?></h2><p class="mrbp-ui-card__description"><?php esc_html_e( 'The format applies to new orders only. Existing order numbers stay unchanged.', 'mr-commerce' ); ?></p></div><span class="mrbp-ui-badge mrbp-ui-badge--info"><?php echo esc_html( $preview ); ?></span></header>
            <div class="mrbp-ui-card__content">
                <form method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>" class="mrbp-ui-form">
                    <?php settings_fields( 'mrbp_sequential_orders_group' ); ?>
                    <?php echo Form::field( __( 'Prefix', 'mr-commerce' ), 'mrbp_sequential_order_settings[prefix]', (string) $settings['prefix'], 'text', __( 'Example: MR-', 'mr-commerce' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php echo Form::field( __( 'Number Length', 'mr-commerce' ), 'mrbp_sequential_order_settings[padding]', (string) $settings['padding'], 'number', __( 'Adds leading zeros, for example 002000.', 'mr-commerce' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php echo Form::field( __( 'Start Number', 'mr-commerce' ), 'mrbp_sequential_order_settings[start_number]', (string) $settings['start_number'], 'number', $started ? __( 'Locked because numbering has already started.', 'mr-commerce' ) : __( 'The first new order will use this number.', 'mr-commerce' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <div class="mrbp-ui-field"><label><input type="checkbox" name="mrbp_sequential_order_settings[search_enabled]" value="1" <?php checked( ! empty( $settings['search_enabled'] ) ); ?>> <?php esc_html_e( 'Find orders by sequential number in WooCommerce admin', 'mr-commerce' ); ?></label></div>
                    <div class="mrbp-ui-field"><label><input type="checkbox" name="mrbp_sequential_order_settings[tracking_enabled]" value="1" <?php checked( ! empty( $settings['tracking_enabled'] ) ); ?>> <?php esc_html_e( 'Accept sequential numbers on the order tracking form', 'mr-commerce' ); ?></label></div>
                    <div class="mrbp-ui-actions"><button type="submit" class="mrbp-ui-button mrbp-ui-button--primary"><?php esc_html_e( 'Save Changes', 'mr-commerce' ); ?></button></div>
                </form>
            </div>
        </article>
        <?php else : ?>
        <article class="mrbp-ui-card">
            <header class="mrbp-ui-card__header"><div><h2 class="mrbp-ui-card__title"><?php esc_html_e( 'Basic Sequential Numbers', 'mr-commerce' ); ?></h2><p class="mrbp-ui-card__description"><?php esc_html_e( 'Free automatically assigns a simple increasing number to every new order.', 'mr-commerce' ); ?></p></div><span class="mrbp-ui-badge mrbp-ui-badge--info"><?php esc_html_e( 'FREE', 'mr-commerce' ); ?></span></header>
        </article>
        <?php
        ProFeature::render(
            'orders.custom_sequence',
            __( 'Custom Order Number Format', 'mr-commerce' ),
            __( 'Unlock branded prefixes, zero padding, custom starting numbers, admin search and customer tracking.', 'mr-commerce' ),
            array(
                __( 'Custom prefix and number length', 'mr-commerce' ),
                __( 'Configurable starting number', 'mr-commerce' ),
                __( 'WooCommerce admin search and order-tracking support', 'mr-commerce' ),
            )
        );
        ?>
        <?php endif; ?>
        <div class="mrbp-module-inline-notice is-warning"><span class="dashicons dashicons-warning" aria-hidden="true"></span><div><strong><?php esc_html_e( 'Compatibility check', 'mr-commerce' ); ?></strong><p><?php esc_html_e( 'Deactivate other sequential-order-number plugins before enabling this module so only one system formats new orders.', 'mr-commerce' ); ?></p></div></div>
        <?php
    }
}
