<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

final class RetentionPrivacy {
    public function register(): void {
        add_action( 'admin_init', array( $this, 'policy' ) );
        add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'exporter' ) );
        add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'eraser' ) );
    }
    public function policy(): void {
        if ( function_exists( 'wp_add_privacy_policy_content' ) ) { wp_add_privacy_policy_content( 'MR Commerce', wp_kses_post( __( 'When a shopper explicitly opts into cart reminders, MR Commerce stores their email, phone, cart product IDs, quantities, cart total and recovery status. Configured email, SMS or courier providers may receive the minimum data required to deliver the requested message or shipment.', 'mr-commerce' ) ) ); }
    }
    public function exporter( array $exporters ): array {
        $exporters['mrc-retention'] = array( 'exporter_friendly_name' => __( 'MR Commerce retention data', 'mr-commerce' ), 'callback' => array( $this, 'export' ) ); return $exporters;
    }
    public function eraser( array $erasers ): array {
        $erasers['mrc-retention'] = array( 'eraser_friendly_name' => __( 'MR Commerce retention data', 'mr-commerce' ), 'callback' => array( $this, 'erase' ) ); return $erasers;
    }
    public function export( string $email, int $page = 1 ): array {
        if ( 1 !== $page ) { return array( 'data' => array(), 'done' => true ); } $cart = $this->find( $email );
        if ( ! $cart ) { return array( 'data' => array(), 'done' => true ); }
        return array( 'data' => array( array( 'group_id' => 'mrc-retention', 'group_label' => __( 'Cart recovery', 'mr-commerce' ), 'item_id' => 'mrc-cart-' . substr( hash( 'sha256', strtolower( $email ) ), 0, 12 ), 'data' => array( array( 'name' => 'Email', 'value' => $cart['email'] ?? '' ), array( 'name' => 'Phone', 'value' => $cart['phone'] ?? '' ), array( 'name' => 'Cart total', 'value' => $cart['total'] ?? '' ), array( 'name' => 'Captured', 'value' => isset( $cart['updated'] ) ? gmdate( 'c', (int) $cart['updated'] ) : '' ) ) ) ), 'done' => true );
    }
    public function erase( string $email, int $page = 1 ): array {
        $carts = (array) get_option( 'mrc_abandoned_carts', array() ); $key = hash_hmac( 'sha256', strtolower( $email ), wp_salt( 'auth' ) ); $removed = isset( $carts[ $key ] ); unset( $carts[ $key ] ); if ( $removed ) { update_option( 'mrc_abandoned_carts', $carts, false ); }
        return array( 'items_removed' => $removed, 'items_retained' => false, 'messages' => array(), 'done' => true );
    }
    private function find( string $email ): array { $carts = (array) get_option( 'mrc_abandoned_carts', array() ); return (array) ( $carts[ hash_hmac( 'sha256', strtolower( $email ), wp_salt( 'auth' ) ) ] ?? array() ); }
}
