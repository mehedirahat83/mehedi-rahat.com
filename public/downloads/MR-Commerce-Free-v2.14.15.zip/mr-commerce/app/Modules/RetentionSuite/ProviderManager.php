<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

final class ProviderManager {
    public function register(): void {
        $this->register_courier();
        $this->register_messaging();
    }
    public function register_courier(): void {
        add_filter( 'mrc/courier_adapters', array( $this, 'courier' ) );
    }
    public function register_messaging(): void {
        add_action( 'mrc/send_sms', array( $this, 'send_sms' ), 10, 2 );
    }
    private static function settings(): array {
        $settings = (array) get_option( 'mrc_integration_settings', array() );
        $cipher = new \MRBP\Modules\PaymentPro\Services\CredentialCipher();
        foreach ( array( 'sms_token', 'courier_token' ) as $key ) { $settings[ $key ] = $cipher->decrypt( (string) ( $settings[ $key ] ?? '' ) ); }
        return $settings;
    }
    public static function email( string $to, string $subject, string $message ): bool {
        if ( ! mrc_can( 'integration.email' ) || ! is_email( $to ) ) { return false; }
        return (bool) apply_filters( 'mrc/provider/email_send', wp_mail( $to, $subject, $message ), $to, $subject, $message );
    }
    public function send_sms( string $phone, string $message ): bool {
        if ( ! mrc_can( 'integration.sms' ) ) { return false; } $s = self::settings(); $url = esc_url_raw( $s['sms_endpoint'] ?? '' ); if ( ! $url ) { return false; }
        $response = wp_remote_post( $url, array( 'timeout' => 15, 'headers' => array( 'Authorization' => 'Bearer ' . (string) ( $s['sms_token'] ?? '' ), 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'to' => sanitize_text_field( $phone ), 'message' => sanitize_textarea_field( $message ) ) ) ) );
        return ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) >= 200 && wp_remote_retrieve_response_code( $response ) < 300;
    }
    public function courier( array $adapters ): array {
        if ( mrc_can( 'integration.courier_webhook' ) && interface_exists( '\\MRBP\\Modules\\PhysicalCommerce\\CourierAdapterInterface' ) ) { $adapter = new GenericCourierAdapter( self::settings() ); $adapters[ $adapter->id() ] = $adapter; }
        return $adapters;
    }
}
