<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;
use MRBP\Modules\PaymentPro\Services\CredentialCipher;

final class RetentionAdmin {
    public function register(): void {
        add_action( 'admin_menu', array( $this, 'menu' ), 44 );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_filter( 'option_page_capability_mrc_retention_group', static fn(): string => 'manage_woocommerce' );
    }
    public function menu(): void { add_submenu_page( null, __( 'Growth Automation', 'mr-commerce' ), __( 'Growth Automation', 'mr-commerce' ), 'manage_woocommerce', 'mrc-retention', array( $this, 'render' ) ); }
    public function settings(): void {
        register_setting( 'mrc_retention_group', 'mrc_retention_settings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_retention' ) ) );
        register_setting( 'mrc_retention_group', 'mrc_integration_settings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_integrations' ) ) );
    }
    public function sanitize_retention( array $in ): array {
        $old = (array) get_option( 'mrc_retention_settings', array() );
        $out = array( 'review_days' => max( 1, min( 90, absint( $in['review_days'] ?? 7 ) ) ), 'email_enabled' => ! empty( $in['email_enabled'] ) ? 'yes' : 'no', 'abandoned_minutes' => absint( $old['abandoned_minutes'] ?? 60 ), 'coupon_percent' => (float) ( $old['coupon_percent'] ?? 10 ) );
        if ( mrc_can( 'retention.abandoned_cart' ) ) { $out['abandoned_minutes'] = max( 15, min( 10080, absint( $in['abandoned_minutes'] ?? 60 ) ) ); }
        if ( mrc_can( 'retention.automated_coupons' ) ) { $out['coupon_percent'] = min( 50, max( 0, (float) ( $in['coupon_percent'] ?? 10 ) ) ); }
        return $out;
    }
    public function sanitize_integrations( array $in ): array {
        $old = (array) get_option( 'mrc_integration_settings', array() ); $cipher = new CredentialCipher();
        $out = array( 'sms_endpoint' => (string) ( $old['sms_endpoint'] ?? '' ), 'sms_token' => (string) ( $old['sms_token'] ?? '' ), 'courier_label' => (string) ( $old['courier_label'] ?? '' ), 'courier_endpoint' => (string) ( $old['courier_endpoint'] ?? '' ), 'courier_token' => (string) ( $old['courier_token'] ?? '' ), 'courier_tracking_url' => (string) ( $old['courier_tracking_url'] ?? '' ) );
        if ( mrc_can( 'integration.sms' ) && array_key_exists( 'sms_endpoint', $in ) ) { $out['sms_endpoint'] = esc_url_raw( $in['sms_endpoint'] ?? '' ); if ( ! empty( $in['sms_token'] ) ) { $out['sms_token'] = $cipher->encrypt( sanitize_text_field( $in['sms_token'] ) ); } }
        if ( mrc_can( 'integration.courier_webhook' ) && array_key_exists( 'courier_endpoint', $in ) ) { $out['courier_label'] = sanitize_text_field( $in['courier_label'] ?? '' ); $out['courier_endpoint'] = esc_url_raw( $in['courier_endpoint'] ?? '' ); $out['courier_tracking_url'] = esc_url_raw( $in['courier_tracking_url'] ?? '' ); if ( ! empty( $in['courier_token'] ) ) { $out['courier_token'] = $cipher->encrypt( sanitize_text_field( $in['courier_token'] ) ); } }
        return $out;
    }
    public function render( bool $embedded = false ): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $r = wp_parse_args( get_option( 'mrc_retention_settings', array() ), array( 'review_days' => 7, 'email_enabled' => 'yes', 'abandoned_minutes' => 60, 'coupon_percent' => 10 ) ); $i = (array) get_option( 'mrc_integration_settings', array() );
        ?><?php if ( ! $embedded ) : ?><div class="wrap mrc-ops-wrap mrc-ops-retention"><?php \MRBP\Admin\OperationsUi::header( __( 'CUSTOMER LIFECYCLE', 'mr-commerce' ), __( 'Growth Automation', 'mr-commerce' ), __( 'Recover revenue with cart recovery, reminders, segmentation and messaging automation.', 'mr-commerce' ), 'dashicons-megaphone', array( __( 'Module', 'mr-commerce' ) => __( 'MR Growth Suite', 'mr-commerce' ), __( 'Automation', 'mr-commerce' ) => __( 'Ready', 'mr-commerce' ) ) ); ?><?php else : ?><section class="mrc-merged-workspace mrc-merged-workspace--growth"><div class="mrc-merged-workspace__header"><span class="dashicons dashicons-megaphone"></span><div><span class="mrc-ops-eyebrow"><?php esc_html_e( 'CUSTOMER LIFECYCLE', 'mr-commerce' ); ?></span><h2><?php esc_html_e( 'Growth Automation & Retention', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Recover carts, request reviews, encourage reorders, segment customers and connect messaging providers.', 'mr-commerce' ); ?></p></div></div><?php endif; ?><form method="post" action="options.php"><?php settings_fields( 'mrc_retention_group' ); ?>
        <div class="card"><h2><?php esc_html_e( 'Review and reorder', 'mr-commerce' ); ?></h2><p><label><input type="checkbox" name="mrc_retention_settings[email_enabled]" value="1" <?php checked( 'yes', $r['email_enabled'] ); ?>> <?php esc_html_e( 'Enable retention email workflow', 'mr-commerce' ); ?></label></p><p><?php esc_html_e( 'Send review reminder after', 'mr-commerce' ); ?> <input type="number" min="1" max="90" name="mrc_retention_settings[review_days]" value="<?php echo esc_attr( (string) $r['review_days'] ); ?>"> <?php esc_html_e( 'days', 'mr-commerce' ); ?></p><p><?php esc_html_e( 'Eligible completed/delivered orders display an Order Again action.', 'mr-commerce' ); ?></p><?php \MRBP\Admin\OperationsUi::guide( 'Delivered order-এর customer-কে review দিতে এবং একই product আবার কিনতে উৎসাহিত করে।', array( 'Retention email workflow চালু করুন।', 'Delivery-এর কত দিন পর reminder যাবে তা নির্ধারণ করুন।', 'Test customer দিয়ে reminder ও Order Again action যাচাই করুন।' ), 'Delivery-এর ৭ দিন পর review reminder পাঠানো যায়।', 'অতিরিক্ত reminder পাঠালে customer বিরক্ত হতে পারে।' ); ?></div>
        <?php if ( mrc_can( 'retention.abandoned_cart' ) ) : ?><div class="card"><h2><?php esc_html_e( 'Abandoned cart recovery', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Wait before recovery', 'mr-commerce' ); ?> <input type="number" min="15" name="mrc_retention_settings[abandoned_minutes]" value="<?php echo esc_attr( (string) $r['abandoned_minutes'] ); ?>"> minutes</p><p><?php esc_html_e( 'Recovery coupon', 'mr-commerce' ); ?> <input type="number" min="0" max="50" step=".01" name="mrc_retention_settings[coupon_percent]" value="<?php echo esc_attr( (string) $r['coupon_percent'] ); ?>">%</p><p><?php echo esc_html( sprintf( __( '%d consented cart records stored.', 'mr-commerce' ), count( (array) get_option( 'mrc_abandoned_carts', array() ) ) ) ); ?></p><?php \MRBP\Admin\OperationsUi::guide( 'Checkout শেষ না করা consented customer-কে cart-এ ফিরে আসার reminder দেয়।', array( 'কত মিনিট পরে cart abandoned ধরা হবে তা দিন।', 'প্রয়োজনে recovery coupon percentage নির্ধারণ করুন।', 'Provider setup করে test recovery message পাঠান।' ), 'Customer checkout ছেড়ে গেলে ৬০ মিনিট পর ১০% couponসহ reminder যেতে পারে।', 'Customer consent এবং privacy policy অনুসরণ করা আবশ্যক।' ); ?></div><?php else : ProFeature::render( 'retention.abandoned_cart', __( 'Abandoned Cart Recovery', 'mr-commerce' ), __( 'Capture consented carts, send recovery messages and optionally generate single-use coupons.', 'mr-commerce' ) ); endif; ?>
        <?php if ( mrc_can( 'integration.sms' ) ) : ?><div class="card"><h2><?php esc_html_e( 'SMS webhook provider', 'mr-commerce' ); ?></h2><input class="large-text" type="url" name="mrc_integration_settings[sms_endpoint]" value="<?php echo esc_attr( $i['sms_endpoint'] ?? '' ); ?>" placeholder="Provider endpoint"><input class="large-text" type="password" name="mrc_integration_settings[sms_token]" value="" placeholder="<?php esc_attr_e( 'New API token (leave blank to preserve)', 'mr-commerce' ); ?>"><?php \MRBP\Admin\OperationsUi::guide( 'আপনার SMS provider-এর API ব্যবহার করে automated customer message পাঠায়।', array( 'Provider থেকে webhook endpoint ও token সংগ্রহ করুন।', 'Endpoint এবং নতুন token লিখে Save করুন।', 'Live campaign চালুর আগে test message যাচাই করুন।' ), 'Order confirmation বা cart recovery SMS provider-এর মাধ্যমে পাঠানো যাবে।', 'ভুল endpoint/token দিলে message যাবে না; token গোপন রাখুন।' ); ?></div><?php else : ProFeature::render( 'integration.sms', __( 'SMS Provider Integration', 'mr-commerce' ), __( 'Send provider-neutral JSON messages through a secured webhook.', 'mr-commerce' ) ); endif; ?>
        <?php submit_button(); ?></form><?php $this->segments(); ?><?php if ( $embedded ) : ?></section><?php else : ?></div><?php endif; ?><?php
    }

    public function render_embedded(): void {
        $this->render( true );
    }
    private function segments(): void {
        if ( ! mrc_can( 'retention.segmentation' ) ) { return; } $limit = mrc_can( 'customer.segmentation' ) ? 100 : 20; $customers = get_users( array( 'role__in' => array( 'customer', 'subscriber' ), 'number' => $limit, 'orderby' => 'registered', 'order' => 'DESC' ) );
        echo '<h2>' . esc_html__( 'Customer Segmentation', 'mr-commerce' ) . '</h2><table class="widefat striped"><thead><tr><th>Customer</th><th>Orders</th><th>Spent</th><th>Segment</th></tr></thead><tbody>';
        foreach ( $customers as $user ) { $customer = new \WC_Customer( $user->ID ); echo '<tr><td>' . esc_html( $customer->get_display_name() ?: $customer->get_email() ) . '</td><td>' . esc_html( (string) $customer->get_order_count() ) . '</td><td>' . wp_kses_post( wc_price( $customer->get_total_spent() ) ) . '</td><td>' . esc_html( ucfirst( RetentionWorkflows::segment( $customer ) ) ) . '</td></tr>'; } echo '</tbody></table>';
    }
}
