<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

use MRBP\Modules\PhysicalCommerce\CourierAdapterInterface;

final class GenericCourierAdapter implements CourierAdapterInterface {
    public function __construct( private array $settings ) {}
    public function id(): string { return 'generic_webhook'; }
    public function label(): string { return (string) ( $this->settings['courier_label'] ?? __( 'Connected courier', 'mr-commerce' ) ); }
    public function create_consignment( \WC_Order $order ): array {
        $endpoint = esc_url_raw( (string) ( $this->settings['courier_endpoint'] ?? '' ) ); if ( ! $endpoint ) { return array( 'success' => false, 'message' => 'Endpoint missing.' ); }
        $response = wp_remote_post( $endpoint, array( 'timeout' => 15, 'headers' => array( 'Authorization' => 'Bearer ' . (string) ( $this->settings['courier_token'] ?? '' ), 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'order_id' => $order->get_id(), 'reference' => $order->get_order_number(), 'name' => $order->get_formatted_shipping_full_name(), 'phone' => $order->get_billing_phone(), 'address' => $order->get_shipping_address_1(), 'city' => $order->get_shipping_city(), 'total' => $order->get_total(), 'cod' => 'cod' === $order->get_payment_method() ) ) ) );
        if ( is_wp_error( $response ) ) { return array( 'success' => false, 'message' => $response->get_error_message() ); }
        $body = json_decode( wp_remote_retrieve_body( $response ), true ); $id = sanitize_text_field( $body['consignment_id'] ?? $body['tracking_id'] ?? '' );
        return array( 'success' => 200 <= wp_remote_retrieve_response_code( $response ) && wp_remote_retrieve_response_code( $response ) < 300 && $id, 'consignment_id' => $id, 'message' => sanitize_text_field( $body['message'] ?? '' ) );
    }
    public function tracking_url( string $id ): string { $base = (string) ( $this->settings['courier_tracking_url'] ?? '' ); return $base ? str_replace( '{id}', rawurlencode( $id ), $base ) : ''; }
}
