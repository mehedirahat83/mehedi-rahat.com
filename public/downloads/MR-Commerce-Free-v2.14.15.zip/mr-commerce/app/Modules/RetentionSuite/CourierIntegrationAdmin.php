<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;
use MRBP\Modules\PaymentPro\Services\CredentialCipher;

final class CourierIntegrationAdmin {
    public function register(): void {
        add_action( 'admin_menu', array( $this, 'menu' ), 44 );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_filter( 'option_page_capability_mrc_courier_integration_group', static fn(): string => 'manage_woocommerce' );
    }

    public function menu(): void {
        add_submenu_page(
            null,
            __( 'Courier Integration', 'mr-commerce' ),
            __( 'Courier Integration', 'mr-commerce' ),
            'manage_woocommerce',
            'mrc-courier-integration',
            array( $this, 'render' )
        );
    }

    public function settings(): void {
        register_setting(
            'mrc_courier_integration_group',
            'mrc_integration_settings',
            array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize' ) )
        );
    }

    public function sanitize( array $input ): array {
        $old = (array) get_option( 'mrc_integration_settings', array() );
        $out = array(
            'sms_endpoint'         => (string) ( $old['sms_endpoint'] ?? '' ),
            'sms_token'            => (string) ( $old['sms_token'] ?? '' ),
            'courier_label'        => (string) ( $old['courier_label'] ?? '' ),
            'courier_endpoint'     => (string) ( $old['courier_endpoint'] ?? '' ),
            'courier_token'        => (string) ( $old['courier_token'] ?? '' ),
            'courier_tracking_url' => (string) ( $old['courier_tracking_url'] ?? '' ),
        );

        if ( mrc_can( 'integration.sms' ) && array_key_exists( 'sms_endpoint', $input ) ) {
            $out['sms_endpoint'] = esc_url_raw( $input['sms_endpoint'] ?? '' );
            if ( ! empty( $input['sms_token'] ) ) {
                $out['sms_token'] = ( new CredentialCipher() )->encrypt( sanitize_text_field( $input['sms_token'] ) );
            }
        }

        if ( mrc_can( 'integration.courier_webhook' ) && array_key_exists( 'courier_endpoint', $input ) ) {
            $out['courier_label']        = sanitize_text_field( $input['courier_label'] ?? '' );
            $out['courier_endpoint']     = esc_url_raw( $input['courier_endpoint'] ?? '' );
            $out['courier_tracking_url'] = esc_url_raw( $input['courier_tracking_url'] ?? '' );
            if ( ! empty( $input['courier_token'] ) ) {
                $out['courier_token'] = ( new CredentialCipher() )->encrypt( sanitize_text_field( $input['courier_token'] ) );
            }
        }

        return $out;
    }

    public function render( bool $embedded = false ): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $settings = (array) get_option( 'mrc_integration_settings', array() );
        ?>
        <?php if ( ! $embedded ) : ?><div class="wrap mrc-ops-wrap mrc-ops-courier">
            <?php
            \MRBP\Admin\OperationsUi::header(
                __( 'COMMERCE INTEGRATIONS', 'mr-commerce' ),
                __( 'Courier Integration', 'mr-commerce' ),
                __( 'Connect MR Commerce with a courier webhook for consignments and tracking.', 'mr-commerce' ),
                'dashicons-admin-site-alt3',
                array( __( 'Module', 'mr-commerce' ) => __( 'MR Commerce', 'mr-commerce' ), __( 'Access', 'mr-commerce' ) => __( 'Pro', 'mr-commerce' ) )
            );
            ?>
        <?php else : ?><section class="mrc-merged-workspace mrc-merged-workspace--courier"><div class="mrc-merged-workspace__header"><span class="dashicons dashicons-admin-site-alt3"></span><div><span class="mrc-ops-eyebrow"><?php esc_html_e( 'COMMERCE INTEGRATIONS', 'mr-commerce' ); ?></span><h2><?php esc_html_e( 'Courier Integration', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Create consignments and tracking links through a secured courier webhook.', 'mr-commerce' ); ?></p></div></div><?php endif; ?>
            <?php if ( mrc_can( 'integration.courier_webhook' ) ) : ?>
                <form method="post" action="options.php">
                    <?php settings_fields( 'mrc_courier_integration_group' ); ?>
                    <div class="card">
                        <h2><?php esc_html_e( 'Courier webhook adapter', 'mr-commerce' ); ?></h2>
                        <div class="mrc-courier-primary-row">
                            <input type="text" name="mrc_integration_settings[courier_label]" value="<?php echo esc_attr( $settings['courier_label'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Courier name', 'mr-commerce' ); ?>">
                            <input type="url" name="mrc_integration_settings[courier_endpoint]" value="<?php echo esc_attr( $settings['courier_endpoint'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Consignment endpoint', 'mr-commerce' ); ?>">
                        </div>
                        <input class="large-text" type="url" name="mrc_integration_settings[courier_tracking_url]" value="<?php echo esc_attr( $settings['courier_tracking_url'] ?? '' ); ?>" placeholder="https://courier.test/track/{id}">
                        <input class="large-text" type="password" name="mrc_integration_settings[courier_token]" value="" placeholder="<?php esc_attr_e( 'New API token (leave blank to preserve)', 'mr-commerce' ); ?>">
                        <?php
                        \MRBP\Admin\OperationsUi::guide(
                            'Order তথ্য courier provider-এ পাঠিয়ে consignment ও tracking link তৈরি করতে সাহায্য করে।',
                            array( 'Courier name, endpoint ও tracking URL দিন।', 'Provider token নিরাপদভাবে Save করুন।', 'একটি test order দিয়ে consignment response যাচাই করুন।' ),
                            'Courier API সফল হলে tracking ID order-এ সংরক্ষণ করা যাবে।',
                            'প্রতিটি courier-এর API format আলাদা; compatible adapter প্রয়োজন।'
                        );
                        ?>
                    </div>
                    <?php submit_button(); ?>
                </form>
            <?php else : ?>
                <?php ProFeature::render( 'integration.courier_webhook', __( 'Connected Courier Integration', 'mr-commerce' ), __( 'Create consignments through a generic authenticated webhook adapter.', 'mr-commerce' ) ); ?>
            <?php endif; ?>
        <?php if ( $embedded ) : ?></section><?php else : ?></div><?php endif; ?>
        <?php
    }

    public function render_embedded(): void {
        $this->render( true );
    }
}
