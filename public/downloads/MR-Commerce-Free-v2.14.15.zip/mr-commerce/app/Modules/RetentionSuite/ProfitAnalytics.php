<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

final class ProfitAnalytics {
    public function register(): void {
        if ( is_admin() ) {
            add_action( 'admin_menu', array( $this, 'menu' ), 45 );
        }
    }

    public function menu(): void {
        add_submenu_page( 'woocommerce', __( 'Profit Analytics', 'mr-commerce' ), __( 'Profit Analytics', 'mr-commerce' ), 'manage_woocommerce', 'mrc-profit-analytics', array( $this, 'render' ) );
    }

    public function render( bool $embedded = false ): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        if ( ! mrc_can( 'analytics.profit' ) ) {
            echo $embedded ? '<section class="mrc-merged-workspace mrc-merged-workspace--profit">' : '<div class="wrap mrc-ops-wrap mrc-ops-profit">';
            if ( $embedded ) {
                $this->render_embedded_header();
            } else {
                \MRBP\Admin\OperationsUi::header( __( 'FINANCIAL INTELLIGENCE', 'mr-commerce' ), __( 'Profit Analytics', 'mr-commerce' ), __( 'Understand revenue, cost, refunds, gross profit and margin from a focused commerce dashboard.', 'mr-commerce' ), 'dashicons-chart-area', array( __( 'Window', 'mr-commerce' ) => __( '30 days', 'mr-commerce' ), __( 'Access', 'mr-commerce' ) => __( 'Pro', 'mr-commerce' ) ) );
            }
            \MRBP\Admin\ProFeature::render( 'analytics.profit', __( 'Advanced Cost & Profit Analytics', 'mr-commerce' ), __( 'Measure revenue, product cost, refunds and estimated gross profit.', 'mr-commerce' ) );
            echo $embedded ? '</section>' : '</div>';
            return;
        }

        $after   = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
        $orders  = wc_get_orders( array( 'limit' => -1, 'status' => array( 'processing', 'completed', 'mrc-delivered' ), 'date_created' => '>' . $after ) );
        $revenue = 0.0;
        $cost    = 0.0;
        $refunds = 0.0;
        $units   = 0;

        foreach ( $orders as $order ) {
            $revenue += (float) $order->get_total();
            $refunds += (float) $order->get_total_refunded();
            foreach ( $order->get_items() as $item ) {
                $product_id = $item->get_variation_id() ?: $item->get_product_id();
                $qty        = (int) $item->get_quantity();
                $units     += $qty;
                $cost      += (float) get_post_meta( $product_id, '_mrc_purchase_cost', true ) * $qty;
            }
        }

        $net    = $revenue - $refunds;
        $profit = $net - $cost;
        $margin = $net > 0 ? $profit / $net * 100 : 0;
        ?>
        <?php if ( $embedded ) : ?><section class="mrc-merged-workspace mrc-merged-workspace--profit"><?php $this->render_embedded_header(); ?><?php else : ?><div class="wrap mrc-ops-wrap mrc-ops-profit">
            <?php \MRBP\Admin\OperationsUi::header( __( 'FINANCIAL INTELLIGENCE', 'mr-commerce' ), __( 'Profit Analytics', 'mr-commerce' ), __( 'Understand revenue, cost, refunds, gross profit and margin across the last 30 days.', 'mr-commerce' ), 'dashicons-chart-area', array( __( 'Window', 'mr-commerce' ) => __( '30 days', 'mr-commerce' ), __( 'Orders', 'mr-commerce' ) => (string) count( $orders ) ) ); ?><?php endif; ?>
            <div class="mrc-ops-kpis">
                <div class="mrc-ops-kpi"><span><?php esc_html_e( 'Net revenue', 'mr-commerce' ); ?></span><strong><?php echo wp_kses_post( wc_price( $net ) ); ?></strong><small><?php esc_html_e( 'After refunds', 'mr-commerce' ); ?></small></div>
                <div class="mrc-ops-kpi"><span><?php esc_html_e( 'Product cost', 'mr-commerce' ); ?></span><strong><?php echo wp_kses_post( wc_price( $cost ) ); ?></strong><small><?php esc_html_e( 'Recorded purchase cost', 'mr-commerce' ); ?></small></div>
                <div class="mrc-ops-kpi is-positive"><span><?php esc_html_e( 'Gross profit', 'mr-commerce' ); ?></span><strong><?php echo wp_kses_post( wc_price( $profit ) ); ?></strong><small><?php esc_html_e( 'Net revenue minus cost', 'mr-commerce' ); ?></small></div>
                <div class="mrc-ops-kpi"><span><?php esc_html_e( 'Profit margin', 'mr-commerce' ); ?></span><strong><?php echo esc_html( number_format_i18n( $margin, 1 ) . '%' ); ?></strong><small><?php esc_html_e( 'Estimated gross margin', 'mr-commerce' ); ?></small></div>
            </div>
            <div class="mrc-ops-note"><span class="dashicons dashicons-chart-bar"></span><div><strong><?php esc_html_e( '30-day commerce summary', 'mr-commerce' ); ?></strong><p><?php echo esc_html( sprintf( __( '%1$d orders · %2$d units · Refunds %3$s', 'mr-commerce' ), count( $orders ), $units, wp_strip_all_tags( wc_price( $refunds ) ) ) ); ?></p></div></div>
        <?php if ( $embedded ) : ?></section><?php else : ?></div><?php endif; ?>
        <?php
    }

    public function render_embedded(): void {
        $this->render( true );
    }

    private function render_embedded_header(): void {
        ?>
        <div class="mrc-merged-workspace__header">
            <span class="dashicons dashicons-chart-area"></span>
            <div>
                <span class="mrc-ops-eyebrow"><?php esc_html_e( 'FINANCIAL INTELLIGENCE', 'mr-commerce' ); ?></span>
                <h2><?php esc_html_e( 'Profit Analytics', 'mr-commerce' ); ?></h2>
                <p><?php esc_html_e( 'Review revenue, product cost, refunds, gross profit and margin for the last 30 days.', 'mr-commerce' ); ?></p>
            </div>
        </div>
        <?php
    }
}
