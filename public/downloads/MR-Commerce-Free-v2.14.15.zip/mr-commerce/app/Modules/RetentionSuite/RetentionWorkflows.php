<?php

namespace MRBP\Modules\RetentionSuite;

defined( 'ABSPATH' ) || exit;

final class RetentionWorkflows {
    public function register(): void {
        add_action( 'woocommerce_review_order_before_submit', array( $this, 'consent_field' ) );
        add_action( 'woocommerce_checkout_update_order_review', array( $this, 'capture_cart' ) );
        add_action( 'woocommerce_checkout_create_order', array( $this, 'save_consent' ), 30, 2 );
        add_action( 'woocommerce_order_status_completed', array( $this, 'schedule_review' ) );
        add_action( 'woocommerce_order_status_mrc-delivered', array( $this, 'schedule_review' ) );
        add_action( 'mrc_send_review_reminder', array( $this, 'send_review' ) );
        add_action( 'mrc_recover_abandoned_carts', array( $this, 'recover_carts' ) );
        add_action( 'init', array( $this, 'schedule_cron' ) );
        add_action( 'woocommerce_order_details_after_order_table', array( $this, 'reorder_button' ), 25 );
        add_action( 'admin_post_mrc_reorder', array( $this, 'reorder' ) );
        add_action( 'admin_post_nopriv_mrc_reorder', array( $this, 'reorder' ) );
    }

    private function settings(): array { return wp_parse_args( get_option( 'mrc_retention_settings', array() ), array( 'review_days' => 7, 'abandoned_minutes' => 60, 'coupon_percent' => 10, 'email_enabled' => 'yes' ) ); }

    public function consent_field(): void {
        if ( ! mrc_can( 'retention.abandoned_cart' ) ) { return; }
        woocommerce_form_field( 'mrc_retention_consent', array( 'type' => 'checkbox', 'label' => __( 'Email me helpful cart reminders and offers.', 'mr-commerce' ), 'required' => false ) );
    }

    public function capture_cart( string $post_data ): void {
        if ( ! mrc_can( 'retention.abandoned_cart' ) || ! WC()->cart || WC()->cart->is_empty() ) { return; }
        parse_str( $post_data, $data );
        if ( empty( $data['mrc_retention_consent'] ) ) { return; }
        $email = sanitize_email( $data['billing_email'] ?? '' ); if ( ! is_email( $email ) ) { return; }
        $items = array(); foreach ( WC()->cart->get_cart() as $item ) { $items[] = array( 'product_id' => absint( $item['product_id'] ), 'variation_id' => absint( $item['variation_id'] ?? 0 ), 'quantity' => max( 1, absint( $item['quantity'] ) ) ); }
        $carts = (array) get_option( 'mrc_abandoned_carts', array() ); $key = hash_hmac( 'sha256', strtolower( $email ), wp_salt( 'auth' ) );
        $carts[ $key ] = array( 'email' => $email, 'phone' => sanitize_text_field( $data['billing_phone'] ?? '' ), 'items' => $items, 'total' => (float) WC()->cart->get_total( 'edit' ), 'updated' => time(), 'sent' => 0, 'recovered' => 0 );
        uasort( $carts, static fn( $a, $b ) => (int) ( $b['updated'] ?? 0 ) <=> (int) ( $a['updated'] ?? 0 ) );
        $carts = array_slice( $carts, 0, max( 1, mrc_limit( 'retention.abandoned_cart' ) ), true );
        if ( false === get_option( 'mrc_abandoned_carts', false ) ) { add_option( 'mrc_abandoned_carts', $carts, '', false ); } else { update_option( 'mrc_abandoned_carts', $carts, false ); }
    }

    public function save_consent( $order, array $data ): void {
        if ( ! $order instanceof \WC_Order ) { return; }
        $order->update_meta_data( '_mrc_retention_consent', empty( $_POST['mrc_retention_consent'] ) ? 'no' : 'yes' );
        $email = strtolower( $order->get_billing_email() ); if ( $email ) { $carts = (array) get_option( 'mrc_abandoned_carts', array() ); $key = hash_hmac( 'sha256', $email, wp_salt( 'auth' ) ); if ( isset( $carts[ $key ] ) ) { $carts[ $key ]['recovered'] = time(); update_option( 'mrc_abandoned_carts', $carts, false ); } }
    }

    public function schedule_cron(): void { if ( ! wp_next_scheduled( 'mrc_recover_abandoned_carts' ) ) { wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'mrc_recover_abandoned_carts' ); } }

    public function recover_carts(): void {
        if ( ! mrc_can( 'retention.abandoned_cart' ) ) { return; }
        $settings = $this->settings(); if ( 'yes' !== $settings['email_enabled'] ) { return; } $carts = (array) get_option( 'mrc_abandoned_carts', array() ); $changed = false;
        foreach ( $carts as &$cart ) {
            if ( ! empty( $cart['sent'] ) || ! empty( $cart['recovered'] ) || (int) $cart['updated'] > time() - max( 15, absint( $settings['abandoned_minutes'] ) ) * MINUTE_IN_SECONDS ) { continue; }
            $coupon = $this->recovery_coupon( (string) $cart['email'], (float) $settings['coupon_percent'] );
            $message = sprintf( __( 'You left items in your cart at %1$s. Return to complete your order: %2$s', 'mr-commerce' ), get_bloginfo( 'name' ), wc_get_cart_url() );
            if ( $coupon ) { $message .= "\n" . sprintf( __( 'Use coupon %1$s for %2$s%% off.', 'mr-commerce' ), $coupon, (float) $settings['coupon_percent'] ); }
            if ( ProviderManager::email( (string) $cart['email'], __( 'Your cart is waiting', 'mr-commerce' ), $message ) ) {
                if ( ! empty( $cart['phone'] ) ) { do_action( 'mrc/send_sms', (string) $cart['phone'], $message ); }
                $cart['sent'] = time(); $changed = true;
            }
        } unset( $cart ); if ( $changed ) { update_option( 'mrc_abandoned_carts', $carts, false ); }
    }

    private function recovery_coupon( string $email, float $percent ): string {
        if ( ! mrc_can( 'retention.automated_coupons' ) || $percent <= 0 ) { return ''; }
        $code = 'RETURN-' . strtoupper( substr( hash( 'sha256', strtolower( $email ) ), 0, 8 ) ); if ( wc_get_coupon_id_by_code( $code ) ) { return $code; }
        $coupon = new \WC_Coupon(); $coupon->set_code( $code ); $coupon->set_discount_type( 'percent' ); $coupon->set_amount( min( 50, $percent ) ); $coupon->set_email_restrictions( array( $email ) ); $coupon->set_usage_limit( 1 ); $coupon->set_date_expires( time() + 7 * DAY_IN_SECONDS ); $coupon->save(); return $code;
    }

    public function schedule_review( int $order_id ): void {
        if ( ! mrc_can( 'retention.review_reminder' ) || wp_next_scheduled( 'mrc_send_review_reminder', array( $order_id ) ) ) { return; }
        wp_schedule_single_event( time() + max( 1, absint( $this->settings()['review_days'] ) ) * DAY_IN_SECONDS, 'mrc_send_review_reminder', array( $order_id ) );
    }

    public function send_review( int $order_id ): void {
        $order = wc_get_order( $order_id ); if ( 'yes' !== $this->settings()['email_enabled'] || ! $order || $order->get_meta( '_mrc_review_reminder_sent' ) ) { return; }
        $links = array(); foreach ( $order->get_items() as $item ) { $product = $item->get_product(); if ( $product ) { $links[] = $product->get_name() . ': ' . $product->get_permalink() . '#reviews'; } }
        if ( $links && ProviderManager::email( $order->get_billing_email(), __( 'How was your order?', 'mr-commerce' ), __( 'We would value your review:', 'mr-commerce' ) . "\n" . implode( "\n", $links ) ) ) { $order->update_meta_data( '_mrc_review_reminder_sent', current_time( 'mysql', true ) ); $order->save(); }
    }

    public function reorder_button( $order ): void {
        if ( ! $order instanceof \WC_Order || ! mrc_can( 'retention.reorder' ) || ! in_array( $order->get_status(), array( 'completed', 'mrc-delivered' ), true ) ) { return; }
        echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrc_reorder&order_id=' . $order->get_id() ), 'mrc_reorder_' . $order->get_id() ) ) . '">' . esc_html__( 'Order again', 'mr-commerce' ) . '</a></p>';
    }

    public function reorder(): void {
        $id = absint( $_GET['order_id'] ?? 0 ); check_admin_referer( 'mrc_reorder_' . $id ); $order = wc_get_order( $id );
        if ( ( ! WC()->cart || ! WC()->customer ) && function_exists( 'wc_load_cart' ) ) { wc_load_cart(); }
        if ( ! $order || ! mrc_can( 'retention.reorder' ) || ( get_current_user_id() ? (int) $order->get_customer_id() !== get_current_user_id() : strtolower( (string) $order->get_billing_email() ) !== strtolower( sanitize_email( WC()->customer ? WC()->customer->get_billing_email() : '' ) ) ) ) { wp_die( esc_html__( 'This order cannot be reordered.', 'mr-commerce' ) ); }
        foreach ( $order->get_items() as $item ) { $product = $item->get_product(); if ( $product && $product->is_purchasable() ) { WC()->cart->add_to_cart( $product->get_id(), $item->get_quantity(), $item->get_variation_id(), $item->get_variation_attributes() ); } }
        wp_safe_redirect( wc_get_cart_url() ); exit;
    }

    public static function segment( \WC_Customer $customer ): string {
        $spent = (float) $customer->get_total_spent(); $orders = (int) $customer->get_order_count();
        if ( ( $spent >= 50000 || $orders >= 10 ) && mrc_can( 'customer.segmentation' ) ) { return 'vip'; } if ( $orders >= 3 ) { return 'loyal'; } if ( $orders >= 1 ) { return 'customer'; } return 'lead';
    }
}
