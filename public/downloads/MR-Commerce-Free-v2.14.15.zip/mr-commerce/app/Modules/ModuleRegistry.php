<?php

namespace MRBP\Modules;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ModuleRegistry {

    public function all(): array {
        $manifest = require MRBP_PATH . 'config/module-manifest.php';
        $modules = apply_filters( 'mrbp/module_registry', is_array( $manifest ) ? $manifest : array() );

        if ( ! is_array( $modules ) ) {
            return array();
        }

        uasort(
            $modules,
            static fn ( array $left, array $right ): int => (int) ( $left['position'] ?? 999 ) <=> (int) ( $right['position'] ?? 999 )
        );

        return $modules;
    }

    public function get( string $module_id ): ?array {
        $modules = $this->all();

        return $modules[ $module_id ] ?? null;
    }

    public function has( string $module_id ): bool {
        return null !== $this->get( $module_id );
    }
}
