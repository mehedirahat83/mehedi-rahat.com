<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Security {
    public static function verify_nonce(string $nonce, string $action): bool {
        return (bool) wp_verify_nonce($nonce, $action);
    }

    public static function can_manage(): bool {
        return current_user_can('manage_options') || current_user_can('manage_woocommerce');
    }

    public static function clean_text($value): string {
        return sanitize_text_field(wp_unslash($value));
    }
}
