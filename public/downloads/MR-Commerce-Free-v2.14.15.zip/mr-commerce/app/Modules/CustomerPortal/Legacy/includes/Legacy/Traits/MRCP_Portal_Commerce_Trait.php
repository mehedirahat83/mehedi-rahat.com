<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait MRCP_Portal_Commerce_Trait {
    private function notification_admin_email() {
        return apply_filters('mrcp_support_admin_email', 'support@mehedirahat.com');
    }

    private function mail_headers() {
        $from_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        return [
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: MehediRahat Support <' . $this->notification_admin_email() . '>',
            'From: ' . $from_name . ' <' . $this->notification_admin_email() . '>',
        ];
    }

    private function html_email($title, $content, $button_text = '', $button_url = '') {
        $brand = '#1E8A8A';
        $html  = '<div style="margin:0;padding:28px;background:#f5f8fb;font-family:Arial,Helvetica,sans-serif;color:#102a2a;">';
        $html .= '<div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:18px;overflow:hidden;box-shadow:0 15px 45px rgba(15,109,109,.12);">';
        $html .= '<div style="padding:24px 28px;background:linear-gradient(135deg,#1E8A8A,#0F6D6D);color:#fff;">';
        $html .= '<h2 style="margin:0;font-size:24px;line-height:1.3;color:#fff;">' . esc_html($title) . '</h2>';
        $html .= '<p style="margin:8px 0 0;color:rgba(255,255,255,.86);">MR Commerce Pro</p>';
        $html .= '</div><div style="padding:28px;line-height:1.65;font-size:15px;">' . wp_kses_post($content);
        if ($button_text && $button_url) {
            $html .= '<p style="margin:26px 0 6px;"><a href="' . esc_url($button_url) . '" style="display:inline-block;background:' . esc_attr($brand) . ';color:#fff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:12px;">' . esc_html($button_text) . '</a></p>';
        }
        $html .= '</div><div style="padding:18px 28px;background:#f6fbfb;color:#6b7b7b;font-size:13px;">This email was sent from MR Commerce Pro.</div>';
        $html .= '</div></div>';
        return $html;
    }

    private function notify_admin_new_ticket($ticket_id, $subject, $message, $category, $order_id = 0, $attachment = '') {
        $user = wp_get_current_user();
        $ticket_ref = 'MR-' . absint($ticket_id);
        $body  = '<p>A new support ticket has been submitted.</p>';
        $body .= '<table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin:18px 0;">';
        $rows = [
            'Ticket ID' => $ticket_ref,
            'Customer' => $user->display_name,
            'Customer Email' => $user->user_email,
            'Category' => ucfirst($category),
            'Related Order' => $order_id ? '#' . $this->display_order_number($order_id) : 'Not selected',
        ];
        foreach ($rows as $label => $value) {
            $body .= '<tr><td style="padding:9px 0;color:#6b7b7b;width:150px;border-bottom:1px solid #eef3f3;">' . esc_html($label) . '</td><td style="padding:9px 0;font-weight:700;border-bottom:1px solid #eef3f3;">' . esc_html($value) . '</td></tr>';
        }
        $body .= '</table>';
        $body .= '<p><strong>Subject:</strong><br>' . esc_html($subject) . '</p>';
        $body .= '<p><strong>Message:</strong><br>' . wp_kses_post(wpautop($message)) . '</p>';
        if ($attachment) $body .= '<p><strong>Attachment:</strong> <a href="' . esc_url($attachment) . '">View attachment</a></p>';
        $admin_url = admin_url('post.php?post=' . absint($ticket_id) . '&action=edit');
        wp_mail($this->notification_admin_email(), '🎫 New Support Ticket #' . $ticket_ref . ' - ' . wp_specialchars_decode($subject, ENT_QUOTES), $this->html_email('New Support Ticket #' . $ticket_ref, $body, 'View Ticket in Admin', $admin_url), $this->mail_headers());
    }

    private function notify_customer_ticket_created($ticket_id, $subject) {
        $user = wp_get_current_user();
        if (!$user || empty($user->user_email)) return;
        $ticket_ref = 'MR-' . absint($ticket_id);
        $body  = '<p>Hello ' . esc_html($user->display_name) . ',</p>';
        $body .= '<p>Thank you for contacting MehediRahat Support. We have received your ticket and our team will review it shortly.</p>';
        $body .= '<p><strong>Ticket ID:</strong> ' . esc_html($ticket_ref) . '<br><strong>Subject:</strong> ' . esc_html($subject) . '</p>';
        wp_mail($user->user_email, 'Your support ticket has been received #' . $ticket_ref, $this->html_email('Ticket Received #' . $ticket_ref, $body, 'View Ticket', $this->ticket_url($ticket_id)), $this->mail_headers());
    }

    private function notify_customer_admin_reply($ticket_id, $message, $attachment = '', $status = 'answered') {
        $ticket = get_post(absint($ticket_id));
        if (!$ticket || $ticket->post_type !== 'mrcp_ticket') return;
        $user = get_user_by('id', (int) $ticket->post_author);
        if (!$user || empty($user->user_email)) return;

        $ticket_ref = 'MR-' . absint($ticket_id);
        $body  = '<p>Hello ' . esc_html($user->display_name) . ',</p>';
        $body .= '<p>Our support team has replied to your ticket.</p>';
        $body .= '<table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin:18px 0;">';
        $rows = [
            'Ticket ID' => $ticket_ref,
            'Subject' => $ticket->post_title,
            'Status' => ucfirst($status),
        ];
        foreach ($rows as $label => $value) {
            $body .= '<tr><td style="padding:9px 0;color:#6b7b7b;width:130px;border-bottom:1px solid #eef3f3;">' . esc_html($label) . '</td><td style="padding:9px 0;font-weight:700;border-bottom:1px solid #eef3f3;">' . esc_html($value) . '</td></tr>';
        }
        $body .= '</table>';
        $body .= '<p><strong>Support Reply:</strong></p>' . wp_kses_post(wpautop($message));
        if ($attachment) $body .= '<p><strong>Attachment:</strong> <a href="' . esc_url($attachment) . '">View attachment</a></p>';

        wp_mail($user->user_email, 'Support replied to your ticket #' . $ticket_ref, $this->html_email('New Reply on Ticket #' . $ticket_ref, $body, 'View Ticket', $this->ticket_url($ticket_id)), $this->mail_headers());
    }

    private function add_notification($user_id, $title, $message, $url = '', $type = 'ticket') {
        $items = get_user_meta($user_id, '_mrcp_notifications', true);
        if (!is_array($items)) $items = [];
        array_unshift($items, [
            'id' => uniqid('mrcp_', true),
            'title' => sanitize_text_field($title),
            'message' => sanitize_text_field($message),
            'url' => esc_url_raw($url),
            'type' => sanitize_key($type),
            'read' => false,
            'read_at' => 0,
            'time' => current_time('timestamp'),
        ]);
        $items = array_slice($items, 0, 20);
        update_user_meta($user_id, '_mrcp_notifications', $items);
    }

    private function notifications($user_id = 0, $limit = 6) {
        $user_id = $user_id ?: get_current_user_id();
        $items = get_user_meta($user_id, '_mrcp_notifications', true);
        if (!is_array($items)) $items = [];
        return array_slice($items, 0, $limit);
    }

    private function unread_notification_count($user_id = 0) {
        $count = 0;
        foreach ($this->notifications($user_id ?: get_current_user_id(), 50) as $item) {
            if (empty($item['read'])) $count++;
        }
        return $count;
    }

    public function ajax_mark_notifications_read() {
        if ('POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''))) {
            wp_send_json_error(['message' => 'Invalid request method.'], 405);
        }
        check_ajax_referer('mrcp_search_nonce', 'nonce');
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Not logged in.'], 401);

        $user_id = get_current_user_id();
        $items = get_user_meta($user_id, '_mrcp_notifications', true);
        if (!is_array($items)) $items = [];
        $read_at = current_time('timestamp');

        foreach ($items as &$item) {
            if (empty($item['read'])) {
                $item['read'] = true;
                $item['read_at'] = $read_at;
            } elseif (!isset($item['read_at'])) {
                $item['read_at'] = 0;
            }
        }
        unset($item);

        update_user_meta($user_id, '_mrcp_notifications', $items);
        wp_send_json_success([
            'count' => 0,
            'html' => $this->notification_items_html($items),
        ]);
    }

    public function ajax_mark_notification_read() {
        if ('POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''))) {
            wp_send_json_error(['message' => 'Invalid request method.'], 405);
        }
        check_ajax_referer('mrcp_search_nonce', 'nonce');
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Not logged in.'], 401);

        $notification_id = isset($_POST['notification_id']) ? sanitize_text_field(wp_unslash($_POST['notification_id'])) : '';
        if ($notification_id === '') wp_send_json_error(['message' => 'Missing notification ID.'], 400);

        $user_id = get_current_user_id();
        $items = get_user_meta($user_id, '_mrcp_notifications', true);
        if (!is_array($items)) $items = [];
        $found = false;

        foreach ($items as &$item) {
            if (!empty($item['id']) && hash_equals((string) $item['id'], $notification_id)) {
                $item['read'] = true;
                $item['read_at'] = current_time('timestamp');
                $found = true;
                break;
            }
        }
        unset($item);

        if (!$found) wp_send_json_error(['message' => 'Notification not found.'], 404);

        update_user_meta($user_id, '_mrcp_notifications', $items);
        wp_send_json_success([
            'count' => $this->unread_notification_count($user_id),
            'html' => $this->notification_items_html($items),
        ]);
    }

    public function ajax_get_notifications() {
        if ('POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''))) {
            wp_send_json_error(['message' => 'Invalid request method.'], 405);
        }
        check_ajax_referer('mrcp_search_nonce', 'nonce');
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Not logged in.'], 401);

        $user_id = get_current_user_id();
        $items = get_user_meta($user_id, '_mrcp_notifications', true);
        if (!is_array($items)) $items = [];

        wp_send_json_success([
            'count' => $this->unread_notification_count($user_id),
            'html' => $this->notification_items_html($items),
        ]);
    }

    public function ticket_admin_badges() {
        global $menu;
        if (empty($menu) || !current_user_can('edit_posts')) return;
        $q = new WP_Query([
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [[
                'key' => '_mrcp_ticket_status',
                'value' => 'closed',
                'compare' => '!=',
            ]],
            'no_found_rows' => false,
        ]);
        $count = (int) $q->found_posts;
        if ($count < 1) return;
        foreach ($menu as $i => $item) {
            if (!empty($item[2]) && $item[2] === 'edit.php?post_type=mrcp_ticket') {
                $menu[$i][0] .= ' <span class="awaiting-mod"><span class="pending-count">' . esc_html($count) . '</span></span>';
                break;
            }
        }
        $activation_count = $this->activation_admin_count('pending');
        if ($activation_count > 0) {
            foreach ($menu as $i => $item) {
                if (!empty($item[2]) && $item[2] === 'edit.php?post_type=mrcp_activation') {
                    $menu[$i][0] .= ' <span class="awaiting-mod"><span class="pending-count">' . esc_html($activation_count) . '</span></span>';
                    break;
                }
            }
        }
    }

    private function support_url($path = '') {
        return home_url('/dashboard/support/' . ltrim($path, '/'));
    }
}
