<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait MRCP_Portal_Core_Trait {
    private function money($amount) {
        $amount = round((float) $amount);
        return '৳ ' . number_format_i18n($amount, 0);
    }

    private function membership_data($total_spent) {
        if (class_exists('MRCP_Membership')) {
            return MRCP_Membership::resolve_by_spend((float) $total_spent, get_current_user_id());
        }

        return [
            'key' => 'silver',
            'level' => 'silver',
            'name' => 'Silver Member',
            'short' => 'Silver',
            'icon' => '🥈',
            'discount' => 0,
            'spent' => (float) $total_spent,
            'lifetime_spend' => (float) $total_spent,
            'next' => null,
            'target' => null,
            'needed' => 0,
            'remaining' => 0,
            'progress' => 0,
            'progress_percentage' => 0,
            'vip' => false,
            'is_top_level' => false,
            'levels' => [],
        ];
    }

    private function current_user_data() {
        $user = wp_get_current_user();
        return [
            'id' => get_current_user_id(),
            'name' => $user->display_name ?: $user->user_login,
            'registered' => $user->user_registered ? date_i18n('d M Y', strtotime($user->user_registered)) : '',
            'avatar' => get_avatar_url(get_current_user_id(), ['size' => 180]),
        ];
    }

    private function stats() {
        $user_id = get_current_user_id();
        $downloads = [];
        $total_spent = 0;
        $completed_orders_count = 0;

        if ($this->wc_active()) {
            // The customer dashboard represents confirmed purchases only.
            // Reuse the existing completed-order helper so on-hold, pending,
            // cancelled, failed and refunded orders never inflate the count.
            $completed_orders_count = $this->completed_order_count();

            $total_spent = class_exists('MRCP_Membership') ? MRCP_Membership::get_lifetime_spend($user_id) : wc_get_customer_total_spent($user_id);
            $downloads = function_exists('wc_get_customer_available_downloads') ? wc_get_customer_available_downloads($user_id) : [];
        }

        return [
            'orders_count' => $completed_orders_count,
            'total_spent' => $total_spent,
            'downloads_count' => is_array($downloads) ? count($downloads) : 0,
            'tickets_count' => $this->ticket_count(),
            'notification_count' => $this->unread_notification_count($user_id),
            'activation_count' => $this->activation_count(),
            'completed_orders_count' => $completed_orders_count,
        ];
    }

    private function recent_orders($limit = 3) {
        if (!$this->wc_active()) return [];
        return wc_get_orders([
            'customer_id' => get_current_user_id(),
            'limit' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array_keys(wc_get_order_statuses()),
        ]);
    }

    private function completed_orders($limit = -1) {
        if (!$this->wc_active()) return [];
        return wc_get_orders([
            'customer_id' => get_current_user_id(),
            'limit' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => ['completed'],
        ]);
    }

    private function completed_order_count() {
        return count($this->completed_orders(-1));
    }

    private function invoice_url($order_id) {
        return home_url('/dashboard/invoice/' . absint($order_id) . '/');
    }

    private function order_view_url($order_id) {
        return home_url('/dashboard/order/' . absint($order_id) . '/');
    }

    /**
     * Return the customer-selected manual gateway instead of the outer
     * WooCommerce gateway title (for example, bKash instead of MR Commerce Pro).
     */
    private function payment_source_label($order): string {
        $fallback = $order->get_payment_method_title() ?: 'N/A';
        $gateway_id = '';

        foreach (['_mrbp_gateway', '_mrbp_preferred_gateway', '_mrbp_payment_gateway'] as $meta_key) {
            $candidate = $order->get_meta($meta_key, true);
            if (is_scalar($candidate) && '' !== trim((string) $candidate)) {
                $gateway_id = sanitize_key((string) $candidate);
                break;
            }
        }

        if ('' === $gateway_id) {
            return $fallback;
        }

        if (function_exists('mrbp')) {
            try {
                $label = mrbp()->gateways()->label($gateway_id);
                if (is_scalar($label) && '' !== trim((string) $label)) {
                    return (string) $label;
                }
            } catch (\Throwable $error) {
                // Payment Pro may be disabled; keep a readable stored gateway ID.
            }
        }

        return ucwords(str_replace(['_', '-'], ' ', $gateway_id));
    }

    private function downloads($limit = 3) {
        if (!$this->wc_active() || !function_exists('wc_get_customer_available_downloads')) return [];
        $downloads = wc_get_customer_available_downloads(get_current_user_id());
        if (!is_array($downloads)) return [];
        return array_slice($downloads, 0, $limit);
    }

    private function url($path = '') {
        return home_url('/dashboard/' . ltrim($path, '/'));
    }

    private function wc_account_url($endpoint = '') {
        if (function_exists('wc_get_account_endpoint_url') && $endpoint) return wc_get_account_endpoint_url($endpoint);
        if (function_exists('wc_get_page_permalink')) return wc_get_page_permalink('myaccount');
        return home_url('/my-account/');
    }

    /** Lightweight, dependency-free icon set for the customer dashboard. */
    private function premium_icon($name): string {
        $paths = [
            'sparkles' => '<path d="M12 3l1.1 3.1L16 7.2l-2.9 1.1L12 11.5l-1.1-3.2L8 7.2l2.9-1.1L12 3Z"/><path d="M5.5 12.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2Z"/><path d="M18.5 13l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7.7-1.8Z"/>',
            'calendar' => '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M7.5 3v4M16.5 3v4M3.5 9.5h17"/><path d="M8 13h.01M12 13h.01M16 13h.01M8 16.5h.01M12 16.5h.01"/>',
            'orders' => '<path d="M6 7.5h12l1 12H5l1-12Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2M9 12h6"/>',
            'wallet' => '<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4H18a2 2 0 0 1 2 2v13H6.5A2.5 2.5 0 0 1 4 16.5v-10Z"/><path d="M4 7h13M15 11h5v5h-5a2.5 2.5 0 0 1 0-5Z"/><path d="M16 13.5h.01"/>',
            'download' => '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M12 7v8M8.5 11.5 12 15l3.5-3.5"/>',
            'support' => '<path d="M5 18.5A8.5 8.5 0 1 1 8.5 21L4 22l1-3.5Z"/><path d="M9.4 9a2.75 2.75 0 1 1 4.3 2.27c-.9.62-1.7 1.12-1.7 2.23M12 17h.01"/>',
            'key' => '<circle cx="8.5" cy="15.5" r="4.5"/><path d="m12 12 8-8M16 8l2 2M18 6l2 2"/>',
            'heart' => '<path d="M20.5 9.5c0 5-8.5 10-8.5 10s-8.5-5-8.5-10A4.5 4.5 0 0 1 12 7.4a4.5 4.5 0 0 1 8.5 2.1Z"/>',
            'silver' => '<path d="m8 3 4 6 4-6M7 3h10l2 5-7 13L5 8l2-5Z"/><path d="M8 9h8"/>',
            'gold' => '<circle cx="12" cy="13" r="7"/><path d="m8 3 4 4 4-4M12 10v6M10 12h3a1.5 1.5 0 0 1 0 3h-3"/>',
            'diamond' => '<path d="m4 8 4-5h8l4 5-8 13L4 8Z"/><path d="M4 8h16M8 3l4 5 4-5M8 8l4 13 4-13"/>',
            'vip' => '<path d="m3 8 4 3 5-7 5 7 4-3-2 11H5L3 8Z"/><path d="M6 15h12"/>',
        ];
        $name = isset($paths[$name]) ? $name : 'sparkles';
        return '<svg class="mrcp-premium-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . $paths[$name] . '</svg>';
    }

    private function membership_roadmap($membership) {
        echo '<section class="mrcp-roadmap" aria-label="Membership Roadmap">';
        $levels = $membership['levels'];
        $i = 0;
        $total = count($levels);
        foreach ($levels as $key => $level) {
            $i++;
            echo '<article class="mrcp-roadmap-card ' . ($key === $membership['key'] ? 'is-current' : '') . '">';
            echo '<div class="mrcp-roadmap-icon">' . $this->premium_icon($key) . '</div>';
            echo '<strong>' . esc_html($level['short']) . '</strong>';
            echo '<span>' . esc_html($level['range']) . '</span>';
            echo '<b>' . esc_html($level['discount']) . '% OFF</b>';
            echo '</article>';
            if ($i < $total) echo '<div class="mrcp-roadmap-arrow">›</div>';
        }
        echo '</section>';
    }

    private function motivation_banner($membership) {
        if ($membership['vip']) {
            echo '<section class="mrcp-motivation is-vip"><strong>🎁 VIP Exclusive Offers Available</strong><span>Thank you for being one of our most valuable customers.</span><a href="' . esc_url(home_url('/shop/')) . '">Explore Offers</a></section>';
            return;
        }
        $next_short = isset($membership['next']['short']) ? $membership['next']['short'] : 'Next';
        $next_discount = isset($membership['next']['discount']) ? (int) $membership['next']['discount'] : 0;
        echo '<section class="mrcp-motivation"><strong>🔥 You are just ' . wp_kses_post($this->money($membership['needed'])) . ' away from ' . esc_html($next_short) . ' Member and ' . esc_html($next_discount) . '% discount on all products!</strong><a href="' . esc_url(home_url('/shop/')) . '">Shop Now 🛒</a></section>';
    }

    public function apply_membership_discount($cart) {
        if (!function_exists('mrc_can') || !mrc_can('digital.membership')) {
            return;
        }
        if (is_admin() && !defined('DOING_AJAX')) return;
        if (!$this->wc_active() || !is_user_logged_in() || !is_a($cart, 'WC_Cart')) return;
        if ($cart->is_empty()) return;

        $membership = class_exists('MRCP_Membership') ? MRCP_Membership::get_customer_membership(get_current_user_id()) : $this->membership_data(wc_get_customer_total_spent(get_current_user_id()));
        $discount_percent = (int) $membership['discount'];
        if ($discount_percent <= 0) return;

        $eligible_amount = (float) $cart->get_subtotal();
        if ($eligible_amount <= 0) return;

        $discount_amount = round(($eligible_amount * $discount_percent) / 100, wc_get_price_decimals());
        if ($discount_amount <= 0) return;

        $label = sprintf('%s Membership Discount (%d%%)', $membership['short'], $discount_percent);
        $cart->add_fee($label, -$discount_amount, false);
    }

    public function ajax_search() {
        if ('POST' !== strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? ''))) {
            wp_send_json_error(['message' => 'Invalid request method.'], 405);
        }
        check_ajax_referer('mrcp_search_nonce', 'nonce');

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Login required.'], 401);
        }

        $query = isset($_POST['q']) ? sanitize_text_field(wp_unslash($_POST['q'])) : '';
        $query = trim($query);
        if (function_exists('mb_substr')) {
            $query = mb_substr($query, 0, 80);
        } else {
            $query = substr($query, 0, 80);
        }

        if (strlen($query) < 2) {
            wp_send_json_success(['results' => []]);
        }

        $query_lc = function_exists('mb_strtolower') ? mb_strtolower($query) : strtolower($query);
        $is_crm_admin = current_user_can('manage_options') || current_user_can('manage_woocommerce') || current_user_can('edit_others_shop_orders') || $this->is_support_admin();
        $results = [];
        $seen = [];

        $push = static function ($type, $title, $meta, $url, $key = '') use (&$results, &$seen) {
            $key = $key !== '' ? $key : md5($type . '|' . $title . '|' . $url);
            if (isset($seen[$key]) || count($results) >= 15) {
                return;
            }
            $seen[$key] = true;
            $results[] = [
                'type'  => sanitize_text_field($type),
                'title' => sanitize_text_field($title),
                'meta'  => sanitize_text_field($meta),
                'url'   => esc_url_raw($url),
            ];
        };

        /* Orders: CRM admins search across the store; customers search their own orders. */
        if ($this->wc_active()) {
            $orders = [];
            $numeric_id = absint(preg_replace('/[^0-9]/', '', $query));

            if ($numeric_id > 0) {
                $exact_order = wc_get_order($numeric_id);
                if ($exact_order instanceof WC_Order) {
                    if ($is_crm_admin || (int) $exact_order->get_customer_id() === get_current_user_id()) {
                        $orders[$exact_order->get_id()] = $exact_order;
                    }
                }
            }

            $order_args = [
                'limit'   => $is_crm_admin ? 150 : 50,
                'orderby' => 'date',
                'order'   => 'DESC',
                'status'  => array_keys(wc_get_order_statuses()),
            ];
            if (!$is_crm_admin) {
                $order_args['customer_id'] = get_current_user_id();
            }

            foreach (wc_get_orders($order_args) as $order) {
                if ($order instanceof WC_Order) {
                    $orders[$order->get_id()] = $order;
                }
            }

            foreach ($orders as $order) {
                $product_names = [];
                foreach ($order->get_items() as $item) {
                    $product_names[] = $item->get_name();
                }
                $customer_name = trim($order->get_formatted_billing_full_name());
                $haystack = implode(' ', [
                    $order->get_id(),
                    $order->get_order_number(),
                    'MR-' . $order->get_order_number(),
                    $customer_name,
                    $order->get_billing_email(),
                    $order->get_billing_phone(),
                    wc_get_order_status_name($order->get_status()),
                    $order->get_payment_method_title(),
                    wp_strip_all_tags($order->get_formatted_order_total()),
                    implode(' ', $product_names),
                ]);
                $haystack_lc = function_exists('mb_strtolower') ? mb_strtolower($haystack) : strtolower($haystack);
                if (strpos($haystack_lc, $query_lc) === false) {
                    continue;
                }

                $url = $is_crm_admin
                    ? home_url('/dashboard/crm/order/' . absint($order->get_id()) . '/')
                    : $this->order_view_url($order->get_id());
                $meta_parts = [];
                if ($customer_name !== '') $meta_parts[] = $customer_name;
                $meta_parts[] = wc_get_order_status_name($order->get_status());
                $meta_parts[] = wp_strip_all_tags($order->get_formatted_order_total());
                $push('Order', 'Order #MR-' . $order->get_order_number(), implode(' • ', $meta_parts), $url, 'order-' . $order->get_id());
            }
        }

        /* Customer records for CRM admins. */
        if ($is_crm_admin && count($results) < 15) {
            $user_query = new WP_User_Query([
                'number'         => 8,
                'search'         => '*' . $query . '*',
                'search_columns' => ['user_login', 'user_email', 'display_name'],
                'orderby'        => 'registered',
                'order'          => 'DESC',
            ]);
            foreach ((array) $user_query->get_results() as $user) {
                if (!($user instanceof WP_User)) continue;
                $name = $user->display_name ?: $user->user_login;
                $push(
                    'Customer',
                    $name,
                    $user->user_email . ' • @' . $user->user_login,
                    home_url('/dashboard/crm/customers/' . absint($user->ID) . '/'),
                    'customer-' . $user->ID
                );
            }
        }

        /* Support tickets. */
        $ticket_args = [
            'post_type'      => 'mrcp_ticket',
            'post_status'    => 'publish',
            'posts_per_page' => $is_crm_admin ? 100 : 50,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];
        if (!$is_crm_admin) {
            $ticket_args['author'] = get_current_user_id();
        }
        $ticket_posts = get_posts($ticket_args);
        $ticket_id = absint(preg_replace('/[^0-9]/', '', $query));
        if ($ticket_id > 0) {
            $ticket = get_post($ticket_id);
            if ($ticket && $ticket->post_type === 'mrcp_ticket' && ($is_crm_admin || (int) $ticket->post_author === get_current_user_id())) {
                array_unshift($ticket_posts, $ticket);
            }
        }
        foreach ($ticket_posts as $ticket) {
            $status = get_post_meta($ticket->ID, '_mrcp_ticket_status', true) ?: 'open';
            $category = get_post_meta($ticket->ID, '_mrcp_ticket_category', true);
            $author = get_userdata((int) $ticket->post_author);
            $haystack = implode(' ', [
                $ticket->ID,
                'MR-' . $ticket->ID,
                $ticket->post_title,
                $ticket->post_content,
                $status,
                $category,
                $author ? $author->display_name : '',
                $author ? $author->user_email : '',
            ]);
            $haystack_lc = function_exists('mb_strtolower') ? mb_strtolower(wp_strip_all_tags($haystack)) : strtolower(wp_strip_all_tags($haystack));
            if (strpos($haystack_lc, $query_lc) === false) continue;
            $push(
                'Ticket',
                'Ticket MR-' . $ticket->ID . ' — ' . $ticket->post_title,
                ucfirst($status) . ($author ? ' • ' . $author->display_name : ''),
                $this->ticket_url($ticket->ID),
                'ticket-' . $ticket->ID
            );
        }

        /* Activation requests. */
        $activation_args = [
            'post_type'      => 'mrcp_activation',
            'post_status'    => 'publish',
            'posts_per_page' => $is_crm_admin ? 100 : 50,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];
        if (!$is_crm_admin) {
            $activation_args['author'] = get_current_user_id();
        }
        $activation_posts = get_posts($activation_args);
        $activation_id = absint(preg_replace('/[^0-9]/', '', $query));
        if ($activation_id > 0) {
            $activation = get_post($activation_id);
            if ($activation && $activation->post_type === 'mrcp_activation' && ($is_crm_admin || (int) $activation->post_author === get_current_user_id())) {
                array_unshift($activation_posts, $activation);
            }
        }
        foreach ($activation_posts as $request) {
            $status = get_post_meta($request->ID, '_mrcp_activation_status', true) ?: 'pending';
            $product = get_post_meta($request->ID, '_mrcp_activation_product', true) ?: $request->post_title;
            $domain = get_post_meta($request->ID, '_mrcp_activation_domain', true);
            $order_id = get_post_meta($request->ID, '_mrcp_activation_order_id', true);
            $author = get_userdata((int) $request->post_author);
            $haystack = implode(' ', [
                $request->ID,
                'ACT-' . $request->ID,
                $request->post_title,
                $request->post_content,
                $product,
                $domain,
                $order_id,
                $status,
                $author ? $author->display_name : '',
                $author ? $author->user_email : '',
            ]);
            $haystack_lc = function_exists('mb_strtolower') ? mb_strtolower(wp_strip_all_tags($haystack)) : strtolower(wp_strip_all_tags($haystack));
            if (strpos($haystack_lc, $query_lc) === false) continue;
            $meta = ucfirst(str_replace('_', ' ', $status));
            if ($product !== '') $meta .= ' • ' . $product;
            if ($domain !== '') $meta .= ' • ' . preg_replace('#^https?://#i', '', $domain);
            $push(
                'Activation',
                'Activation ACT-' . $request->ID,
                $meta,
                $this->activation_view_url($request->ID),
                'activation-' . $request->ID
            );
        }

        /* Products are included for CRM admins. */
        if ($is_crm_admin && count($results) < 15) {
            $products = get_posts([
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'posts_per_page' => 6,
                's'              => $query,
                'orderby'        => 'relevance date',
                'order'          => 'DESC',
            ]);
            foreach ($products as $product_post) {
                $product = function_exists('wc_get_product') ? wc_get_product($product_post->ID) : null;
                $meta = $product ? wp_strip_all_tags($product->get_price_html()) : 'WooCommerce product';
                $push(
                    'Product',
                    $product_post->post_title,
                    $meta,
                    get_permalink($product_post->ID),
                    'product-' . $product_post->ID
                );
            }
        }

        wp_send_json_success([
            'results' => array_slice($results, 0, 12),
            'query'   => $query,
        ]);
    }

    private function render_orders_page() {
        $orders = $this->recent_orders(20);
        echo '<section class="mrcp-module-page"><div class="mrcp-module-head"><div><span>Orders Module</span><h1>My Orders</h1><p>View your recent purchases, payment totals, and order status.</p></div><a href="' . esc_url(home_url('/shop/')) . '">Shop More →</a></div>';
        echo '<div class="mrcp-module-card mrcp-orders-list-card">';
        if ($orders) {
            foreach ($orders as $order) $this->order_row($order, true);
        } else {
            $this->empty_state('📦', 'No recent orders yet', 'Your recent purchases will appear here.');
        }
        echo '</div></section>';
    }

    private function render_downloads_page() {
        $downloads = $this->downloads(20);
        echo '<section class="mrcp-module-page"><div class="mrcp-module-head"><div><span>Downloads Module</span><h1>My Downloads</h1><p>Access your purchased files and latest downloadable products.</p></div><a href="' . esc_url($this->url('downloads')) . '">Woo Downloads →</a></div>';
        echo '<div class="mrcp-module-card">';
        if ($downloads) {
            foreach ($downloads as $download) $this->download_row($download);
        } else {
            $this->empty_state('⬇️', 'No downloads available yet', 'Your purchased files will appear here.');
        }
        echo '</div></section>';
    }

    private function render_invoices_page() {
        $orders = $this->completed_orders(-1);
        echo '<section class="mrcp-module-page"><div class="mrcp-module-head"><div><span>Invoice Module</span><h1>Completed Orders & Invoices</h1><p>View all completed purchases and download/print invoices.</p></div><a href="' . esc_url($this->url('orders')) . '">All Orders →</a></div>';
        echo '<div class="mrcp-invoice-list">';
        if ($orders) {
            echo '<div class="mrcp-invoice-table">';
            echo '<div class="mrcp-invoice-row mrcp-invoice-head"><span>Order</span><span>Date</span><span>Total</span><span>Status</span><span>Actions</span></div>';
            foreach ($orders as $order) {
                if (!$order || !is_a($order, 'WC_Order')) continue;
                $date = $order->get_date_created() ? $order->get_date_created()->date_i18n('F j, Y') : '';
                echo '<div class="mrcp-invoice-row">';
                echo '<span><strong>#' . esc_html($order->get_order_number()) . '</strong><small>' . esc_html($order->get_item_count()) . ' item(s)</small></span>';
                echo '<span>' . esc_html($date) . '</span>';
                echo '<span><strong>' . wp_kses_post($order->get_formatted_order_total()) . '</strong></span>';
                echo '<span><em class="status-completed">Completed</em></span>';
                echo '<span class="mrcp-invoice-actions"><a href="' . esc_url($this->order_view_url($order->get_id())) . '">View Order</a><a class="is-primary" href="' . esc_url($this->invoice_url($order->get_id())) . '">Invoice</a></span>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            $this->empty_state('🧾', 'No completed orders yet', 'Completed orders and invoices will appear here.');
        }
        echo '</div></section>';
    }

    private function render_order_view_page() {
        $order_id = absint(get_query_var('mrcp_order_id'));
        $order = $order_id ? wc_get_order($order_id) : false;

        if (!$order || !is_a($order, 'WC_Order') || (int) $order->get_customer_id() !== get_current_user_id()) {
            echo '<section class="mrcp-module-page">';
            $this->empty_state('📦', 'Order not available', 'This order could not be found in your account.');
            echo '</section>';
            return;
        }

        $date = $order->get_date_created() ? $order->get_date_created()->date_i18n('F j, Y') : '';
        $status = wc_get_order_status_name($order->get_status());
        $billing_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $billing_name = $billing_name ?: $order->get_formatted_billing_full_name();
        $billing_email = $order->get_billing_email();
        $billing_phone = $order->get_billing_phone();
        $payment_method = $this->payment_source_label($order);

        echo '<section class="mrcp-order-view">';
        echo '<div class="mrcp-order-toolbar"><a href="' . esc_url($this->url('orders')) . '">← Back to Orders</a><div>';
        if ($order->has_status('completed')) {
            echo '<a class="is-primary" href="' . esc_url($this->invoice_url($order->get_id())) . '">View Invoice</a>';
        }
        echo '</div></div>';

        echo '<div class="mrcp-order-hero">';
        echo '<div><span>Order Details</span><h1>Order #' . esc_html($order->get_order_number()) . '</h1><p>Placed on ' . esc_html($date) . '</p></div>';
        echo '<div class="mrcp-order-status-card"><small>Status</small><strong class="status-' . esc_attr($order->get_status()) . '">' . esc_html($status) . '</strong><b>' . wp_kses_post($order->get_formatted_order_total()) . '</b></div>';
        echo '</div>';

        echo '<div class="mrcp-order-summary-grid">';
        echo '<div><small>Total Amount</small><strong>' . wp_kses_post($order->get_formatted_order_total()) . '</strong></div>';
        echo '<div><small>Payment Method</small><strong>' . esc_html($payment_method) . '</strong></div>';
        echo '<div><small>Total Items</small><strong>' . esc_html($order->get_item_count()) . '</strong></div>';
        echo '<div><small>Order Date</small><strong>' . esc_html($date) . '</strong></div>';
        echo '</div>';

        echo '<div class="mrcp-order-layout">';
        echo '<div class="mrcp-order-card mrcp-order-items-card"><div class="mrcp-order-card-head"><h2>Purchased Products</h2><span>' . esc_html($order->get_item_count()) . ' item(s)</span></div>';
        echo '<div class="mrcp-order-items">';
        foreach ($order->get_items('line_item') as $item_id => $item) {
            $product = $item->get_product();
            $thumbnail = $product ? $product->get_image('thumbnail') : '<span class="mrcp-product-fallback">📦</span>';
            $sku = $product && $product->get_sku() ? $product->get_sku() : '—';
            $qty = max(1, (int) $item->get_quantity());
            $line_total = (float) $item->get_total();
            $unit_price = $qty > 0 ? $line_total / $qty : $line_total;
            $meta_html = wc_display_item_meta($item, [
                'before' => '<ul class="mrcp-order-item-meta"><li>',
                'after' => '</li></ul>',
                'separator' => '</li><li>',
                'echo' => false,
                'autop' => false,
            ]);

            echo '<article class="mrcp-order-item">';
            echo '<div class="mrcp-order-thumb">' . wp_kses_post($thumbnail) . '</div>';
            echo '<div class="mrcp-order-product-info"><h3>' . esc_html($item->get_name()) . '</h3><p>SKU: ' . esc_html($sku) . ' • Qty: ' . esc_html($qty) . '</p>';
            if ($meta_html) echo wp_kses_post($meta_html);
            if (class_exists('\MRCP\Modules\Orders\LicenseDomainsModule')) {
                \MRCP\Modules\Orders\LicenseDomainsModule::render_badges($item);
            }
            echo '</div>';
            echo '<div class="mrcp-order-price"><small>Unit</small><strong>' . wp_kses_post($this->money($unit_price)) . '</strong></div>';
            echo '<div class="mrcp-order-price"><small>Total</small><strong>' . wp_kses_post($order->get_formatted_line_subtotal($item)) . '</strong></div>';
            echo '</article>';
        }
        echo '</div></div>';

        echo '<aside class="mrcp-order-side">';
        echo '<div class="mrcp-order-card mrcp-payment-summary-card"><h2>Payment Summary</h2><table class="mrcp-order-totals"><tbody>';
        foreach ($order->get_order_item_totals() as $key => $total) {
            $class = $key === 'order_total' ? ' class="is-grand-total"' : '';
            $value = 'payment_method' === $key ? esc_html($payment_method) : wp_kses_post($total['value']);
            echo '<tr' . $class . '><th>' . esc_html(wp_strip_all_tags($total['label'])) . '</th><td>' . $value . '</td></tr>';
        }
        echo '</tbody></table></div>';

        echo '<div class="mrcp-order-card"><h2>Billing Details</h2><p><strong>' . esc_html($billing_name ?: 'Customer') . '</strong><br>' . wp_kses_post($order->get_formatted_billing_address() ?: 'No billing address found.') . '</p>';
        if ($billing_email || $billing_phone) {
            echo '<p class="mrcp-order-contact">';
            if ($billing_email) echo 'Email: ' . esc_html($billing_email) . '<br>';
            if ($billing_phone) echo 'Phone: ' . esc_html($billing_phone);
            echo '</p>';
        }
        echo '</div>';

        echo '<div class="mrcp-order-card"><h2>Need Help?</h2><p>If you need product installation or activation support, create a support ticket from your dashboard.</p><a class="mrcp-order-support" href="' . esc_url($this->url('support')) . '#new-ticket">Create Ticket</a></div>';
        echo '</aside>';
        echo '</div>';
        echo '</section>';
    }

    private function render_invoice_page() {
        $order_id = absint(get_query_var('mrcp_order_id'));
        $order = $order_id ? wc_get_order($order_id) : false;
        if (!$order || !is_a($order, 'WC_Order') || (!$this->is_support_admin() && (int) $order->get_customer_id() !== get_current_user_id()) || !$order->has_status('completed')) {
            echo '<section class="mrcp-module-page">';
            $this->empty_state('🧾', 'Invoice not available', 'Only completed orders from your account can be viewed here.');
            echo '</section>';
            return;
        }

        $user_id = get_current_user_id();
        $date = $order->get_date_created() ? $order->get_date_created()->date_i18n('F j, Y') : '';
        $invoice_no = 'MRCP-' . $order->get_order_number();
        $billing_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $billing_name = $billing_name ?: $order->get_formatted_billing_full_name();
        $billing_email = $order->get_billing_email();
        $billing_phone = $order->get_billing_phone();
        $verify_url = add_query_arg([
            'mrcp_invoice' => rawurlencode($invoice_no),
            'order' => rawurlencode($order->get_order_number()),
        ], home_url('/'));
        $qr_url = 'https://api.qrserver.com/v1/create-qr-code/?size=130x130&margin=8&data=' . rawurlencode($verify_url);
        $membership = class_exists('MRCP_Membership') ? MRCP_Membership::get_customer_membership($user_id) : [];
        $membership_name = !empty($membership['name']) ? $membership['name'] : 'Silver Member';
        $membership_icon = !empty($membership['icon']) ? $membership['icon'] : '🥈';
        $membership_discount = isset($membership['discount']) ? (float) $membership['discount'] : 0;
        $discount_total = (float) $order->get_discount_total();
        $discount_tax = method_exists($order, 'get_discount_tax') ? (float) $order->get_discount_tax() : 0;
        $total_discount = max(0, $discount_total + $discount_tax);
        $payment_status = $order->is_paid() ? 'Paid' : ucfirst($order->get_status());
        $payment_method = $this->payment_source_label($order);

        $downloads_for_order = [];
        if (function_exists('wc_get_customer_available_downloads')) {
            $all_downloads = wc_get_customer_available_downloads($user_id);
            if (!empty($all_downloads) && is_array($all_downloads)) {
                foreach ($all_downloads as $download) {
                    $download_order_id = isset($download['order_id']) ? absint($download['order_id']) : 0;
                    if ($download_order_id === $order->get_id()) {
                        $downloads_for_order[] = $download;
                    }
                }
            }
        }

        echo '<section class="mrcp-invoice-doc mrcp-invoice-premium-doc">';
        echo '<div class="mrcp-invoice-toolbar"><a href="' . esc_url($this->url('invoices')) . '">← Back to Invoices</a><button type="button" onclick="window.print()">Print / Save PDF</button></div>';
        echo '<div class="mrcp-invoice-paper mrcp-invoice-paper-premium">';

        echo '<header class="mrcp-invoice-title mrcp-invoice-title-pro mrcp-invoice-title-premium">';
        echo '<div class="mrcp-invoice-head-left"><span class="mrcp-invoice-label">Paid Invoice</span><h1>Invoice</h1><p>Invoice #' . esc_html($invoice_no) . '</p></div>';
        echo '<div class="mrcp-invoice-brand mrcp-invoice-brand-logo mrcp-invoice-brand-premium"><img src="' . esc_url(MRCP_PLUGIN_URL . 'assets/images/mehedi-rahat-logo.png') . '" alt="Mehedi Rahat"><span>Best Web Developer in Bangladesh</span></div>';
        echo '</header>';

        echo '<div class="mrcp-invoice-premium-strip">';
        echo '<div class="mrcp-invoice-status-badge is-paid">✓ Payment Status: ' . esc_html($payment_status) . '</div>';
        if (function_exists('mrc_can') && mrc_can('digital.membership')) {
            echo '<div class="mrcp-invoice-member-badge">' . esc_html($membership_icon . ' ' . $membership_name) . '</div>';
        }
        echo '<div class="mrcp-invoice-verify"><img src="' . esc_url($qr_url) . '" alt="Invoice verification QR code"><span>Scan to verify invoice</span></div>';
        echo '</div>';

        echo '<div class="mrcp-invoice-meta mrcp-invoice-meta-pro mrcp-invoice-meta-premium">';
        echo '<div><strong>Order Number</strong><span>#' . esc_html($order->get_order_number()) . '</span></div>';
        echo '<div><strong>Invoice Date</strong><span>' . esc_html($date) . '</span></div>';
        echo '<div><strong>Status</strong><span class="mrcp-paid-status">Completed / Paid</span></div>';
        echo '<div><strong>Payment Method</strong><span>' . esc_html($payment_method) . '</span></div>';
        echo '</div>';

        echo '<div class="mrcp-invoice-addresses mrcp-invoice-addresses-pro">';
        echo '<div><h3>Billed To</h3>';
        echo '<p><strong>' . esc_html($billing_name ?: 'Customer') . '</strong><br>' . wp_kses_post($order->get_formatted_billing_address() ?: 'No billing address found.') . '</p>';
        if ($billing_email || $billing_phone) {
            echo '<p class="mrcp-invoice-contact mrcp-billing-contact">';
            if ($billing_email) echo '<span>✉ ' . esc_html($billing_email) . '</span>';
            if ($billing_phone) echo '<span>☎ ' . esc_html($billing_phone) . '</span>';
            echo '</p>';
        }
        echo '</div>';
        echo '<div class="mrcp-invoice-seller-card"><h3>Seller</h3><p><strong>MehediRahat.com</strong><br>Best Web Developer in Bangladesh</p><p class="mrcp-invoice-contact mrcp-seller-contact"><span>📍 Bashundhara r/a, Dhaka</span><span>✉ support@mehedirahat.com</span></p></div>';
        echo '</div>';

        echo '<div class="mrcp-invoice-section-title"><h3>Product Details</h3><span>' . esc_html($order->get_item_count()) . ' item(s)</span></div>';
        echo '<div class="mrcp-invoice-table-wrap">';
        echo '<table class="mrcp-invoice-items mrcp-invoice-items-pro">';
        echo '<thead><tr><th>Product Details</th><th>SKU</th><th>Unit Price</th><th>Qty</th><th>Line Total</th></tr></thead><tbody>';

        foreach ($order->get_items('line_item') as $item_id => $item) {
            $product = $item->get_product();
            $sku = $product && $product->get_sku() ? $product->get_sku() : '—';
            $qty = max(1, (int) $item->get_quantity());
            $line_total = (float) $item->get_total();
            $unit_price = $qty > 0 ? $line_total / $qty : $line_total;
            $meta_html = wc_display_item_meta($item, [
                'before' => '<ul class="mrcp-invoice-item-meta"><li>',
                'after' => '</li></ul>',
                'separator' => '</li><li>',
                'echo' => false,
                'autop' => false,
            ]);

            echo '<tr>';
            echo '<td class="mrcp-product-cell"><strong>' . esc_html($item->get_name()) . '</strong>';
            if ($meta_html) echo wp_kses_post($meta_html);
            if ($product && $product->get_id()) echo '<small>Product ID: ' . esc_html($product->get_id()) . '</small>';
            echo '</td>';
            echo '<td>' . esc_html($sku) . '</td>';
            echo '<td>' . wp_kses_post($this->money($unit_price)) . '</td>';
            echo '<td>' . esc_html($qty) . '</td>';
            echo '<td>' . wp_kses_post($order->get_formatted_line_subtotal($item)) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';

        if (!empty($downloads_for_order)) {
            echo '<div class="mrcp-invoice-downloads"><div><h3>Available Downloads</h3><p>Download your purchased files from this completed order.</p></div><div class="mrcp-invoice-download-buttons">';
            $shown = 0;
            foreach ($downloads_for_order as $download) {
                if ($shown >= 4) break;
                $name = !empty($download['product_name']) ? $download['product_name'] : 'Download File';
                $url = !empty($download['download_url']) ? $download['download_url'] : '';
                if (!$url) continue;
                echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">⬇ ' . esc_html(wp_trim_words($name, 4, '')) . '</a>';
                $shown++;
            }
            echo '<a class="is-secondary" href="' . esc_url($this->url('downloads')) . '">All Downloads</a>';
            echo '</div></div>';
        }

        echo '<div class="mrcp-invoice-summary mrcp-invoice-summary-premium">';
        echo '<div class="mrcp-invoice-note"><h3>Notes</h3><p>Thank you for purchasing from MehediRahat.com.</p>';
        if (function_exists('mrc_can') && mrc_can('digital.membership')) {
            echo '<div class="mrcp-invoice-discount-summary"><strong>Discount Summary</strong><span>Membership: ' . esc_html($membership_name) . ' (' . esc_html((string) $membership_discount) . '%)</span><span>Order Discount: ' . wp_kses_post($total_discount > 0 ? $this->money($total_discount) : $this->money(0)) . '</span></div>';
        }
        echo '</div>';
        echo '<table class="mrcp-invoice-totals"><tbody>';
        foreach ($order->get_order_item_totals() as $key => $total) {
            $class = $key === 'order_total' ? ' class="is-grand-total"' : '';
            echo '<tr' . $class . '><th>' . esc_html(wp_strip_all_tags($total['label'])) . '</th><td>' . wp_kses_post($total['value']) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '</div>';

        echo '<footer class="mrcp-invoice-footer mrcp-invoice-footer-pro"><p>Generated from MR Commerce Pro.</p><p>For support: support@mehedirahat.com</p></footer>';
        echo '</div></section>';
    }

    private function display_order_number($order_id) {
        $order_id = absint($order_id);
        if (!$order_id) {
            return '';
        }
        if (function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order && is_a($order, 'WC_Order')) {
                return $order->get_order_number();
            }
        }
        return (string) $order_id;
    }
}
