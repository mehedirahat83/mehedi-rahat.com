<?php
namespace MRCP\Modules\Notifications;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin CRM notifications.
 *
 * Reuses the portal's existing `_mrcp_notifications` user-meta format while
 * routing admin notifications through a secure click handler. The handler
 * marks the selected notification as read and then opens the custom CRM page.
 */
final class NotificationsModule {
    private const META_KEY = '_mrcp_notifications';
    private const CREATED_FLAG = '_mrcp_admin_notification_created';
    private const MAX_ITEMS = 50;

    public static function register(): void {
        add_action('wp_after_insert_post', [self::class, 'capture_new_request'], 20, 4);
        add_action('admin_post_mrcp_open_notification', [self::class, 'open_notification']);
        add_action('init', [self::class, 'upgrade_existing_admin_notifications'], 30);
    }

    /**
     * Create an admin notification after a customer creates a support ticket
     * or activation request.
     */
    public static function capture_new_request($post_id, $post, $update, $post_before): void {
        if ($update || !$post instanceof \WP_Post || 'publish' !== $post->post_status) {
            return;
        }

        if (!in_array($post->post_type, ['mrcp_ticket', 'mrcp_activation'], true)) {
            return;
        }

        if (get_post_meta($post_id, self::CREATED_FLAG, true)) {
            return;
        }

        $customer = get_user_by('id', (int) $post->post_author);
        $customer_name = $customer ? $customer->display_name : __('Customer', 'mr-customer-portal-pro');

        if ('mrcp_activation' === $post->post_type) {
            $title = sprintf(__('New Activation Request ACT-%d', 'mr-customer-portal-pro'), $post_id);
            $message = sprintf(
                __('%s submitted a new activation request.', 'mr-customer-portal-pro'),
                $customer_name
            );
            $target_url = home_url('/dashboard/activation/' . absint($post_id) . '/');
            $type = 'activation_admin';
        } else {
            $title = sprintf(__('New Support Ticket MR-%d', 'mr-customer-portal-pro'), $post_id);
            $subject = sanitize_text_field(get_the_title($post_id));
            $message = $subject
                ? sprintf(__('%1$s: %2$s', 'mr-customer-portal-pro'), $customer_name, $subject)
                : sprintf(__('%s created a new support ticket.', 'mr-customer-portal-pro'), $customer_name);
            $target_url = home_url('/dashboard/ticket/' . absint($post_id) . '/');
            $type = 'ticket_admin';
        }

        foreach (self::admin_recipient_ids() as $user_id) {
            self::add_notification($user_id, $title, $message, $target_url, $type, (int) $post_id);
        }

        update_post_meta($post_id, self::CREATED_FLAG, current_time('mysql'));
    }

    /**
     * Secure notification click endpoint.
     * Marks only the clicked item as read and then redirects to the CRM view.
     */
    public static function open_notification(): void {
        if (!is_user_logged_in()) {
            auth_redirect();
        }

        $notification_id = isset($_GET['notification'])
            ? sanitize_text_field(wp_unslash($_GET['notification']))
            : '';

        if (!$notification_id) {
            wp_safe_redirect(home_url('/dashboard/crm/'));
            exit;
        }

        check_admin_referer('mrcp_open_notification_' . $notification_id);

        $user_id = get_current_user_id();
        $items = get_user_meta($user_id, self::META_KEY, true);
        $target_url = home_url('/dashboard/crm/');

        if (is_array($items)) {
            foreach ($items as &$item) {
                if (($item['id'] ?? '') !== $notification_id) {
                    continue;
                }

                $item['read'] = true;
                $candidate = isset($item['target_url']) ? esc_url_raw($item['target_url']) : '';
                if ($candidate) {
                    $target_url = $candidate;
                }
                break;
            }
            unset($item);
            update_user_meta($user_id, self::META_KEY, $items);
        }

        $target_url = add_query_arg([
            'mrcp_highlight' => '1',
            'mrcp_from_notification' => '1',
        ], $target_url);

        wp_safe_redirect($target_url);
        exit;
    }

    /**
     * Convert v12.5.7 admin notifications that still use wp-admin post links.
     */
    public static function upgrade_existing_admin_notifications(): void {
        if (!is_user_logged_in()) {
            return;
        }

        $user_id = get_current_user_id();
        if (!user_can($user_id, 'manage_options') && !user_can($user_id, 'manage_woocommerce')) {
            return;
        }

        $items = get_user_meta($user_id, self::META_KEY, true);
        if (!is_array($items) || !$items) {
            return;
        }

        $changed = false;
        foreach ($items as &$item) {
            $type = sanitize_key((string) ($item['type'] ?? ''));
            if (!in_array($type, ['activation_admin', 'ticket_admin'], true)) {
                continue;
            }

            $id = (string) ($item['id'] ?? '');
            if (!$id) {
                $id = uniqid('mrcp_admin_', true);
                $item['id'] = $id;
            }

            $object_id = absint($item['object_id'] ?? 0);
            if (!$object_id) {
                $source = (string) ($item['title'] ?? '');
                if (preg_match('/(?:ACT|MR)-(\d+)/', $source, $matches)) {
                    $object_id = absint($matches[1]);
                }
            }

            if (!$object_id) {
                continue;
            }

            $target_url = 'activation_admin' === $type
                ? home_url('/dashboard/activation/' . $object_id . '/')
                : home_url('/dashboard/ticket/' . $object_id . '/');

            $item['object_id'] = $object_id;
            $item['target_url'] = $target_url;
            $item['url'] = self::click_url($id);
            $changed = true;
        }
        unset($item);

        if ($changed) {
            update_user_meta($user_id, self::META_KEY, $items);
        }
    }

    private static function admin_recipient_ids(): array {
        $ids = [];
        $users = get_users([
            'fields' => ['ID'],
            'role__in' => ['administrator', 'shop_manager'],
        ]);

        foreach ($users as $user) {
            $user_id = (int) $user->ID;
            if ($user_id && (user_can($user_id, 'manage_woocommerce') || user_can($user_id, 'manage_options'))) {
                $ids[] = $user_id;
            }
        }

        $admin_email = (string) get_option('admin_email');
        if ($admin_email) {
            $site_admin = get_user_by('email', $admin_email);
            if ($site_admin) {
                $ids[] = (int) $site_admin->ID;
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    private static function add_notification(int $user_id, string $title, string $message, string $target_url, string $type, int $object_id): void {
        if ($user_id <= 0) {
            return;
        }

        $items = get_user_meta($user_id, self::META_KEY, true);
        if (!is_array($items)) {
            $items = [];
        }

        $notification_id = uniqid('mrcp_admin_', true);
        array_unshift($items, [
            'id' => $notification_id,
            'title' => sanitize_text_field($title),
            'message' => sanitize_text_field($message),
            'url' => self::click_url($notification_id),
            'target_url' => esc_url_raw($target_url),
            'object_id' => $object_id,
            'type' => sanitize_key($type),
            'read' => false,
            'time' => current_time('timestamp'),
        ]);

        update_user_meta($user_id, self::META_KEY, array_slice($items, 0, self::MAX_ITEMS));
    }

    private static function click_url(string $notification_id): string {
        return wp_nonce_url(
            admin_url('admin-post.php?action=mrcp_open_notification&notification=' . rawurlencode($notification_id)),
            'mrcp_open_notification_' . $notification_id
        );
    }
}
