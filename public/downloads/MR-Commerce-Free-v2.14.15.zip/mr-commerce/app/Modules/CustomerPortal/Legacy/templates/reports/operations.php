<?php
if (!defined('ABSPATH')) exit;
$ops = $data['operations_intelligence'] ?? [];
$summary = $ops['summary'] ?? [];
$ticket_statuses = $ops['ticket_statuses'] ?? [];
$activation_statuses = $ops['activation_statuses'] ?? [];
$max_month = 1;
foreach (($ops['monthly_trend'] ?? []) as $row) {
    $max_month = max($max_month, (int) ($row['tickets'] ?? 0), (int) ($row['activations'] ?? 0));
}
$status_label = static function(string $status): string {
    return ucwords(str_replace('_', ' ', $status));
};
?>
<div class="mrcp-oi">
    <div class="mrcp-bi__section-head">
        <div><span>OPERATIONS INTELLIGENCE</span><h2>Support and activation performance</h2></div>
        <p>Monitor workload, response speed, completion rates and recent customer activity.</p>
    </div>

    <div class="mrcp-oi__kpis">
        <article class="is-primary"><i>🎫</i><small>Total Tickets</small><strong><?php echo esc_html(number_format_i18n((int) ($summary['tickets_total'] ?? 0))); ?></strong><em><?php echo esc_html(number_format_i18n((int) ($summary['tickets_unresolved'] ?? 0))); ?> unresolved</em></article>
        <article><i>⏱</i><small>Avg First Reply</small><strong><?php echo esc_html(number_format_i18n((float) ($summary['avg_reply_hours'] ?? 0), 1)); ?>h</strong><em>Admin response time</em></article>
        <article><i>✓</i><small>Ticket Close Rate</small><strong><?php echo esc_html(number_format_i18n((float) ($summary['ticket_close_rate'] ?? 0), 1)); ?>%</strong><em>Closed support requests</em></article>
        <article><i>🔑</i><small>Activation Requests</small><strong><?php echo esc_html(number_format_i18n((int) ($summary['activation_total'] ?? 0))); ?></strong><em><?php echo esc_html(number_format_i18n((int) ($summary['activation_pending'] ?? 0))); ?> pending/in progress</em></article>
        <article><i>⚡</i><small>Activation Completion</small><strong><?php echo esc_html(number_format_i18n((float) ($summary['activation_completion_rate'] ?? 0), 1)); ?>%</strong><em><?php echo esc_html(number_format_i18n((float) ($summary['avg_activation_hours'] ?? 0), 1)); ?>h average completion</em></article>
        <article class="is-health"><i>♡</i><small>Operations Health</small><strong><?php echo esc_html(number_format_i18n((int) ($summary['health_score'] ?? 0))); ?>/100</strong><em><?php echo esc_html(number_format_i18n((int) ($summary['current_workload'] ?? 0))); ?> current workload</em></article>
    </div>

    <div class="mrcp-oi__main-grid">
        <article class="mrcp-bi-card mrcp-oi__trend-card">
            <header><div><span>ACTIVITY TREND</span><h3>Last 12 months</h3></div><b>Tickets vs activations</b></header>
            <div class="mrcp-oi__trend">
                <?php foreach (($ops['monthly_trend'] ?? []) as $row):
                    $ticket_h = max(3, round(((int) ($row['tickets'] ?? 0) / $max_month) * 100));
                    $activation_h = max(3, round(((int) ($row['activations'] ?? 0) / $max_month) * 100)); ?>
                    <div class="mrcp-oi__month" title="<?php echo esc_attr(($row['label'] ?? '') . ' — Tickets: ' . (int) ($row['tickets'] ?? 0) . ', Activations: ' . (int) ($row['activations'] ?? 0)); ?>">
                        <span><i class="is-ticket" style="height:<?php echo esc_attr($ticket_h); ?>%"></i><i class="is-activation" style="height:<?php echo esc_attr($activation_h); ?>%"></i></span>
                        <b><?php echo esc_html($row['short'] ?? ''); ?></b>
                        <small><?php echo esc_html((int) ($row['tickets'] ?? 0)); ?> / <?php echo esc_html((int) ($row['activations'] ?? 0)); ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="mrcp-oi__legend"><span><i class="is-ticket"></i>Support tickets</span><span><i class="is-activation"></i>Activation requests</span></div>
        </article>

        <div class="mrcp-oi__status-stack">
            <article class="mrcp-bi-card">
                <header><div><span>SUPPORT STATUS</span><h3>Ticket pipeline</h3></div><a href="<?php echo esc_url(home_url('/dashboard/support/')); ?>">Open support →</a></header>
                <div class="mrcp-oi__status-list">
                    <?php foreach ($ticket_statuses as $key => $value): ?>
                        <div><span><i class="is-<?php echo esc_attr(sanitize_html_class($key)); ?>"></i><?php echo esc_html($status_label($key)); ?></span><strong><?php echo esc_html(number_format_i18n((int) $value)); ?></strong></div>
                    <?php endforeach; ?>
                </div>
            </article>
            <article class="mrcp-bi-card">
                <header><div><span>ACTIVATION STATUS</span><h3>Request pipeline</h3></div><a href="<?php echo esc_url(home_url('/dashboard/activation/')); ?>">Open activations →</a></header>
                <div class="mrcp-oi__status-list">
                    <?php foreach ($activation_statuses as $key => $value): ?>
                        <div><span><i class="is-<?php echo esc_attr(sanitize_html_class($key)); ?>"></i><?php echo esc_html($status_label($key)); ?></span><strong><?php echo esc_html(number_format_i18n((int) $value)); ?></strong></div>
                    <?php endforeach; ?>
                </div>
            </article>
        </div>
    </div>

    <div class="mrcp-oi__distribution-grid">
        <article class="mrcp-bi-card">
            <header><div><span>TICKET PRIORITY</span><h3>Urgency distribution</h3></div></header>
            <div class="mrcp-oi__meter-list">
                <?php $priority_total = max(1, array_sum($ops['ticket_priorities'] ?? [])); foreach (($ops['ticket_priorities'] ?? []) as $key => $value): $width = round(((int) $value / $priority_total) * 100); ?>
                    <div><p><strong><?php echo esc_html($status_label($key)); ?></strong><span><?php echo esc_html(number_format_i18n((int) $value)); ?> · <?php echo esc_html($width); ?>%</span></p><i><b class="is-<?php echo esc_attr(sanitize_html_class($key)); ?>" style="width:<?php echo esc_attr($width); ?>%"></b></i></div>
                <?php endforeach; ?>
            </div>
        </article>
        <article class="mrcp-bi-card">
            <header><div><span>TICKET CATEGORIES</span><h3>What customers need</h3></div></header>
            <div class="mrcp-oi__category-list">
                <?php foreach (($ops['ticket_categories'] ?? []) as $key => $value): ?><div><span><?php echo esc_html($status_label($key)); ?></span><strong><?php echo esc_html(number_format_i18n((int) $value)); ?></strong></div><?php endforeach; ?>
            </div>
        </article>
        <article class="mrcp-bi-card mrcp-oi__insights">
            <header><div><span>SMART OPERATIONS INSIGHTS</span><h3>What needs attention</h3></div></header>
            <?php foreach (($ops['insights'] ?? []) as $insight): ?><p><i>✦</i><span><?php echo esc_html($insight); ?></span></p><?php endforeach; ?>
        </article>
    </div>

    <div class="mrcp-oi__recent-grid">
        <article class="mrcp-bi-card">
            <header><div><span>LATEST SUPPORT</span><h3>Recent tickets</h3></div><a href="<?php echo esc_url(home_url('/dashboard/support/')); ?>">View all →</a></header>
            <div class="mrcp-oi__recent-list">
                <?php foreach (($ops['recent_tickets'] ?? []) as $row): ?>
                    <a href="<?php echo esc_url($row['url'] ?? '#'); ?>"><i>🎫</i><span><strong><?php echo esc_html($row['title'] ?? 'Ticket'); ?></strong><small><?php echo esc_html(($row['customer'] ?? '') . ' · ' . ($row['category'] ?? '') . ' · ' . ($row['date'] ?? '')); ?></small></span><em class="is-<?php echo esc_attr(sanitize_html_class($row['status'] ?? 'open')); ?>"><?php echo esc_html($status_label($row['status'] ?? 'open')); ?></em></a>
                <?php endforeach; if (empty($ops['recent_tickets'])): ?><p class="mrcp-oi__empty">No support tickets yet.</p><?php endif; ?>
            </div>
        </article>
        <article class="mrcp-bi-card">
            <header><div><span>LATEST ACTIVATIONS</span><h3>Recent requests</h3></div><a href="<?php echo esc_url(home_url('/dashboard/activation/')); ?>">View all →</a></header>
            <div class="mrcp-oi__recent-list">
                <?php foreach (($ops['recent_activations'] ?? []) as $row): ?>
                    <a href="<?php echo esc_url($row['url'] ?? '#'); ?>"><i>🔑</i><span><strong><?php echo esc_html($row['product'] ?? 'Activation Request'); ?></strong><small><?php echo esc_html(($row['customer'] ?? '') . ' · ' . ($row['domain'] ?: 'No domain') . ' · ' . ($row['date'] ?? '')); ?></small></span><em class="is-<?php echo esc_attr(sanitize_html_class($row['status'] ?? 'pending')); ?>"><?php echo esc_html($status_label($row['status'] ?? 'pending')); ?></em></a>
                <?php endforeach; if (empty($ops['recent_activations'])): ?><p class="mrcp-oi__empty">No activation requests yet.</p><?php endif; ?>
            </div>
        </article>
    </div>
</div>
