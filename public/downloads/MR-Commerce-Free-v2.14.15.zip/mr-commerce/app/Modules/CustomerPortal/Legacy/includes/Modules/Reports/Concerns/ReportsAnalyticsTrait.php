<?php

namespace MRCP\Modules\Reports\Concerns;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait ReportsAnalyticsTrait {
    private static function month_buckets(int $now, int $month_count = 12): array {
        $buckets = [];
        $month_count = max(1, $month_count);
        for ($i = $month_count - 1; $i >= 0; $i--) {
            $timestamp = strtotime('-' . $i . ' months', strtotime(date('Y-m-01', $now)));
            $key = wp_date('Y-m', $timestamp);
            $buckets[$key] = [
                'key' => $key,
                'label' => wp_date('M Y', $timestamp),
                'short' => wp_date('M y', $timestamp),
                'revenue' => 0.0,
                'orders' => 0,
            ];
        }
        return $buckets;
    }

    private static function current_week_overview(array $daily, int $now): array {
        $start = strtotime('monday this week', $now);
        $rows = [];
        for ($i = 0; $i < 7; $i++) {
            $ts = strtotime('+' . $i . ' days', $start);
            $key = wp_date('Y-m-d', $ts);
            $row = $daily[$key] ?? ['orders' => 0, 'revenue' => 0.0, 'customers' => []];
            $rows[] = [
                'date' => wp_date('D, M j', $ts),
                'orders' => (int) $row['orders'],
                'revenue' => (float) $row['revenue'],
                'customers' => count($row['customers']),
            ];
        }
        return $rows;
    }

    private static function build_customer_analytics(array $paid_customers, float $membership_discount, int $now): array {
        $month_buckets = self::customer_month_buckets($now);
        $membership = [
            'silver' => 0,
            'gold' => 0,
            'diamond' => 0,
            'vip' => 0,
        ];
        $rows = [];
        $new_today = 0;
        $new_week = 0;
        $new_month = 0;
        $active = 0;
        $inactive = 0;
        $returning = 0;
        $single_order = 0;
        $total_spend = 0.0;
        $total_orders = 0;
        $today_start = strtotime('today', $now);
        $week_start = strtotime('monday this week', $now);
        $month_start = strtotime(wp_date('Y-m-01 00:00:00', $now));
        $active_cutoff = strtotime('-180 days', $now);

        $users = get_users([
            'fields' => ['ID', 'display_name', 'user_email', 'user_registered'],
            'number' => -1,
            'orderby' => 'registered',
            'order' => 'DESC',
        ]);

        foreach ($users as $user) {
            $user_id = (int) $user->ID;
            if (user_can($user_id, 'manage_options')) {
                continue;
            }

            $registered_ts = strtotime((string) $user->user_registered);
            if ($registered_ts >= $today_start) {
                $new_today++;
            }
            if ($registered_ts >= $week_start) {
                $new_week++;
            }
            if ($registered_ts >= $month_start) {
                $new_month++;
            }
            $month_key = wp_date('Y-m', $registered_ts);
            if (isset($month_buckets[$month_key])) {
                $month_buckets[$month_key]['customers']++;
            }

            $paid = $paid_customers[$user_id] ?? [];
            $orders = (int) ($paid['orders'] ?? 0);
            $spend = (float) ($paid['revenue'] ?? 0);
            $stored_spend = (float) get_user_meta($user_id, '_mrcp_lifetime_spend', true);
            if ($stored_spend > $spend) {
                $spend = $stored_spend;
            }
            $total_orders += $orders;
            $total_spend += $spend;

            $level = 'silver';
            $discount = 0;
            if ($spend >= 100000) {
                $level = 'vip';
                $discount = 30;
            } elseif ($spend >= 50000) {
                $level = 'diamond';
                $discount = 20;
            } elseif ($spend >= 10000) {
                $level = 'gold';
                $discount = 10;
            }
            $membership[$level]++;

            if ($orders > 1) {
                $returning++;
            } elseif ($orders === 1) {
                $single_order++;
            }

            $last_order_ts = (int) ($paid['last_order_ts'] ?? 0);
            $is_active = $last_order_ts >= $active_cutoff || $registered_ts >= strtotime('-90 days', $now);
            $is_active ? $active++ : $inactive++;

            $recency_score = 0;
            if ($last_order_ts) {
                $days = max(0, (int) floor(($now - $last_order_ts) / DAY_IN_SECONDS));
                $recency_score = $days <= 30 ? 35 : ($days <= 90 ? 25 : ($days <= 180 ? 15 : 5));
            }
            $order_score = min(30, $orders * 4);
            $spend_score = min(35, (int) floor($spend / 3000));
            $health_score = min(100, $recency_score + $order_score + $spend_score);
            $health_label = $health_score >= 75 ? 'Excellent' : ($health_score >= 50 ? 'Good' : ($health_score >= 25 ? 'At Risk' : 'Inactive'));

            $rows[] = [
                'id' => $user_id,
                'name' => $user->display_name ?: $user->user_email,
                'email' => $user->user_email,
                'avatar' => get_avatar_url($user_id, ['size' => 52]),
                'joined' => $registered_ts ? wp_date('M j, Y', $registered_ts) : '—',
                'orders' => $orders,
                'spend' => $spend,
                'aov' => $orders > 0 ? $spend / $orders : 0,
                'membership' => ucfirst($level),
                'membership_key' => $level,
                'discount' => $discount,
                'last_order' => $paid['last_order_date'] ?? 'No paid order',
                'active' => $is_active,
                'health_score' => $health_score,
                'health_label' => $health_label,
            ];
        }

        usort($rows, static function (array $a, array $b): int {
            return $b['spend'] <=> $a['spend'];
        });

        $total_members = count($rows);
        $paid_customer_count = count(array_filter($rows, static fn(array $row): bool => $row['orders'] > 0));
        $retention_base = max(1, $returning + $single_order);

        return [
            'summary' => [
                'total_members' => $total_members,
                'new_today' => $new_today,
                'new_week' => $new_week,
                'new_month' => $new_month,
                'active' => $active,
                'inactive' => $inactive,
                'average_value' => $paid_customer_count > 0 ? $total_spend / $paid_customer_count : 0,
                'total_spend' => $total_spend,
                'total_orders' => $total_orders,
                'discount_given' => $membership_discount,
                'returning_rate' => round(($returning / $retention_base) * 100, 1),
                'new_buyer_rate' => round(($single_order / $retention_base) * 100, 1),
            ],
            'membership' => $membership,
            'growth' => array_values($month_buckets),
            'top_members' => array_slice($rows, 0, 10),
        ];
    }

    private static function customer_month_buckets(int $now): array {
        $buckets = [];
        for ($i = 11; $i >= 0; $i--) {
            $timestamp = strtotime('-' . $i . ' months', strtotime(wp_date('Y-m-01 00:00:00', $now)));
            $key = wp_date('Y-m', $timestamp);
            $buckets[$key] = [
                'key' => $key,
                'label' => wp_date('M Y', $timestamp),
                'short' => wp_date('M', $timestamp),
                'customers' => 0,
            ];
        }
        return $buckets;
    }

    private static function build_insights(array $metrics, array $products, array $payment, array $customers): array {
        $insights = [];
        $top_product = reset($products);
        if ($top_product && $metrics['all']['revenue'] > 0) {
            $share = round(($top_product['revenue'] / $metrics['all']['revenue']) * 100, 1);
            $insights[] = sprintf('%s generated %s%% of paid-order revenue.', $top_product['name'], $share);
        }
        $top_payment_name = key($payment);
        if ($top_payment_name) {
            $insights[] = sprintf('%s is the most-used payment method by revenue.', $top_payment_name);
        }
        if ($metrics['month']['revenue'] > 0) {
            $insights[] = sprintf('This month has generated %s from %d paid orders.', wp_strip_all_tags(wc_price($metrics['month']['revenue'])), $metrics['month']['orders']);
        }
        $top_customer = reset($customers);
        if ($top_customer) {
            $insights[] = sprintf('%s is the highest-value customer with %d paid orders.', $top_customer['name'], $top_customer['orders']);
        }
        if (!$insights) {
            $insights[] = __('Complete more orders to unlock automatic business insights.', 'mr-customer-portal-pro');
        }
        return array_slice($insights, 0, 5);
    }
}
