<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shared cache and invalidation service.
 *
 * Keeps expensive CRM aggregates out of the hot path while ensuring that
 * order, customer, ticket and activation changes invalidate relevant data.
 */
final class Performance {
    private const GROUP = 'mrcp';
    private const GENERATION_OPTION = 'mrcp_cache_generation';

    public static function register(): void {
        if (class_exists(Database::class) && get_option('mrcp_performance_indexes_version') !== (defined('MRCP_VERSION') ? MRCP_VERSION : '13.3.0')) {
            Database::install_performance_indexes();
        }

        // Runtime invalidation hooks live in the lightweight modern listener so
        // REST and cron updates stay fresh without loading the legacy UI layer.
    }

    /**
     * Cache a callback result with persistent transient and object-cache support.
     * False, zero and empty arrays are valid cached values.
     *
     * @param string   $key      Logical cache key.
     * @param callable $callback Value producer.
     * @param int      $ttl      Cache duration in seconds.
     * @return mixed
     */
    public static function remember(string $key, callable $callback, int $ttl = 300) {
        $cache_key = self::key($key);
        $found = false;
        $value = wp_cache_get($cache_key, self::GROUP, false, $found);

        if ($found) {
            return $value;
        }

        $value = get_transient($cache_key);
        if (false !== $value) {
            wp_cache_set($cache_key, $value, self::GROUP, $ttl);
            return $value;
        }

        $value = $callback();
        set_transient($cache_key, $value, max(30, $ttl));
        wp_cache_set($cache_key, $value, self::GROUP, max(30, $ttl));

        return $value;
    }

    public static function invalidate_all(): void {
        $generation = (int) get_option(self::GENERATION_OPTION, 1);
        update_option(self::GENERATION_OPTION, $generation + 1, false);
        if (function_exists('wp_cache_flush_group')) {
            wp_cache_flush_group(self::GROUP);
        }
    }

    public static function invalidate_orders(...$args): void {
        self::invalidate_all();

        $order_id = isset($args[0]) ? absint($args[0]) : 0;
        if ($order_id && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                $customer_id = (int) $order->get_customer_id();
                if ($customer_id && class_exists('\\MRCP_Membership')) {
                    \MRCP_Membership::clear_cache($customer_id);
                }
            }
        }
    }

    public static function invalidate_support(...$args): void {
        self::invalidate_all();
    }

    public static function invalidate_activation(...$args): void {
        self::invalidate_all();
    }

    public static function invalidate_customers(...$args): void {
        self::invalidate_all();
    }

    public static function invalidate_products(...$args): void {
        self::invalidate_all();
    }

    public static function invalidate_deleted_post(int $post_id): void {
        $post_type = get_post_type($post_id);
        if (in_array($post_type, ['mrcp_ticket', 'mrcp_activation', 'product', 'shop_order'], true)) {
            self::invalidate_all();
        }
    }

    private static function key(string $key): string {
        $generation = max(1, (int) get_option(self::GENERATION_OPTION, 1));
        return 'mrcp_' . $generation . '_' . md5($key);
    }
}
