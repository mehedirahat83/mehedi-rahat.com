<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait MRCP_Portal_Admin_Trait {
    public function portal_document_title($title) {
        if (!get_query_var('mrcp_dashboard')) {
            return $title;
        }
        $section = get_query_var('mrcp_section') ?: 'dashboard';
        $labels = [
            'dashboard' => 'Dashboard',
            'crm' => 'Admin CRM Dashboard',
            'crm-customers' => 'Customers',
            'crm-orders' => 'CRM Orders',
            'crm-membership' => 'Membership Overview',
            'crm-products' => 'Product Performance Center',
            'crm-reports' => 'WooCommerce Business Reports',
            'orders' => 'Orders',
            'order' => 'View Order',
            'downloads' => 'Downloads',
            'invoices' => 'Invoices',
            'invoice' => 'Invoice',
            'support' => 'Support Tickets',
            'ticket' => 'Support Ticket',
            'activation' => 'Activation Requests',
            'account' => 'Account Details',
            'addresses' => 'Addresses',
            'payment-methods' => 'Payment Methods',
        ];
        $page = isset($labels[$section]) ? $labels[$section] : 'Dashboard';
        return $page . ' - ' . get_bloginfo('name');
    }

    public function portal_document_title_parts($parts) {
        if (!get_query_var('mrcp_dashboard')) {
            return $parts;
        }
        $section = get_query_var('mrcp_section') ?: 'dashboard';
        $labels = [
            'dashboard' => 'Dashboard',
            'crm' => 'Admin CRM Dashboard',
            'crm-customers' => 'Customers',
            'crm-orders' => 'CRM Orders',
            'crm-membership' => 'Membership Overview',
            'crm-products' => 'Product Performance Center',
            'crm-reports' => 'WooCommerce Business Reports',
            'orders' => 'Orders',
            'order' => 'View Order',
            'downloads' => 'Downloads',
            'invoices' => 'Invoices',
            'invoice' => 'Invoice',
            'support' => 'Support Tickets',
            'ticket' => 'Support Ticket',
            'activation' => 'Activation Requests',
            'account' => 'Account Details',
            'addresses' => 'Addresses',
            'payment-methods' => 'Payment Methods',
        ];
        $parts['title'] = isset($labels[$section]) ? $labels[$section] : 'Dashboard';
        return $parts;
    }

    public function register_ticket_cpt() {
        $support_enabled = function_exists('mrc_can') && mrc_can('digital.support_tickets');
        $activation_enabled = function_exists('mrc_can') && mrc_can('digital.activation_requests');
        register_post_type('mrcp_ticket', [
            'labels' => [
                'name' => 'Support Tickets',
                'singular_name' => 'Support Ticket',
                'menu_name' => 'Support Tickets',
                'add_new_item' => 'Add New Ticket',
                'edit_item' => 'Edit Ticket',
                'view_item' => 'View Ticket',
            ],
            'public' => false,
            'show_ui' => $support_enabled,
            'show_in_menu' => $support_enabled,
            'menu_icon' => 'dashicons-sos',
            'supports' => ['title', 'editor', 'author', 'comments'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);

        register_post_type('mrcp_activation', [
            'labels' => [
                'name' => 'Activation Requests',
                'singular_name' => 'Activation Request',
                'menu_name' => 'Activation Requests',
                'add_new_item' => 'Add New Activation Request',
                'edit_item' => 'Edit Activation Request',
                'view_item' => 'View Activation Request',
            ],
            'public' => false,
            'show_ui' => $activation_enabled,
            'show_in_menu' => $activation_enabled,
            'menu_icon' => 'dashicons-admin-network',
            'supports' => ['title', 'editor', 'author'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }

    public function activation_admin_columns($columns) {
        $new = [];
        $new['cb'] = isset($columns['cb']) ? $columns['cb'] : '';
        $new['title'] = 'Activation Request';
        $new['customer'] = 'Customer';
        $new['domain'] = 'Domain';
        $new['activation_status'] = 'Status';
        $new['date'] = 'Date';
        return $new;
    }

    public function activation_admin_column_content($column, $post_id) {
        if ($column === 'customer') {
            $user = get_user_by('id', (int) get_post_field('post_author', $post_id));
            echo esc_html($user ? $user->display_name : 'Guest');
        } elseif ($column === 'domain') {
            $domain = get_post_meta($post_id, '_mrcp_activation_domain', true);
            echo $domain ? '<a href="' . esc_url($domain) . '" target="_blank">' . esc_html($domain) . '</a>' : '—';
        } elseif ($column === 'activation_status') {
            echo esc_html($this->activation_status_label(get_post_meta($post_id, '_mrcp_activation_status', true) ?: 'pending'));
        }
    }

    public function admin_activation_meta_boxes($post) {
        remove_meta_box('submitdiv', 'mrcp_activation', 'side');
        add_meta_box('mrcp_activation_info', 'Activation Details', [$this, 'render_admin_activation_info_box'], 'mrcp_activation', 'side', 'high');
        add_meta_box('mrcp_activation_workflow', 'Activation Workflow', [$this, 'render_admin_activation_workflow_box'], 'mrcp_activation', 'normal', 'high');
        add_meta_box('submitdiv', 'Publish', 'post_submit_meta_box', 'mrcp_activation', 'side', 'low');
    }

    public function render_admin_activation_info_box($post) {
        $customer = get_user_by('id', (int) $post->post_author);
        $status = get_post_meta($post->ID, '_mrcp_activation_status', true) ?: 'pending';
        $order_id = absint(get_post_meta($post->ID, '_mrcp_activation_order_id', true));
        $domain = get_post_meta($post->ID, '_mrcp_activation_domain', true);
        $login_url = get_post_meta($post->ID, '_mrcp_activation_login_url', true);
        wp_nonce_field('mrcp_admin_activation_action', 'mrcp_admin_activation_nonce');
        echo '<style>.mrcp-admin-info-row{border-bottom:1px solid #e7eef0;padding:10px 0}.mrcp-admin-info-row span{display:block;color:#64748b;font-size:12px;margin-bottom:4px}.mrcp-admin-info-row strong{font-size:13px}.mrcp-admin-status-select{width:100%;margin-top:6px}</style>';
        echo '<div class="mrcp-admin-info-row"><span>Request ID</span><strong>ACT-' . esc_html($post->ID) . '</strong></div>';
        echo '<div class="mrcp-admin-info-row"><span>Customer</span><strong>' . esc_html($customer ? $customer->display_name : 'Unknown') . '</strong><br><small>' . esc_html($customer ? $customer->user_email : '') . '</small></div>';
        if ($order_id) echo '<div class="mrcp-admin-info-row"><span>Related Order</span><strong><a href="' . esc_url(admin_url('post.php?post=' . $order_id . '&action=edit')) . '">#' . esc_html($this->display_order_number($order_id)) . '</a></strong></div>';
        if ($domain) echo '<div class="mrcp-admin-info-row"><span>Website</span><strong><a target="_blank" href="' . esc_url($domain) . '">' . esc_html($domain) . '</a></strong></div>';
        if ($login_url) echo '<div class="mrcp-admin-info-row"><span>Login URL</span><strong><a target="_blank" href="' . esc_url($login_url) . '">' . esc_html($login_url) . '</a></strong></div>';
        echo '<div class="mrcp-admin-info-row"><span>Status</span><select class="mrcp-admin-status-select" name="mrcp_admin_activation_status">';
        foreach ($this->activation_statuses() as $key => $label) echo '<option value="' . esc_attr($key) . '" ' . selected($status, $key, false) . '>' . esc_html($label) . '</option>';
        echo '</select></div>';
    }

    public function render_admin_activation_workflow_box($post) {
        $domain = get_post_meta($post->ID, '_mrcp_activation_domain', true);
        $login_url = get_post_meta($post->ID, '_mrcp_activation_login_url', true);
        $username = get_post_meta($post->ID, '_mrcp_activation_username', true);
        $password = $this->decrypt_secret(get_post_meta($post->ID, '_mrcp_activation_password', true));
        $admin_note = get_post_meta($post->ID, '_mrcp_activation_admin_note', true);
        echo '<style>.mrcp-admin-activation-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:12px 0}.mrcp-admin-activation-grid div,.mrcp-admin-secret{background:#f8fbfb;border:1px solid #e2eeee;border-radius:14px;padding:14px}.mrcp-admin-activation-grid span,.mrcp-admin-secret span{display:block;color:#64748b;font-size:12px;font-weight:700;text-transform:uppercase;margin-bottom:6px}.mrcp-admin-activation-grid strong{word-break:break-all}.mrcp-admin-note-field{width:100%;min-height:130px}</style>';
        echo '<h3>Customer Request</h3><div class="mrcp-admin-activation-grid">';
        echo '<div><span>Website Domain</span><strong>' . esc_html($domain ?: '—') . '</strong></div>';
        echo '<div><span>WP Login URL</span><strong>' . esc_html($login_url ?: '—') . '</strong></div>';
        echo '<div><span>WP Username</span><strong>' . esc_html($username ?: '—') . '</strong></div>';
        echo '<div><span>Temporary Password</span><strong>' . esc_html($password ?: 'Not provided') . '</strong></div>';
        echo '</div>';
        echo '<div class="mrcp-admin-secret"><span>Customer Note</span>' . wp_kses_post(wpautop($post->post_content)) . '</div>';
        echo '<h3>Admin Note / Reply</h3><p>This note will be visible to the customer and sent by email when the request is updated.</p><textarea class="mrcp-admin-note-field" name="mrcp_admin_activation_note" placeholder="Write update for customer...">' . esc_textarea($admin_note) . '</textarea>';
        echo '<p><label><input type="checkbox" name="mrcp_admin_activation_email" value="1" checked> Email this update to customer</label></p>';
    }

    public function handle_admin_activation_save($post_id, $post, $update) {
        if (!is_admin() || wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
        if (!$post || $post->post_type !== 'mrcp_activation') return;
        if (!current_user_can('edit_post', $post_id)) return;
        if (empty($_POST['mrcp_admin_activation_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_admin_activation_nonce'])), 'mrcp_admin_activation_action')) return;
        $old_status = get_post_meta($post_id, '_mrcp_activation_status', true) ?: 'pending';
        $status = isset($_POST['mrcp_admin_activation_status']) ? sanitize_key(wp_unslash($_POST['mrcp_admin_activation_status'])) : $old_status;
        if (!array_key_exists($status, $this->activation_statuses())) $status = $old_status;
        update_post_meta($post_id, '_mrcp_activation_status', $status);
        $note = isset($_POST['mrcp_admin_activation_note']) ? wp_kses_post(wp_unslash($_POST['mrcp_admin_activation_note'])) : '';
        if ($note !== '') update_post_meta($post_id, '_mrcp_activation_admin_note', $note);
        if ($old_status !== $status || $note !== '') {
            $customer_id = (int) $post->post_author;
            if ($customer_id) $this->add_notification($customer_id, 'Activation Request ACT-' . $post_id . ' updated', 'Status: ' . $this->activation_status_label($status), $this->url('activation'), 'activation');
            if (!empty($_POST['mrcp_admin_activation_email'])) $this->notify_customer_activation_update($post_id, $status, $note);
        }
    }

    public function ticket_admin_columns($columns) {
        $new = [];
        $new['cb'] = isset($columns['cb']) ? $columns['cb'] : '';
        $new['title'] = 'Ticket';
        $new['customer'] = 'Customer';
        $new['category'] = 'Category';
        $new['ticket_status'] = 'Status';
        $new['date'] = 'Date';
        return $new;
    }

    public function ticket_admin_column_content($column, $post_id) {
        if ($column === 'customer') {
            $user = get_user_by('id', (int) get_post_field('post_author', $post_id));
            echo esc_html($user ? $user->display_name : 'Guest');
        } elseif ($column === 'category') {
            echo esc_html(ucfirst((string) get_post_meta($post_id, '_mrcp_ticket_category', true)) ?: 'Other');
        } elseif ($column === 'ticket_status') {
            echo esc_html(ucfirst((string) get_post_meta($post_id, '_mrcp_ticket_status', true)) ?: 'Open');
        }
    }

    public function admin_ticket_meta_boxes($post) {
        remove_meta_box('submitdiv', 'mrcp_ticket', 'side');
        add_meta_box('mrcp_ticket_customer', 'Customer & Ticket Info', [$this, 'render_admin_ticket_info_box'], 'mrcp_ticket', 'side', 'high');
        add_meta_box('mrcp_ticket_conversation', 'Ticket Conversation & Reply', [$this, 'render_admin_ticket_reply_box'], 'mrcp_ticket', 'normal', 'high');
        add_meta_box('submitdiv', 'Publish', 'post_submit_meta_box', 'mrcp_ticket', 'side', 'low');
    }

    public function render_admin_ticket_info_box($post) {
        $customer = get_user_by('id', (int) $post->post_author);
        $meta = $this->ticket_meta($post->ID);
        $statuses = $this->ticket_statuses();
        wp_nonce_field('mrcp_admin_ticket_action', 'mrcp_admin_ticket_nonce');

        echo '<style>.mrcp-admin-info-row{border-bottom:1px solid #e7eef0;padding:10px 0}.mrcp-admin-info-row span{display:block;color:#64748b;font-size:12px;margin-bottom:4px}.mrcp-admin-info-row strong{font-size:13px}.mrcp-admin-status-select{width:100%;margin-top:6px}</style>';
        echo '<div class="mrcp-admin-info-row"><span>Ticket ID</span><strong>MR-' . esc_html($post->ID) . '</strong></div>';
        echo '<div class="mrcp-admin-info-row"><span>Customer</span><strong>' . esc_html($customer ? $customer->display_name : 'Unknown customer') . '</strong><br><small>' . esc_html($customer ? $customer->user_email : '') . '</small></div>';
        echo '<div class="mrcp-admin-info-row"><span>Category</span><strong>' . esc_html(ucfirst($meta['category'])) . '</strong></div>';
        if (!empty($meta['order_id'])) {
            echo '<div class="mrcp-admin-info-row"><span>Related Order</span><strong><a href="' . esc_url(admin_url('post.php?post=' . absint($meta['order_id']) . '&action=edit')) . '">#' . esc_html($this->display_order_number($meta['order_id'])) . '</a></strong></div>';
        }
        echo '<div class="mrcp-admin-info-row"><span>Status</span><select class="mrcp-admin-status-select" name="mrcp_admin_ticket_status">';
        foreach ($statuses as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($meta['status'], $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></div>';
        echo '<p style="margin-top:12px"><a class="button button-secondary" target="_blank" href="' . esc_url($this->ticket_url($post->ID)) . '">View customer ticket page</a></p>';
    }

    public function render_admin_ticket_reply_box($post) {
        $meta = $this->ticket_meta($post->ID);
        $comments = get_comments([
            'post_id' => $post->ID,
            'status' => 'approve',
            'type' => 'mrcp_ticket_reply',
            'order' => 'ASC',
        ]);

        echo '<style>
        .mrcp-admin-thread{background:#f8fbfb;border:1px solid #e7eef0;border-radius:14px;padding:16px;margin-bottom:18px}
        .mrcp-admin-message{background:#fff;border:1px solid #e7eef0;border-radius:14px;padding:14px 16px;margin:0 0 12px;box-shadow:0 6px 16px rgba(15,109,109,.06)}
        .mrcp-admin-message.is-admin{background:#effafa;border-color:#cdeeee;margin-left:34px}
        .mrcp-admin-message.is-customer{margin-right:34px}
        .mrcp-admin-message-head{display:flex;justify-content:space-between;gap:12px;margin-bottom:8px;color:#475569}
        .mrcp-admin-message-head strong{color:#102a2a}.mrcp-admin-reply textarea{width:100%;min-height:150px}.mrcp-admin-reply-actions{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-top:12px;flex-wrap:wrap}.mrcp-admin-attachment{display:inline-block;margin-top:8px}.mrcp-admin-note{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:12px;padding:10px 12px;margin:12px 0}
        </style>';
        echo '<div class="mrcp-admin-thread">';
        echo '<div class="mrcp-admin-message is-customer"><div class="mrcp-admin-message-head"><strong>Customer</strong><small>' . esc_html(get_the_date('F j, Y g:i A', $post)) . '</small></div><div>' . wp_kses_post(wpautop($post->post_content)) . '</div>';
        if (!empty($meta['attachment'])) echo '<a class="mrcp-admin-attachment" target="_blank" href="' . esc_url($meta['attachment']) . '">View attachment</a>';
        echo '</div>';

        if ($comments) {
            foreach ($comments as $comment) {
                $is_admin = user_can((int) $comment->user_id, 'manage_options');
                $attachment = get_comment_meta($comment->comment_ID, '_mrcp_reply_attachment', true);
                echo '<div class="mrcp-admin-message ' . ($is_admin ? 'is-admin' : 'is-customer') . '"><div class="mrcp-admin-message-head"><strong>' . esc_html($is_admin ? 'Support Team' : $comment->comment_author) . '</strong><small>' . esc_html(get_comment_date('F j, Y g:i A', $comment)) . '</small></div><div>' . wp_kses_post(wpautop($comment->comment_content)) . '</div>';
                if ($attachment) echo '<a class="mrcp-admin-attachment" target="_blank" href="' . esc_url($attachment) . '">View attachment</a>';
                echo '</div>';
            }
        } else {
            echo '<div class="mrcp-admin-note">No replies yet. Send the first support reply below.</div>';
        }
        echo '</div>';

        if ($meta['status'] === 'closed') {
            echo '<div class="mrcp-admin-note">This ticket is currently closed. Change the status to Open/Answered from the side box and update if you want to reopen it.</div>';
        }

        echo '<div class="mrcp-admin-reply">';
        echo '<h3>Send Admin Reply</h3>';
        echo '<p>Reply will be saved in the ticket conversation, emailed to the customer, and shown in the customer notification bell.</p>';
        echo '<textarea name="mrcp_admin_reply_message" placeholder="Write your reply to the customer..."></textarea>';
        echo '<p><label>Attachment <small>JPG, PNG, PDF, ZIP, TXT</small><br><input type="file" name="mrcp_admin_reply_attachment" accept=".jpg,.jpeg,.png,.pdf,.zip,.txt"></label></p>';
        echo '<div class="mrcp-admin-reply-actions"><label><input type="checkbox" name="mrcp_admin_close_after_reply" value="1"> Close ticket after this reply</label><label><input type="checkbox" name="mrcp_admin_send_email" value="1" checked> Email this reply to customer</label></div>';
        echo '</div>';
    }

    public function handle_admin_ticket_save($post_id, $post, $update) {
        if (!is_admin() || wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
        if (!$post || $post->post_type !== 'mrcp_ticket') return;
        if (!current_user_can('edit_post', $post_id)) return;
        if (empty($_POST['mrcp_admin_ticket_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_admin_ticket_nonce'])), 'mrcp_admin_ticket_action')) return;

        $statuses = $this->ticket_statuses();
        $status = isset($_POST['mrcp_admin_ticket_status']) ? sanitize_key(wp_unslash($_POST['mrcp_admin_ticket_status'])) : '';
        if ($status && array_key_exists($status, $statuses)) {
            update_post_meta($post_id, '_mrcp_ticket_status', $status);
        }

        $message = isset($_POST['mrcp_admin_reply_message']) ? wp_kses_post(wp_unslash($_POST['mrcp_admin_reply_message'])) : '';
        if (!$message) return;

        $admin = wp_get_current_user();
        $comment_id = wp_insert_comment([
            'comment_post_ID' => $post_id,
            'comment_content' => $message,
            'user_id' => get_current_user_id(),
            'comment_author' => $admin ? $admin->display_name : 'Support Team',
            'comment_author_email' => $admin ? $admin->user_email : $this->notification_admin_email(),
            'comment_approved' => 1,
            'comment_type' => 'mrcp_ticket_reply',
        ]);

        $attachment = $this->handle_ticket_upload('mrcp_admin_reply_attachment');
        if ($comment_id && $attachment) update_comment_meta($comment_id, '_mrcp_reply_attachment', $attachment);

        $new_status = !empty($_POST['mrcp_admin_close_after_reply']) ? 'closed' : 'answered';
        update_post_meta($post_id, '_mrcp_ticket_status', $new_status);
        update_post_meta($post_id, '_mrcp_last_admin_reply', current_time('mysql'));

        $customer_id = (int) $post->post_author;
        if ($customer_id) {
            $this->add_notification($customer_id, 'Support replied to Ticket MR-' . $post_id, wp_trim_words(wp_strip_all_tags($message), 16), $this->ticket_url($post_id), 'ticket_reply');
        }

        if (!empty($_POST['mrcp_admin_send_email'])) {
            $this->notify_customer_admin_reply($post_id, $message, $attachment, $new_status);
        }

        update_post_meta($post_id, '_mrcp_admin_reply_notice', 'sent');
    }

    public function admin_ticket_notices() {
        global $post;
        if (!$post || $post->post_type !== 'mrcp_ticket') return;
        if (get_post_meta($post->ID, '_mrcp_admin_reply_notice', true) === 'sent') {
            delete_post_meta($post->ID, '_mrcp_admin_reply_notice');
            echo '<div class="notice notice-success is-dismissible"><p>Support reply sent to the customer successfully.</p></div>';
        }
    }

    public function admin_ticket_form_enctype() {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && $screen->post_type === 'mrcp_ticket') {
            echo ' enctype="multipart/form-data"';
        }
    }

    private function is_support_admin() {
        return current_user_can('manage_options') || current_user_can('edit_others_posts');
    }

    public static function activate() {
        $self = new self();
        $self->rewrite_rules();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public function rewrite_rules() {
        add_rewrite_rule('^dashboard/?$', 'index.php?mrcp_dashboard=1&mrcp_section=dashboard', 'top');
        add_rewrite_rule('^dashboard/activation/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=activation-view&mrcp_activation_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/crm/customers/([0-9]+)/orders/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customer-orders&mrcp_customer_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/crm/order/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-order-view&mrcp_order_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/crm/customers/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customer-profile&mrcp_customer_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/crm/customers/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customers', 'top');
        add_rewrite_rule('^dashboard/crm/orders/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-orders', 'top');
        add_rewrite_rule('^dashboard/crm/membership/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-membership', 'top');
        add_rewrite_rule('^dashboard/crm/products/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-products', 'top');
        add_rewrite_rule('^dashboard/crm/reports/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-reports', 'top');
        add_rewrite_rule('^dashboard/(orders|downloads|invoices|support|activation|membership|account|addresses|payment-methods|crm)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/ticket/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=ticket&mrcp_ticket_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/order/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=order&mrcp_order_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/invoice/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=invoice&mrcp_order_id=$matches[1]', 'top');
    }

    public function query_vars($vars) {
        $vars[] = 'mrcp_dashboard';
        $vars[] = 'mrcp_section';
        $vars[] = 'mrcp_order_id';
        $vars[] = 'mrcp_ticket_id';
        $vars[] = 'mrcp_activation_id';
        $vars[] = 'mrcp_customer_id';
        return $vars;
    }

    public function assets() {
        return;
    }

    private function wc_active() {
        return class_exists('WooCommerce') && function_exists('wc_get_orders');
    }
}
