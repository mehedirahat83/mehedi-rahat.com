<?php

namespace MRCP\Modules\Reports\Concerns;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait ReportsDataTrait {
    /**
     * Prefer the selected MR manual gateway (bKash, Nagad, Rocket, etc.) over
     * the outer WooCommerce gateway title used to process the order.
     */
    private static function get_payment_source_label($order): string {
        $fallback = $order->get_payment_method_title() ?: __('Unknown', 'mr-customer-portal-pro');
        $gateway_id = '';

        foreach (['_mrbp_gateway', '_mrbp_preferred_gateway', '_mrbp_payment_gateway'] as $meta_key) {
            $candidate = $order->get_meta($meta_key, true);
            if (is_scalar($candidate) && '' !== trim((string) $candidate)) {
                $gateway_id = sanitize_key((string) $candidate);
                break;
            }
        }

        if ('' === $gateway_id) {
            return $fallback;
        }

        if (function_exists('mrbp')) {
            try {
                $label = mrbp()->gateways()->label($gateway_id);
                if ('' !== trim($label)) {
                    return $label;
                }
            } catch (\Throwable $error) {
                // Payment Pro may be disabled; use a readable stored gateway ID.
            }
        }

        return ucwords(str_replace(['_', '-'], ' ', $gateway_id));
    }

    private static function get_report_data(): array {
        $cached = get_transient(self::CACHE_KEY);
        if (is_array($cached)) {
            return $cached;
        }

        $now = current_time('timestamp');
        $today_start = strtotime('today', $now);
        $weekly_sales = \MRBP\Services\Analytics::get_weekly_sales();
        $week_start = (int) ($weekly_sales['start_timestamp'] ?? $today_start);
        $month_start = strtotime(date('Y-m-01 00:00:00', $now));
        $year_start = strtotime(date('Y-01-01 00:00:00', $now));

        $yesterday_start = strtotime('-1 day', $today_start);
        $last_week_start = (int) ($weekly_sales['previous_start_timestamp'] ?? strtotime('-1 week', $week_start));
        $last_month_start = strtotime('first day of last month 00:00:00', $now);
        $last_year_start = strtotime(date('Y-01-01 00:00:00', strtotime('-1 year', $now)));
        $rolling_30_start = strtotime('-29 days', $today_start);
        $previous_30_start = strtotime('-59 days', $today_start);

        $paid_statuses = ['wc-completed'];

        $metrics = [
            'today' => ['revenue' => 0.0, 'orders' => 0],
            'week' => ['revenue' => 0.0, 'orders' => 0],
            'month' => ['revenue' => 0.0, 'orders' => 0],
            'year' => ['revenue' => 0.0, 'orders' => 0],
            'all' => ['revenue' => 0.0, 'orders' => 0],
            'yesterday' => ['revenue' => 0.0, 'orders' => 0],
            'last_week' => ['revenue' => 0.0, 'orders' => 0],
            'last_month' => ['revenue' => 0.0, 'orders' => 0],
            'last_year' => ['revenue' => 0.0, 'orders' => 0],
        ];
        $metrics['week'] = [
            'revenue' => (float) ($weekly_sales['revenue'] ?? 0.0),
            'orders' => (int) ($weekly_sales['orders'] ?? 0),
        ];
        $metrics['last_week'] = [
            'revenue' => (float) ($weekly_sales['previous_revenue'] ?? 0.0),
            'orders' => (int) ($weekly_sales['previous_orders'] ?? 0),
        ];
        $payment = [];
        $statuses = [];
        $categories = [];
        $products = [];
        $customers = [];
        $recent_orders = [];
        $membership_discount = 0.0;
        $refund_total = 0.0;
        $gross_total = 0.0;
        $first_paid_ts = 0;
        $rolling_30 = ['revenue' => 0.0, 'orders' => 0];
        $previous_30 = ['revenue' => 0.0, 'orders' => 0];
        $weekday_revenue = array_fill(0, 7, 0.0);
        $weekday_orders = array_fill(0, 7, 0);
        $hour_revenue = array_fill(0, 24, 0.0);
        $hour_orders = array_fill(0, 24, 0);
        $daily = [];
        $month_buckets = self::month_buckets($now, 24);

        $page = 1;
        $max_pages = 1;
        do {
            $query = wc_get_orders([
                'status' => $paid_statuses,
                'limit' => 100,
                'page' => $page,
                'paginate' => true,
                'return' => 'ids',
                'orderby' => 'date',
                'order' => 'DESC',
            ]);
            $order_ids = is_object($query) && isset($query->orders) ? (array) $query->orders : [];
            $max_pages = is_object($query) && isset($query->max_num_pages) ? max(1, (int) $query->max_num_pages) : 1;

            foreach ($order_ids as $order_id) {
                try {
                    $order = wc_get_order($order_id);
                    if (!$order) {
                        continue;
                    }
                    $date = $order->get_date_paid() ?: $order->get_date_created();
            if (!$date) {
                continue;
            }
            $timestamp = $date->getTimestamp();
            $total = (float) $order->get_total();
            $refunded = (float) $order->get_total_refunded();
            $net = max(0, $total - $refunded);
            $gross_total += $total;
            $refund_total += $refunded;
            if (!$first_paid_ts || $timestamp < $first_paid_ts) {
                $first_paid_ts = $timestamp;
            }
            if ($timestamp >= $rolling_30_start) {
                $rolling_30['revenue'] += $net;
                $rolling_30['orders']++;
            } elseif ($timestamp >= $previous_30_start && $timestamp < $rolling_30_start) {
                $previous_30['revenue'] += $net;
                $previous_30['orders']++;
            }
            $weekday_index = (int) wp_date('w', $timestamp);
            $hour_index = (int) wp_date('G', $timestamp);
            $weekday_revenue[$weekday_index] += $net;
            $weekday_orders[$weekday_index]++;
            $hour_revenue[$hour_index] += $net;
            $hour_orders[$hour_index]++;

            self::add_period_metric($metrics, $timestamp, $net, $today_start, PHP_INT_MAX, $month_start, $year_start);

                    if ($timestamp >= $yesterday_start && $timestamp < $today_start) {
                        $metrics['yesterday']['revenue'] += $net;
                        $metrics['yesterday']['orders']++;
                    }
                    if ($timestamp >= $last_month_start && $timestamp < $month_start) {
                        $metrics['last_month']['revenue'] += $net;
                        $metrics['last_month']['orders']++;
                    }
                    if ($timestamp >= $last_year_start && $timestamp < $year_start) {
                        $metrics['last_year']['revenue'] += $net;
                        $metrics['last_year']['orders']++;
                    }

            $month_key = wp_date('Y-m', $timestamp);
            if (isset($month_buckets[$month_key])) {
                $month_buckets[$month_key]['revenue'] += $net;
                $month_buckets[$month_key]['orders']++;
            }

            $day_key = wp_date('Y-m-d', $timestamp);
            if (!isset($daily[$day_key])) {
                $daily[$day_key] = ['orders' => 0, 'revenue' => 0.0, 'customers' => []];
            }
            $daily[$day_key]['orders']++;
            $daily[$day_key]['revenue'] += $net;
            if ($order->get_customer_id()) {
                $daily[$day_key]['customers'][(int) $order->get_customer_id()] = true;
            }

            $method = self::get_payment_source_label($order);
            if (!isset($payment[$method])) {
                $payment[$method] = ['orders' => 0, 'revenue' => 0.0];
            }
            $payment[$method]['orders']++;
            $payment[$method]['revenue'] += $net;

            $status = wc_get_order_status_name($order->get_status());
            if (!isset($statuses[$status])) {
                $statuses[$status] = 0;
            }
            $statuses[$status]++;

            $customer_id = (int) $order->get_customer_id();
            if ($customer_id) {
                if (!isset($customers[$customer_id])) {
                    $user = get_userdata($customer_id);
                    $customers[$customer_id] = [
                        'id' => $customer_id,
                        'name' => $user ? $user->display_name : $order->get_formatted_billing_full_name(),
                        'email' => $user ? $user->user_email : $order->get_billing_email(),
                        'orders' => 0,
                        'revenue' => 0.0,
                        'avatar' => get_avatar_url($customer_id, ['size' => 48]),
                        'last_order_ts' => 0,
                        'last_order_date' => '',
                    ];
                }
                $customers[$customer_id]['orders']++;
                $customers[$customer_id]['revenue'] += $net;
                if (empty($customers[$customer_id]['last_order_ts']) || $timestamp > $customers[$customer_id]['last_order_ts']) {
                    $customers[$customer_id]['last_order_ts'] = $timestamp;
                    $customers[$customer_id]['last_order_date'] = wp_date('M j, Y', $timestamp);
                }
            }

            foreach ($order->get_fees() as $fee) {
                if (false !== stripos($fee->get_name(), 'membership') && (float) $fee->get_total() < 0) {
                    $membership_discount += abs((float) $fee->get_total());
                }
            }

            foreach ($order->get_items('line_item') as $item) {
                $product = $item->get_product();
                $product_id = $item->get_product_id();
                if (!$product_id) {
                    continue;
                }
                $qty = max(0, (float) $item->get_quantity() - (float) abs($order->get_qty_refunded_for_item($item->get_id())));
                $line_revenue = max(0, (float) $item->get_total() - (float) abs($order->get_total_refunded_for_item($item->get_id())));
                if (!isset($products[$product_id])) {
                    $products[$product_id] = [
                        'id' => $product_id,
                        'name' => $item->get_name(),
                        'sold' => 0.0,
                        'revenue' => 0.0,
                        'image' => $product && $product->get_image_id() ? wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') : wc_placeholder_img_src('thumbnail'),
                    ];
                }
                $products[$product_id]['sold'] += $qty;
                $products[$product_id]['revenue'] += $line_revenue;

                if ($product) {
                    $terms = get_the_terms($product_id, 'product_cat');
                    if (is_array($terms)) {
                        foreach ($terms as $term) {
                            if (!isset($categories[$term->term_id])) {
                                $categories[$term->term_id] = ['name' => $term->name, 'revenue' => 0.0, 'sold' => 0.0];
                            }
                            $categories[$term->term_id]['revenue'] += $line_revenue;
                            $categories[$term->term_id]['sold'] += $qty;
                        }
                    }
                }
            }

            if (count($recent_orders) < 5) {
                $recent_items = array_values($order->get_items('line_item'));
                $product_label = __('No products', 'mr-customer-portal-pro');
                if ($recent_items) {
                    $product_label = $recent_items[0]->get_name();
                    if (count($recent_items) > 1) {
                        $product_label .= sprintf(
                            /* translators: %d: number of additional products in the order. */
                            __(' +%d more', 'mr-customer-portal-pro'),
                            count($recent_items) - 1
                        );
                    }
                }
                $recent_orders[] = [
                    'id' => $order_id,
                    'number' => $order->get_order_number(),
                    'customer' => $order->get_formatted_billing_full_name() ?: __('Guest', 'mr-customer-portal-pro'),
                    'product' => $product_label,
                    'payment' => $method,
                    'total' => $net,
                    'status' => wc_get_order_status_name($order->get_status()),
                    'status_slug' => sanitize_html_class($order->get_status()),
                    'date' => wp_date('M j, Y', $timestamp),
                    'relative_time' => sprintf(
                        /* translators: %s: human-readable elapsed time. */
                        __('%s ago', 'mr-customer-portal-pro'),
                        human_time_diff($timestamp, $now)
                    ),
                    'url' => home_url('/dashboard/crm/order/' . absint($order_id) . '/'),
                ];
            }
                } catch (\Throwable $order_error) {
                    error_log('[MRCP Reports Order ' . absint($order_id) . '] ' . $order_error->getMessage());
                    continue;
                }
            }
            $page++;
        } while ($page <= $max_pages);

        uasort($products, static function(array $a, array $b): int {
            $by_revenue = (float) ($b['revenue'] ?? 0) <=> (float) ($a['revenue'] ?? 0);
            if (0 !== $by_revenue) {
                return $by_revenue;
            }

            $by_units = (float) ($b['sold'] ?? 0) <=> (float) ($a['sold'] ?? 0);
            return 0 !== $by_units ? $by_units : strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
        });
        uasort($customers, static fn($a, $b) => $b['revenue'] <=> $a['revenue']);
        uasort($categories, static fn($a, $b) => $b['revenue'] <=> $a['revenue']);
        uasort($payment, static fn($a, $b) => $b['revenue'] <=> $a['revenue']);
        arsort($statuses);

        $today_orders = max(1, $metrics['today']['orders']);
        $lifetime_orders = max(1, (int) $metrics['all']['orders']);
        $active_days = $first_paid_ts ? max(1, (int) floor(($now - $first_paid_ts) / DAY_IN_SECONDS) + 1) : 1;
        $days_elapsed_month = max(1, (int) wp_date('j', $now));
        $days_in_month = max(1, (int) wp_date('t', $now));
        $month_forecast = ($metrics['month']['revenue'] / $days_elapsed_month) * $days_in_month;
        $best_month = ['label' => '—', 'revenue' => 0.0, 'orders' => 0];
        foreach ($month_buckets as $bucket) {
            if ((float) $bucket['revenue'] > (float) $best_month['revenue']) {
                $best_month = $bucket;
            }
        }
        $weekday_labels = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
        $weekday_rows = [];
        foreach ($weekday_labels as $index => $label) {
            $weekday_rows[] = [
                'label' => $label,
                'revenue' => (float) $weekday_revenue[$index],
                'orders' => (int) $weekday_orders[$index],
            ];
        }
        $hour_rows = [];
        foreach ($hour_revenue as $hour => $revenue) {
            $hour_rows[] = [
                'hour' => $hour,
                'label' => wp_date('g A', strtotime(sprintf('%02d:00:00', $hour))),
                'revenue' => (float) $revenue,
                'orders' => (int) $hour_orders[$hour],
            ];
        }
        usort($hour_rows, static fn(array $a, array $b): int => $b['revenue'] <=> $a['revenue']);

        $ticket_counts = wp_count_posts('mrcp_ticket');
        $activation_counts = wp_count_posts('mrcp_activation');
        $support_open = is_object($ticket_counts) && isset($ticket_counts->publish) ? (int) $ticket_counts->publish : 0;
        $activation_total = is_object($activation_counts) && isset($activation_counts->publish) ? (int) $activation_counts->publish : 0;

        $data = [
            'kpis' => [
                'today_revenue' => $metrics['today']['revenue'],
                'today_orders' => $metrics['today']['orders'],
                'aov' => $metrics['today']['revenue'] / $today_orders,
                'customers' => count_users()['total_users'] ?? 0,
                'refunds' => $refund_total,
            ],
            'periods' => $metrics,
            'comparisons' => [
                'today' => self::growth($metrics['today']['revenue'], $metrics['yesterday']['revenue']),
                'week' => self::growth($metrics['week']['revenue'], $metrics['last_week']['revenue']),
                'month' => self::growth($metrics['month']['revenue'], $metrics['last_month']['revenue']),
                'year' => self::growth($metrics['year']['revenue'], $metrics['last_year']['revenue']),
            ],
            'revenue_intelligence' => [
                'gross_revenue' => $gross_total,
                'net_revenue' => $metrics['all']['revenue'],
                'refunds' => $refund_total,
                'refund_rate' => $gross_total > 0 ? round(($refund_total / $gross_total) * 100, 2) : 0.0,
                'lifetime_aov' => $metrics['all']['revenue'] / $lifetime_orders,
                'average_daily_revenue' => $metrics['all']['revenue'] / $active_days,
                'rolling_30' => $rolling_30,
                'previous_30' => $previous_30,
                'rolling_30_growth' => self::growth($rolling_30['revenue'], $previous_30['revenue']),
                'month_forecast' => $month_forecast,
                'best_month' => $best_month,
                'weekday' => $weekday_rows,
                'best_hours' => array_slice($hour_rows, 0, 5),
                'payment_methods' => array_slice($payment, 0, 6, true),
            ],
            'trend' => array_values($month_buckets),
            'payment_methods' => array_slice($payment, 0, 5, true),
            'order_statuses' => array_slice($statuses, 0, 6, true),
            'top_categories' => array_slice($categories, 0, 5, true),
            // The Overview card is explicitly a revenue leaderboard. Product
            // Intelligence has its own scoring/ranking and must not replace it.
            'top_products' => array_slice($products, 0, 5, true),
            'top_customers' => array_slice($customers, 0, 5, true),
            'customer_analytics' => self::build_customer_analytics($customers, $membership_discount, $now),
            'product_intelligence' => self::build_product_intelligence(),
            'operations_intelligence' => self::build_operations_intelligence($now),
            'recent_orders' => $recent_orders,
            'membership_discount' => $membership_discount,
            'support_open' => $support_open,
            'activation_total' => $activation_total,
            'daily_overview' => self::current_week_overview($daily, $now),
            'insights' => self::build_insights($metrics, $products, $payment, $customers),
            'generated_at' => wp_date('M j, Y g:i A'),
        ];

        $data['business_health'] = self::build_business_health($data);

        set_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
        return $data;
    }

    private static function build_business_health(array $data): array {
        $periods = $data['periods'] ?? [];
        $comparisons = $data['comparisons'] ?? [];
        $revenue = $data['revenue_intelligence'] ?? [];
        $products = $data['product_intelligence'] ?? [];
        $customers = $data['customer_analytics'] ?? [];
        $operations = $data['operations_intelligence'] ?? [];

        $month_growth = $comparisons['month'] ?? ['percent' => 0, 'direction' => 'flat'];
        $signed_growth = (float) ($month_growth['percent'] ?? 0);
        if (($month_growth['direction'] ?? 'flat') === 'down') {
            $signed_growth *= -1;
        } elseif (($month_growth['direction'] ?? 'flat') === 'flat') {
            $signed_growth = 0;
        }

        $refund_rate = (float) ($revenue['refund_rate'] ?? 0);
        $revenue_score = 72 + max(-22, min(18, $signed_growth * 0.8)) - min(25, $refund_rate * 2.2);
        $revenue_score = (int) round(max(0, min(100, $revenue_score)));

        $product_rows = $products['products'] ?? [];
        if ($product_rows) {
            $product_score = (int) round(array_sum(array_map(static fn(array $row): int => (int) ($row['health'] ?? 50), $product_rows)) / count($product_rows));
        } else {
            $product_score = 50;
        }

        $customer_summary = $customers['summary'] ?? [];
        $total_members = max(1, (int) ($customer_summary['total_members'] ?? 0));
        $active_share = ((int) ($customer_summary['active'] ?? 0) / $total_members) * 100;
        $returning_rate = (float) ($customer_summary['returning_rate'] ?? 0);
        $customer_score = (int) round(max(0, min(100, ($active_share * .55) + ($returning_rate * .45))));

        $operations_score = (int) ($operations['summary']['health_score'] ?? 50);
        $membership = $customers['membership'] ?? [];
        $premium_members = (int) ($membership['gold'] ?? 0) + (int) ($membership['diamond'] ?? 0) + (int) ($membership['vip'] ?? 0);
        $premium_share = ($premium_members / $total_members) * 100;
        $loyalty_score = (int) round(max(0, min(100, 45 + ($returning_rate * .35) + min(25, $premium_share * 2))));

        $overall = (int) round(
            ($revenue_score * .30) +
            ($product_score * .20) +
            ($customer_score * .20) +
            ($operations_score * .20) +
            ($loyalty_score * .10)
        );
        $overall = max(0, min(100, $overall));

        $label_for = static function (int $score): string {
            return $score >= 85 ? 'Excellent' : ($score >= 70 ? 'Healthy' : ($score >= 55 ? 'Stable' : ($score >= 40 ? 'Needs Attention' : 'Critical')));
        };

        $pillars = [
            ['key' => 'revenue', 'label' => 'Revenue', 'score' => $revenue_score, 'status' => $label_for($revenue_score), 'detail' => number_format_i18n(abs($signed_growth), 1) . '% month movement'],
            ['key' => 'products', 'label' => 'Products', 'score' => $product_score, 'status' => $label_for($product_score), 'detail' => number_format_i18n(count($product_rows)) . ' parent products analysed'],
            ['key' => 'customers', 'label' => 'Customers', 'score' => $customer_score, 'status' => $label_for($customer_score), 'detail' => number_format_i18n($active_share, 1) . '% active customers'],
            ['key' => 'operations', 'label' => 'Operations', 'score' => $operations_score, 'status' => $label_for($operations_score), 'detail' => number_format_i18n((int) ($operations['summary']['current_workload'] ?? 0)) . ' current workload'],
            ['key' => 'loyalty', 'label' => 'Membership & Loyalty', 'score' => $loyalty_score, 'status' => $label_for($loyalty_score), 'detail' => number_format_i18n($returning_rate, 1) . '% returning buyers'],
        ];

        $insights = [];
        $actions = [];
        $risks = [];
        $opportunities = [];

        if ($signed_growth > 5) {
            $insights[] = 'Monthly revenue is growing by ' . number_format_i18n($signed_growth, 1) . '% compared with the previous month.';
            $opportunities[] = 'Reinvest in the products and campaigns driving current revenue growth.';
        } elseif ($signed_growth < -5) {
            $insights[] = 'Monthly revenue is down ' . number_format_i18n(abs($signed_growth), 1) . '% from the previous month.';
            $risks[] = 'Revenue momentum is declining and needs a focused promotion plan.';
            $actions[] = 'Review the last 30 days of product and payment performance.';
        } else {
            $insights[] = 'Monthly revenue is stable compared with the previous month.';
        }
        if ($refund_rate > 8) {
            $risks[] = 'Refund rate is elevated at ' . number_format_i18n($refund_rate, 1) . '%.';
            $actions[] = 'Audit products with the highest refund value and customer complaints.';
        } else {
            $opportunities[] = 'Refund risk is controlled at ' . number_format_i18n($refund_rate, 1) . '%.';
        }
        if ($returning_rate < 25) {
            $risks[] = 'Returning-customer rate is low at ' . number_format_i18n($returning_rate, 1) . '%.';
            $actions[] = 'Create a repeat-purchase offer for first-time customers.';
        } else {
            $insights[] = number_format_i18n($returning_rate, 1) . '% of paid customers are returning buyers.';
        }
        if ($operations_score < 70) {
            $risks[] = 'Operations workload or response performance needs attention.';
            $actions[] = 'Clear unresolved support tickets and pending activation requests.';
        } else {
            $opportunities[] = 'Operations are healthy enough to support additional sales growth.';
        }
        if ($product_score < 60) {
            $actions[] = 'Promote healthy products and review low-performing product listings.';
        }
        $top_product = $product_rows[0] ?? null;
        if ($top_product) {
            $insights[] = ($top_product['name'] ?? 'Top product') . ' is the strongest product with a health score of ' . (int) ($top_product['health'] ?? 0) . '/100.';
        }
        if (!$actions) {
            $actions[] = 'Maintain current performance and review this dashboard weekly.';
        }
        if (!$risks) {
            $risks[] = 'No major business risk is visible in the current report period.';
        }
        if (!$opportunities) {
            $opportunities[] = 'Use customer and product segments to identify the next growth campaign.';
        }

        $month_forecast = (float) ($revenue['month_forecast'] ?? 0);
        $month_orders = (int) ($periods['month']['orders'] ?? 0);
        $days_elapsed = max(1, (int) wp_date('j'));
        $days_in_month = max(1, (int) wp_date('t'));
        $forecast_orders = (int) round(($month_orders / $days_elapsed) * $days_in_month);

        return [
            'score' => $overall,
            'label' => $label_for($overall),
            'pillars' => $pillars,
            'insights' => array_slice($insights, 0, 6),
            'actions' => array_slice(array_values(array_unique($actions)), 0, 5),
            'risks' => array_slice(array_values(array_unique($risks)), 0, 4),
            'opportunities' => array_slice(array_values(array_unique($opportunities)), 0, 4),
            'forecast' => [
                'revenue' => $month_forecast,
                'orders' => $forecast_orders,
                'growth' => $signed_growth,
                'direction' => $signed_growth > 0 ? 'up' : ($signed_growth < 0 ? 'down' : 'flat'),
            ],
            'benchmarks' => [
                'refund_rate' => $refund_rate,
                'returning_rate' => $returning_rate,
                'active_share' => $active_share,
                'operations_workload' => (int) ($operations['summary']['current_workload'] ?? 0),
            ],
        ];
    }
}
