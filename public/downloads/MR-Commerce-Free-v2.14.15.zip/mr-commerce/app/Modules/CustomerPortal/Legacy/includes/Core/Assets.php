<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Central asset manager with route-aware conditional loading.
 */
final class Assets {
    /** @var array<string,string> */
    private static array $versions = [];
    public static function register(): void {
        add_action('wp_enqueue_scripts', [__CLASS__, 'frontend_assets'], 20);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_assets'], 20);
    }

    public static function frontend_assets(): void {
        if (!self::is_portal_request()) {
            return;
        }

        $section = Router::current_section();

        wp_enqueue_style('mrbp-design-tokens', MRBP_URL . 'assets/css/design-tokens.css', [], MRBP_VERSION);
        self::enqueue_style('mrcp-core-foundation', 'assets/css/core-foundation.css', ['mrbp-design-tokens']);
        self::enqueue_style('mrcp-core-modules', 'assets/css/core-modules.css', ['mrcp-core-foundation']);
        self::enqueue_style('mrcp-mobile-polish', 'assets/css/mobile-polish.css', ['mrcp-core-modules']);
        if (self::is_crm_section($section)) {
            if ('crm-order-view' === $section) {
                self::enqueue_style('mrcp-crm-order-detail', 'assets/css/crm-order-detail.css', ['mrcp-core-modules']);
            } else {
                self::enqueue_style('mrcp-crm-dashboard', 'assets/css/crm-dashboard.css', ['mrcp-core-modules']);
            }
        }
        self::enqueue_script('mrcp-core', 'assets/js/core.js');
        self::enqueue_script('mrcp-mobile-polish', 'assets/js/mobile-polish.js', ['mrcp-core']);

        // Customer and admin notification bells are available throughout the portal.
        self::enqueue_script('mrcp-notifications', 'assets/js/notifications.js', ['mrcp-core']);

        // The global CRM search exists only on CRM routes.
        if (self::is_crm_section($section)) {
            self::enqueue_script('mrcp-search', 'assets/js/search.js', ['mrcp-core']);
        }

        // Membership-specific styles are intentionally isolated from other routes.
        if ('membership' === $section) {
            self::enqueue_style('mrcp-membership', 'assets/css/membership.css', ['mrcp-core-modules']);
        }

        self::enqueue_optional_module_assets($section);
        self::enqueue_style('mrcp-visual-polish', 'assets/css/visual-polish.css', ['mrcp-mobile-polish']);

        wp_localize_script('mrcp-core', 'MRCP_DATA', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('mrcp_search_nonce'),
            'section'  => $section,
        ]);
    }

    public static function admin_assets(): void {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;

        if (!$screen) {
            return;
        }

        $screen_id = (string) $screen->id;
        $page      = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        $allowed   = false !== strpos($screen_id, 'mrcp')
            || in_array($page, ['mrbp-customer-portal', 'mrbp-portal-compatibility'], true);

        if (!$allowed) {
            return;
        }

        wp_enqueue_style('mrbp-design-tokens', MRBP_URL . 'assets/css/design-tokens.css', [], MRBP_VERSION);
        self::enqueue_style('mrcp-admin', 'assets/css/admin.css', ['mrbp-design-tokens']);
        self::enqueue_script('mrcp-admin', 'assets/js/admin.js', ['jquery']);
    }

    private static function enqueue_optional_module_assets(string $section): void {
        $safe_section = sanitize_key($section);
        self::enqueue_style('mrcp-' . $safe_section, 'assets/css/modules/' . $safe_section . '.css', ['mrcp-core-modules']);
        self::enqueue_script('mrcp-' . $safe_section, 'assets/js/modules/' . $safe_section . '.js', ['mrcp-core']);
    }

    private static function enqueue_style(string $handle, string $relative_path, array $dependencies = []): void {
        $file = MRCP_PLUGIN_DIR . $relative_path;
        if (!is_readable($file)) {
            return;
        }

        wp_enqueue_style($handle, MRCP_PLUGIN_URL . $relative_path, $dependencies, self::asset_version($file));
    }

    private static function enqueue_script(string $handle, string $relative_path, array $dependencies = []): void {
        $file = MRCP_PLUGIN_DIR . $relative_path;
        if (!is_readable($file)) {
            return;
        }

        wp_enqueue_script($handle, MRCP_PLUGIN_URL . $relative_path, $dependencies, self::asset_version($file), true);
    }


    private static function asset_version(string $file): string {
        if (!isset(self::$versions[$file])) {
            $modified = filemtime($file);
            self::$versions[$file] = false === $modified ? MRBP_VERSION : (string) $modified;
        }
        return self::$versions[$file];
    }

    private static function is_crm_section(string $section): bool {
        return 'crm' === $section || 0 === strpos($section, 'crm-');
    }

    private static function is_portal_request(): bool {
        return (bool) get_query_var('mrcp_dashboard') || is_page('dashboard');
    }
}
