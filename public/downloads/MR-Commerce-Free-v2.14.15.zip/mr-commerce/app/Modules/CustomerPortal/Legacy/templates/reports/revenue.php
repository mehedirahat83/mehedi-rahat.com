<?php
if (!defined('ABSPATH')) exit;

$ri = $data['revenue_intelligence'] ?? [];
$periods = $data['periods'] ?? [];
$comparisons = $data['comparisons'] ?? [];
$trend = $data['trend'] ?? [];
$payments = $ri['payment_methods'] ?? [];
$gross = (float) ($ri['gross_revenue'] ?? 0);
$net = (float) ($ri['net_revenue'] ?? 0);
$refunds = (float) ($ri['refunds'] ?? 0);
$refund_rate = (float) ($ri['refund_rate'] ?? 0);
$lifetime_aov = (float) ($ri['lifetime_aov'] ?? 0);
$daily_average = (float) ($ri['average_daily_revenue'] ?? 0);
$month_forecast = (float) ($ri['month_forecast'] ?? 0);
$best_month = $ri['best_month'] ?? ['label' => '—', 'revenue' => 0, 'orders' => 0];
$rolling_growth = $ri['rolling_30_growth'] ?? ['percent' => 0, 'direction' => 'flat'];

$max_revenue = 1;
foreach ($trend as $row) {
    $max_revenue = max($max_revenue, (float) ($row['revenue'] ?? 0));
}
$max_weekday = 1;
foreach (($ri['weekday'] ?? []) as $row) {
    $max_weekday = max($max_weekday, (float) ($row['revenue'] ?? 0));
}
$payment_total = 0.0;
foreach ($payments as $row) {
    $payment_total += (float) ($row['revenue'] ?? 0);
}

$comparison_labels = [
    'today' => ['Today', 'vs yesterday'],
    'week' => ['This Week', 'vs last week'],
    'month' => ['This Month', 'vs last month'],
    'year' => ['This Year', 'vs last year'],
];
?>
<div class="mrcp-ri">
    <div class="mrcp-bi__section-head">
        <div><span>REVENUE INTELLIGENCE</span><h2>Revenue performance</h2></div>
        <p>Net paid-order revenue, refunds, growth, payment sources and forecasting.</p>
    </div>

    <div class="mrcp-ri__kpis">
        <article><i>৳</i><small>Gross Revenue</small><strong><?php echo wp_kses_post($money($gross)); ?></strong><em>Before refunds</em></article>
        <article class="is-primary"><i>↗</i><small>Net Revenue</small><strong><?php echo wp_kses_post($money($net)); ?></strong><em><?php echo esc_html(number_format_i18n((int) ($periods['all']['orders'] ?? 0))); ?> paid orders</em></article>
        <article><i>↩</i><small>Refunded Revenue</small><strong><?php echo wp_kses_post($money($refunds)); ?></strong><em><?php echo esc_html(number_format_i18n($refund_rate, 1)); ?>% of gross</em></article>
        <article><i>◎</i><small>Lifetime AOV</small><strong><?php echo wp_kses_post($money($lifetime_aov)); ?></strong><em>Per paid order</em></article>
        <article><i>◷</i><small>Average Daily Revenue</small><strong><?php echo wp_kses_post($money($daily_average)); ?></strong><em>Lifetime daily average</em></article>
        <article class="is-forecast"><i>⌁</i><small>Month Forecast</small><strong><?php echo wp_kses_post($money($month_forecast)); ?></strong><em>Current pace estimate</em></article>
    </div>

    <div class="mrcp-ri__comparison-grid">
        <?php foreach ($comparison_labels as $key => $labels):
            $growth = $comparisons[$key] ?? ['percent' => 0, 'direction' => 'flat'];
            $direction = sanitize_html_class($growth['direction'] ?? 'flat'); ?>
            <article>
                <span><small><?php echo esc_html($labels[0]); ?></small><b><?php echo wp_kses_post($money($periods[$key]['revenue'] ?? 0)); ?></b></span>
                <span class="mrcp-ri__growth is-<?php echo esc_attr($direction); ?>"><?php echo 'down' === $direction ? '↓' : ('up' === $direction ? '↑' : '→'); ?> <?php echo esc_html(number_format_i18n((float) ($growth['percent'] ?? 0), 1)); ?>%</span>
                <em><?php echo esc_html(number_format_i18n((int) ($periods[$key]['orders'] ?? 0))); ?> orders · <?php echo esc_html($labels[1]); ?></em>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="mrcp-ri__main-grid">
        <article class="mrcp-bi-card mrcp-ri__trend-card">
            <header><div><span>NET REVENUE TREND</span><h3>Last 24 months</h3></div><b>Refund-adjusted paid revenue</b></header>
            <div class="mrcp-ri__trend">
                <?php foreach ($trend as $row):
                    $height = max(4, round(((float) ($row['revenue'] ?? 0) / $max_revenue) * 100)); ?>
                    <div class="mrcp-ri__trend-item" title="<?php echo esc_attr(($row['label'] ?? '') . ' · ' . wp_strip_all_tags($money($row['revenue'] ?? 0))); ?>">
                        <b><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?></b>
                        <span><i style="height:<?php echo esc_attr($height); ?>%"></i></span>
                        <strong><?php echo esc_html($row['short'] ?? ''); ?></strong>
                        <small><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?> orders</small>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <aside class="mrcp-ri__highlights">
            <article class="mrcp-bi-card">
                <span>BEST MONTH</span>
                <h3><?php echo esc_html($best_month['label'] ?? '—'); ?></h3>
                <strong><?php echo wp_kses_post($money($best_month['revenue'] ?? 0)); ?></strong>
                <small><?php echo esc_html(number_format_i18n((int) ($best_month['orders'] ?? 0))); ?> paid orders</small>
            </article>
            <article class="mrcp-bi-card">
                <span>LAST 30 DAYS</span>
                <h3><?php echo wp_kses_post($money($ri['rolling_30']['revenue'] ?? 0)); ?></h3>
                <?php $rdir = sanitize_html_class($rolling_growth['direction'] ?? 'flat'); ?>
                <strong class="is-<?php echo esc_attr($rdir); ?>"><?php echo 'down' === $rdir ? '↓' : ('up' === $rdir ? '↑' : '→'); ?> <?php echo esc_html(number_format_i18n((float) ($rolling_growth['percent'] ?? 0), 1)); ?>%</strong>
                <small>vs previous 30 days</small>
            </article>
        </aside>
    </div>

    <div class="mrcp-ri__analytics-grid">
        <article class="mrcp-bi-card">
            <header><div><span>PAYMENT REVENUE</span><h3>Revenue by payment method</h3></div></header>
            <div class="mrcp-ri__payment-list">
                <?php if ($payments): foreach ($payments as $name => $row):
                    $share = $payment_total > 0 ? ((float) $row['revenue'] / $payment_total) * 100 : 0; ?>
                    <div>
                        <p><strong><?php echo esc_html($name); ?></strong><span><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?> · <?php echo esc_html(number_format_i18n($share, 1)); ?>%</span></p>
                        <i><b style="width:<?php echo esc_attr(min(100, $share)); ?>%"></b></i>
                        <small><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?> paid orders</small>
                    </div>
                <?php endforeach; else: ?>
                    <p class="mrcp-ri__empty">No paid-order payment data yet.</p>
                <?php endif; ?>
            </div>
        </article>

        <article class="mrcp-bi-card">
            <header><div><span>WEEKDAY PERFORMANCE</span><h3>Best revenue days</h3></div></header>
            <div class="mrcp-ri__weekdays">
                <?php foreach (($ri['weekday'] ?? []) as $row):
                    $width = max(2, ((float) ($row['revenue'] ?? 0) / $max_weekday) * 100); ?>
                    <div><span><?php echo esc_html($row['label'] ?? ''); ?></span><i><b style="width:<?php echo esc_attr($width); ?>%"></b></i><strong><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?></strong><small><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?> orders</small></div>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="mrcp-bi-card">
            <header><div><span>BEST SELLING HOURS</span><h3>Revenue timing</h3></div></header>
            <div class="mrcp-ri__hours">
                <?php foreach (($ri['best_hours'] ?? []) as $index => $row): ?>
                    <div><b>#<?php echo esc_html($index + 1); ?></b><span><strong><?php echo esc_html($row['label'] ?? ''); ?></strong><small><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?> orders</small></span><em><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?></em></div>
                <?php endforeach; ?>
            </div>
        </article>
    </div>

    <div class="mrcp-ri__footer-note"><i>i</i><span>Revenue uses Processing and Completed WooCommerce orders. Refunds are deducted from net revenue and growth calculations.</span></div>
</div>
