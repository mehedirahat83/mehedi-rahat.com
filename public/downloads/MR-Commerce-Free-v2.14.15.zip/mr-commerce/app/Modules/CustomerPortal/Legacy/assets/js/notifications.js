'use strict';
// v12.6 Customer Notification Read System
(function(){
  document.addEventListener('DOMContentLoaded', function(){
    var bell = document.querySelector('.mrcp-bell');
    var dropdown = document.querySelector('.mrcp-notification-dropdown');
    if(!bell || !dropdown || typeof MRCP_DATA === 'undefined') return;

    var list = dropdown.querySelector('.mrcp-notification-list');
    var unreadLabel = dropdown.querySelector('.mrcp-unread-label');
    var markAllButton = dropdown.querySelector('.mrcp-mark-all-read');
    var requestBusy = false;
    var cooldownUntil = 0;

    function setCount(count){
      count = Math.max(0, parseInt(count || 0, 10));
      bell.setAttribute('data-count', String(count));
      if(unreadLabel) unreadLabel.textContent = count + ' unread';
      if(markAllButton) markAllButton.disabled = count < 1;
    }

    function post(action, extras){
      var data = new FormData();
      data.append('action', action);
      data.append('nonce', MRCP_DATA.nonce);
      Object.keys(extras || {}).forEach(function(key){ data.append(key, extras[key]); });
      if(Date.now() < cooldownUntil) return Promise.reject(new Error('cooldown'));
      return fetch(MRCP_DATA.ajax_url, {method:'POST', credentials:'same-origin', body:data})
        .then(function(response){
          if(response.status === 429){
            cooldownUntil = Date.now() + 120000;
            throw new Error('rate-limited');
          }
          if(!response.ok) throw new Error('HTTP '+response.status);
          return response.json();
        });
    }

    function applyResponse(json){
      if(!json || !json.success || !json.data) return false;
      setCount(json.data.count || 0);
      if(list && typeof json.data.html === 'string') list.innerHTML = json.data.html;
      return true;
    }

    function refresh(){
      if(requestBusy) return Promise.resolve();
      requestBusy = true;
      return post('mrcp_get_notifications', {})
        .then(applyResponse)
        .catch(function(){})
        .finally(function(){ requestBusy = false; });
    }

    bell.addEventListener('click', function(e){
      e.preventDefault();
      e.stopPropagation();
      dropdown.classList.toggle('is-open');
      if(dropdown.classList.contains('is-open')) refresh();
    });

    dropdown.addEventListener('click', function(e){
      var markAll = e.target.closest('.mrcp-mark-all-read');
      if(markAll){
        e.preventDefault();
        e.stopPropagation();
        if(markAll.disabled || requestBusy) return;
        requestBusy = true;
        markAll.classList.add('is-loading');
        post('mrcp_mark_notifications_read', {})
          .then(applyResponse)
          .catch(function(){})
          .finally(function(){
            requestBusy = false;
            markAll.classList.remove('is-loading');
          });
        return;
      }

      var item = e.target.closest('.mrcp-notification-item');
      if(!item) return;
      var id = item.getAttribute('data-notification-id');
      var url = item.getAttribute('href') || '#';
      if(!id || item.classList.contains('is-read')) return;

      e.preventDefault();
      item.classList.add('is-marking');
      post('mrcp_mark_notification_read', {notification_id:id})
        .then(function(json){
          applyResponse(json);
          window.location.href = url;
        })
        .catch(function(){ window.location.href = url; });
    });

    document.addEventListener('click', function(e){
      if(!e.target.closest('.mrcp-userchip')) dropdown.classList.remove('is-open');
    });

    // No background polling: refresh only when the user opens the bell.
  });
})();
