<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Installer {
    public static function activate(): void {
        require_once MRCP_PLUGIN_DIR . 'includes/Core/Router.php';
        require_once MRCP_PLUGIN_DIR . 'includes/Core/Database.php';
        Router::register_rewrite_rules();
        Database::install_performance_indexes();
        update_option('mrcp_version', MRCP_VERSION);
        update_option('mrcp_db_version', MRCP_DB_VERSION);
        flush_rewrite_rules();

        $legacy_path = MRCP_PLUGIN_DIR . 'includes/Legacy/class-legacy-portal.php';
        if (file_exists($legacy_path)) {
            require_once $legacy_path;
            if (class_exists('MRCP_Customer_Portal')) {
                \MRCP_Customer_Portal::activate();
            }
        }
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }
}
