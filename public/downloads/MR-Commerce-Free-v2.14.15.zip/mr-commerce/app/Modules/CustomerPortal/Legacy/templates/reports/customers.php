<?php
if (!defined('ABSPATH')) exit;

$customer_data = $data['customer_analytics'] ?? [];
$summary       = $customer_data['summary'] ?? [];
$membership    = $customer_data['membership'] ?? [];
$growth_rows   = $customer_data['growth'] ?? [];
$top_members   = $customer_data['top_members'] ?? [];

$total_members = (int) ($summary['total_members'] ?? 0);
$active        = (int) ($summary['active'] ?? 0);
$inactive      = (int) ($summary['inactive'] ?? 0);
$returning     = (float) ($summary['returning_rate'] ?? 0);
$new_rate      = (float) ($summary['new_buyer_rate'] ?? 0);
$average_value = (float) ($summary['average_value'] ?? 0);
$total_spend   = (float) ($summary['total_spend'] ?? 0);
$total_orders  = (int) ($summary['total_orders'] ?? 0);
$discount      = (float) ($summary['discount_given'] ?? 0);
$avg_orders    = $total_members > 0 ? $total_orders / $total_members : 0;

$max_growth = 1;
foreach ($growth_rows as $row) {
    $max_growth = max($max_growth, (int) ($row['customers'] ?? 0));
}

$membership_total = max(1, array_sum(array_map('intval', $membership)));
$health_counts = ['Excellent' => 0, 'Good' => 0, 'At Risk' => 0, 'Inactive' => 0];
foreach ($top_members as $row) {
    $label = (string) ($row['health_label'] ?? 'Inactive');
    if (isset($health_counts[$label])) $health_counts[$label]++;
}

$customer_insights = [];
if ($returning >= 50) {
    $customer_insights[] = sprintf('Returning customers represent %s%% of paid buyers — a strong retention signal.', number_format_i18n($returning, 1));
} elseif ($returning > 0) {
    $customer_insights[] = sprintf('Returning customer rate is %s%%; retention campaigns may improve repeat purchases.', number_format_i18n($returning, 1));
}
if ($average_value > 0) {
    $customer_insights[] = 'Average paid-customer value is ' . wp_strip_all_tags(wc_price($average_value)) . '.';
}
if ($inactive > 0) {
    $customer_insights[] = number_format_i18n($inactive) . ' customer(s) are currently inactive and may benefit from a re-engagement offer.';
}
if (($membership['gold'] ?? 0) + ($membership['diamond'] ?? 0) + ($membership['vip'] ?? 0) > 0) {
    $customer_insights[] = number_format_i18n((int) (($membership['gold'] ?? 0) + ($membership['diamond'] ?? 0) + ($membership['vip'] ?? 0))) . ' premium member(s) are currently active across Gold, Diamond and VIP tiers.';
}
if (!$customer_insights) {
    $customer_insights[] = 'More paid orders will unlock richer customer intelligence and retention insights.';
}
?>
<div class="mrcp-ci">
    <div class="mrcp-bi__section-head">
        <div><span>CUSTOMER INTELLIGENCE</span><h2>Customer growth, value and retention</h2></div>
        <p>Understand who your customers are, how much they spend and where follow-up can improve retention.</p>
    </div>

    <div class="mrcp-ci__kpis">
        <article class="is-primary"><i>♟</i><small>Total Customers</small><strong><?php echo esc_html(number_format_i18n($total_members)); ?></strong><em><?php echo esc_html(number_format_i18n((int) ($summary['new_month'] ?? 0))); ?> joined this month</em></article>
        <article><i>＋</i><small>New This Month</small><strong><?php echo esc_html(number_format_i18n((int) ($summary['new_month'] ?? 0))); ?></strong><em><?php echo esc_html(number_format_i18n((int) ($summary['new_week'] ?? 0))); ?> this week</em></article>
        <article><i>৳</i><small>Average Customer Value</small><strong><?php echo wp_kses_post(wc_price($average_value)); ?></strong><em>Paid customers only</em></article>
        <article><i>↻</i><small>Returning Rate</small><strong><?php echo esc_html(number_format_i18n($returning, 1)); ?>%</strong><em><?php echo esc_html(number_format_i18n($new_rate, 1)); ?>% one-time buyers</em></article>
        <article><i>✓</i><small>Active Customers</small><strong><?php echo esc_html(number_format_i18n($active)); ?></strong><em><?php echo esc_html(number_format_i18n($inactive)); ?> inactive</em></article>
        <article><i>🏷</i><small>Discount Given</small><strong><?php echo wp_kses_post(wc_price($discount)); ?></strong><em>Membership savings</em></article>
    </div>

    <div class="mrcp-ci__main-grid">
        <article class="mrcp-bi-card mrcp-ci__growth-card">
            <header><div><span>CUSTOMER GROWTH</span><h3>Last 12 months</h3></div><b>New registrations by month</b></header>
            <div class="mrcp-ci__growth-chart">
                <?php foreach ($growth_rows as $row):
                    $count = (int) ($row['customers'] ?? 0);
                    $height = max(5, (int) round(($count / $max_growth) * 100)); ?>
                    <div class="mrcp-ci__growth-item" title="<?php echo esc_attr(($row['label'] ?? '') . ': ' . number_format_i18n($count) . ' customers'); ?>">
                        <b><?php echo esc_html(number_format_i18n($count)); ?></b>
                        <span><i style="height:<?php echo esc_attr($height); ?>%"></i></span>
                        <strong><?php echo esc_html($row['short'] ?? ''); ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <aside class="mrcp-ci__summary-stack">
            <article class="mrcp-bi-card"><span>PAID CUSTOMER VALUE</span><strong><?php echo wp_kses_post(wc_price($total_spend)); ?></strong><small><?php echo esc_html(number_format_i18n($total_orders)); ?> paid orders in total</small></article>
            <article class="mrcp-bi-card"><span>AVERAGE ORDERS</span><strong><?php echo esc_html(number_format_i18n($avg_orders, 1)); ?></strong><small>Orders per registered customer</small></article>
            <article class="mrcp-bi-card"><span>ACTIVE SHARE</span><strong><?php echo esc_html(number_format_i18n($total_members > 0 ? ($active / $total_members) * 100 : 0, 1)); ?>%</strong><small>Recent purchase or registration activity</small></article>
        </aside>
    </div>

    <div class="mrcp-ci__distribution-grid">
        <article class="mrcp-bi-card">
            <header><div><span>MEMBERSHIP DISTRIBUTION</span><h3>Customers by tier</h3></div></header>
            <div class="mrcp-ci__membership-list">
                <?php foreach (['silver' => 'Silver', 'gold' => 'Gold', 'diamond' => 'Diamond', 'vip' => 'VIP'] as $key => $label):
                    $count = (int) ($membership[$key] ?? 0);
                    $percent = ($count / $membership_total) * 100; ?>
                    <div class="is-<?php echo esc_attr($key); ?>">
                        <p><strong><?php echo esc_html($label); ?></strong><span><?php echo esc_html(number_format_i18n($count)); ?> · <?php echo esc_html(number_format_i18n($percent, 1)); ?>%</span></p>
                        <i><b style="width:<?php echo esc_attr(min(100, $percent)); ?>%"></b></i>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>

        <article class="mrcp-bi-card">
            <header><div><span>CUSTOMER STATUS</span><h3>Active vs inactive</h3></div></header>
            <div class="mrcp-ci__status-ring" style="--active-share:<?php echo esc_attr($total_members > 0 ? round(($active / $total_members) * 100, 1) : 0); ?>">
                <div><strong><?php echo esc_html(number_format_i18n($active)); ?></strong><small>Active</small></div>
            </div>
            <div class="mrcp-ci__status-legend"><span><i class="active"></i>Active <b><?php echo esc_html(number_format_i18n($active)); ?></b></span><span><i class="inactive"></i>Inactive <b><?php echo esc_html(number_format_i18n($inactive)); ?></b></span></div>
        </article>

        <article class="mrcp-bi-card">
            <header><div><span>SMART INSIGHTS</span><h3>Customer opportunities</h3></div></header>
            <div class="mrcp-ci__insights">
                <?php foreach (array_slice($customer_insights, 0, 5) as $insight): ?>
                    <p><i>✦</i><span><?php echo esc_html($insight); ?></span></p>
                <?php endforeach; ?>
            </div>
        </article>
    </div>

    <article class="mrcp-bi-card mrcp-ci__table-card">
        <header><div><span>TOP CUSTOMERS</span><h3>Highest lifetime value</h3></div><a href="<?php echo esc_url(home_url('/dashboard/crm/customers/')); ?>">View all customers →</a></header>
        <div class="mrcp-ci__table">
            <div class="head"><span>Customer</span><span>Orders</span><span>Lifetime Spend</span><span>Average Order</span><span>Membership</span><span>Discount</span><span>Last Order</span><span>Health</span></div>
            <?php foreach (array_slice($top_members, 0, 10) as $row):
                $health_key = strtolower(str_replace(' ', '-', (string) ($row['health_label'] ?? 'inactive'))); ?>
                <div>
                    <span class="customer"><img src="<?php echo esc_url($row['avatar'] ?? get_avatar_url(0)); ?>" alt=""><b><?php echo esc_html($row['name'] ?? 'Customer'); ?><small><?php echo esc_html($row['email'] ?? ''); ?></small></b></span>
                    <strong><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?></strong>
                    <strong class="money"><?php echo wp_kses_post(wc_price($row['spend'] ?? 0)); ?></strong>
                    <span><?php echo wp_kses_post(wc_price($row['aov'] ?? 0)); ?></span>
                    <em class="membership is-<?php echo esc_attr($row['membership_key'] ?? 'silver'); ?>"><?php echo esc_html($row['membership'] ?? 'Silver'); ?></em>
                    <span><?php echo esc_html(number_format_i18n((float) ($row['discount'] ?? 0), 0)); ?>%</span>
                    <span><?php echo esc_html($row['last_order'] ?? '—'); ?></span>
                    <em class="health is-<?php echo esc_attr($health_key); ?>"><b><?php echo esc_html(number_format_i18n((int) ($row['health_score'] ?? 0))); ?></b><?php echo esc_html($row['health_label'] ?? 'Inactive'); ?></em>
                </div>
            <?php endforeach; ?>
        </div>
    </article>
</div>
