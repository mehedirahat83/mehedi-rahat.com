<?php
if (!defined('ABSPATH')) exit;

final class MRCP_Customer_Portal {
    use MRCP_Portal_Admin_Trait;
    use MRCP_Portal_Core_Trait;
    use MRCP_Portal_Commerce_Trait;
    use MRCP_Portal_Support_Trait;
    use MRCP_Portal_CRM_Trait;

    private $notice = null;

    const VERSION = '1.0.0';
    const SLUG = 'dashboard';

    public function __construct() {
        add_action('init', [$this, 'register_ticket_cpt'], 0);
        add_action('init', [$this, 'rewrite_rules']);
        add_filter('query_vars', [$this, 'query_vars']);
        add_action('template_redirect', [$this, 'maybe_export_membership_csv'], 5);
        add_action('template_redirect', [$this, 'render_portal']);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_action('wp_ajax_mrcp_search', [$this, 'ajax_search']);
        add_action('woocommerce_cart_calculate_fees', [$this, 'apply_membership_discount'], 20, 1);
        add_filter('manage_mrcp_ticket_posts_columns', [$this, 'ticket_admin_columns']);
        add_action('manage_mrcp_ticket_posts_custom_column', [$this, 'ticket_admin_column_content'], 10, 2);
        add_filter('manage_mrcp_activation_posts_columns', [$this, 'activation_admin_columns']);
        add_action('manage_mrcp_activation_posts_custom_column', [$this, 'activation_admin_column_content'], 10, 2);
        add_action('admin_menu', [$this, 'ticket_admin_badges'], 99);
        add_action('wp_ajax_mrcp_mark_notifications_read', [$this, 'ajax_mark_notifications_read']);
        add_action('wp_ajax_mrcp_mark_notification_read', [$this, 'ajax_mark_notification_read']);
        add_action('wp_ajax_mrcp_get_notifications', [$this, 'ajax_get_notifications']);
        add_action('add_meta_boxes_mrcp_ticket', [$this, 'admin_ticket_meta_boxes']);
        add_action('add_meta_boxes_mrcp_activation', [$this, 'admin_activation_meta_boxes']);
        add_action('save_post_mrcp_ticket', [$this, 'handle_admin_ticket_save'], 10, 3);
        add_action('save_post_mrcp_activation', [$this, 'handle_admin_activation_save'], 10, 3);
        add_action('admin_notices', [$this, 'admin_ticket_notices']);
        add_action('post_edit_form_tag', [$this, 'admin_ticket_form_enctype']);
        add_filter('pre_get_document_title', [$this, 'portal_document_title'], 999);
        add_filter('document_title_parts', [$this, 'portal_document_title_parts'], 999);

        // Cache invalidation is registered by the lightweight modern listener.
        // Keeping it outside this legacy renderer prevents duplicate callbacks.
    }















































    /**
     * Asset loading is handled centrally by MRCP\Core\Assets since v13.2.
     * Kept as a no-op for backward compatibility with the legacy hook map.
     */























































































































































































    /**
     * Return completed-order sales analytics using the WordPress site timezone.
     * The sale date prefers the paid date, then completed date, then created date.
     */


    /**
     * Last 12 calendar months of completed-order revenue.
     * Uses the WordPress site timezone and the paid/completed/created date fallback.
     */

















    /**
     * Return authoritative lifetime product analytics.
     *
     * Units sold use WooCommerce's canonical lifetime `total_sales` value when
     * it is higher than the quantity reconstructed from order items. Revenue is
     * rebuilt from every historical order that was paid (plus refunded orders),
     * with refunded line totals and tax deducted. There is no date or order limit.
     */


    /**
     * Clear every supported lifetime-product analytics cache variant.
     */









    /**
     * v13.0 premium customer membership dashboard.
     */




















































    /**
     * Render the admin-only CRM order details page.
     */



    /**
     * Clear cached CRM membership analytics whenever customer or order data changes.
     */


    /**
     * Return the actual membership discount stored as negative order fees.
     */


    /**
     * Build a cached, lifetime membership analytics dataset.
     */









    /**
     * Clear cached CRM product performance analytics.
     */


    /**
     * Build lifetime/year/month/week product sales analytics from paid orders.
     * Revenue is net line revenue after discounts and item refunds, excluding tax.
     */























}
