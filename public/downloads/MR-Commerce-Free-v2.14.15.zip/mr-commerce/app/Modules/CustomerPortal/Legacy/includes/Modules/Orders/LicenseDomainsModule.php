<?php
namespace MRCP\Modules\Orders;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Product-wise licensed domains stored as WooCommerce order-item metadata.
 *
 * This keeps each domain attached to the exact purchased product, works with
 * HPOS through WooCommerce CRUD objects, and avoids ambiguous order notes.
 */
final class LicenseDomainsModule {
    public const META_KEY = '_mrcp_license_domains';
    private const NONCE_ACTION = 'mrcp_save_license_domains';
    private const NONCE_NAME = 'mrcp_license_domains_nonce';

    public static function register(): void {
        add_action('woocommerce_after_order_itemmeta', [self::class, 'render_admin_field'], 20, 3);
        add_action('woocommerce_saved_order_items', [self::class, 'save_admin_fields'], 20, 2);
    }

    /**
     * Show a textarea below each product on the WooCommerce admin order screen.
     */
    public static function render_admin_field($item_id, $item, $product): void {
        if (!is_admin() || !$item instanceof \WC_Order_Item_Product) {
            return;
        }

        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }

        static $nonce_printed = false;
        static $styles_printed = false;

        if (!$nonce_printed) {
            wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);
            $nonce_printed = true;
        }

        if (!$styles_printed) {
            echo '<style>
                .mrcp-admin-license-domains{margin:14px 0 4px;padding:13px 14px;background:#f4fbfa;border:1px solid #d7eeeb;border-radius:10px;max-width:520px}
                .mrcp-admin-license-domains label{display:block;margin:0 0 7px;color:#175f5d;font-size:13px;font-weight:700}
                .mrcp-admin-license-domains textarea{display:block;width:100%;min-height:74px;padding:9px 11px;border:1px solid #c7dedb;border-radius:8px;background:#fff;box-sizing:border-box;resize:vertical}
                .mrcp-admin-license-domains small{display:block;margin-top:6px;color:#667085;font-size:12px}
            </style>';
            $styles_printed = true;
        }

        $domains = (string) $item->get_meta(self::META_KEY, true);
        ?>
        <div class="mrcp-admin-license-domains">
            <label for="mrcp-license-domains-<?php echo esc_attr((string) $item_id); ?>">
                <?php esc_html_e('Licensed Domains', 'mr-customer-portal-pro'); ?>
            </label>
            <textarea
                id="mrcp-license-domains-<?php echo esc_attr((string) $item_id); ?>"
                name="mrcp_license_domains[<?php echo esc_attr((string) $item_id); ?>]"
                rows="3"
                placeholder="example.com&#10;clientsite.com"
            ><?php echo esc_textarea($domains); ?></textarea>
            <small><?php esc_html_e('Enter one domain per line. Protocols and paths are removed automatically.', 'mr-customer-portal-pro'); ?></small>
        </div>
        <?php
    }

    /**
     * Save domains through WooCommerce order-item CRUD (HPOS compatible).
     */
    public static function save_admin_fields($order_id, $posted_items): void {
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }

        $nonce = isset($_POST[self::NONCE_NAME])
            ? sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME]))
            : '';

        if (!$nonce || !wp_verify_nonce($nonce, self::NONCE_ACTION)) {
            return;
        }

        $posted_domains = isset($_POST['mrcp_license_domains'])
            ? wp_unslash($_POST['mrcp_license_domains'])
            : [];

        if (!is_array($posted_domains)) {
            return;
        }

        foreach ($posted_domains as $item_id => $raw_domains) {
            $item_id = absint($item_id);
            if (!$item_id) {
                continue;
            }

            $item = \WC_Order_Factory::get_order_item($item_id);
            if (!$item instanceof \WC_Order_Item_Product || (int) $item->get_order_id() !== (int) $order_id) {
                continue;
            }

            $domains = self::normalize_domains($raw_domains);

            if (!$domains) {
                $item->delete_meta_data(self::META_KEY);
            } else {
                $item->update_meta_data(self::META_KEY, implode("\n", $domains));
            }

            $item->save();
        }
    }

    /**
     * Return clean, unique domain names.
     *
     * @return string[]
     */
    public static function normalize_domains($raw_domains): array {
        $parts = preg_split('/[\r\n,]+/', (string) $raw_domains, -1, PREG_SPLIT_NO_EMPTY);
        if (!$parts) {
            return [];
        }

        $clean = [];

        foreach ($parts as $domain) {
            $domain = strtolower(trim(sanitize_text_field($domain)));
            if ('' === $domain) {
                continue;
            }

            if (0 !== strpos($domain, 'http://') && 0 !== strpos($domain, 'https://')) {
                $domain = 'https://' . $domain;
            }

            $host = wp_parse_url($domain, PHP_URL_HOST);
            $host = is_string($host) ? strtolower(trim($host, ". \t\n\r\0\x0B")) : '';
            $host = preg_replace('/^www\./i', '', $host);

            if (!$host || strlen($host) > 253) {
                continue;
            }

            // Allow valid internet hostnames and punycode domains.
            if (!filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
                continue;
            }

            $clean[] = $host;
        }

        return array_values(array_unique($clean));
    }

    /**
     * Get saved domains for a line item.
     *
     * @return string[]
     */
    public static function get_domains($item): array {
        if (!$item instanceof \WC_Order_Item_Product) {
            return [];
        }

        return self::normalize_domains((string) $item->get_meta(self::META_KEY, true));
    }

    /**
     * Build a stable display-only license reference for an order item.
     */
    public static function get_license_reference($item): string {
        if (!$item instanceof \WC_Order_Item_Product) {
            return '';
        }

        $order_id = (int) $item->get_order_id();
        $item_id  = (int) $item->get_id();

        if (!$order_id || !$item_id) {
            return '';
        }

        return sprintf('LIC-%d-%d', $order_id, $item_id);
    }

    /**
     * Render a compact, future-ready license summary block.
     */
    public static function render_summary($item, bool $show_empty = false, bool $compact = false): void {
        if (!$item instanceof \WC_Order_Item_Product) {
            return;
        }

        $domains = self::get_domains($item);
        if (!$domains && !$show_empty) {
            return;
        }

        $license_reference = self::get_license_reference($item);
        $classes = 'mrcp-license-summary' . ($compact ? ' is-compact' : '');
        ?>
        <div class="<?php echo esc_attr($classes); ?>">
            <div class="mrcp-license-summary-head">
                <strong><?php esc_html_e('License Summary', 'mr-customer-portal-pro'); ?></strong>
                <span class="mrcp-license-status <?php echo $domains ? 'is-active' : 'is-unassigned'; ?>">
                    <span aria-hidden="true"><?php echo $domains ? '●' : '○'; ?></span>
                    <?php echo esc_html($domains ? __('Active', 'mr-customer-portal-pro') : __('Not Assigned', 'mr-customer-portal-pro')); ?>
                </span>
            </div>

            <?php if ($domains) : ?>
                <div class="mrcp-license-domain-list">
                    <?php foreach ($domains as $domain) : ?>
                        <a class="mrcp-license-domain-badge" href="<?php echo esc_url('https://' . $domain); ?>" target="_blank" rel="noopener noreferrer">
                            <span aria-hidden="true">🌐</span><?php echo esc_html($domain); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <span class="mrcp-license-empty"><?php esc_html_e('No domain assigned', 'mr-customer-portal-pro'); ?></span>
            <?php endif; ?>

            <?php if ($license_reference) : ?>
                <small class="mrcp-license-reference"><?php echo esc_html($license_reference); ?></small>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Backward-compatible renderer used by existing order views.
     */
    public static function render_badges($item): void {
        self::render_summary($item, false, false);
    }
}
