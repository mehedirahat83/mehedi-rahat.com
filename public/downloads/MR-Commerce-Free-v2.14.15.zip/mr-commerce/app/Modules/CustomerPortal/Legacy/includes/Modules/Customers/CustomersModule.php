<?php
namespace MRCP\Modules\Customers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Stable Customers CRM module.
 *
 * Version 11.1.6
 */
final class CustomersModule {
    const MENU_SLUG = 'mrcp-crm-customers';
    const PER_PAGE  = 20;

    public static function register(): void {
        add_action('admin_menu', [__CLASS__, 'register_menu'], 20);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function register_menu(): void {
        $parent = class_exists('MRCP\\Core\\AdminCRM') ? \MRCP\Core\AdminCRM::MENU_SLUG : 'mrcp-admin-crm';
        $capability = current_user_can('manage_woocommerce') ? 'manage_woocommerce' : 'manage_options';

        add_submenu_page(
            $parent,
            __('Customers', 'mr-customer-portal-pro'),
            __('Customers', 'mr-customer-portal-pro'),
            $capability,
            self::MENU_SLUG,
            [__CLASS__, 'render_page']
        );
    }

    public static function enqueue_assets(string $hook): void {
        if (strpos($hook, self::MENU_SLUG) === false) {
            return;
        }

        wp_register_style('mrcp-crm-customers', false, [], defined('MRCP_VERSION') ? MRCP_VERSION : '10.5.5');
        wp_enqueue_style('mrcp-crm-customers');
        wp_add_inline_style('mrcp-crm-customers', self::css());
    }

    public static function render_page(): void {
        $capability = current_user_can('manage_woocommerce') ? 'manage_woocommerce' : 'manage_options';
        if (!current_user_can($capability)) {
            wp_die(esc_html__('You do not have permission to access this page.', 'mr-customer-portal-pro'));
        }

        $search = isset($_GET['mrcp_customer_search']) ? sanitize_text_field(wp_unslash($_GET['mrcp_customer_search'])) : '';
        $level  = isset($_GET['mrcp_membership']) ? sanitize_key(wp_unslash($_GET['mrcp_membership'])) : 'all';
        $paged  = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;

        $query_data = self::query_customers($search, $level, $paged);
        $stats      = self::stats();
        ?>
        <div class="wrap mrcp-customers-wrap">
            <div class="mrcp-customers-hero">
                <div>
                    <h1><?php esc_html_e('Customers', 'mr-customer-portal-pro'); ?></h1>
                    <p><?php esc_html_e('Manage customer memberships, orders and lifetime value.', 'mr-customer-portal-pro'); ?></p>
                </div>
                <a href="<?php echo esc_url(admin_url('admin.php?page=mrcp-admin-crm')); ?>" class="mrcp-back-link">← <?php esc_html_e('Back to CRM Dashboard', 'mr-customer-portal-pro'); ?></a>
            </div>

            <div class="mrcp-customer-stats">
                <?php self::stat_card('👥', __('Total Customers', 'mr-customer-portal-pro'), number_format_i18n($stats['total_customers'])); ?>
                <?php self::stat_card('💰', __('Total Customer Spend', 'mr-customer-portal-pro'), self::money($stats['total_spend'])); ?>
                <?php self::stat_card('🛒', __('Total Orders', 'mr-customer-portal-pro'), number_format_i18n($stats['total_orders'])); ?>
                <?php self::stat_card('⭐', __('Premium Members', 'mr-customer-portal-pro'), number_format_i18n($stats['premium_members'])); ?>
            </div>

            <section class="mrcp-customers-panel">
                <div class="mrcp-customers-toolbar">
                    <form method="get" class="mrcp-customers-search">
                        <input type="hidden" name="page" value="<?php echo esc_attr(self::MENU_SLUG); ?>">
                        <input type="search" name="mrcp_customer_search" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search by name, email, username or phone...', 'mr-customer-portal-pro'); ?>">
                        <select name="mrcp_membership">
                            <?php foreach (self::membership_filter_options() as $key => $label) : ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($level, $key); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit"><?php esc_html_e('Search', 'mr-customer-portal-pro'); ?></button>
                        <?php if ($search || 'all' !== $level) : ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=' . self::MENU_SLUG)); ?>" class="mrcp-reset-link"><?php esc_html_e('Reset', 'mr-customer-portal-pro'); ?></a>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="mrcp-customers-table-wrap">
                    <table class="mrcp-customers-table mrcp-customers-crm-table">
                        <thead>
                        <tr>
                            <th><?php esc_html_e('Customer', 'mr-customer-portal-pro'); ?></th>
                            <th><?php esc_html_e('Email', 'mr-customer-portal-pro'); ?></th>
                            <th><?php esc_html_e('Phone Number', 'mr-customer-portal-pro'); ?></th>
                            <th><?php esc_html_e('Total Spend', 'mr-customer-portal-pro'); ?></th>
                            <th><?php esc_html_e('Total Orders', 'mr-customer-portal-pro'); ?></th>
                            <th><?php esc_html_e('Action', 'mr-customer-portal-pro'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (!empty($query_data['customers'])) : ?>
                            <?php foreach ($query_data['customers'] as $customer) : ?>
                                <?php self::render_customer_row($customer); ?>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="6" class="mrcp-empty-row"><?php esc_html_e('No customers found.', 'mr-customer-portal-pro'); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php self::pagination($query_data['total'], $paged, $search, $level); ?>
            </section>
        </div>
        <?php
    }

    private static function render_customer_row(\WP_User $user): void {
        $user_id     = (int) $user->ID;
        $orders      = self::customer_order_count($user_id);
        $spend       = self::customer_total_spent($user_id);
        $membership  = self::membership_for_user($user_id);
        $phone       = self::customer_phone($user);
        $first_name  = (string) get_user_meta($user_id, 'billing_first_name', true);
        if (!$first_name) {
            $first_name = (string) get_user_meta($user_id, 'first_name', true);
        }
        if (!$first_name) {
            $first_name = $user->display_name ?: $user->user_login;
        }
        $profile_url = home_url('/dashboard/crm/customers/' . $user_id . '/');
        ?>
        <tr>
            <td>
                <div class="mrcp-customer-cell">
                    <?php echo get_avatar($user_id, 44); ?>
                    <div>
                        <strong><?php echo esc_html($first_name); ?></strong>
                        <span class="mrcp-customer-membership-mini is-<?php echo esc_attr(sanitize_html_class($membership['key'])); ?>"><?php echo esc_html($membership['icon'] . ' ' . $membership['name']); ?></span>
                    </div>
                </div>
            </td>
            <td><a href="mailto:<?php echo esc_attr($user->user_email); ?>"><?php echo esc_html($user->user_email); ?></a></td>
            <td><?php echo $phone ? '<a class="mrcp-customer-contact-link" href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $phone)) . '">' . esc_html($phone) . '</a>' : '<span class="mrcp-customer-empty-value">—</span>'; ?></td>
            <td><strong class="mrcp-customer-total-spend"><?php echo wp_kses_post(self::money($spend)); ?></strong></td>
            <td><strong class="mrcp-customer-order-count"><?php echo esc_html(number_format_i18n($orders)); ?></strong></td>
            <td><a class="mrcp-view-btn" href="<?php echo esc_url($profile_url); ?>"><?php esc_html_e('View', 'mr-customer-portal-pro'); ?></a></td>
        </tr>
        <?php
    }

    private static function query_customers(string $search, string $level, int $paged): array {
        // The common "All Memberships" view is paginated and ordered directly
        // in SQL. This avoids loading every customer and calculating spend for
        // the complete result set before showing only twenty rows.
        if ('all' === $level) {
            return self::query_customers_paginated($search, $paged);
        }

        // Membership filtering still uses the compatibility path because the
        // legacy membership rules are dynamic and filterable. The expensive
        // result is cached, then sliced for the requested page.
        $callback = static function () use ($search, $level): array {
            $args = [
                'role__in'       => ['customer', 'subscriber'],
                'orderby'        => 'registered',
                'order'          => 'DESC',
                'count_total'    => false,
                'number'         => 1000,
                'fields'         => 'all',
                'cache_results'  => true,
            ];

            if ($search !== '') {
                $args['search'] = '*' . esc_attr($search) . '*';
                $args['search_columns'] = ['user_login', 'user_email', 'display_name', 'user_nicename'];
            }

            $query = new \WP_User_Query($args);
            $users = array_values(array_filter($query->get_results(), static function ($user) use ($level) {
                if (!$user instanceof \WP_User) {
                    return false;
                }
                $membership = self::membership_for_user((int) $user->ID);
                return isset($membership['key']) && sanitize_key((string) $membership['key']) === $level;
            }));

            usort($users, static function ($a, $b) {
                $a_spend = self::customer_total_spent((int) $a->ID);
                $b_spend = self::customer_total_spent((int) $b->ID);
                return $a_spend === $b_spend
                    ? strcmp((string) $b->user_registered, (string) $a->user_registered)
                    : (($a_spend < $b_spend) ? 1 : -1);
            });

            return $users;
        };

        $cache_key = 'customers_filtered_' . md5($search . '|' . $level);
        $users = class_exists('MRCP\\Core\\Performance')
            ? \MRCP\Core\Performance::remember($cache_key, $callback, 10 * MINUTE_IN_SECONDS)
            : $callback();

        $feature_limit = function_exists('mrc_limit') ? mrc_limit('customer.basic_profiles') : -1;
        if ($feature_limit >= 0) {
            $users = array_slice($users, 0, $feature_limit);
        }
        $total  = count($users);
        $offset = max(0, ($paged - 1) * self::PER_PAGE);

        return [
            'customers' => array_slice($users, $offset, self::PER_PAGE),
            'total'     => $total,
        ];
    }

    private static function query_customers_paginated(string $search, int $paged): array {
        global $wpdb;

        $users_table    = $wpdb->users;
        $usermeta_table = $wpdb->usermeta;
        $lookup_table   = $wpdb->prefix . 'wc_customer_lookup';
        $capability_key = $wpdb->prefix . 'capabilities';
        $where          = [
            'caps.meta_key = %s',
            '(caps.meta_value LIKE %s OR caps.meta_value LIKE %s)',
        ];
        $bindings = [
            $capability_key,
            '%"customer"%',
            '%"subscriber"%',
        ];

        if ('' !== $search) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where[] = '(u.user_login LIKE %s OR u.user_email LIKE %s OR u.display_name LIKE %s OR u.user_nicename LIKE %s)';
            array_push($bindings, $like, $like, $like, $like);
        }

        $where_sql = implode(' AND ', $where);
        $page       = max(1, $paged);
        $offset     = ($page - 1) * self::PER_PAGE;

        $count_sql = "SELECT COUNT(DISTINCT u.ID)
            FROM {$users_table} u
            INNER JOIN {$usermeta_table} caps ON caps.user_id = u.ID
            WHERE {$where_sql}";
        $total = (int) $wpdb->get_var($wpdb->prepare($count_sql, $bindings));
        $feature_limit = function_exists('mrc_limit') ? mrc_limit('customer.basic_profiles') : -1;
        if ($feature_limit >= 0) {
            $total = min($total, $feature_limit);
            if ($offset >= $feature_limit) {
                return ['customers' => [], 'total' => $total];
            }
        }

        $query_sql = "SELECT DISTINCT u.ID
            FROM {$users_table} u
            INNER JOIN {$usermeta_table} caps ON caps.user_id = u.ID
            LEFT JOIN {$lookup_table} cl ON cl.user_id = u.ID
            WHERE {$where_sql}
            ORDER BY COALESCE(cl.total_spent, 0) DESC, u.user_registered DESC
            LIMIT %d OFFSET %d";
        $page_limit = $feature_limit >= 0 ? min(self::PER_PAGE, max(0, $feature_limit - $offset)) : self::PER_PAGE;
        $ids = $wpdb->get_col($wpdb->prepare($query_sql, array_merge($bindings, [$page_limit, $offset])));

        $customers = [];
        foreach ($ids as $user_id) {
            $user = get_userdata((int) $user_id);
            if ($user instanceof \WP_User) {
                $customers[] = $user;
            }
        }

        return [
            'customers' => $customers,
            'total'     => $total,
        ];
    }

    private static function stats(): array {
        $callback = static function (): array {
            global $wpdb;

            $lookup_table = $wpdb->prefix . 'wc_customer_lookup';
            $aggregate = $wpdb->get_row(
                "SELECT COUNT(*) AS total_customers,
                    COALESCE(SUM(total_spent), 0) AS total_spend,
                    COALESCE(SUM(order_count), 0) AS total_orders
                FROM {$lookup_table}",
                ARRAY_A
            );

            $users = get_users([
                'role__in' => ['customer', 'subscriber'],
                'fields'   => ['ID'],
                'number'   => 1000,
            ]);
            $premium = 0;
            foreach ($users as $user) {
                $membership = self::membership_for_user((int) $user->ID);
                if (isset($membership['key']) && in_array($membership['key'], ['gold', 'diamond', 'vip'], true)) {
                    $premium++;
                }
            }

            return [
                'total_customers' => max(count($users), (int) ($aggregate['total_customers'] ?? 0)),
                'total_spend'     => (float) ($aggregate['total_spend'] ?? 0),
                'total_orders'    => (int) ($aggregate['total_orders'] ?? 0),
                'premium_members' => $premium,
            ];
        };

        return class_exists('MRCP\\Core\\Performance')
            ? \MRCP\Core\Performance::remember('customers_module_stats', $callback, 15 * MINUTE_IN_SECONDS)
            : $callback();
    }

    /**
     * Resolve a customer's best available phone number.
     *
     * Prefer the newest WooCommerce order phone because many customers do not
     * save billing details on their WordPress profile. Fall back to user meta.
     */
    private static function customer_phone(\WP_User $user): string {
        $user_id = (int) $user->ID;
        $phone   = '';

        if (function_exists('wc_get_orders')) {
            $statuses = function_exists('wc_get_order_statuses') ? array_keys(wc_get_order_statuses()) : [];
            $args = [
                'limit'       => 10,
                'orderby'     => 'date',
                'order'       => 'DESC',
                'return'      => 'objects',
                'customer_id' => $user_id,
            ];
            if ($statuses) {
                $args['status'] = $statuses;
            }

            $orders = wc_get_orders($args);

            // Historical or imported orders may be linked only by billing email.
            if (empty($orders) && !empty($user->user_email)) {
                unset($args['customer_id']);
                $args['billing_email'] = $user->user_email;
                $orders = wc_get_orders($args);
            }

            foreach ($orders as $order) {
                if ($order instanceof \WC_Order) {
                    $candidate = trim((string) $order->get_billing_phone());
                    if ($candidate !== '') {
                        $phone = $candidate;
                        break;
                    }
                }
            }
        }

        if ($phone === '') {
            $phone = trim((string) get_user_meta($user_id, 'billing_phone', true));
        }

        return $phone;
    }

    private static function customer_total_spent(int $user_id): float {
        if (function_exists('wc_get_customer_total_spent')) {
            return (float) wc_get_customer_total_spent($user_id);
        }
        return 0.0;
    }

    private static function customer_order_count(int $user_id): int {
        if (function_exists('wc_get_customer_order_count')) {
            return (int) wc_get_customer_order_count($user_id);
        }
        return 0;
    }

    private static function membership_for_user(int $user_id): array {
        if (class_exists('MRCP_Membership') && method_exists('MRCP_Membership', 'get_customer_membership')) {
            $membership = \MRCP_Membership::get_customer_membership($user_id);
            if (is_array($membership)) {
                $key = isset($membership['key']) ? sanitize_key((string) $membership['key']) : 'silver';
                $name = isset($membership['name']) ? (string) $membership['name'] : ucfirst($key) . ' Member';
                $icon = isset($membership['icon']) ? (string) $membership['icon'] : self::membership_icon($key);
                return ['key' => $key, 'name' => $name, 'icon' => $icon];
            }
        }

        $spent = self::customer_total_spent($user_id);
        if ($spent >= 100000) {
            return ['key' => 'vip', 'name' => 'VIP Member', 'icon' => '👑'];
        }
        if ($spent >= 50000) {
            return ['key' => 'diamond', 'name' => 'Diamond Member', 'icon' => '💎'];
        }
        if ($spent >= 10000) {
            return ['key' => 'gold', 'name' => 'Gold Member', 'icon' => '🥇'];
        }
        return ['key' => 'silver', 'name' => 'Silver Member', 'icon' => '🥈'];
    }

    private static function membership_icon(string $key): string {
        $icons = ['silver' => '🥈', 'gold' => '🥇', 'diamond' => '💎', 'vip' => '👑'];
        return $icons[$key] ?? '🥈';
    }


    private static function membership_filter_options(): array {
        return [
            'all'     => __('All Memberships', 'mr-customer-portal-pro'),
            'silver'  => __('Silver', 'mr-customer-portal-pro'),
            'gold'    => __('Gold', 'mr-customer-portal-pro'),
            'diamond' => __('Diamond', 'mr-customer-portal-pro'),
            'vip'     => __('VIP', 'mr-customer-portal-pro'),
        ];
    }

    private static function stat_card(string $icon, string $label, string $value): void {
        echo '<section class="mrcp-customer-stat"><span>' . esc_html($icon) . '</span><div><p>' . esc_html($label) . '</p><strong>' . wp_kses_post($value) . '</strong></div></section>';
    }

    private static function pagination(int $total, int $paged, string $search, string $level): void {
        $pages = (int) ceil($total / self::PER_PAGE);
        if ($pages <= 1) {
            return;
        }

        $base_args = [
            'page' => self::MENU_SLUG,
            'mrcp_customer_search' => $search,
            'mrcp_membership' => $level,
        ];

        $make_url = static function (int $page) use ($base_args): string {
            return add_query_arg(array_merge($base_args, ['paged' => max(1, $page)]), admin_url('admin.php'));
        };

        $window = 2;
        $items = [1, $pages];
        for ($i = max(1, $paged - $window); $i <= min($pages, $paged + $window); $i++) {
            $items[] = $i;
        }
        $items = array_values(array_unique(array_filter($items, static fn($i) => $i >= 1 && $i <= $pages)));
        sort($items);

        echo '<nav class="mrcp-pagination" aria-label="' . esc_attr__('Customers pagination', 'mr-customer-portal-pro') . '">';

        if ($paged > 1) {
            echo '<a class="mrcp-page-btn mrcp-page-prev" href="' . esc_url($make_url($paged - 1)) . '">‹ ' . esc_html__('Previous', 'mr-customer-portal-pro') . '</a>';
        } else {
            echo '<span class="mrcp-page-btn mrcp-page-prev is-disabled">‹ ' . esc_html__('Previous', 'mr-customer-portal-pro') . '</span>';
        }

        $last = 0;
        foreach ($items as $i) {
            if ($last && $i > $last + 1) {
                echo '<span class="mrcp-page-dots">…</span>';
            }
            if ($i === $paged) {
                echo '<span class="mrcp-page-number is-active" aria-current="page">' . esc_html((string) $i) . '</span>';
            } else {
                echo '<a class="mrcp-page-number" href="' . esc_url($make_url($i)) . '">' . esc_html((string) $i) . '</a>';
            }
            $last = $i;
        }

        if ($paged < $pages) {
            echo '<a class="mrcp-page-btn mrcp-page-next" href="' . esc_url($make_url($paged + 1)) . '">' . esc_html__('Next', 'mr-customer-portal-pro') . ' ›</a>';
        } else {
            echo '<span class="mrcp-page-btn mrcp-page-next is-disabled">' . esc_html__('Next', 'mr-customer-portal-pro') . ' ›</span>';
        }

        echo '</nav>';
    }

    private static function money($amount): string {
        if (function_exists('wc_price')) {
            return wc_price((float) $amount, ['decimals' => 0]);
        }
        return '৳' . number_format_i18n((float) $amount, 0);
    }

    private static function css(): string {
        return <<<'CSS'
#wpcontent{background:#f5fbfb}.mrcp-customers-wrap{max-width:1500px;margin:28px 28px 28px 8px;color:#0f172a;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.mrcp-customers-hero{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;margin-bottom:22px}.mrcp-customers-hero h1{font-size:34px;line-height:1.1;margin:0 0 10px;font-weight:900;color:#0f172a}.mrcp-customers-hero p{font-size:16px;margin:0;color:#53627a}.mrcp-back-link{background:#fff;border:1px solid #dcebed;border-radius:14px;padding:13px 18px;text-decoration:none;color:#008f82;font-weight:900;box-shadow:0 14px 34px rgba(15,23,42,.06)}.mrcp-customer-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin-bottom:22px}.mrcp-customer-stat{background:#fff;border:1px solid #e5eeee;border-radius:22px;padding:24px;display:flex;gap:18px;align-items:center;box-shadow:0 18px 46px rgba(15,23,42,.07)}.mrcp-customer-stat span{width:64px;height:64px;border-radius:50%;display:grid;place-items:center;background:#eafafa;font-size:31px}.mrcp-customer-stat p{margin:0 0 13px;font-weight:900;color:#0f172a}.mrcp-customer-stat strong{font-size:32px;line-height:1;font-weight:900;color:#0b1532}.mrcp-customers-panel{background:#fff;border:1px solid #e5eeee;border-radius:24px;box-shadow:0 18px 46px rgba(15,23,42,.065);padding:24px}.mrcp-customers-toolbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}.mrcp-customers-search{display:flex;gap:12px;width:100%;align-items:center}.mrcp-customers-search input{min-width:360px;flex:1;height:48px;border:1px solid #dcebed;border-radius:14px;padding:0 16px}.mrcp-customers-search select{height:48px;border:1px solid #dcebed;border-radius:14px;padding:0 15px;background:#fff}.mrcp-customers-search button,.mrcp-view-btn{height:48px;border:0;border-radius:14px;background:#008f82;color:#fff;padding:0 20px;font-weight:900;text-decoration:none;display:inline-flex;align-items:center}.mrcp-reset-link{font-weight:900;color:#64748b;text-decoration:none}.mrcp-customers-table-wrap{overflow:auto}.mrcp-customers-table{width:100%;min-width:1080px;border-collapse:separate;border-spacing:0 10px;table-layout:fixed}.mrcp-customers-table th{text-align:left;font-size:13px;text-transform:uppercase;letter-spacing:.06em;color:#64748b;padding:8px 14px}.mrcp-customers-table td{background:#f9fcfc;border-top:1px solid #edf3f4;border-bottom:1px solid #edf3f4;padding:16px 14px;vertical-align:middle}.mrcp-customers-table td:first-child{border-left:1px solid #edf3f4;border-radius:16px 0 0 16px}.mrcp-customers-table td:last-child{border-right:1px solid #edf3f4;border-radius:0 16px 16px 0}.mrcp-customer-cell{display:flex;gap:12px;align-items:center}.mrcp-customer-cell img{border-radius:50%}.mrcp-customer-cell strong{display:block;font-weight:900;color:#0f172a}.mrcp-customer-cell span{display:block;color:#64748b;font-size:13px;margin-top:4px}.mrcp-membership-badge{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:8px 12px;font-weight:900;font-size:13px;background:#eef7ff;color:#1683f5}.mrcp-membership-badge.is-gold{background:#fff7e7;color:#d97706}.mrcp-membership-badge.is-diamond{background:#eef8ff;color:#0369a1}.mrcp-membership-badge.is-vip{background:#fff0f0;color:#dc2626}.mrcp-empty-row{text-align:center!important;color:#64748b!important;font-weight:800!important;padding:35px!important}.mrcp-pagination{display:flex;flex-wrap:wrap;gap:10px;justify-content:flex-end;align-items:center;margin-top:22px;padding:12px 0 0;clear:both}.mrcp-pagination a,.mrcp-pagination span{box-sizing:border-box}.mrcp-page-number{min-width:40px;height:40px;border-radius:13px;border:1px solid #dcebed;background:#fff;display:inline-flex;align-items:center;justify-content:center;text-decoration:none!important;color:#0f172a!important;font-weight:900;line-height:1;box-shadow:0 10px 22px rgba(15,23,42,.04)}.mrcp-page-number:hover{border-color:#008f82;color:#008f82!important}.mrcp-page-number.is-active{background:#008f82!important;color:#fff!important;border-color:#008f82!important}.mrcp-page-btn{height:40px;min-width:112px;padding:0 16px;border-radius:13px;border:1px solid #dcebed;background:#fff;display:inline-flex;align-items:center;justify-content:center;text-decoration:none!important;color:#0f172a!important;font-weight:900;white-space:nowrap;line-height:1;box-shadow:0 10px 22px rgba(15,23,42,.04)}.mrcp-page-btn:hover{border-color:#008f82;color:#008f82!important}.mrcp-page-btn.is-disabled{opacity:.45;pointer-events:none;background:#f8fafc}.mrcp-page-dots{height:40px;min-width:30px;display:inline-flex;align-items:center;justify-content:center;color:#64748b;font-weight:900}@media(max-width:1100px){.mrcp-customer-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.mrcp-customers-search{flex-wrap:wrap}.mrcp-customers-search input{min-width:0;width:100%}}@media(max-width:782px){.mrcp-customers-wrap{margin:18px 10px}.mrcp-customers-hero{flex-direction:column}.mrcp-customer-stats{grid-template-columns:1fr}.mrcp-customers-search input,.mrcp-customers-search select,.mrcp-customers-search button{width:100%}}.mrcp-customer-membership-mini{display:inline-flex!important;width:max-content;margin-top:6px!important;padding:4px 8px;border-radius:999px;background:#eef7ff;color:#1683f5!important;font-size:11px!important;font-weight:900}.mrcp-customer-membership-mini.is-gold{background:#fff7e7;color:#d97706!important}.mrcp-customer-membership-mini.is-diamond{background:#eef8ff;color:#0369a1!important}.mrcp-customer-membership-mini.is-vip{background:#fff0f0;color:#dc2626!important}.mrcp-customer-order-count{display:inline-flex;min-width:42px;height:38px;align-items:center;justify-content:center;border-radius:12px;background:#eafafa;color:#008f82;font-size:16px}.mrcp-customer-empty-value{color:#94a3b8}.mrcp-customers-table th:nth-child(1){width:23%}.mrcp-customers-table th:nth-child(2){width:23%}.mrcp-customers-table th:nth-child(3){width:18%}.mrcp-customers-table th:nth-child(4){width:15%}.mrcp-customers-table th:nth-child(5){width:10%}.mrcp-customers-table th:nth-child(6){width:11%;text-align:right}.mrcp-customers-table td:last-child{text-align:right}.mrcp-customer-total-spend{display:inline-flex;align-items:center;min-height:38px;padding:0 12px;border-radius:12px;background:#f0fdf9;color:#008f82;font-size:16px;font-weight:900;white-space:nowrap}.mrcp-customer-total-spend .woocommerce-Price-amount,.mrcp-customer-total-spend .woocommerce-Price-currencySymbol{color:inherit;font-size:inherit;font-weight:inherit}
CSS;
    }
}
