<?php
if (!defined('ABSPATH')) exit;
$health = $data['business_health'] ?? [];
$score = (int) ($health['score'] ?? 0);
$label = (string) ($health['label'] ?? 'No data');
$forecast = $health['forecast'] ?? [];
$score_class = $score >= 85 ? 'excellent' : ($score >= 70 ? 'healthy' : ($score >= 55 ? 'stable' : ($score >= 40 ? 'attention' : 'critical')));
?>
<div class="mrcp-bh">
    <div class="mrcp-bi__section-head">
        <div><span>BUSINESS HEALTH & SMART INSIGHTS</span><h2>Executive health center</h2></div>
        <p>A weighted view of revenue, products, customers, loyalty and operations.</p>
    </div>

    <div class="mrcp-bh__hero">
        <article class="mrcp-bi-card mrcp-bh__score-card is-<?php echo esc_attr($score_class); ?>">
            <div class="mrcp-bh__ring" style="--health-score:<?php echo esc_attr($score); ?>">
                <div><strong><?php echo esc_html($score); ?></strong><small>/100</small></div>
            </div>
            <div class="mrcp-bh__score-copy">
                <span>OVERALL BUSINESS HEALTH</span>
                <h3><?php echo esc_html($label); ?></h3>
                <p>This score combines five core business pillars and updates with cached report data.</p>
                <em>Updated <?php echo esc_html($data['generated_at'] ?? wp_date('M j, Y g:i A')); ?></em>
            </div>
        </article>

        <div class="mrcp-bh__forecast-grid">
            <article class="mrcp-bi-card">
                <i>৳</i><span>MONTH REVENUE FORECAST</span>
                <strong><?php echo wp_kses_post($money($forecast['revenue'] ?? 0)); ?></strong>
                <small>Projected at the current daily pace</small>
            </article>
            <article class="mrcp-bi-card">
                <i>▣</i><span>EXPECTED ORDERS</span>
                <strong><?php echo esc_html(number_format_i18n((int) ($forecast['orders'] ?? 0))); ?></strong>
                <small>Projected by month end</small>
            </article>
            <article class="mrcp-bi-card">
                <i><?php echo ($forecast['direction'] ?? 'flat') === 'up' ? '↗' : (($forecast['direction'] ?? 'flat') === 'down' ? '↘' : '→'); ?></i><span>MONTH MOMENTUM</span>
                <strong><?php echo esc_html(number_format_i18n(abs((float) ($forecast['growth'] ?? 0)), 1)); ?>%</strong>
                <small><?php echo esc_html(ucfirst((string) ($forecast['direction'] ?? 'flat'))); ?> vs previous month</small>
            </article>
        </div>
    </div>

    <div class="mrcp-bh__pillars">
        <?php foreach (($health['pillars'] ?? []) as $pillar):
            $pillar_score = (int) ($pillar['score'] ?? 0);
            $pillar_class = $pillar_score >= 85 ? 'excellent' : ($pillar_score >= 70 ? 'healthy' : ($pillar_score >= 55 ? 'stable' : ($pillar_score >= 40 ? 'attention' : 'critical')));
        ?>
            <article class="mrcp-bi-card is-<?php echo esc_attr($pillar_class); ?>">
                <header><span><?php echo esc_html($pillar['label'] ?? 'Pillar'); ?></span><b><?php echo esc_html($pillar_score); ?>/100</b></header>
                <h3><?php echo esc_html($pillar['status'] ?? 'No data'); ?></h3>
                <i><b style="width:<?php echo esc_attr($pillar_score); ?>%"></b></i>
                <small><?php echo esc_html($pillar['detail'] ?? ''); ?></small>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="mrcp-bh__intelligence-grid">
        <article class="mrcp-bi-card mrcp-bh__insights">
            <header><div><span>SMART BUSINESS INSIGHTS</span><h3>What the data says</h3></div></header>
            <?php foreach (($health['insights'] ?? []) as $insight): ?><p><i>✦</i><span><?php echo esc_html($insight); ?></span></p><?php endforeach; ?>
        </article>
        <article class="mrcp-bi-card mrcp-bh__actions">
            <header><div><span>RECOMMENDED ACTIONS</span><h3>What to do next</h3></div></header>
            <?php foreach (($health['actions'] ?? []) as $index => $action): ?><p><b><?php echo esc_html($index + 1); ?></b><span><?php echo esc_html($action); ?></span></p><?php endforeach; ?>
        </article>
    </div>

    <div class="mrcp-bh__risk-grid">
        <article class="mrcp-bi-card is-risk">
            <header><div><span>RISKS & WATCHLIST</span><h3>Items requiring attention</h3></div></header>
            <?php foreach (($health['risks'] ?? []) as $risk): ?><p><i>!</i><span><?php echo esc_html($risk); ?></span></p><?php endforeach; ?>
        </article>
        <article class="mrcp-bi-card is-opportunity">
            <header><div><span>GROWTH OPPORTUNITIES</span><h3>Where to focus next</h3></div></header>
            <?php foreach (($health['opportunities'] ?? []) as $opportunity): ?><p><i>↗</i><span><?php echo esc_html($opportunity); ?></span></p><?php endforeach; ?>
        </article>
        <article class="mrcp-bi-card mrcp-bh__benchmarks">
            <header><div><span>KEY BENCHMARKS</span><h3>Current operating signals</h3></div></header>
            <div><span>Refund Rate</span><strong><?php echo esc_html(number_format_i18n((float) ($health['benchmarks']['refund_rate'] ?? 0), 1)); ?>%</strong></div>
            <div><span>Returning Buyers</span><strong><?php echo esc_html(number_format_i18n((float) ($health['benchmarks']['returning_rate'] ?? 0), 1)); ?>%</strong></div>
            <div><span>Active Customers</span><strong><?php echo esc_html(number_format_i18n((float) ($health['benchmarks']['active_share'] ?? 0), 1)); ?>%</strong></div>
            <div><span>Operations Workload</span><strong><?php echo esc_html(number_format_i18n((int) ($health['benchmarks']['operations_workload'] ?? 0))); ?></strong></div>
        </article>
    </div>

    <div class="mrcp-ri__footer-note"><i>i</i><span>Business Health is a decision-support score, not an accounting measure. Review the underlying Revenue, Products, Customers and Operations tabs before acting.</span></div>
</div>
