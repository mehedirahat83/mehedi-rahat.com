(function(){
  'use strict';
  document.addEventListener('DOMContentLoaded',function(){
    var input=document.getElementById('mrcp-live-search');
    var box=document.getElementById('mrcp-search-results');
    var timer=null;
    var activeIndex=-1;
    var controller=null;
    var cooldownUntil=0;
    if(!input||!box||typeof MRCP_DATA==='undefined') return;

    function escapeHtml(str){
      return String(str||'').replace(/[&<>'"]/g,function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c];
      });
    }

    function render(results){
      if(!results||!results.length){
        box.innerHTML='<div class="mrcp-search-empty">No results found</div>';
        box.classList.add('is-open');
        return;
      }
      box.innerHTML=results.map(function(item){
        return '<a href="'+escapeHtml(item.url)+'" role="option"><span>'+escapeHtml(item.type)+'</span><strong>'+escapeHtml(item.title)+'</strong><small>'+escapeHtml(item.meta)+'</small></a>';
      }).join('');
      activeIndex=-1;
      box.classList.add('is-open');
    }

    input.addEventListener('input',function(){
      var q=input.value.trim();
      window.clearTimeout(timer);
      if(controller){controller.abort();controller=null;}
      if(q.length<2){box.classList.remove('is-open');box.innerHTML='';return;}
      if(Date.now()<cooldownUntil){
        box.innerHTML='<div class="mrcp-search-empty">Search is cooling down. Please wait a moment.</div>';
        box.classList.add('is-open');
        return;
      }
      timer=window.setTimeout(function(){
        var data=new FormData();
        data.append('action','mrcp_search');
        data.append('nonce',MRCP_DATA.nonce);
        data.append('q',q);
        box.innerHTML='<div class="mrcp-search-empty">Searching...</div>';
        box.classList.add('is-open');
        var currentController=new AbortController();
        controller=currentController;
        fetch(MRCP_DATA.ajax_url,{method:'POST',credentials:'same-origin',body:data,signal:currentController.signal})
          .then(function(r){if(r.status===429){cooldownUntil=Date.now()+120000;throw new Error('rate-limited');}if(!r.ok) throw new Error('HTTP '+r.status);return r.json();})
          .then(function(json){
            if(!json||!json.success) throw new Error((json&&json.data&&json.data.message)||'Search failed');
            render((json.data&&json.data.results)||[]);
          })
          .catch(function(error){if(error&&error.name==='AbortError')return;box.innerHTML='<div class="mrcp-search-empty">'+(Date.now()<cooldownUntil?'Search is cooling down. Please wait a moment.':'Search failed. Please try again.')+'</div>';box.classList.add('is-open');})
          .finally(function(){if(controller===currentController)controller=null;});
      },280);
    });

    input.addEventListener('keydown',function(e){
      var links=Array.prototype.slice.call(box.querySelectorAll('a'));
      if(e.key==='ArrowDown'&&links.length){e.preventDefault();activeIndex=Math.min(activeIndex+1,links.length-1);}
      else if(e.key==='ArrowUp'&&links.length){e.preventDefault();activeIndex=Math.max(activeIndex-1,0);}
      else if(e.key==='Enter'&&links.length){e.preventDefault();links[activeIndex>=0?activeIndex:0].click();return;}
      else if(e.key==='Escape'){box.classList.remove('is-open');activeIndex=-1;return;}
      else{return;}
      links.forEach(function(link,index){link.classList.toggle('is-active',index===activeIndex);});
      if(links[activeIndex]) links[activeIndex].scrollIntoView({block:'nearest'});
    });

    document.addEventListener('click',function(e){
      if(!e.target.closest('.mrcp-search')) box.classList.remove('is-open');
    });
  });
})();
