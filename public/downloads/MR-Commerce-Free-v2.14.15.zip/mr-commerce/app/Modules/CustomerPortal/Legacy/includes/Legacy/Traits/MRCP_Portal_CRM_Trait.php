<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait MRCP_Portal_CRM_Trait {
    private function render_support_page() {
        $filter = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : 'all';
        $tickets = $this->tickets(30, $filter);
        $statuses = $this->ticket_statuses();
        echo '<section class="mrcp-module-page mrcp-ticket-page">';
        echo '<div class="mrcp-module-head"><div><span>' . ($this->is_support_admin() ? 'Admin Support Desk' : 'Support Desk') . '</span><h1>Support Tickets</h1><p>' . ($this->is_support_admin() ? 'Open customer tickets and reply directly from the portal.' : 'Create a ticket, track replies, and link requests with your WooCommerce orders.') . '</p></div>' . ($this->is_support_admin() ? '<a href="' . esc_url(admin_url('edit.php?post_type=mrcp_ticket')) . '" target="_blank">WP Admin Tickets</a>' : '<a href="#new-ticket">+ New Ticket</a>') . '</div>';

        echo '<div class="mrcp-ticket-stats">';
        echo '<div><strong>' . esc_html($this->ticket_count('open')) . '</strong><span>Open</span></div>';
        echo '<div><strong>' . esc_html($this->ticket_count('pending')) . '</strong><span>Pending</span></div>';
        echo '<div><strong>' . esc_html($this->ticket_count('answered')) . '</strong><span>Answered</span></div>';
        echo '<div><strong>' . esc_html($this->ticket_count('closed')) . '</strong><span>Closed</span></div>';
        echo '</div>';

        echo '<div class="mrcp-ticket-layout ' . ($this->is_support_admin() ? 'mrcp-admin-full-layout' : '') . '">';
        echo '<div class="mrcp-ticket-list-card">';
        echo '<div class="mrcp-ticket-filter"><a class="' . ($filter === 'all' ? 'is-active' : '') . '" href="' . esc_url($this->support_url()) . '">All</a>';
        foreach ($statuses as $key => $label) echo '<a class="' . ($filter === $key ? 'is-active' : '') . '" href="' . esc_url(add_query_arg('status', $key, $this->support_url())) . '">' . esc_html($label) . '</a>';
        echo '</div>';

        if ($tickets) {
            echo '<div class="mrcp-ticket-table ' . ($this->is_support_admin() ? 'mrcp-admin-support-table' : '') . '">';
            if ($this->is_support_admin()) {
                echo '<div class="mrcp-ticket-row mrcp-support-admin-row is-head"><span>Ticket</span><span>Customer</span><span>Subject</span><span>Status</span><span>Updated</span></div>';
            } else {
                echo '<div class="mrcp-ticket-row is-head"><span>Ticket</span><span>Category</span><span>Status</span><span>Updated</span></div>';
            }
            foreach ($tickets as $ticket) $this->ticket_row($ticket);
            echo '</div>';
        } else {
            $this->empty_state('🎟️', 'No tickets found', 'Create a new support ticket when you need help.');
        }
        echo '</div>';

        if (!$this->is_support_admin()) {
        echo '<form method="post" enctype="multipart/form-data" class="mrcp-new-ticket-card" id="new-ticket">';
        wp_nonce_field('mrcp_create_ticket', 'mrcp_ticket_nonce');
        echo '<input type="hidden" name="mrcp_create_ticket" value="1">';
        echo '<h2>Create New Ticket</h2><p>Tell us what you need help with. Attach screenshots or ZIP files when helpful.</p>';
        echo '<label><span>Subject</span><input name="ticket_subject" required placeholder="Example: Need Elementor Pro activation support"></label>';
        echo '<div class="mrcp-ticket-form-grid">';
        $this->select_field('ticket_category', 'Category', $this->ticket_categories(), 'technical');
        $this->ticket_order_select();
        echo '</div>';
        echo '<label><span>Message</span><textarea name="ticket_message" rows="6" required placeholder="Write your issue details..."></textarea></label>';
        echo '<label><span>Attachment <small>JPG, PNG, PDF, ZIP, TXT</small></span><input type="file" name="ticket_attachment" accept=".jpg,.jpeg,.png,.pdf,.zip,.txt"></label>';
        echo '<button type="submit" class="mrcp-save-btn">Submit Ticket</button>';
        echo '</form>';
        }
        echo '</div></section>';
    }

    private function render_ticket_view_page() {
        $ticket_id = absint(get_query_var('mrcp_ticket_id'));
        $ticket = $this->get_ticket($ticket_id);
        if (!$ticket) {
            echo '<section class="mrcp-module-page">';
            $this->empty_state('🎟️', 'Ticket not available', 'This support ticket could not be found in your account.');
            echo '</section>';
            return;
        }
        $meta = $this->ticket_meta($ticket_id);
        $comments = get_comments(['post_id' => $ticket_id, 'status' => 'approve', 'type' => 'mrcp_ticket_reply', 'order' => 'ASC']);
        echo '<section class="mrcp-ticket-view' . (isset($_GET['mrcp_highlight']) ? ' mrcp-notification-highlight' : '') . '">';
        echo '<div class="mrcp-order-toolbar"><div class="mrcp-toolbar-back-links"><a href="' . esc_url($this->support_url()) . '">← Back to Tickets</a>' . (isset($_GET['mrcp_from_notification']) ? '<a class="mrcp-back-dashboard" href="' . esc_url($this->url('crm')) . '">← Back to CRM Dashboard</a>' : '') . '</div><div><a class="is-primary" href="#reply-ticket">Reply Ticket</a></div></div>';
        echo '<div class="mrcp-ticket-hero"><div><span>Ticket MR-' . esc_html($ticket_id) . '</span><h1>' . esc_html($ticket->post_title) . '</h1><p>Created ' . esc_html(get_the_date('F j, Y', $ticket)) . ' • Updated ' . esc_html(get_the_modified_date('F j, Y', $ticket)) . '</p></div><div class="mrcp-ticket-status-card"><small>Status</small><strong class="ticket-status-' . esc_attr($meta['status']) . '">' . esc_html(ucfirst($meta['status'])) . '</strong></div></div>';
        echo '<div class="mrcp-ticket-view-grid">';
        echo '<div class="mrcp-ticket-thread">';
        $ticket_customer = get_user_by('id', (int) $ticket->post_author);
        echo '<article class="mrcp-ticket-message is-customer"><div><strong>' . esc_html($ticket_customer ? $ticket_customer->display_name : 'Customer') . '</strong><small>' . esc_html(get_the_date('F j, Y g:i A', $ticket)) . '</small></div><p>' . wp_kses_post(wpautop($ticket->post_content)) . '</p>';
        if ($meta['attachment']) echo '<a class="mrcp-attachment" href="' . esc_url($meta['attachment']) . '" target="_blank" rel="noopener">View attachment</a>';
        echo '</article>';
        foreach ($comments as $comment) {
            $is_admin = user_can((int) $comment->user_id, 'manage_options');
            $attachment = get_comment_meta($comment->comment_ID, '_mrcp_reply_attachment', true);
            echo '<article class="mrcp-ticket-message ' . ($is_admin ? 'is-admin' : 'is-customer') . '"><div><strong>' . esc_html($is_admin ? 'Support Team' : $comment->comment_author) . '</strong><small>' . esc_html(get_comment_date('F j, Y g:i A', $comment)) . '</small></div><p>' . wp_kses_post(wpautop($comment->comment_content)) . '</p>';
            if ($attachment) echo '<a class="mrcp-attachment" href="' . esc_url($attachment) . '" target="_blank" rel="noopener">View attachment</a>';
            echo '</article>';
        }
        if ($meta['status'] !== 'closed') {
            echo '<form method="post" enctype="multipart/form-data" class="mrcp-reply-card" id="reply-ticket">';
            wp_nonce_field('mrcp_reply_ticket', 'mrcp_reply_nonce');
            echo '<input type="hidden" name="mrcp_reply_ticket" value="1"><input type="hidden" name="ticket_id" value="' . esc_attr($ticket_id) . '">';
            if ($this->is_support_admin()) {
                echo '<h2>Send Admin Reply</h2><p>This reply will be emailed to the customer and added to their dashboard notification bell.</p><textarea name="reply_message" rows="5" required placeholder="Write your support reply..."></textarea><input type="file" name="reply_attachment" accept=".jpg,.jpeg,.png,.pdf,.zip,.txt"><label class="mrcp-close-after"><input type="checkbox" name="mrcp_close_after_reply" value="1"> Close ticket after this reply</label><button type="submit" class="mrcp-save-btn">Send Reply to Customer</button>';
            } else {
                echo '<h2>Write a Reply</h2><textarea name="reply_message" rows="5" required placeholder="Write your reply..."></textarea><input type="file" name="reply_attachment" accept=".jpg,.jpeg,.png,.pdf,.zip,.txt"><button type="submit" class="mrcp-save-btn">Send Reply</button>';
            }
            echo '</form>';
        } else {
            $this->empty_state('✅', 'Ticket closed', 'This ticket is closed. Create a new ticket if you need further help.');
        }
        echo '</div>';
        echo '<aside class="mrcp-ticket-info">';
        echo '<div><span>Ticket ID</span><strong>MR-' . esc_html($ticket_id) . '</strong></div>';
        echo '<div><span>Status</span><strong class="ticket-status-' . esc_attr($meta['status']) . '">' . esc_html(ucfirst($meta['status'])) . '</strong></div>';
        echo '<div><span>Category</span><strong>' . esc_html(ucfirst($meta['category'])) . '</strong></div>';
        if ($meta['order_id']) echo '<div><span>Related Order</span><strong><a href="' . esc_url($this->order_view_url($meta['order_id'])) . '">#' . esc_html($this->display_order_number($meta['order_id'])) . '</a></strong></div>';
        echo '<div class="mrcp-ticket-help"><h3>Need faster help?</h3><p>Add screenshots, order ID, temporary login details if needed, and exact error message.</p></div>';
        echo '</aside></div></section>';
    }

    private function ticket_row($ticket, $show_category = true) {
        $meta = $this->ticket_meta($ticket->ID);
        $is_admin_table = $show_category && $this->is_support_admin();
        $row_class = $show_category ? 'mrcp-ticket-row' : 'mrcp-ticket-row mrcp-ticket-row-compact';
        if ($is_admin_table) {
            $row_class .= ' mrcp-support-admin-row';
        }
        echo '<a class="' . esc_attr($row_class) . '" href="' . esc_url($this->ticket_url($ticket->ID)) . '">';

        if ($is_admin_table) {
            $customer = get_user_by('id', (int) $ticket->post_author);
            $customer_name = $customer ? $customer->display_name : 'Unknown';
            $customer_email = $customer ? $customer->user_email : '';
            echo '<span class="mrcp-ticket-id"><strong>MR-' . esc_html($ticket->ID) . '</strong><small>' . esc_html(ucfirst($meta['category'])) . '</small></span>';
            echo '<span class="mrcp-ticket-customer"><strong>' . esc_html($customer_name) . '</strong><small>' . esc_html($customer_email) . '</small></span>';
            echo '<span class="mrcp-ticket-subject"><strong>' . esc_html($ticket->post_title) . '</strong><small>Click to open conversation</small></span>';
            echo '<span class="mrcp-ticket-status"><b class="ticket-status-' . esc_attr($meta['status']) . '">' . esc_html(ucfirst($meta['status'])) . '</b></span>';
            echo '<span class="mrcp-ticket-date"><strong>' . esc_html(get_the_modified_date('M j, Y', $ticket)) . '</strong><small>' . esc_html(get_the_modified_date('g:i A', $ticket)) . '</small></span>';
        } else {
            echo '<span class="mrcp-ticket-main"><strong>MR-' . esc_html($ticket->ID) . '</strong><small>' . esc_html($ticket->post_title) . '</small></span>';
            if ($show_category) echo '<span class="mrcp-ticket-category">' . esc_html(ucfirst($meta['category'])) . '</span>';
            echo '<span class="mrcp-ticket-status"><b class="ticket-status-' . esc_attr($meta['status']) . '">' . esc_html(ucfirst($meta['status'])) . '</b></span>';
            echo '<span class="mrcp-ticket-date">' . esc_html(get_the_modified_date('M j, Y', $ticket)) . '</span>';
        }
        echo '</a>';
    }

    private function select_field($name, $label, $options, $selected = '') {
        echo '<label><span>' . esc_html($label) . '</span><select name="' . esc_attr($name) . '">';
        foreach ($options as $key => $value) echo '<option value="' . esc_attr($key) . '" ' . selected($selected, $key, false) . '>' . esc_html($value) . '</option>';
        echo '</select></label>';
    }

    private function ticket_order_select() {
        echo '<label><span>Related Order <small>Optional</small></span><select name="ticket_order_id"><option value="0">No related order</option>';
        foreach ($this->recent_orders(30) as $order) {
            if (!$order || !is_a($order, 'WC_Order')) continue;
            echo '<option value="' . esc_attr($order->get_id()) . '">#' . esc_html($order->get_order_number()) . ' — ' . wp_kses_post($order->get_formatted_order_total()) . '</option>';
        }
        echo '</select></label>';
    }

    private function render_account_page($user, $membership) {
        $user_id = get_current_user_id();
        $wp_user = wp_get_current_user();
        echo '<section class="mrcp-module-page mrcp-profile-page">';
        echo '<div class="mrcp-module-head"><div><span>Profile Settings</span><h1>Account Details</h1><p>Manage your personal information, login email, phone number, and password.</p></div><a href="' . esc_url($this->url()) . '">Back to Dashboard →</a></div>';
        echo '<div class="mrcp-profile-grid">';

        echo '<aside class="mrcp-profile-card">';
        echo '<img src="' . esc_url($user['avatar']) . '" alt="' . esc_attr($user['name']) . '">';
        echo '<h2>' . esc_html($user['name']) . '</h2>';
        echo '<p>' . esc_html($wp_user->user_email) . '</p>';
        if (mrc_can('digital.membership')) {
            echo '<div class="mrcp-profile-badge">' . esc_html($membership['icon'] . ' ' . $membership['name']) . '</div>';
            echo '<dl><div><dt>Member Since</dt><dd>' . esc_html($user['registered']) . '</dd></div><div><dt>Current Discount</dt><dd>' . esc_html($membership['discount']) . '%</dd></div></dl>';
        } else {
            echo '<dl><div><dt>Customer Since</dt><dd>' . esc_html($user['registered']) . '</dd></div></dl>';
        }
        echo '</aside>';

        echo '<form method="post" class="mrcp-form-card">';
        wp_nonce_field('mrcp_update_account', 'mrcp_account_nonce');
        echo '<input type="hidden" name="mrcp_update_account" value="1">';
        echo '<h2>Personal Information</h2><div class="mrcp-form-grid">';
        $this->form_input('first_name', 'First Name', get_user_meta($user_id, 'first_name', true));
        $this->form_input('last_name', 'Last Name', get_user_meta($user_id, 'last_name', true));
        $this->form_input('display_name', 'Display Name', $wp_user->display_name);
        $this->form_input('user_email', 'Email Address', $wp_user->user_email, 'email');
        $this->form_input('billing_phone', 'Phone Number', get_user_meta($user_id, 'billing_phone', true), 'tel');
        echo '</div><h2 class="mrcp-form-subtitle">Change Password</h2><div class="mrcp-form-grid">';
        $this->form_input('password_1', 'New Password', '', 'password', 'Leave blank to keep current password');
        $this->form_input('password_2', 'Confirm Password', '', 'password', 'Repeat new password');
        echo '</div><button type="submit" class="mrcp-save-btn">Save Account Details</button></form>';

        echo '</div></section>';
    }

    private function render_addresses_page($user) {
        echo '<section class="mrcp-module-page mrcp-address-page">';
        echo '<div class="mrcp-module-head"><div><span>Customer Addresses</span><h1>Billing & Shipping Address</h1><p>Keep your billing and shipping information updated for faster checkout and support.</p></div><a href="' . esc_url($this->wc_account_url('edit-address')) . '">WooCommerce Address →</a></div>';
        echo '<form method="post" class="mrcp-address-form">';
        wp_nonce_field('mrcp_update_addresses', 'mrcp_addresses_nonce');
        echo '<input type="hidden" name="mrcp_update_addresses" value="1">';
        echo '<div class="mrcp-address-grid">';
        $this->address_form_card('billing', 'Billing Address', 'Used for invoices and payment verification.');
        $this->address_form_card('shipping', 'Shipping Address', 'Used if you purchase products that require delivery.');
        echo '</div><button type="submit" class="mrcp-save-btn">Save Addresses</button></form>';
        echo '</section>';
    }

    private function render_payment_methods_page() {
        echo '<section class="mrcp-module-page mrcp-payment-page">';
        echo '<div class="mrcp-module-head"><div><span>Saved Payments</span><h1>Payment Methods</h1><p>Manage saved payment methods linked to your WooCommerce account.</p></div><a href="' . esc_url($this->wc_account_url('add-payment-method')) . '">Add Payment Method →</a></div>';
        echo '<div class="mrcp-module-card mrcp-payment-card">';

        if (!$this->wc_active() || !class_exists('WC_Payment_Tokens')) {
            $this->empty_state('💳', 'Payment methods are not available', 'Please enable a WooCommerce payment gateway that supports saved payment methods.');
            echo '</div></section>';
            return;
        }

        $tokens = WC_Payment_Tokens::get_customer_tokens(get_current_user_id());
        if (!$tokens) {
            $this->empty_state('💳', 'No saved payment methods', 'Saved cards or payment methods will appear here after checkout.');
            echo '<div class="mrcp-payment-help"><strong>Want to add one?</strong><p>Use WooCommerce secure checkout or the Add Payment Method page. Your payment details are stored by the payment gateway, not by this website.</p><a href="' . esc_url($this->wc_account_url('add-payment-method')) . '">Add Payment Method</a></div>';
            echo '</div></section>';
            return;
        }

        echo '<div class="mrcp-payment-list">';
        foreach ($tokens as $token) {
            $is_default = method_exists($token, 'is_default') && $token->is_default();
            $type = method_exists($token, 'get_type') ? $token->get_type() : 'payment';
            $display = method_exists($token, 'get_display_name') ? $token->get_display_name() : ucfirst($type);
            echo '<article class="mrcp-payment-method ' . ($is_default ? 'is-default' : '') . '">';
            echo '<div class="mrcp-payment-icon">💳</div><div><h3>' . esc_html($display) . '</h3><p>' . esc_html(ucfirst($type)) . ' payment method</p>' . ($is_default ? '<span>Default Method</span>' : '') . '</div>';
            echo '<div class="mrcp-payment-actions">';
            if (!$is_default) {
                echo '<form method="post">';
                wp_nonce_field('mrcp_payment_action', 'mrcp_payment_nonce');
                echo '<input type="hidden" name="token_id" value="' . esc_attr($token->get_id()) . '"><input type="hidden" name="mrcp_payment_action" value="default"><button type="submit">Make Default</button></form>';
            }
            echo '<form method="post" onsubmit="return confirm(\'Remove this payment method?\');">';
            wp_nonce_field('mrcp_payment_action', 'mrcp_payment_nonce');
            echo '<input type="hidden" name="token_id" value="' . esc_attr($token->get_id()) . '"><input type="hidden" name="mrcp_payment_action" value="delete"><button class="is-danger" type="submit">Remove</button></form>';
            echo '</div></article>';
        }
        echo '</div></div></section>';
    }

    private function form_input($name, $label, $value = '', $type = 'text', $hint = '') {
        echo '<label class="mrcp-field"><span>' . esc_html($label) . '</span><input type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" ' . ($type === 'password' ? 'autocomplete="new-password"' : '') . '>' . ($hint ? '<small>' . esc_html($hint) . '</small>' : '') . '</label>';
    }

    private function address_form_card($type, $title, $desc) {
        echo '<div class="mrcp-address-card"><h2>' . esc_html($title) . '</h2><p>' . esc_html($desc) . '</p><div class="mrcp-form-grid">';
        foreach ($this->address_fields($type) as $key => $label) {
            $value = get_user_meta(get_current_user_id(), $key, true);
            $field_type = strpos($key, 'email') !== false ? 'email' : (strpos($key, 'phone') !== false ? 'tel' : 'text');
            $this->form_input($key, $label, $value, $field_type);
        }
        echo '</div></div>';
    }

    private function crm_total_revenue() {
        if (!$this->wc_active()) return 0;
        $orders = wc_get_orders([
            'limit' => -1,
            'return' => 'ids',
            'status' => ['completed'],
        ]);
        $total = 0;
        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            if ($order) $total += (float) $order->get_total();
        }
        return $total;
    }

    private function crm_sales_analytics() {
        $empty = [
            'today_total'    => 0.0,
            'today_count'    => 0,
            'week_total'     => 0.0,
            'week_count'     => 0,
            'month_total'    => 0.0,
            'month_count'    => 0,
            'lifetime_total' => 0.0,
            'lifetime_count' => 0,
        ];

        if (!$this->wc_active()) {
            return $empty;
        }

        $timezone = wp_timezone();
        $now = new DateTimeImmutable('now', $timezone);
        $today_start = $now->setTime(0, 0, 0);
        $weekly_sales = \MRBP\Services\Analytics::get_weekly_sales();
        $month_start = $today_start->modify('first day of this month');

        $orders = wc_get_orders([
            'limit'   => -1,
            'orderby' => 'date',
            'order'   => 'DESC',
            'status'  => ['completed'],
        ]);

        $stats = $empty;
        $stats['week_total'] = (float) ($weekly_sales['revenue'] ?? 0.0);
        $stats['week_count'] = (int) ($weekly_sales['orders'] ?? 0);

        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }

            $amount = (float) $order->get_total();
            $date = $order->get_date_paid();
            if (!$date) {
                $date = $order->get_date_completed();
            }
            if (!$date) {
                $date = $order->get_date_created();
            }

            $stats['lifetime_total'] += $amount;
            $stats['lifetime_count']++;

            if (!$date) {
                continue;
            }

            $sale_date = (new DateTimeImmutable('@' . $date->getTimestamp()))->setTimezone($timezone);

            if ($sale_date >= $month_start && $sale_date <= $now) {
                $stats['month_total'] += $amount;
                $stats['month_count']++;
            }

            if ($sale_date >= $today_start && $sale_date <= $now) {
                $stats['today_total'] += $amount;
                $stats['today_count']++;
            }
        }

        return $stats;
    }

    private function crm_annual_sales_growth() {
        $timezone = wp_timezone();
        $now = new DateTimeImmutable('now', $timezone);
        $current_month = $now->modify('first day of this month')->setTime(0, 0, 0);
        $first_month = $current_month->modify('-23 months');

        $months = [];
        for ($index = 0; $index < 24; $index++) {
            $start = $first_month->modify('+' . $index . ' months');
            $key = $start->format('Y-m');
            $months[$key] = [
                'key'   => $key,
                'label' => wp_date('M', $start->getTimestamp(), $timezone),
                'year'  => wp_date('Y', $start->getTimestamp(), $timezone),
                'total' => 0.0,
                'count' => 0,
            ];
        }

        if ($this->wc_active()) {
            $orders = wc_get_orders([
                'limit'   => -1,
                'orderby' => 'date',
                'order'   => 'DESC',
                'status'  => ['completed'],
            ]);

            foreach ($orders as $order) {
                if (!$order instanceof WC_Order) {
                    continue;
                }

                $date = $order->get_date_paid();
                if (!$date) {
                    $date = $order->get_date_completed();
                }
                if (!$date) {
                    $date = $order->get_date_created();
                }
                if (!$date) {
                    continue;
                }

                $sale_date = (new DateTimeImmutable('@' . $date->getTimestamp()))->setTimezone($timezone);
                if ($sale_date < $first_month || $sale_date > $now) {
                    continue;
                }

                $key = $sale_date->format('Y-m');
                if (isset($months[$key])) {
                    $months[$key]['total'] += (float) $order->get_total();
                    $months[$key]['count']++;
                }
            }
        }

        $months = array_values($months);
        $total = array_sum(array_column($months, 'total'));
        $max = 0.0;
        $highest = null;
        foreach ($months as $month) {
            if ($month['total'] >= $max) {
                $max = (float) $month['total'];
                $highest = $month;
            }
        }

        return [
            'months'  => $months,
            'total'   => $total,
            'average' => $total / 24,
            'max'     => $max,
            'highest' => $highest,
        ];
    }

    private function crm_customer_count() {
        $counts = count_users();
        $roles = isset($counts['avail_roles']) ? $counts['avail_roles'] : [];
        if (isset($roles['customer'])) return (int) $roles['customer'];
        return (int) $counts['total_users'];
    }

    private function crm_order_count() {
        if (!$this->wc_active()) return 0;
        return count(wc_get_orders([
            'limit' => -1,
            'return' => 'ids',
            'status' => array_keys(wc_get_order_statuses()),
        ]));
    }

    private function crm_pending_ticket_count() {
        return count(get_posts([
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'fields' => 'ids',
            'numberposts' => -1,
            'meta_query' => [[
                'key' => '_mrcp_ticket_status',
                'value' => ['open','pending','customer_replied'],
                'compare' => 'IN',
            ]],
        ]));
    }

    private function crm_latest_orders($limit = 5) {
        if (!$this->wc_active()) return [];
        return wc_get_orders([
            'limit' => max(1, (int) $limit),
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array_keys(wc_get_order_statuses()),
        ]);
    }

    private function crm_latest_tickets($limit = 5) {
        return get_posts([
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'numberposts' => $limit,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);
    }

    private function crm_latest_activations($limit = 5) {
        return get_posts([
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'numberposts' => $limit,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);
    }

    private function crm_membership_summary() {
        $summary = [
            'silver' => ['icon' => '🥈', 'label' => 'Silver', 'count' => 0],
            'gold' => ['icon' => '🥇', 'label' => 'Gold', 'count' => 0],
            'diamond' => ['icon' => '💎', 'label' => 'Diamond', 'count' => 0],
            'vip' => ['icon' => '👑', 'label' => 'VIP', 'count' => 0],
        ];
        $users = get_users(['role__in' => ['customer','subscriber'], 'fields' => ['ID'], 'number' => 500]);
        foreach ($users as $user) {
            $spent = function_exists('wc_get_customer_total_spent') ? (float) wc_get_customer_total_spent($user->ID) : 0;
            $membership = class_exists('MRCP_Membership') ? MRCP_Membership::resolve_by_spend($spent, $user->ID) : $this->membership_data($spent);
            $key = isset($membership['key']) ? $membership['key'] : 'silver';
            if (!isset($summary[$key])) $key = 'silver';
            $summary[$key]['count']++;
        }
        return $summary;
    }

    private function crm_top_selling_products($limit = 5) {
        if (class_exists('\MRCP\Services\ProductIntelligenceService')) {
            return \MRCP\Services\ProductIntelligenceService::get_top(max(1, (int) $limit));
        }
        return [];
    }

    public function clear_lifetime_product_analytics_cache(...$args) {
        if (class_exists('\MRCP\Services\ProductIntelligenceService')) {
            \MRCP\Services\ProductIntelligenceService::clear_cache();
            return;
        }
        for ($limit = 1; $limit <= 20; $limit++) {
            delete_transient('mrcp_lifetime_top_products_v1424_' . $limit);
            delete_transient('mrcp_lifetime_top_products_v1422_' . $limit);
            delete_transient('mrcp_crm_top_products_' . $limit);
        }
    }

    private function crm_top_customers($limit = 5) {
        $users = get_users(['role__in' => ['customer','subscriber'], 'fields' => ['ID','display_name','user_email'], 'number' => 2000]);
        $rows = [];
        foreach ($users as $user) {
            $spent = function_exists('wc_get_customer_total_spent') ? (float) wc_get_customer_total_spent($user->ID) : 0;
            if ($spent <= 0) continue;
            $membership = class_exists('MRCP_Membership') ? MRCP_Membership::resolve_by_spend($spent, $user->ID) : $this->membership_data($spent);
            $rows[] = [
                'id' => $user->ID,
                'name' => $user->display_name ?: $user->user_email,
                'email' => $user->user_email,
                'spent' => $spent,
                'orders' => function_exists('wc_get_customer_order_count') ? (int) wc_get_customer_order_count($user->ID) : 0,
                'membership' => $membership,
            ];
        }
        usort($rows, function($a, $b){ return $b['spent'] <=> $a['spent']; });
        return array_slice($rows, 0, $limit);
    }

    private function crm_profit_analytics(): array {
        if (!function_exists('wc_get_orders')) {
            return ['orders' => 0, 'units' => 0, 'refunds' => 0.0, 'net' => 0.0, 'cost' => 0.0, 'profit' => 0.0, 'margin' => 0.0];
        }

        $cache_key = 'mrcp_profit_analytics_v1';
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            return $cached;
        }

        $revenue = 0.0;
        $refunds = 0.0;
        $cost = 0.0;
        $units = 0;
        $order_count = 0;
        $page = 1;

        do {
            $result = wc_get_orders([
                'limit' => 100,
                'page' => $page,
                'paginate' => true,
                'status' => ['processing', 'completed', 'mrc-delivered'],
                'date_created' => '>' . gmdate('Y-m-d', strtotime('-30 days')),
            ]);
            $orders = is_object($result) && isset($result->orders) ? $result->orders : [];
            foreach ($orders as $order) {
                $order_count++;
                $revenue += (float) $order->get_total();
                $refunds += (float) $order->get_total_refunded();
                foreach ($order->get_items() as $item) {
                    $product_id = $item->get_variation_id() ?: $item->get_product_id();
                    $quantity = (int) $item->get_quantity();
                    $units += $quantity;
                    $cost += (float) get_post_meta($product_id, '_mrc_purchase_cost', true) * $quantity;
                }
            }
            $max_pages = is_object($result) && isset($result->max_num_pages) ? (int) $result->max_num_pages : 1;
            $page++;
        } while ($page <= $max_pages);

        $net = $revenue - $refunds;
        $profit = $net - $cost;

        $analytics = [
            'orders' => $order_count,
            'units' => $units,
            'refunds' => $refunds,
            'net' => $net,
            'cost' => $cost,
            'profit' => $profit,
            'margin' => $net > 0 ? ($profit / $net) * 100 : 0.0,
        ];
        set_transient($cache_key, $analytics, 5 * MINUTE_IN_SECONDS);

        return $analytics;
    }

    private function render_frontend_crm_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view the CRM Dashboard.</p></section>';
            return;
        }

        $membership_enabled  = mrc_can('digital.membership');
        $activation_enabled  = mrc_can('digital.activation_requests');
        $support_enabled     = mrc_can('digital.support_tickets');
        $customers           = $this->crm_customer_count();
        $orders_count        = $this->crm_order_count();
        $revenue             = $this->crm_total_revenue();
        $customer_stats      = $membership_enabled ? $this->crm_customers_stats() : [];
        $sales_stats         = $this->crm_sales_analytics();
        $profit_stats        = mrc_can('analytics.profit') ? $this->crm_profit_analytics() : [];
        $annual_sales        = $this->crm_annual_sales_growth();
        $activation_pending  = $activation_enabled ? $this->activation_admin_count('pending') : 0;
        $activation_progress = $activation_enabled ? $this->activation_admin_count('in_progress') : 0;
        $activation_done     = $activation_enabled ? $this->activation_admin_count('completed') : 0;
        $activation_rejected = $activation_enabled ? $this->activation_admin_count('rejected') : 0;
        $activation_total    = $activation_pending + $activation_progress + $activation_done + $activation_rejected;

        $ticket_open     = $support_enabled ? $this->ticket_count('open') : 0;
        $ticket_pending  = $support_enabled ? $this->ticket_count('pending') : 0;
        $ticket_answered = $support_enabled ? $this->ticket_count('answered') : 0;
        $ticket_closed   = $support_enabled ? $this->ticket_count('closed') : 0;
        $ticket_total    = $ticket_open + $ticket_pending + $ticket_answered + $ticket_closed;

        $latest_orders      = $this->crm_latest_orders(3);
        $latest_activations = $activation_enabled ? $this->crm_latest_activations(3) : [];
        $latest_tickets     = $support_enabled ? $this->crm_latest_tickets(3) : [];
        $top_customers      = $this->crm_top_customers(3);
        $top_products       = $this->crm_top_selling_products(5);

        $products_count = 0;
        if (post_type_exists('product')) {
            $product_counts = wp_count_posts('product');
            $products_count = isset($product_counts->publish) ? (int) $product_counts->publish : 0;
        }
        ?>
        <?php
        $current_user = wp_get_current_user();
        $hour = (int) wp_date('G');
        $greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
        $display_name = $current_user && $current_user->exists() ? $current_user->display_name : 'Administrator';
        ?>
        <section class="mrcp-v12-welcome">
            <div class="mrcp-v12-welcome-copy">
                <span class="mrcp-v12-kicker">Welcome</span>
                <h1><?php echo esc_html($greeting . ', ' . $display_name); ?> 👋</h1>
                <p>Here is a clear snapshot of your sales, customers, operations and recent activity.</p>
            </div>
            <div class="mrcp-v12-welcome-meta">
                <span><?php echo esc_html(wp_date('l')); ?></span>
                <strong><?php echo esc_html(wp_date('M j, Y')); ?></strong>
            </div>
        </section>

        <div class="mrcp-v12-section-head"><div><span>Sales Analytics</span><h2>Revenue performance</h2></div><p>Today, this week, this month and lifetime sales.</p></div>
        <section class="mrcp-crm-v103-kpis mrcp-crm-dashboard-top-stats mrcp-sales-analytics-cards" aria-label="Sales analytics">
            <article class="is-today">
                <span aria-hidden="true">💳</span>
                <div>
                    <small>Today's Sales</small>
                    <strong><?php echo esc_html($this->money($sales_stats['today_total'])); ?></strong>
                    <em><?php echo esc_html(sprintf(_n('%s completed order today', '%s completed orders today', $sales_stats['today_count'], 'mr-customer-portal-pro'), number_format_i18n($sales_stats['today_count']))); ?></em>
                </div>
            </article>
            <article class="is-week">
                <span aria-hidden="true">📈</span>
                <div>
                    <small>This Week's Sales</small>
                    <strong><?php echo esc_html($this->money($sales_stats['week_total'])); ?></strong>
                    <em><?php echo esc_html(sprintf(_n('%s completed order this week', '%s completed orders this week', $sales_stats['week_count'], 'mr-customer-portal-pro'), number_format_i18n($sales_stats['week_count']))); ?></em>
                </div>
            </article>
            <article class="is-month">
                <span aria-hidden="true">📅</span>
                <div>
                    <small>This Month's Sales</small>
                    <strong><?php echo esc_html($this->money($sales_stats['month_total'])); ?></strong>
                    <em><?php echo esc_html(sprintf(_n('%s completed order this month', '%s completed orders this month', $sales_stats['month_count'], 'mr-customer-portal-pro'), number_format_i18n($sales_stats['month_count']))); ?></em>
                </div>
            </article>
            <article class="is-lifetime">
                <span aria-hidden="true">🏆</span>
                <div>
                    <small>Lifetime Sales</small>
                    <strong><?php echo esc_html($this->money($sales_stats['lifetime_total'])); ?></strong>
                    <em><?php echo esc_html(sprintf(_n('%s completed order overall', '%s completed orders overall', $sales_stats['lifetime_count'], 'mr-customer-portal-pro'), number_format_i18n($sales_stats['lifetime_count']))); ?></em>
                </div>
            </article>
        </section>

        <?php if (mrc_can('analytics.profit')) : ?>
        <div class="mrcp-v12-section-head"><div><span>Financial Intelligence</span><h2>Profit Analytics</h2></div><p>Revenue, cost, refunds and estimated gross profit for the last 30 days.</p></div>
        <section class="mrcp-crm-v103-kpis mrcp-profit-analytics-cards" aria-label="Profit analytics">
            <article class="is-net-revenue"><span aria-hidden="true">💳</span><div><small>Net Revenue</small><strong><?php echo esc_html($this->money($profit_stats['net'])); ?></strong><em>After refunds</em></div></article>
            <article class="is-product-cost"><span aria-hidden="true">📦</span><div><small>Product Cost</small><strong><?php echo esc_html($this->money($profit_stats['cost'])); ?></strong><em>Recorded purchase cost</em></div></article>
            <article class="is-gross-profit"><span aria-hidden="true">📈</span><div><small>Gross Profit</small><strong><?php echo esc_html($this->money($profit_stats['profit'])); ?></strong><em>Net revenue minus cost</em></div></article>
            <article class="is-profit-margin"><span aria-hidden="true">%</span><div><small>Profit Margin</small><strong><?php echo esc_html(number_format_i18n($profit_stats['margin'], 1) . '%'); ?></strong><em><?php echo esc_html(sprintf('%d orders · %d units', $profit_stats['orders'], $profit_stats['units'])); ?></em></div></article>
        </section>
        <?php endif; ?>

        <?php if ($membership_enabled) : ?>
        <div class="mrcp-v12-section-head"><div><span>Customers</span><h2>Membership overview</h2></div><a href="<?php echo esc_url($this->url('crm/customers')); ?>">View all customers →</a></div>
        <section class="mrcp-crm-v103-kpis mrcp-membership-tier-kpis mrcp-crm-dashboard-membership-stats" aria-label="Membership statistics">
            <article class="is-silver"><span>🥈</span><div><small>Silver Members</small><strong><?php echo esc_html(number_format_i18n($customer_stats['silver_members'])); ?></strong><em><?php echo esc_html($customer_stats['total_customers'] > 0 ? number_format_i18n(($customer_stats['silver_members'] / $customer_stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
            <article class="is-gold"><span>🥇</span><div><small>Gold Members</small><strong><?php echo esc_html(number_format_i18n($customer_stats['gold_members'])); ?></strong><em><?php echo esc_html($customer_stats['total_customers'] > 0 ? number_format_i18n(($customer_stats['gold_members'] / $customer_stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
            <article class="is-diamond"><span>💎</span><div><small>Diamond Members</small><strong><?php echo esc_html(number_format_i18n($customer_stats['diamond_members'])); ?></strong><em><?php echo esc_html($customer_stats['total_customers'] > 0 ? number_format_i18n(($customer_stats['diamond_members'] / $customer_stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
            <article class="is-vip"><span>👑</span><div><small>VIP Members</small><strong><?php echo esc_html(number_format_i18n($customer_stats['vip_members'])); ?></strong><em><?php echo esc_html($customer_stats['total_customers'] > 0 ? number_format_i18n(($customer_stats['vip_members'] / $customer_stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
        </section>

        <?php endif; ?>

        <?php if ($activation_enabled || $support_enabled) : ?>
        <div class="mrcp-v12-section-head"><div><span>Operations</span><h2>Activation & support</h2></div><p>Monitor requests and customer service workload.</p></div>
        <section class="mrcp-crm-v1152-workload" aria-label="Workload overview">
            <?php if ($activation_enabled) : ?><article class="mrcp-crm-v1152-work-card">
                <header><h2>Activation Requests</h2><em class="mrcp-crm-v1152-count"><?php echo esc_html(number_format_i18n($activation_total)); ?></em></header>
                <div class="mrcp-crm-v1152-work-body">
                    <div class="mrcp-crm-v1152-total"><span class="mrcp-crm-v1152-icon">🔧</span><div><strong><?php echo esc_html(number_format_i18n($activation_total)); ?></strong><small>Total Requests</small></div></div>
                    <ul class="mrcp-crm-v1152-statuses">
                        <li><i class="mrcp-crm-v1152-dot" style="background:#f59e0b"></i><span>Pending</span><b><?php echo esc_html(number_format_i18n($activation_pending)); ?></b></li>
                        <li><i class="mrcp-crm-v1152-dot" style="background:#2196f3"></i><span>In Progress</span><b><?php echo esc_html(number_format_i18n($activation_progress)); ?></b></li>
                        <li><i class="mrcp-crm-v1152-dot" style="background:#22c55e"></i><span>Completed</span><b><?php echo esc_html(number_format_i18n($activation_done)); ?></b></li>
                    </ul>
                </div>
                <a href="<?php echo esc_url($this->url('activation')); ?>">View All Activation Requests →</a>
            </article><?php endif; ?>
            <?php if ($support_enabled) : ?><article class="mrcp-crm-v1152-work-card">
                <header><h2>Support Tickets</h2><em class="mrcp-crm-v1152-count"><?php echo esc_html(number_format_i18n($ticket_total)); ?></em></header>
                <div class="mrcp-crm-v1152-work-body">
                    <div class="mrcp-crm-v1152-total"><span class="mrcp-crm-v1152-icon" style="background:#fff0f1">🎧</span><div><strong style="color:#ef3340!important"><?php echo esc_html(number_format_i18n($ticket_total)); ?></strong><small>Total Tickets</small></div></div>
                    <ul class="mrcp-crm-v1152-statuses">
                        <li><i class="mrcp-crm-v1152-dot" style="background:#ef3340"></i><span>Open</span><b><?php echo esc_html(number_format_i18n($ticket_open)); ?></b></li>
                        <li><i class="mrcp-crm-v1152-dot" style="background:#8b5cf6"></i><span>Waiting Reply</span><b><?php echo esc_html(number_format_i18n($ticket_pending)); ?></b></li>
                        <li><i class="mrcp-crm-v1152-dot" style="background:#94a3b8"></i><span>Closed</span><b><?php echo esc_html(number_format_i18n($ticket_closed)); ?></b></li>
                    </ul>
                </div>
                <a href="<?php echo esc_url($this->url('support')); ?>">View All Support Tickets →</a>
            </article><?php endif; ?>
        </section>

        <?php endif; ?>

        <section class="mrcp-crm-v1152-latest" aria-label="Latest CRM activity">
            <article class="mrcp-crm-v1152-latest-card">
                <header><h3>Latest Orders</h3><a href="<?php echo esc_url($this->url('crm/orders')); ?>">View all →</a></header>
                <div class="mrcp-crm-v1152-feed">
                    <?php if ($latest_orders) : foreach ($latest_orders as $latest_order) :
                        if (!$latest_order instanceof WC_Order) continue;
                        $order_customer = trim($latest_order->get_formatted_billing_full_name());
                        if (!$order_customer) $order_customer = $latest_order->get_billing_email();
                        $order_thumb = $this->order_thumbnail_data($latest_order);
                        $order_date = $latest_order->get_date_created() ? $latest_order->get_date_created()->date_i18n('M j, Y') : '';
                        $order_meta = $order_thumb['name'];
                        if ($order_thumb['more'] > 0) $order_meta .= ' +' . $order_thumb['more'] . ' more';
                        if ($order_date) $order_meta .= ' • ' . $order_date;
                    ?>
                        <a class="mrcp-crm-v1152-feed-item" href="<?php echo esc_url(home_url('/dashboard/crm/order/' . $latest_order->get_id() . '/')); ?>">
                            <span class="mrcp-crm-v1152-feed-icon mrcp-order-feed-thumb"><img src="<?php echo esc_url($order_thumb['url']); ?>" alt="<?php echo esc_attr($order_thumb['name']); ?>" loading="lazy"></span>
                            <span class="mrcp-crm-v1152-feed-copy"><strong>#<?php echo esc_html($latest_order->get_order_number()); ?> — <?php echo esc_html($order_customer ?: 'Guest Customer'); ?></strong><small><?php echo esc_html($order_meta); ?></small></span>
                            <span class="mrcp-crm-v1152-badge"><?php echo esc_html($this->money((float) $latest_order->get_total())); ?></span>
                        </a>
                    <?php endforeach; else : ?><div class="mrcp-crm-v1152-empty">No recent orders found.</div><?php endif; ?>
                </div>
            </article>

            <?php if (mrc_can('digital.activation_requests')) : ?>
            <article class="mrcp-crm-v1152-latest-card">
                <header><h3>Latest Activation Requests</h3><a href="<?php echo esc_url($this->url('activation')); ?>">View all →</a></header>
                <div class="mrcp-crm-v1152-feed">
                    <?php if ($latest_activations) : foreach ($latest_activations as $activation_post) :
                        $act_status = (string) get_post_meta($activation_post->ID, '_mrcp_activation_status', true);
                        if (!$act_status) $act_status = (string) get_post_meta($activation_post->ID, '_mrcp_status', true);
                        $act_product = (string) get_post_meta($activation_post->ID, '_mrcp_product', true);
                        $act_domain = (string) get_post_meta($activation_post->ID, '_mrcp_domain', true);
                    ?>
                        <a class="mrcp-crm-v1152-feed-item" href="<?php echo esc_url($this->activation_url($activation_post->ID)); ?>">
                            <span class="mrcp-crm-v1152-feed-icon">🔑</span>
                            <span class="mrcp-crm-v1152-feed-copy"><strong>ACT-<?php echo esc_html($activation_post->ID); ?> — <?php echo esc_html($act_product ?: get_the_title($activation_post)); ?></strong><small><?php echo esc_html($act_domain ?: get_the_modified_date('M j, Y', $activation_post)); ?></small></span>
                            <span class="mrcp-crm-v1152-badge"><?php echo esc_html(ucwords(str_replace('_',' ', $act_status ?: 'pending'))); ?></span>
                        </a>
                    <?php endforeach; else : ?><div class="mrcp-crm-v1152-empty">No activation requests found.</div><?php endif; ?>
                </div>
            </article>
            <?php endif; ?>

            <?php if (mrc_can('digital.support_tickets')) : ?>
            <article class="mrcp-crm-v1152-latest-card">
                <header><h3>Latest Support Tickets</h3><a href="<?php echo esc_url($this->url('support')); ?>">View all →</a></header>
                <div class="mrcp-crm-v1152-feed">
                    <?php if ($latest_tickets) : foreach ($latest_tickets as $ticket_post) :
                        $ticket_status = (string) get_post_meta($ticket_post->ID, '_mrcp_ticket_status', true);
                        $ticket_subject = (string) get_post_meta($ticket_post->ID, '_mrcp_ticket_subject', true);
                        if (!$ticket_subject) $ticket_subject = get_the_title($ticket_post);
                    ?>
                        <a class="mrcp-crm-v1152-feed-item" href="<?php echo esc_url($this->ticket_url($ticket_post->ID)); ?>">
                            <span class="mrcp-crm-v1152-feed-icon" style="background:#fff0f1">🎫</span>
                            <span class="mrcp-crm-v1152-feed-copy"><strong>MR-<?php echo esc_html($ticket_post->ID); ?> — <?php echo esc_html($ticket_subject); ?></strong><small>Updated <?php echo esc_html(get_the_modified_date('M j, Y', $ticket_post)); ?></small></span>
                            <span class="mrcp-crm-v1152-badge"><?php echo esc_html(ucwords(str_replace('_',' ', $ticket_status ?: 'open'))); ?></span>
                        </a>
                    <?php endforeach; else : ?><div class="mrcp-crm-v1152-empty">No support tickets found.</div><?php endif; ?>
                </div>
            </article>
            <?php endif; ?>
        </section>

        <div class="mrcp-v12-section-head"><div><span>Top Customers</span><h2>Customer leaderboard</h2></div><p>Your three highest-spending customers.</p></div>
        <section class="mrcp-crm-v116-top-customers" aria-label="Top customers">
            <div class="mrcp-crm-v116-top-head">
                <div>
                    <h2>🏆 Top Customers</h2>
                    <p>Highest-spending customers based on completed WooCommerce orders.</p>
                </div>
                <a href="<?php echo esc_url($this->url('crm/customers')); ?>">View all customers →</a>
            </div>
            <?php if ($top_customers) : ?>
                <div class="mrcp-crm-v116-table-wrap">
                    <table class="mrcp-crm-v116-table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Customer</th>
                                <th>Orders</th>
                                <th>Total Spent</th>
                                <?php if (mrc_can('digital.membership')) : ?><th>Membership</th><?php endif; ?>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_customers as $top_index => $top_customer) :
                                $membership = is_array($top_customer['membership']) ? $top_customer['membership'] : [];
                                $member_key = !empty($membership['key']) ? sanitize_key($membership['key']) : 'silver';
                                $member_label = !empty($membership['label']) ? $membership['label'] : ucfirst($member_key);
                                $member_icon = ['silver'=>'🥈','gold'=>'🥇','diamond'=>'💎','vip'=>'👑'][$member_key] ?? '🥈';
                                $rank = (int) $top_index + 1;
                                $rank_icon = [1=>'🥇',2=>'🥈',3=>'🥉'][$rank] ?? '🏅';
                            ?>
                                <tr>
                                    <td><span class="mrcp-crm-v116-rank rank-<?php echo esc_attr($rank); ?>"><?php echo esc_html($rank_icon . ' TOP ' . $rank); ?></span></td>
                                    <td>
                                        <div class="mrcp-crm-v116-customer">
                                            <?php echo get_avatar((int) $top_customer['id'], 46, '', $top_customer['name'], ['loading'=>'lazy']); ?>
                                            <div><strong><?php echo esc_html($top_customer['name']); ?></strong></div>
                                        </div>
                                    </td>
                                    <td><span class="mrcp-crm-v116-orders">🛒 <?php echo esc_html(number_format_i18n((int) $top_customer['orders'])); ?> Orders</span></td>
                                    <td><span class="mrcp-crm-v116-money"><?php echo esc_html($this->money((float) $top_customer['spent'])); ?></span></td>
                                    <?php if (mrc_can('digital.membership')) : ?><td><span class="mrcp-crm-v116-membership is-<?php echo esc_attr($member_key); ?>"><?php echo esc_html($member_icon . ' ' . $member_label); ?></span></td><?php endif; ?>
                                    <td><a class="mrcp-crm-v116-view" href="<?php echo esc_url($this->url('crm/customers/' . (int) $top_customer['id'])); ?>">View Profile</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else : ?>
                <div class="mrcp-crm-v116-empty">No customer spending data found yet.</div>
            <?php endif; ?>
        </section>

        <div class="mrcp-v12-section-head"><div><span>Lifetime Analytics</span><h2>Lifetime best-selling products</h2></div><p>Your five strongest products across all paid orders.</p></div>
        <section class="mrcp-v1252-top-products" aria-label="Top selling products">
            <div class="mrcp-v1252-products-head">
                <div>
                    <h2>🏆 Lifetime Top Selling Products</h2>
                    <p>Parent-level intelligence combining every variation, net revenue, customers, domains and average selling price.</p>
                </div>
                <a href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>">View all products →</a>
            </div>

            <?php if ($top_products) : ?>
                <div class="mrcp-v1252-product-grid">
                    <?php foreach ($top_products as $index => $product_row) :
                        $rank = (int) $index + 1;
                        $rank_icon = [1 => '🥇', 2 => '🥈', 3 => '🥉'][$rank] ?? '🏅';
                        $variation_count = isset($product_row['variation_count']) ? (int) $product_row['variation_count'] : 0;
                        $variation_label = $variation_count > 0
                            ? sprintf(_n('%s Variation', '%s Variations', $variation_count, 'mr-customer-portal-pro'), number_format_i18n($variation_count))
                            : __('Simple Product', 'mr-customer-portal-pro');
                        $customer_count = isset($product_row['customer_count']) ? (int) $product_row['customer_count'] : 0;
                        $domain_count = isset($product_row['active_domain_count']) ? (int) $product_row['active_domain_count'] : 0;
                    ?>
                        <article class="mrcp-v1252-product-card mrcp-v174-product-card rank-<?php echo esc_attr($rank); ?>">
                            <div class="mrcp-v1252-product-rank"><?php echo esc_html($rank_icon . ' #' . $rank); ?></div>
                            <img src="<?php echo esc_url($product_row['image']); ?>" alt="<?php echo esc_attr($product_row['name']); ?>" loading="lazy">
                            <div class="mrcp-v1252-product-copy">
                                <strong title="<?php echo esc_attr($product_row['name']); ?>"><?php echo esc_html($product_row['name']); ?></strong>
                                <span class="mrcp-v174-variation-badge"><?php echo esc_html($variation_label); ?></span>
                                <small>All variation sales combined under the parent product.</small>
                            </div>
                            <div class="mrcp-v174-product-stats">
                                <div class="mrcp-v1252-product-metric">
                                    <span>Lifetime Sold</span>
                                    <strong><?php echo esc_html(number_format_i18n((int) $product_row['sold'])); ?></strong>
                                </div>
                                <div class="mrcp-v1252-product-metric revenue">
                                    <span>Lifetime Revenue</span>
                                    <strong><?php echo esc_html($this->money((float) $product_row['revenue'])); ?></strong>
                                </div>
                                <div class="mrcp-v1252-product-metric compact">
                                    <span>Customers</span>
                                    <strong><?php echo esc_html(number_format_i18n($customer_count)); ?></strong>
                                </div>
                                <div class="mrcp-v1252-product-metric compact">
                                    <span>Active Domains</span>
                                    <strong><?php echo esc_html(number_format_i18n($domain_count)); ?></strong>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div class="mrcp-v1252-product-empty">No paid product sales found yet.</div>
            <?php endif; ?>
        </section>

        <div class="mrcp-v12-section-head"><div><span>Revenue Analytics</span><h2>Two-year selling growth</h2></div><p>Monthly performance across the last 24 months.</p></div>
        <section class="mrcp-crm-v117-growth" aria-label="Annual sales growth">
            <div class="mrcp-crm-v117-head">
                <div>
                    <h2>📈 Selling Growth — Last 24 Months</h2>
                    <p>Monthly revenue from completed WooCommerce orders.</p>
                </div>
                <div class="mrcp-crm-v117-summary">
                    <span><small>24-Month Revenue</small><strong><?php echo esc_html($this->money((float) $annual_sales['total'])); ?></strong></span>
                    <span><small>Monthly Average</small><strong><?php echo esc_html($this->money((float) $annual_sales['average'])); ?></strong></span>
                    <span><small>Highest Month</small><strong><?php echo esc_html(!empty($annual_sales['highest']) ? $annual_sales['highest']['label'] . ' ' . $annual_sales['highest']['year'] : '—'); ?></strong></span>
                </div>
            </div>
            <div class="mrcp-crm-v117-chart-scroll">
                <div class="mrcp-crm-v117-chart">
                    <?php foreach ($annual_sales['months'] as $growth_month) :
                        $height = $annual_sales['max'] > 0 ? max(2, (($growth_month['total'] / $annual_sales['max']) * 100)) : 2;
                        $is_highest = $annual_sales['max'] > 0 && (float) $growth_month['total'] === (float) $annual_sales['max'];
                        $tooltip = $growth_month['label'] . ' ' . $growth_month['year'] . ': ' . $this->money((float) $growth_month['total']) . ' — ' . number_format_i18n((int) $growth_month['count']) . ' orders';
                    ?>
                        <div class="mrcp-crm-v117-month" title="<?php echo esc_attr($tooltip); ?>">
                            <div class="mrcp-crm-v117-value"><?php echo esc_html($this->money((float) $growth_month['total'])); ?></div>
                            <div class="mrcp-crm-v117-bar-track"><i class="mrcp-crm-v117-bar<?php echo $is_highest ? ' is-highest' : ''; ?>" style="height:<?php echo esc_attr(number_format((float) $height, 2, '.', '')); ?>%"></i></div>
                            <div class="mrcp-crm-v117-label"><span><?php echo esc_html($growth_month['label']); ?></span><small><?php echo esc_html($growth_month['year']); ?></small></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <small class="mrcp-crm-v117-orders">Hover a bar to see revenue and completed-order count for that month.</small>
        </section>

        <div class="mrcp-v12-section-head"><div><span>Quick Actions</span><h2>Move faster</h2></div><p>Jump directly to the most-used CRM actions.</p></div>
        <section class="mrcp-v12-quick-actions" aria-label="Quick actions">
            <a href="<?php echo esc_url(admin_url('user-new.php')); ?>"><span>👤</span><div><strong>Add Customer</strong><small>Create a new WordPress customer account.</small></div><b>→</b></a>
            <a href="<?php echo esc_url($this->url('crm-orders')); ?>"><span>🛒</span><div><strong>Manage Orders</strong><small>Review orders, totals and customer purchases.</small></div><b>→</b></a>
            <a href="<?php echo esc_url($this->url('activation')); ?>"><span>🔑</span><div><strong>Activation Requests</strong><small>Review and update activation requests.</small></div><b>→</b></a>
            <a href="<?php echo esc_url($this->url('support')); ?>"><span>🎫</span><div><strong>Support Tickets</strong><small>Open the support desk and reply to customers.</small></div><b>→</b></a>
        </section>

        <footer class="mrcp-crm-v103-footer">© <?php echo esc_html(gmdate('Y')); ?> Mehedi Rahat - MR Commerce Pro v1.0.0</footer>
        <?php
    }

    private function render_membership_page($user, $membership) {
        $levels = !empty($membership['levels']) && is_array($membership['levels']) ? $membership['levels'] : (class_exists('MRCP_Membership') ? MRCP_Membership::rules() : []);
        $current_key = !empty($membership['key']) ? sanitize_key($membership['key']) : 'silver';
        $next = !empty($membership['next']) && is_array($membership['next']) ? $membership['next'] : null;
        $is_vip = !empty($membership['vip']);
        $progress = isset($membership['progress']) ? max(0, min(100, (int) $membership['progress'])) : 0;
        $spent = isset($membership['spent']) ? (float) $membership['spent'] : 0;
        $needed = isset($membership['needed']) ? (float) $membership['needed'] : 0;
        $member_since = !empty($user['registered']) ? $user['registered'] : '—';
        $updated_raw = get_user_meta(get_current_user_id(), '_mrcp_membership_updated_at', true);
        $updated = $updated_raw ? date_i18n('d M Y', strtotime($updated_raw)) : date_i18n('d M Y');
        $next_label = $is_vip ? 'Highest Level' : (!empty($next['short']) ? $next['short'] : 'Next Level');
        $next_discount = $is_vip ? (int) $membership['discount'] : (!empty($next['discount']) ? (int) $next['discount'] : (int) $membership['discount']);
        $tier_order = array_keys($levels);
        $current_index = array_search($current_key, $tier_order, true);
        ?>
        <div class="mrcp-membership-v13">
            <section class="mrcp-membership-v13-hero">
                <div>
                    <span class="mrcp-membership-v13-eyebrow">Your Membership</span>
                    <h1><?php echo esc_html($membership['name']); ?> <span aria-hidden="true">👑</span></h1>
                    <p>You currently enjoy <strong><?php echo esc_html((int) $membership['discount']); ?>% discount</strong> on all eligible products.</p>
                </div>
                <div class="mrcp-membership-v13-crown" aria-hidden="true">👑</div>
            </section>

            <section class="mrcp-membership-v13-progress-card">
                <div class="mrcp-membership-v13-kpis">
                    <div><span>💼</span><small>Lifetime Spend</small><strong><?php echo esc_html($this->money($spent)); ?></strong></div>
                    <div><span>💎</span><small>Next Level</small><strong><?php echo esc_html($next_label); ?></strong></div>
                    <div><span>📈</span><small><?php echo $is_vip ? 'Membership Status' : 'Remaining to ' . esc_html($next_label); ?></small><strong><?php echo $is_vip ? 'Top Tier' : esc_html($this->money($needed)); ?></strong></div>
                </div>
                <div class="mrcp-membership-v13-progress-meta"><b><?php echo esc_html($membership['short']); ?></b><strong><?php echo esc_html($progress); ?>%</strong><b><?php echo esc_html($next_label); ?></b></div>
                <div class="mrcp-membership-v13-progress"><i style="width:<?php echo esc_attr($progress); ?>%"></i></div>
            </section>

            <section class="mrcp-membership-v13-current-grid">
                <article class="mrcp-membership-v13-current is-<?php echo esc_attr($current_key); ?>">
                    <header><div><span class="mrcp-membership-v13-medal"><?php echo esc_html($membership['icon']); ?></span><h2><?php echo esc_html($membership['name']); ?></h2></div><em>Active Member</em></header>
                    <div class="mrcp-membership-v13-current-stats">
                        <div><small>Current Discount</small><strong><?php echo esc_html((int) $membership['discount']); ?>%</strong></div>
                        <div><small>Lifetime Spend</small><strong><?php echo esc_html($this->money($spent)); ?></strong></div>
                        <div><small>Member Since</small><strong><?php echo esc_html($member_since); ?></strong></div>
                        <div><small>Next Level</small><strong><?php echo esc_html($next_label); ?></strong></div>
                    </div>
                </article>
                <article class="mrcp-membership-v13-next">
                    <span>💎</span><small>Next Level Benefit</small><strong><?php echo esc_html($next_discount); ?>%</strong><p><?php echo $is_vip ? 'You already receive the maximum membership discount.' : 'Discount after reaching ' . esc_html($next_label) . '.'; ?></p><a href="#membership-benefits">View Benefits →</a>
                </article>
            </section>

            <section class="mrcp-membership-v13-roadmap" aria-label="Membership roadmap">
                <?php foreach ($levels as $index_key => $level) :
                    $idx = array_search($index_key, $tier_order, true);
                    $state = $index_key === $current_key ? 'is-current' : (($current_index !== false && $idx < $current_index) ? 'is-complete' : 'is-locked');
                ?>
                    <article class="<?php echo esc_attr($state . ' is-' . $index_key); ?>">
                        <span><?php echo esc_html($level['icon']); ?></span>
                        <h3><?php echo esc_html($level['short']); ?></h3>
                        <p><?php echo esc_html($level['range']); ?></p>
                        <strong><?php echo esc_html((int) $level['discount']); ?>% Discount</strong>
                        <em><?php echo $state === 'is-current' ? 'Your Current Level' : ($state === 'is-complete' ? 'Unlocked' : 'Locked 🔒'); ?></em>
                    </article>
                <?php endforeach; ?>
            </section>

            <section class="mrcp-membership-v13-motivation <?php echo $is_vip ? 'is-vip' : ''; ?>">
                <div><span><?php echo $is_vip ? '🎁' : '🚀'; ?></span><div><strong><?php echo $is_vip ? 'VIP Exclusive Benefits Unlocked' : 'Spend ' . esc_html($this->money($needed)) . ' more to unlock ' . esc_html($next_label) . ' Benefits'; ?></strong><p><?php echo $is_vip ? 'Thank you for being one of our most valuable customers.' : 'Unlock a higher discount, priority support and faster activation.'; ?></p></div></div>
                <a href="<?php echo esc_url(home_url('/shop/')); ?>">Shop Now →</a>
            </section>

            <section class="mrcp-membership-v13-benefits" id="membership-benefits">
                <header><h2>Membership Benefits Comparison</h2><p>Benefits increase automatically as your lifetime completed-order spend grows.</p></header>
                <div class="mrcp-membership-v13-table-wrap"><table>
                    <thead><tr><th>Benefit</th><?php foreach ($levels as $level) : ?><th><?php echo esc_html($level['short']); ?></th><?php endforeach; ?></tr></thead>
                    <tbody>
                        <tr><td>Product Discount</td><?php foreach ($levels as $level) : ?><td><strong><?php echo esc_html((int) $level['discount']); ?>%</strong></td><?php endforeach; ?></tr><tr><td>Faster Activation</td><td>✓</td><td>✓</td><td>✓</td><td>✓</td></tr><tr><td>Priority Support</td><td>—</td><td>✓</td><td>✓</td><td>✓</td></tr><tr><td>Exclusive Offers</td><td>—</td><td>—</td><td>✓</td><td>✓</td></tr>
                    </tbody>
                </table></div>
            </section>

            <section class="mrcp-membership-v13-lower">
                <article class="mrcp-membership-v13-activity"><h2>Membership Activity</h2>
                    <div><span>🥈</span><p><strong>Joined as Silver Member</strong><small><?php echo esc_html($member_since); ?></small></p><b><?php echo esc_html($this->money(0)); ?></b></div>
                    <div><span><?php echo esc_html($membership['icon']); ?></span><p><strong>Current level: <?php echo esc_html($membership['name']); ?></strong><small>Last calculated <?php echo esc_html($updated); ?></small></p><b><?php echo esc_html($this->money($spent)); ?></b></div>
                    <div><span>📈</span><p><strong>Current Lifetime Spend</strong><small>Completed WooCommerce orders only</small></p><b><?php echo esc_html($this->money($spent)); ?></b></div>
                </article>
                <div class="mrcp-membership-v13-benefit-cards">
                    <article><span>🏷️</span><div><h3>Your Current Benefit</h3><p>You are enjoying <?php echo esc_html((int) $membership['discount']); ?>% discount on all eligible products.</p></div></article>
                    <article><span>🛒</span><div><h3>Automatic at Checkout</h3><p>Your membership discount is applied automatically to eligible cart items.</p></div></article>
                </div>
            </section>

            <section class="mrcp-membership-v13-faq"><h2>Frequently Asked Questions</h2><div>
                <details><summary>How is my membership level calculated?</summary><p>It is calculated from your net lifetime spend on completed WooCommerce orders.</p></details>
                <details><summary>Does membership expire?</summary><p>No. Your level remains active unless membership rules or your eligible lifetime spend changes.</p></details>
                <details><summary>Will my level decrease after a refund?</summary><p>Refunded amounts are removed from eligible lifetime spend and may change your level.</p></details>
                <details><summary>When is the discount applied?</summary><p>The discount is applied automatically to eligible products during checkout.</p></details>
                <details><summary>Do guest orders count?</summary><p>Only orders linked to your logged-in customer account are included.</p></details>
                <details><summary>How can I check my lifetime spend?</summary><p>Your live lifetime spend is shown at the top of this page.</p></details>
            </div></section>
        </div>
        <?php
    }

    private function pro_feature_for_section($section) {
        $map = [
            'crm-reports'     => 'crm.advanced_reports',
            'crm-membership'  => 'digital.membership',
            'membership'      => 'digital.membership',
            'support'         => 'digital.support_tickets',
            'ticket'          => 'digital.support_tickets',
            'ticket-view'     => 'digital.support_tickets',
            'activation'      => 'digital.activation_requests',
            'activation-view' => 'digital.activation_requests',
        ];
        $feature = isset($map[$section]) ? $map[$section] : '';
        return $feature && (!function_exists('mrc_can') || !mrc_can($feature)) ? $feature : '';
    }

    private function render_pro_feature_page($feature) {
        $titles = [
            'crm.advanced_reports'        => 'Advanced Business Reports',
            'digital.membership'          => 'Membership',
            'digital.support_tickets'     => 'Support Tickets',
            'digital.activation_requests' => 'Activation Requests',
        ];
        $title = isset($titles[$feature]) ? $titles[$feature] : 'Pro Feature';
        $url = class_exists('\MRBP\Admin\ProFeature') ? \MRBP\Admin\ProFeature::upgrade_url() : 'https://mehedirahat.com/mr-commerce-pro/';
        echo '<section class="mrcp-panel"><div class="mrcp-panel-head"><h2>' . esc_html($title) . ' <span class="mrbp-ui-badge">PRO</span></h2></div>';
        echo '<div style="padding:28px"><p>' . esc_html__('This Digital Products capability is available in MR Commerce Pro. Existing settings and records remain preserved in Free mode.', 'mr-commerce') . '</p>';
        echo '<a class="mrcp-button" href="' . esc_url($url) . '">' . esc_html__('Upgrade or activate Pro', 'mr-commerce') . '</a></div></section>';
    }

    public function render_portal() {
        if (!get_query_var('mrcp_dashboard')) return;

        if (!is_user_logged_in()) {
            wp_safe_redirect(wp_login_url(home_url('/dashboard/')));
            exit;
        }

        nocache_headers();
        $user = $this->current_user_data();
        $stats = $this->stats();
        $membership = $this->membership_data($stats['total_spent']);
        $orders = $this->recent_orders(3);
        $downloads = $this->downloads(3);
        $section = get_query_var('mrcp_section') ?: 'dashboard';
        $locked_feature = $this->pro_feature_for_section($section);
        if (!$locked_feature) {
            $this->process_form_actions($section);
        }
        // Refresh user/stats after possible form updates.
        $user = $this->current_user_data();
        $stats = $this->stats();
        $membership = $this->membership_data($stats['total_spent']);
        status_header(200);
        ?>
        <!doctype html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <?php wp_head(); ?>
        </head>
        <body <?php body_class('mrcp-body' . ('crm-reports' === $section ? ' mrcp-reports-page' : '')); ?>>
        <?php wp_body_open(); ?>
        <main class="mrcp-app" aria-label="Customer Dashboard">
            <aside class="mrcp-sidebar <?php echo (in_array($section, ['crm','crm-customers','crm-customer-profile','crm-customer-orders','crm-orders','crm-order-view','crm-membership','crm-products','crm-reports'], true) && $this->is_support_admin()) ? 'mrcp-crm-sidebar' : ''; ?>">
                <?php if (in_array($section, ['crm','crm-customers','crm-customer-profile','crm-customer-orders','crm-orders','crm-order-view','crm-membership','crm-products','crm-reports'], true) && $this->is_support_admin()) : ?>
                    <?php $this->render_crm_sidebar($section); ?>
                <?php else : ?>
                    <a class="mrcp-logo mrcp-logo-image" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Mehedi Rahat Home"><img src="<?php echo esc_url(MRCP_PLUGIN_URL . 'assets/images/mehedi-rahat-logo.png'); ?>" alt="Mehedi Rahat - Digital Growth Partner"></a>
                    <nav class="mrcp-nav">
                        <?php $this->nav_item('🏠', 'Dashboard', $this->url(), $section === 'dashboard'); ?>
                        <?php if ($this->is_support_admin()) : ?>
                            <?php $this->nav_item('📊', 'CRM Dashboard', $this->url('crm'), $section === 'crm'); ?>
                        <?php endif; ?>
                        <?php $this->nav_item('▣', 'Orders', $this->url('orders'), $section === 'orders', $stats['orders_count']); ?>
                        <?php $this->nav_item('↓', 'Downloads', $this->url('downloads'), $section === 'downloads', $stats['downloads_count']); ?>
                        <?php $this->nav_item('🧾', 'Invoices', $this->url('invoices'), in_array($section, ['invoices','invoice'], true), $stats['completed_orders_count']); ?>
                        <?php $this->nav_item('👑', 'Membership', $this->url('membership'), $section === 'membership'); ?>
                        <?php $this->nav_item('▤', 'Support Tickets', $this->url('support'), in_array($section, ['support','ticket'], true), $stats['tickets_count']); ?>
                        <?php $this->nav_item('⚙', 'Activation Requests', $this->url('activation'), $section === 'activation', $stats['activation_count']); ?>
                        <?php $this->nav_item('♡', 'Wishlist', home_url('/wishlist/')); ?>
                        <div class="mrcp-divider"></div>
                        <?php $this->nav_item('♙', 'Account Details', $this->url('account'), $section === 'account'); ?>
                        <?php $this->nav_item('◆', 'Addresses', $this->url('addresses'), $section === 'addresses'); ?>
                        <?php $this->nav_item('▭', 'Payment Methods', $this->url('payment-methods'), $section === 'payment-methods'); ?>
                        <?php $this->nav_item('↪', 'Logout', wp_logout_url(home_url('/'))); ?>
                    </nav>
                    <div class="mrcp-help-card">
                        <div class="mrcp-help-icon">🎧</div>
                        <h3>Need Help?</h3>
                        <p>We are here to help you.</p>
                        <a href="<?php echo esc_url($this->url('support')); ?>#new-ticket">Create Ticket</a>
                    </div>
                <?php endif; ?>
            </aside>

            <section class="mrcp-main">
                <header class="mrcp-topbar">
                    <div class="mrcp-search"><input type="search" id="mrcp-live-search" placeholder="Search orders, customers, tickets..." autocomplete="off"><b>⌕</b><div class="mrcp-search-results" id="mrcp-search-results"></div></div>
                    <div class="mrcp-userchip"><span class="mrcp-bell" data-count="<?php echo esc_attr($stats['notification_count']); ?>">🔔</span><?php $this->render_notification_dropdown(); ?><img src="<?php echo esc_url($user['avatar']); ?>" alt=""><strong><?php echo esc_html($user['name']); ?></strong></div>
                </header>

                <?php if (!empty($this->notice)) : ?>
                    <div class="mrcp-notice <?php echo esc_attr($this->notice['type']); ?>"><?php echo esc_html($this->notice['message']); ?></div>
                <?php endif; ?>

                <?php if ($locked_feature) : ?>
                    <?php $this->render_pro_feature_page($locked_feature); ?>
                <?php elseif ($section === 'crm') : ?>
                    <?php $this->render_frontend_crm_page(); ?>
                <?php elseif ($section === 'crm-customers') : ?>
                    <?php $this->render_frontend_crm_customers_page(); ?>
                <?php elseif ($section === 'crm-customer-profile') : ?>
                    <?php $this->render_frontend_crm_customer_profile_page(); ?>
                <?php elseif ($section === 'crm-customer-orders') : ?>
                    <?php $this->render_frontend_crm_customer_orders_page(); ?>
                <?php elseif ($section === 'crm-orders') : ?>
                    <?php $this->render_frontend_crm_orders_page(); ?>
                <?php elseif ($section === 'crm-membership') : ?>
                    <?php $this->render_frontend_crm_membership_page(); ?>
                <?php elseif ($section === 'crm-products') : ?>
                    <?php $this->render_frontend_crm_products_page(); ?>
                <?php elseif ($section === 'crm-reports') : ?>
                    <?php if (class_exists('\MRCP\Modules\Reports\ReportsModule')) { \MRCP\Modules\Reports\ReportsModule::render(); } ?>
                <?php elseif ($section === 'crm-order-view') : ?>
                    <?php $this->render_frontend_crm_order_detail_page(); ?>
                <?php elseif ($section === 'orders') : ?>
                    <?php $this->render_orders_page(); ?>
                <?php elseif ($section === 'downloads') : ?>
                    <?php $this->render_downloads_page(); ?>
                <?php elseif ($section === 'invoices') : ?>
                    <?php $this->render_invoices_page(); ?>
                <?php elseif ($section === 'order') : ?>
                    <?php $this->render_order_view_page(); ?>
                <?php elseif ($section === 'invoice') : ?>
                    <?php $this->render_invoice_page(); ?>
                <?php elseif ($section === 'membership') : ?>
                    <?php $this->render_membership_page($user, $membership); ?>
                <?php elseif ($section === 'account') : ?>
                    <?php $this->render_account_page($user, $membership); ?>
                <?php elseif ($section === 'addresses') : ?>
                    <?php $this->render_addresses_page($user); ?>
                <?php elseif ($section === 'payment-methods') : ?>
                    <?php $this->render_payment_methods_page(); ?>
                <?php elseif ($section === 'support') : ?>
                    <?php $this->render_support_page(); ?>
                <?php elseif ($section === 'activation') : ?>
                    <?php $this->render_activation_page(); ?>
                <?php elseif ($section === 'activation-view') : ?>
                    <?php $this->render_activation_view_page(); ?>
                <?php elseif ($section === 'ticket') : ?>
                    <?php $this->render_ticket_view_page(); ?>
                <?php else : ?>

                <section class="mrcp-hero">
                    <div class="mrcp-hero-left">
                        <img class="mrcp-avatar" src="<?php echo esc_url($user['avatar']); ?>" alt="<?php echo esc_attr($user['name']); ?>">
                        <div>
                            <h1>Welcome back,<br><?php echo esc_html($user['name']); ?>! <span class="mrcp-welcome-icon"><?php echo $this->premium_icon('sparkles'); ?></span></h1>
                            <div class="mrcp-hero-badges">
                                <?php if (mrc_can('digital.membership')) : ?>
                                <span><?php echo $this->premium_icon($membership['key']); ?><b><?php echo esc_html($membership['name']); ?></b></span>
                                <?php endif; ?>
                                <span><?php echo $this->premium_icon('calendar'); ?><b>Member since <?php echo esc_html($user['registered']); ?></b></span>
                            </div>
                        </div>
                    </div>
                    <?php if (mrc_can('digital.membership')) : ?>
                    <div class="mrcp-membership mrcp-level-<?php echo esc_attr($membership['key']); ?>">
                        <small>Your Membership</small>
                        <h2><span class="mrcp-membership-title-icon"><?php echo $this->premium_icon($membership['key']); ?></span><?php echo esc_html($membership['name']); ?></h2>

                        <div class="mrcp-member-grid">
                            <div><span>Lifetime Purchase</span><strong><?php echo wp_kses_post($this->money($membership['spent'])); ?></strong></div>
                            <div><span>Current Discount</span><strong><?php echo esc_html($membership['discount']); ?>%</strong></div>
                            <div><span><?php echo $membership['vip'] ? 'Highest Level' : 'Next: ' . esc_html($membership['next']['name']); ?></span><strong><?php echo $membership['vip'] ? '30%' : esc_html($membership['next']['discount']) . '%'; ?></strong></div>
                        </div>

                        <?php if ($membership['vip']) : ?>
                            <div class="mrcp-business-badge is-vip">🎁 VIP Exclusive Offers Available</div>
                            <p>You are enjoying our highest <?php echo esc_html($membership['discount']); ?>% lifetime discount.</p>
                        <?php else : ?>
                            <div class="mrcp-progress-wrap">
                                <div class="mrcp-progress-info">
                                    <span class="mrcp-progress-copy"><?php echo $this->premium_icon('sparkles'); ?><b>Spend <?php echo wp_kses_post($this->money($membership['needed'])); ?> more to unlock <?php echo esc_html(str_replace(' Member', '', $membership['next']['name'])); ?> Benefits</b></span>
                                    <strong><?php echo esc_html($membership['progress']); ?>%</strong>
                                </div>
                                <div class="mrcp-progress"><i style="width:<?php echo esc_attr($membership['progress']); ?>%"></i></div>
                            </div>
                            <p>You are now getting <?php echo esc_html($membership['discount']); ?>% discount. Next level gives <?php echo esc_html($membership['next']['discount']); ?>% discount.</p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </section>

                <section class="mrcp-stats">
                    <?php $this->stat_card('orders', $stats['orders_count'], 'Total Orders', 'View Orders →', $this->url('orders')); ?>
                    <?php $this->stat_card('wallet', $this->money($stats['total_spent']), 'Total Spent', 'View details →', $this->url('orders'), true); ?>
                    <?php $this->stat_card('download', $stats['downloads_count'], 'Downloads', 'View downloads →', $this->url('downloads')); ?>
                    <?php if (mrc_can('digital.support_tickets')) { $this->stat_card('support', $stats['tickets_count'], 'Support Tickets', 'View tickets →', $this->url('support')); } ?>
                    <?php if (mrc_can('digital.activation_requests')) { $this->stat_card('key', $stats['activation_count'], 'Activation Requests', 'View requests →', $this->url('activation')); } ?>
                </section>

                <?php if (mrc_can('digital.membership')) : ?>
                    <?php $this->membership_roadmap($membership); ?>
                    <?php $this->motivation_banner($membership); ?>
                <?php endif; ?>

                <section class="mrcp-panel">
                    <div class="mrcp-panel-head"><h2>Quick Actions</h2><a href="#">View all →</a></div>
                    <div class="mrcp-actions">
                        <?php $this->action_card('orders', 'My Orders', 'View your all orders and order details.', 'View Orders', $this->url('orders')); ?>
                        <?php $this->action_card('download', 'Downloads', 'Access your purchased products and files.', 'View Downloads', $this->url('downloads')); ?>
                        <?php $this->action_card('support', 'Support Tickets', 'Submit new ticket or view all tickets.', 'View Tickets', $this->url('support')); ?>
                        <?php $this->action_card('key', 'Activation Request', 'Request plugin/theme activation support.', 'New Request', $this->url('activation')); ?>
                        <?php $this->action_card('heart', 'Wishlist', 'View your saved items and products.', 'View Wishlist', home_url('/wishlist/')); ?>
                    </div>
                </section>

                <section class="mrcp-widgets">
                    <div class="mrcp-widget">
                        <div class="mrcp-widget-head"><h2>Recent Orders</h2><a href="<?php echo esc_url($this->url('orders')); ?>">View all orders →</a></div>
                        <?php if ($orders): foreach ($orders as $order): $this->order_row($order, false); endforeach; else: $this->empty_state('📦', 'No recent orders yet', 'Your recent purchases will appear here.'); endif; ?>
                    </div>
                    <div class="mrcp-widget">
                        <div class="mrcp-widget-head"><h2>Latest Downloads</h2><a href="<?php echo esc_url($this->url('downloads')); ?>">View all downloads →</a></div>
                        <?php if ($downloads): foreach ($downloads as $download): $this->download_row($download); endforeach; else: $this->empty_state('⬇️', 'No downloads available yet', 'Your purchased files will appear here.'); endif; ?>
                    </div>
                    <div class="mrcp-widget" id="tickets">
                        <div class="mrcp-widget-head"><h2>Recent Tickets</h2><a href="<?php echo esc_url($this->url('support')); ?>">View all tickets →</a></div>
                        <?php $recent_tickets = $this->tickets(3); if ($recent_tickets): foreach ($recent_tickets as $ticket): $this->ticket_row($ticket, false); endforeach; else: $this->empty_state('🎟️', 'No tickets yet', 'Create a ticket when you need help.'); endif; ?>
                    </div>
                </section>
                <?php do_action('mrbp/customer_portal/dashboard_after_widgets'); ?>
                <?php endif; ?>
            </section>
        </main>
        <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        exit;
    }

    private function notification_items_html($items): string {
        if (!is_array($items)) $items = [];
        $items = array_slice($items, 0, 6);
        ob_start();
        if ($items) {
            foreach ($items as $item) {
                $class = empty($item['read']) ? 'is-unread' : 'is-read';
                $url = !empty($item['url']) ? $item['url'] : '#';
                $id = !empty($item['id']) ? (string) $item['id'] : '';
                $type = !empty($item['type']) ? sanitize_html_class((string) $item['type']) : 'general';
                $time = !empty($item['time']) ? (int) $item['time'] : current_time('timestamp');
                echo '<a class="mrcp-notification-item ' . esc_attr($class) . ' type-' . esc_attr($type) . '" data-notification-id="' . esc_attr($id) . '" href="' . esc_url($url) . '">';
                echo '<span class="mrcp-notification-dot" aria-hidden="true"></span>';
                echo '<strong>' . esc_html($item['title'] ?? '') . '</strong>';
                echo '<span>' . esc_html($item['message'] ?? '') . '</span>';
                echo '<small>' . esc_html(human_time_diff($time, current_time('timestamp'))) . ' ago</small>';
                echo '</a>';
            }
        } else {
            echo '<div class="mrcp-notification-empty">No notifications yet.</div>';
        }
        return (string) ob_get_clean();
    }

    private function render_notification_dropdown() {
        $items = $this->notifications(get_current_user_id(), 6);
        $unread = $this->unread_notification_count();
        echo '<div class="mrcp-notification-dropdown">';
        echo '<div class="mrcp-notification-head">';
        echo '<div><strong>Notifications</strong><small class="mrcp-unread-label">' . esc_html($unread) . ' unread</small></div>';
        echo '<button type="button" class="mrcp-mark-all-read"' . ($unread < 1 ? ' disabled' : '') . '>Mark all as read</button>';
        echo '</div>';
        echo '<div class="mrcp-notification-list">' . $this->notification_items_html($items) . '</div>';
        echo '</div>';
    }

    private function render_frontend_crm_customers_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view Customers CRM.</p></section>';
            return;
        }

        $search = isset($_GET['mrcp_customer_search']) ? sanitize_text_field(wp_unslash($_GET['mrcp_customer_search'])) : '';
        $level_filter = isset($_GET['mrcp_membership']) ? sanitize_key(wp_unslash($_GET['mrcp_membership'])) : '';
        $paged = isset($_GET['mrcp_page']) ? max(1, absint($_GET['mrcp_page'])) : 1;
        $per_page = 20;

        $data = $this->crm_customers_query($search, $level_filter, $paged, $per_page);
        $stats = $this->crm_customers_stats();
        ?>
        <section class="mrcp-crm-customers-wrap">
            <header class="mrcp-crm-v103-head">
                <div>
                    <span>Customer CRM</span>
                    <h1>Customers</h1>
                    <p>Manage customers, membership levels, spending and activity from one clean CRM view.</p>
                </div>
                <a class="mrcp-crm-v103-date" href="<?php echo esc_url($this->url('crm')); ?>">← Back to CRM Dashboard</a>
            </header>

            <section class="mrcp-crm-v103-kpis mrcp-membership-tier-kpis" aria-label="Membership statistics">
                <article class="is-silver"><span>🥈</span><div><small>Silver Members</small><strong><?php echo esc_html(number_format_i18n($stats['silver_members'])); ?></strong><em><?php echo esc_html($stats['total_customers'] > 0 ? number_format_i18n(($stats['silver_members'] / $stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
                <article class="is-gold"><span>🥇</span><div><small>Gold Members</small><strong><?php echo esc_html(number_format_i18n($stats['gold_members'])); ?></strong><em><?php echo esc_html($stats['total_customers'] > 0 ? number_format_i18n(($stats['gold_members'] / $stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
                <article class="is-diamond"><span>💎</span><div><small>Diamond Members</small><strong><?php echo esc_html(number_format_i18n($stats['diamond_members'])); ?></strong><em><?php echo esc_html($stats['total_customers'] > 0 ? number_format_i18n(($stats['diamond_members'] / $stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
                <article class="is-vip"><span>👑</span><div><small>VIP Members</small><strong><?php echo esc_html(number_format_i18n($stats['vip_members'])); ?></strong><em><?php echo esc_html($stats['total_customers'] > 0 ? number_format_i18n(($stats['vip_members'] / $stats['total_customers']) * 100, 1) : '0'); ?>% of customers</em></div></article>
            </section>

            <section class="mrcp-crm-v103-card mrcp-customers-crm-panel">
                <div class="mrcp-customers-crm-toolbar">
                    <form method="get" action="<?php echo esc_url($this->url('crm/customers')); ?>">
                        <input type="search" name="mrcp_customer_search" value="<?php echo esc_attr($search); ?>" placeholder="Search by name, email or username">
                        <select name="mrcp_membership">
                            <option value="">All Memberships</option>
                            <?php foreach (['silver' => 'Silver', 'gold' => 'Gold', 'diamond' => 'Diamond', 'vip' => 'VIP'] as $key => $label) : ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($level_filter, $key); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit">Search</button>
                        <?php if ($search || $level_filter) : ?>
                            <a href="<?php echo esc_url($this->url('crm/customers')); ?>">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="mrcp-customers-crm-table-wrap">
                    <table class="mrcp-customers-crm-table">
                        <thead>
                            <tr>
                                <th>Customer</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Total Spend</th>
                                <th>Total Orders</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($data['customers'])) : ?>
                                <?php foreach ($data['customers'] as $customer) : ?>
                                    <?php
                                    $customer_id = (int) $customer->ID;
                                    $spend = $this->crm_customer_spend($customer_id);
                                    $orders_count = $this->crm_customer_order_count($customer_id);
                                    $membership = MRCP_Membership::get_customer_membership( (int) $customer_id );
                                    ?>
                                    <?php
                                    $first_name = (string) get_user_meta($customer_id, 'billing_first_name', true);
                                    if (!$first_name) {
                                        $first_name = (string) get_user_meta($customer_id, 'first_name', true);
                                    }
                                    if (!$first_name) {
                                        $first_name = $customer->display_name ?: $customer->user_login;
                                    }
                                    $phone = (string) get_user_meta($customer_id, 'billing_phone', true);
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="mrcp-crm-customer-cell">
                                                <?php echo get_avatar($customer_id, 42); ?>
                                                <div>
                                                    <strong><?php echo esc_html($first_name); ?></strong>
                                                    <span class="mrcp-customer-membership-mini is-<?php echo esc_attr(sanitize_html_class($membership['key'])); ?>"><?php echo esc_html($membership['icon'] . ' ' . $membership['label']); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td><a class="mrcp-customer-contact-link" href="mailto:<?php echo esc_attr($customer->user_email); ?>"><?php echo esc_html($customer->user_email); ?></a></td>
                                        <td><?php echo $phone ? '<a class="mrcp-customer-contact-link" href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $phone)) . '">' . esc_html($phone) . '</a>' : '<span class="mrcp-customer-empty-value">—</span>'; ?></td>
                                        <td><strong class="mrcp-customer-total-spend"><?php echo wp_kses_post($this->money($spend)); ?></strong></td>
                                        <td><strong class="mrcp-customer-order-count"><?php echo esc_html(number_format_i18n($orders_count)); ?></strong></td>
                                        <td><a class="mrcp-view-btn" href="<?php echo esc_url($this->url('crm/customers/' . $customer_id)); ?>">View</a></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr><td colspan="6" class="mrcp-empty-row">No customers found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($data['pages'] > 1) : ?>
                    <?php
                    $make_page_url = function($page) use ($search, $level_filter) {
                        return add_query_arg([
                            'mrcp_customer_search' => $search,
                            'mrcp_membership' => $level_filter,
                            'mrcp_page' => max(1, (int) $page),
                        ], $this->url('crm/customers'));
                    };
                    $pages_to_show = [1, (int) $data['pages']];
                    for ($i = max(1, $paged - 2); $i <= min((int) $data['pages'], $paged + 2); $i++) {
                        $pages_to_show[] = $i;
                    }
                    $pages_to_show = array_values(array_unique(array_filter($pages_to_show, function($page) use ($data) {
                        return $page >= 1 && $page <= (int) $data['pages'];
                    })));
                    sort($pages_to_show);
                    ?>
                    <nav class="mrcp-crm-pagination" aria-label="Customer pagination">
                        <?php if ($paged > 1) : ?>
                            <a class="mrcp-crm-page-btn" href="<?php echo esc_url($make_page_url($paged - 1)); ?>">‹ Previous</a>
                        <?php else : ?>
                            <span class="mrcp-crm-page-btn is-disabled">‹ Previous</span>
                        <?php endif; ?>

                        <?php $last_page = 0; ?>
                        <?php foreach ($pages_to_show as $i) : ?>
                            <?php if ($last_page && $i > $last_page + 1) : ?>
                                <span class="mrcp-crm-page-dots">…</span>
                            <?php endif; ?>

                            <?php if ((int) $i === (int) $paged) : ?>
                                <span class="mrcp-crm-page-number is-active"><?php echo esc_html($i); ?></span>
                            <?php else : ?>
                                <a class="mrcp-crm-page-number" href="<?php echo esc_url($make_page_url($i)); ?>"><?php echo esc_html($i); ?></a>
                            <?php endif; ?>
                            <?php $last_page = $i; ?>
                        <?php endforeach; ?>

                        <?php if ($paged < (int) $data['pages']) : ?>
                            <a class="mrcp-crm-page-btn" href="<?php echo esc_url($make_page_url($paged + 1)); ?>">Next ›</a>
                        <?php else : ?>
                            <span class="mrcp-crm-page-btn is-disabled">Next ›</span>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            </section>
        </section>
        <?php
    }

    private function render_frontend_crm_customer_profile_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view Customer CRM.</p></section>';
            return;
        }

        $customer_id = absint(get_query_var('mrcp_customer_id'));
        $customer = $customer_id ? get_userdata($customer_id) : false;

        if (!$customer) {
            echo '<section class="mrcp-panel"><h2>Customer not found</h2><p>The requested customer profile could not be found.</p><p><a class="mrcp-view-btn" href="' . esc_url($this->url('crm/customers')) . '">Back to Customers</a></p></section>';
            return;
        }

        $spend = $this->crm_customer_spend($customer_id);
        $orders_count = $this->crm_customer_order_count($customer_id);
        $membership = MRCP_Membership::get_customer_membership( (int) $customer_id );
        $email = (string) $customer->user_email;
        $phone = (string) get_user_meta($customer_id, 'billing_phone', true);
        $company = (string) get_user_meta($customer_id, 'billing_company', true);
        $first_name = (string) get_user_meta($customer_id, 'billing_first_name', true);
        $last_name = (string) get_user_meta($customer_id, 'billing_last_name', true);
        $display_name = trim($first_name . ' ' . $last_name);
        if (!$display_name) {
            $display_name = $customer->display_name ?: $customer->user_login;
        }
        $address = array_filter([
            get_user_meta($customer_id, 'billing_address_1', true),
            get_user_meta($customer_id, 'billing_city', true),
            get_user_meta($customer_id, 'billing_state', true),
            get_user_meta($customer_id, 'billing_country', true),
        ]);
        $downloads_count = 0;
        $activation_count = $this->crm_customer_post_count('mrcp_activation', $customer_id);
        $ticket_count = $this->crm_customer_post_count('mrcp_ticket', $customer_id);
        $recent_orders = $this->crm_customer_recent_orders($customer_id, 5);
        $recent_tickets = $this->crm_customer_recent_posts('mrcp_ticket', $customer_id, 4);
        $recent_activations = $this->crm_customer_recent_posts('mrcp_activation', $customer_id, 4);
        ?>
        <section class="mrcp-crm-customer-profile">
            <header class="mrcp-crm-v103-head mrcp-profile-head">
                <div>
                    <span>Customer Profile</span>
                    <h1><?php echo esc_html($display_name); ?></h1>
                    <p><?php echo esc_html($email); ?><?php echo $phone ? ' • ' . esc_html($phone) : ''; ?></p>
                </div>
                <a class="mrcp-crm-v103-date" href="<?php echo esc_url($this->url('crm/customers')); ?>">← Back to Customers</a>
            </header>

            <section class="mrcp-profile-hero-card">
                <div class="mrcp-profile-avatar-wrap">
                    <?php echo get_avatar($customer_id, 96); ?>
                    <div>
                        <h2><?php echo esc_html($display_name); ?></h2>
                        <p>@<?php echo esc_html($customer->user_login); ?></p>
                        <?php echo wp_kses_post($this->crm_membership_badge($membership)); ?>
                    </div>
                </div>
                <div class="mrcp-profile-meta-grid">
                    <div><span>Email</span><strong><?php echo esc_html($email ?: '—'); ?></strong></div>
                    <div><span>Phone</span><strong><?php echo esc_html($phone ?: '—'); ?></strong></div>
                    <div><span>Company</span><strong><?php echo esc_html($company ?: '—'); ?></strong></div>
                    <div><span>Joined</span><strong><?php echo esc_html(date_i18n('d M Y', strtotime($customer->user_registered))); ?></strong></div>
                </div>
            </section>

            <section class="mrcp-profile-stat-grid">
                <article><span>🛒</span><div><small>Total Orders</small><strong><?php echo esc_html(number_format_i18n($orders_count)); ?></strong></div></article>
                <article class="mrcp-lifetime-spend-card"><span class="mrcp-profile-stat-icon mrcp-currency-icon">৳</span><div><small>Lifetime Spend</small><strong class="mrcp-profile-money"><span class="mrcp-profile-amount"><?php echo esc_html(number_format_i18n(round((float) $spend), 0)); ?></span></strong></div></article>
                <article><span>🎟️</span><div><small>Support Tickets</small><strong><?php echo esc_html(number_format_i18n($ticket_count)); ?></strong></div></article>
                <article><span>🔑</span><div><small>Activation Requests</small><strong><?php echo esc_html(number_format_i18n($activation_count)); ?></strong></div></article>
            </section>

            <section class="mrcp-profile-grid">
                <article class="mrcp-profile-card mrcp-profile-membership-card">
                    <header><h2>Membership Information</h2></header>
                    <div class="mrcp-profile-membership-main">
                        <span><?php echo esc_html($membership['icon']); ?></span>
                        <div><strong><?php echo esc_html($membership['label']); ?></strong><p>Based on lifetime purchase amount.</p></div>
                    </div>
                    <?php $this->crm_profile_membership_progress($spend); ?>
                </article>

                <article class="mrcp-profile-card">
                    <header><h2>Customer Info</h2></header>
                    <div class="mrcp-profile-info-list">
                        <p><span>Full Name</span><strong><?php echo esc_html($display_name); ?></strong></p>
                        <p><span>Username</span><strong><?php echo esc_html($customer->user_login); ?></strong></p>
                        <p><span>Billing Address</span><strong><?php echo esc_html($address ? implode(', ', $address) : '—'); ?></strong></p>
                    </div>
                </article>
            </section>

            <section class="mrcp-profile-grid mrcp-profile-grid-three">
                <article class="mrcp-profile-card">
                    <header><h2>Recent Orders</h2><a href="<?php echo esc_url($this->url('crm/customers/' . $customer_id . '/orders')); ?>">View all →</a></header>
                    <?php if ($recent_orders) : ?>
                        <div class="mrcp-profile-list">
                            <?php foreach ($recent_orders as $order) : ?>
                                <a href="<?php echo esc_url($this->url('crm/order/' . $order->get_id())); ?>">
                                    <span>#<?php echo esc_html($order->get_order_number()); ?></span>
                                    <strong><?php echo wp_kses_post($this->money($order->get_total())); ?></strong>
                                    <em><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></em>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p class="mrcp-profile-empty">No recent orders found.</p>
                    <?php endif; ?>
                </article>

                <article class="mrcp-profile-card">
                    <header><h2>Support History</h2><a href="<?php echo esc_url($this->support_url()); ?>">View all →</a></header>
                    <?php $this->crm_profile_posts_list($recent_tickets, '_mrcp_ticket_status', 'No support tickets found.'); ?>
                </article>

                <article class="mrcp-profile-card">
                    <header><h2>Activation History</h2><a href="<?php echo esc_url($this->activation_url()); ?>">View all →</a></header>
                    <?php $this->crm_profile_posts_list($recent_activations, '_mrcp_activation_status', 'No activation requests found.'); ?>
                </article>
            </section>

            <section class="mrcp-profile-card mrcp-profile-actions">
                <header><h2>Quick Actions</h2></header>
                <div>
                    <a href="<?php echo esc_url(admin_url('user-edit.php?user_id=' . $customer_id)); ?>">Edit WordPress User →</a>
                    <a href="<?php echo esc_url($this->url('crm/customers/' . $customer_id . '/orders')); ?>">Customer Orders →</a>
                    <a href="mailto:<?php echo esc_attr($email); ?>">Send Email →</a>
                    <a href="<?php echo esc_url($this->url('crm/customers')); ?>">Back to Customers →</a>
                </div>
            </section>
        </section>
        <?php
    }

    private function render_frontend_crm_customer_orders_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view Customer CRM.</p></section>';
            return;
        }

        $customer_id = absint(get_query_var('mrcp_customer_id'));
        $customer = $customer_id ? get_userdata($customer_id) : false;

        if (!$customer) {
            echo '<section class="mrcp-panel"><h2>Customer not found</h2><p>The requested customer could not be found.</p><p><a class="mrcp-view-btn" href="' . esc_url($this->url('crm/customers')) . '">Back to Customers</a></p></section>';
            return;
        }

        $display_name = $customer->display_name ?: $customer->user_login;
        $orders = $this->crm_customer_recent_orders($customer_id, 50);
        $completed = 0;
        $processing = 0;
        $total_spend = $this->crm_customer_spend($customer_id);
        foreach ($orders as $order) {
            if ($order->has_status('completed')) {
                $completed++;
            }
            if ($order->has_status('processing')) {
                $processing++;
            }
        }
        ?>
        <section class="mrcp-crm-customer-orders">
            <header class="mrcp-crm-v103-head mrcp-profile-head">
                <div>
                    <span>Customer Orders</span>
                    <h1><?php echo esc_html($display_name); ?></h1>
                    <p>All purchases made by this customer.</p>
                </div>
                <a class="mrcp-crm-v103-date" href="<?php echo esc_url($this->url('crm/customers/' . $customer_id)); ?>">← Back to Profile</a>
            </header>

            <section class="mrcp-profile-stat-grid mrcp-orders-stat-grid">
                <article><span>🛒</span><div><small>Total Orders</small><strong><?php echo esc_html(number_format_i18n(count($orders))); ?></strong></div></article>
                <article><span>✅</span><div><small>Completed Orders</small><strong><?php echo esc_html(number_format_i18n($completed)); ?></strong></div></article>
                <article><span>⏳</span><div><small>Processing Orders</small><strong><?php echo esc_html(number_format_i18n($processing)); ?></strong></div></article>
                <article class="mrcp-lifetime-spend-card"><span class="mrcp-profile-stat-icon mrcp-currency-icon">৳</span><div><small>Total Spent</small><strong class="mrcp-profile-money"><span class="mrcp-profile-amount"><?php echo esc_html(number_format_i18n(round((float) $total_spend), 0)); ?></span></strong></div></article>
            </section>

            <section class="mrcp-profile-card mrcp-customer-orders-card">
                <header>
                    <h2>Orders History</h2>
                    <a href="<?php echo esc_url(admin_url('edit.php?post_type=shop_order&_customer_user=' . $customer_id)); ?>">Open in WooCommerce →</a>
                </header>
                <?php if ($orders) : ?>
                    <div class="mrcp-customer-orders-table-wrap">
                        <table class="mrcp-customer-orders-table">
                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Date</th>
                                    <th>Products</th>
                                    <th>Payment</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($orders as $order) : ?>
                                <?php
                                $items = [];
                                foreach ($order->get_items() as $item) {
                                    $items[] = $item->get_name();
                                }
                                $date = $order->get_date_created() ? $order->get_date_created()->date_i18n('d M Y') : '—';
                                $payment = $order->get_payment_method_title() ?: '—';
                                $status = wc_get_order_status_name($order->get_status());
                                ?>
                                <tr>
                                    <td><strong>#<?php echo esc_html($order->get_order_number()); ?></strong></td>
                                    <td><?php echo esc_html($date); ?></td>
                                    <td><?php echo esc_html($items ? implode(', ', array_slice($items, 0, 2)) . (count($items) > 2 ? ' +' . (count($items) - 2) : '') : '—'); ?></td>
                                    <td><?php echo esc_html($payment); ?></td>
                                    <td><strong><?php echo wp_kses_post($this->money($order->get_total())); ?></strong></td>
                                    <td><span class="mrcp-order-status status-<?php echo esc_attr($order->get_status()); ?>"><?php echo esc_html($status); ?></span></td>
                                    <td><a class="mrcp-view-btn" href="<?php echo esc_url(method_exists($order, 'get_edit_order_url') ? $order->get_edit_order_url() : $this->url('crm/order/' . $order->get_id())); ?>">View</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <p class="mrcp-profile-empty">No orders found for this customer.</p>
                <?php endif; ?>
            </section>
        </section>
        <?php
    }

    private function crm_customer_recent_orders($customer_id, $limit = 5) {
        if (!function_exists('wc_get_orders')) {
            return [];
        }
        return wc_get_orders([
            'customer_id' => (int) $customer_id,
            'limit'      => (int) $limit,
            'orderby'    => 'date',
            'order'      => 'DESC',
            'return'     => 'objects',
        ]);
    }

    private function crm_customer_post_count($post_type, $customer_id) {
        $q = new WP_Query([
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'author'         => (int) $customer_id,
            'no_found_rows'  => false,
        ]);
        return (int) $q->found_posts;
    }

    private function crm_customer_recent_posts($post_type, $customer_id, $limit = 4) {
        return get_posts([
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => (int) $limit,
            'author'         => (int) $customer_id,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);
    }

    private function crm_profile_posts_list($posts, $status_meta_key, $empty_message) {
        if (!$posts) {
            echo '<p class="mrcp-profile-empty">' . esc_html($empty_message) . '</p>';
            return;
        }

        echo '<div class="mrcp-profile-history-list">';
        foreach ($posts as $post) {
            if (!$post || empty($post->ID)) {
                continue;
            }

            $post_id      = (int) $post->ID;
            $post_type    = (string) get_post_type($post_id);
            $is_activation = $post_type === 'mrcp_activation';
            $raw_status   = (string) get_post_meta($post_id, $status_meta_key, true);
            $status       = $raw_status ? sanitize_key($raw_status) : ($is_activation ? 'pending' : 'open');
            $status_label = $raw_status ? ucwords(str_replace('_', ' ', $raw_status)) : ($is_activation ? 'Pending' : 'Open');
            $title        = get_the_title($post_id);
            $updated      = get_the_modified_date('d M Y', $post_id);
            $prefix       = $is_activation ? 'ACT-' : 'MR-';
            $icon         = $is_activation ? '🔑' : '🎟️';
            $view_url     = $is_activation ? $this->activation_view_url($post_id) : $this->ticket_url($post_id);

            if ($is_activation) {
                $product = (string) get_post_meta($post_id, '_mrcp_activation_product', true);
                $domain  = (string) get_post_meta($post_id, '_mrcp_activation_domain', true);
                $headline = $product ?: ($title ?: $prefix . $post_id);
                $subline  = $domain ? $domain : 'No domain added';
            } else {
                $headline = $title ?: $prefix . $post_id;
                $subline  = 'Last updated ' . $updated;
            }

            echo '<a class="mrcp-profile-history-item" href="' . esc_url($view_url) . '">';
            echo '<span class="mrcp-profile-history-icon">' . esc_html($icon) . '</span>';
            echo '<span class="mrcp-profile-history-main">';
            echo '<strong>' . esc_html($prefix . $post_id) . '</strong>';
            echo '<small>' . esc_html($headline) . '</small>';
            echo '<small class="mrcp-profile-history-subline">' . esc_html($subline) . '</small>';
            echo '</span>';
            echo '<span class="mrcp-profile-history-meta">';
            echo '<em class="mrcp-history-status is-' . esc_attr($status) . '">' . esc_html($status_label) . '</em>';
            echo '<small>' . esc_html($updated) . '</small>';
            echo '<b>View</b>';
            echo '</span>';
            echo '</a>';
        }
        echo '</div>';
    }

    private function crm_profile_membership_progress($spent) {
        $levels = [
            ['key' => 'silver', 'name' => 'Silver', 'threshold' => 0, 'next' => 10000, 'discount' => 0],
            ['key' => 'gold', 'name' => 'Gold', 'threshold' => 10000, 'next' => 50000, 'discount' => 10],
            ['key' => 'diamond', 'name' => 'Diamond', 'threshold' => 50000, 'next' => 100000, 'discount' => 20],
            ['key' => 'vip', 'name' => 'VIP', 'threshold' => 100000, 'next' => 100000, 'discount' => 30],
        ];
        $current = $levels[0];
        foreach ($levels as $level) {
            if ($spent >= $level['threshold']) {
                $current = $level;
            }
        }
        $is_vip = $current['key'] === 'vip';
        $next_amount = $is_vip ? 100000 : $current['next'];
        $range = max(1, $next_amount - $current['threshold']);
        $progress = $is_vip ? 100 : max(0, min(100, (($spent - $current['threshold']) / $range) * 100));
        $needed = $is_vip ? 0 : max(0, $next_amount - $spent);
        echo '<div class="mrcp-profile-progress-wrap">';
        echo '<div class="mrcp-profile-progress-info"><span>Current Discount</span><strong>' . esc_html($current['discount']) . '%</strong></div>';
        echo '<div class="mrcp-profile-progress"><i style="width:' . esc_attr(round($progress, 1)) . '%"></i></div>';
        if ($is_vip) {
            echo '<p>Customer is already enjoying the highest VIP benefits.</p>';
        } else {
            echo '<p>Spend ' . wp_kses_post($this->money($needed)) . ' more to reach the next membership level.</p>';
        }
        echo '</div>';
    }

    private function crm_customers_query($search = '', $level_filter = '', $paged = 1, $per_page = 20) {
        $base_args = [
            'role__in'    => ['customer', 'subscriber'],
            'orderby'     => 'registered',
            'order'       => 'DESC',
            'count_total' => true,
            'number'      => -1,
            'offset'      => 0,
        ];

        if (!empty($search)) {
            $base_args['search'] = '*' . esc_attr($search) . '*';
            $base_args['search_columns'] = ['user_login', 'user_email', 'user_nicename', 'display_name'];
        }

        $query = new WP_User_Query($base_args);
        $users = array_values(array_filter($query->get_results(), function($user) use ($level_filter) {
            if (!$user instanceof WP_User) {
                return false;
            }

            if (empty($level_filter)) {
                return true;
            }

            $membership = MRCP_Membership::get_customer_membership( (int) $user->ID );
            return isset($membership['key']) && sanitize_key((string) $membership['key']) === sanitize_key((string) $level_filter);
        }));

        // Business-first ordering: highest lifetime spender appears first.
        // A registration-date tie-breaker keeps rows stable when spend is equal.
        usort($users, function($a, $b) {
            $a_spend = $this->crm_customer_spend((int) $a->ID);
            $b_spend = $this->crm_customer_spend((int) $b->ID);

            if ($a_spend === $b_spend) {
                return strcmp((string) $b->user_registered, (string) $a->user_registered);
            }

            return ($a_spend < $b_spend) ? 1 : -1;
        });

        $total  = count($users);
        $offset = max(0, ($paged - 1) * $per_page);

        return [
            'customers' => array_slice($users, $offset, $per_page),
            'total'     => $total,
            'pages'     => max(1, (int) ceil($total / $per_page)),
        ];
    }

    private function crm_customers_stats() {
        $customers = get_users([
            'role__in' => ['customer', 'subscriber'],
            'fields'   => ['ID', 'user_registered'],
            'number'   => 9999,
        ]);

        $start_month = strtotime(date_i18n('Y-m-01 00:00:00'));
        $new_this_month = 0;
        $premium_members = 0;
        $tier_counts = [
            'silver'  => 0,
            'gold'    => 0,
            'diamond' => 0,
            'vip'     => 0,
        ];
        $total_revenue = 0;

        foreach ($customers as $customer) {
            $registered = strtotime($customer->user_registered);
            if ($registered >= $start_month) {
                $new_this_month++;
            }

            $spend = $this->crm_customer_spend((int) $customer->ID);
            $total_revenue += $spend;

            $membership = MRCP_Membership::get_customer_membership( (int) $customer->ID );
            $membership_key = isset($membership['key']) ? sanitize_key((string) $membership['key']) : 'silver';
            if (!isset($tier_counts[$membership_key])) {
                $membership_key = 'silver';
            }
            $tier_counts[$membership_key]++;

            if (in_array($membership_key, ['gold', 'diamond', 'vip'], true)) {
                $premium_members++;
            }
        }

        return [
            'total_customers' => count($customers),
            'new_this_month'  => $new_this_month,
            'premium_members' => $premium_members,
            'silver_members'  => $tier_counts['silver'],
            'gold_members'    => $tier_counts['gold'],
            'diamond_members' => $tier_counts['diamond'],
            'vip_members'     => $tier_counts['vip'],
            'total_revenue'   => $total_revenue,
        ];
    }

    private function crm_customer_spend($customer_id) {
        if (function_exists('wc_get_customer_total_spent')) {
            return (float) wc_get_customer_total_spent($customer_id);
        }

        return 0.0;
    }

    private function crm_customer_order_count($customer_id) {
        if (function_exists('wc_get_customer_order_count')) {
            return (int) wc_get_customer_order_count($customer_id);
        }

        return 0;
    }

    private function crm_membership_from_spend($spend) {
        $spend = (float) $spend;

        if ($spend >= 100000) {
            return ['key' => 'vip', 'label' => 'VIP', 'icon' => '👑', 'discount' => 30];
        }

        if ($spend >= 50000) {
            return ['key' => 'diamond', 'label' => 'Diamond', 'icon' => '💎', 'discount' => 20];
        }

        if ($spend >= 10000) {
            return ['key' => 'gold', 'label' => 'Gold', 'icon' => '🥇', 'discount' => 10];
        }

        return ['key' => 'silver', 'label' => 'Silver', 'icon' => '🥈', 'discount' => 0];
    }

    private function crm_membership_badge($membership) {
        $class = 'mrcp-membership-badge is-' . sanitize_html_class($membership['key']);
        return '<span class="' . esc_attr($class) . '">' . esc_html($membership['icon'] . ' ' . $membership['label']) . '</span>';
    }

    private function render_frontend_crm_orders_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view Orders CRM.</p></section>';
            return;
        }

        if (!function_exists('wc_get_orders')) {
            echo '<section class="mrcp-panel"><h2>WooCommerce is required</h2><p>The Orders CRM needs WooCommerce to load order data.</p></section>';
            return;
        }

        $search         = isset($_GET['crm_order_search']) ? sanitize_text_field(wp_unslash($_GET['crm_order_search'])) : '';
        $status         = isset($_GET['crm_order_status']) ? sanitize_key(wp_unslash($_GET['crm_order_status'])) : '';
        $date_filter    = isset($_GET['crm_order_date']) ? sanitize_key(wp_unslash($_GET['crm_order_date'])) : '';
        $payment_method = isset($_GET['crm_order_payment']) ? sanitize_key(wp_unslash($_GET['crm_order_payment'])) : '';
        $current_page   = isset($_GET['crm_order_page']) ? max(1, absint($_GET['crm_order_page'])) : 1;
        $per_page       = 20;

        $query_args = [
            'limit'    => $per_page,
            'page'     => $current_page,
            'paginate' => true,
            'orderby'  => 'date',
            'order'    => 'DESC',
            'return'   => 'objects',
        ];

        if ($status && array_key_exists('wc-' . $status, wc_get_order_statuses())) {
            $query_args['status'] = [$status];
        }

        if ($payment_method) {
            $query_args['payment_method'] = $payment_method;
        }

        if ($date_filter === 'today') {
            $query_args['date_created'] = '>=' . current_time('Y-m-d');
        } elseif ($date_filter === '7days') {
            $query_args['date_created'] = '>=' . wp_date('Y-m-d', strtotime('-7 days', current_time('timestamp')));
        } elseif ($date_filter === '30days') {
            $query_args['date_created'] = '>=' . wp_date('Y-m-d', strtotime('-30 days', current_time('timestamp')));
        }

        if ($search !== '') {
            if (ctype_digit(ltrim($search, '#'))) {
                $query_args['include'] = [absint(ltrim($search, '#'))];
            } else {
                $query_args['search'] = '*' . $search . '*';
            }
        }

        try {
            $result = wc_get_orders($query_args);
        } catch (Throwable $e) {
            unset($query_args['search']);
            $result = wc_get_orders($query_args);
        }

        $orders      = is_object($result) && isset($result->orders) ? $result->orders : [];
        $total_pages = is_object($result) && isset($result->max_num_pages) ? (int) $result->max_num_pages : 1;

        $total_orders      = $this->crm_all_order_count();
        $total_revenue     = $this->crm_total_revenue();
        $processing_orders = function_exists('wc_orders_count') ? (int) wc_orders_count('processing') : 0;
        $completed_orders  = function_exists('wc_orders_count') ? (int) wc_orders_count('completed') : 0;
        $payment_methods   = $this->crm_payment_methods();
        ?>
        <section class="mrcp-crm-orders-wrap">
            <header class="mrcp-crm-v103-head mrcp-crm-orders-head">
                <div>
                    <span>Orders CRM</span>
                    <h1>Orders</h1>
                    <p>Search, filter and manage all WooCommerce orders from one place.</p>
                </div>
                <a class="mrcp-crm-v103-date" href="<?php echo esc_url(admin_url('edit.php?post_type=shop_order')); ?>">Open WooCommerce Orders →</a>
            </header>

            <div class="mrcp-crm-orders-stats">
                <?php $this->crm_orders_stat('🛒', 'Total Orders', number_format_i18n($total_orders), 'All order statuses'); ?>
                <?php $this->crm_orders_stat('💰', 'Total Revenue', wp_strip_all_tags($this->money($total_revenue)), 'Processing + completed'); ?>
                <?php $this->crm_orders_stat('📦', 'Processing Orders', number_format_i18n($processing_orders), 'Currently being processed'); ?>
                <?php $this->crm_orders_stat('✅', 'Completed Orders', number_format_i18n($completed_orders), 'Successfully completed'); ?>
            </div>

            <section class="mrcp-panel mrcp-crm-orders-panel">
                <form class="mrcp-crm-orders-filter" method="get" action="<?php echo esc_url($this->url('crm/orders')); ?>">
                    <div class="mrcp-crm-orders-search">
                        <span>⌕</span>
                        <input type="search" name="crm_order_search" value="<?php echo esc_attr($search); ?>" placeholder="Search order number, customer or email">
                    </div>
                    <select name="crm_order_status" aria-label="Order status">
                        <option value="">All statuses</option>
                        <?php foreach (wc_get_order_statuses() as $status_key => $status_label) : $status_value = str_replace('wc-', '', $status_key); ?>
                            <option value="<?php echo esc_attr($status_value); ?>" <?php selected($status, $status_value); ?>><?php echo esc_html($status_label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="crm_order_date" aria-label="Order date">
                        <option value="">All dates</option>
                        <option value="today" <?php selected($date_filter, 'today'); ?>>Today</option>
                        <option value="7days" <?php selected($date_filter, '7days'); ?>>Last 7 days</option>
                        <option value="30days" <?php selected($date_filter, '30days'); ?>>Last 30 days</option>
                    </select>
                    <select name="crm_order_payment" aria-label="Payment method">
                        <option value="">All payment methods</option>
                        <?php foreach ($payment_methods as $method_id => $method_title) : ?>
                            <option value="<?php echo esc_attr($method_id); ?>" <?php selected($payment_method, $method_id); ?>><?php echo esc_html($method_title); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Apply Filters</button>
                    <?php if ($search || $status || $date_filter || $payment_method) : ?>
                        <a class="mrcp-crm-orders-reset" href="<?php echo esc_url($this->url('crm/orders')); ?>">Reset</a>
                    <?php endif; ?>
                </form>

                <div class="mrcp-crm-orders-table-wrap">
                    <table class="mrcp-crm-orders-table">
                        <thead><tr>
                            <th>Order Number</th><th>Customer</th><th>Product</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th>
                        </tr></thead>
                        <tbody>
                        <?php if ($orders) : foreach ($orders as $order) :
                            if (!$order instanceof WC_Order) { continue; }
                            $customer_id = (int) $order->get_customer_id();
                            $customer_name = trim($order->get_formatted_billing_full_name());
                            if (!$customer_name) { $customer_name = $order->get_billing_email() ?: 'Guest Customer'; }
                            $customer_email = $order->get_billing_email();
                            $product_names = [];
                            $order_items = [];
                            foreach ($order->get_items() as $item) {
                                $product_names[] = $item->get_name();
                                $order_items[] = $item;
                            }
                            $date_created = $order->get_date_created();
                            $view_url = $this->url('crm/order/' . $order->get_id());
                            ?>
                            <tr>
                                <td data-label="Order Number"><strong>#<?php echo esc_html($order->get_order_number()); ?></strong></td>
                                <td data-label="Customer">
                                    <div class="mrcp-crm-order-customer">
                                        <?php echo get_avatar($customer_id ?: $customer_email, 38); ?>
                                        <span><strong><?php echo esc_html($customer_name); ?></strong><small><?php echo esc_html($customer_email ?: 'No email'); ?></small></span>
                                    </div>
                                </td>
                                <td data-label="Product">
                                    <div class="mrcp-crm-order-products-list" title="<?php echo esc_attr(implode(', ', $product_names)); ?>">
                                        <?php if ($order_items) : ?>
                                            <?php foreach (array_slice($order_items, 0, 2) as $order_item) : ?>
                                                <div class="mrcp-crm-order-product-entry">
                                                    <strong class="mrcp-crm-order-product-name"><?php echo esc_html($order_item->get_name()); ?></strong>
                                                    <?php if (class_exists('\MRCP\Modules\Orders\LicenseDomainsModule')) { \MRCP\Modules\Orders\LicenseDomainsModule::render_summary($order_item, true, true); } ?>
                                                </div>
                                            <?php endforeach; ?>
                                            <?php if (count($order_items) > 2) : ?>
                                                <small class="mrcp-crm-order-product-more">+<?php echo esc_html((string) (count($order_items) - 2)); ?> more product(s)</small>
                                            <?php endif; ?>
                                        <?php else : ?>
                                            <span>—</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td data-label="Total"><strong class="mrcp-crm-order-total"><?php echo wp_kses_post($this->money($order->get_total())); ?></strong></td>
                                <td data-label="Status"><span class="mrcp-order-status status-<?php echo esc_attr($order->get_status()); ?>"><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></span></td>
                                <td data-label="Date"><?php echo esc_html($date_created ? $date_created->date_i18n('d M Y') : '—'); ?></td>
                                <td data-label="Action"><a class="mrcp-view-btn" href="<?php echo esc_url($view_url); ?>">View Order</a></td>
                            </tr>
                        <?php endforeach; else : ?>
                            <tr><td colspan="7"><div class="mrcp-crm-orders-empty">No orders found for the selected filters.</div></td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php $this->crm_orders_pagination($current_page, $total_pages, [
                    'crm_order_search' => $search,
                    'crm_order_status' => $status,
                    'crm_order_date' => $date_filter,
                    'crm_order_payment' => $payment_method,
                ]); ?>
            </section>
        </section>
        <?php
    }

    private function crm_orders_stat($icon, $label, $value, $description) {
        echo '<article><span>' . esc_html($icon) . '</span><div><small>' . esc_html($label) . '</small><strong>' . esc_html($value) . '</strong><em>' . esc_html($description) . '</em></div></article>';
    }

    private function crm_all_order_count() {
        if (!function_exists('wc_orders_count')) { return 0; }
        $count = 0;
        foreach (array_keys(wc_get_order_statuses()) as $status) {
            $count += (int) wc_orders_count(str_replace('wc-', '', $status));
        }
        return $count;
    }

    private function crm_payment_methods() {
        $methods = [];
        if (function_exists('WC') && WC()->payment_gateways()) {
            foreach (WC()->payment_gateways()->payment_gateways() as $id => $gateway) {
                $methods[sanitize_key($id)] = $gateway->get_title();
            }
        }
        return $methods;
    }

    private function crm_orders_pagination($current, $total, array $filters = []) {
        $total = max(1, (int) $total);
        $current = max(1, min((int) $current, $total));
        if ($total <= 1) { return; }
        $base_url = $this->url('crm/orders');
        $url_for = function ($page) use ($base_url, $filters) {
            $args = array_filter(array_merge($filters, ['crm_order_page' => (int) $page]), static function ($value) { return $value !== '' && $value !== null; });
            return add_query_arg($args, $base_url);
        };
        echo '<nav class="mrcp-crm-orders-pagination" aria-label="Orders pagination">';
        echo $current > 1 ? '<a href="' . esc_url($url_for($current - 1)) . '">← Previous</a>' : '<span class="is-disabled">← Previous</span>';
        $start = max(1, $current - 2); $end = min($total, $current + 2);
        if ($start > 1) { echo '<a href="' . esc_url($url_for(1)) . '">1</a>'; if ($start > 2) { echo '<i>…</i>'; } }
        for ($i = $start; $i <= $end; $i++) { echo $i === $current ? '<strong>' . esc_html($i) . '</strong>' : '<a href="' . esc_url($url_for($i)) . '">' . esc_html($i) . '</a>'; }
        if ($end < $total) { if ($end < $total - 1) { echo '<i>…</i>'; } echo '<a href="' . esc_url($url_for($total)) . '">' . esc_html($total) . '</a>'; }
        echo $current < $total ? '<a href="' . esc_url($url_for($current + 1)) . '">Next →</a>' : '<span class="is-disabled">Next →</span>';
        echo '</nav>';
    }

    private function render_frontend_crm_order_detail_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view CRM order details.</p></section>';
            return;
        }

        if (!function_exists('wc_get_order')) {
            echo '<section class="mrcp-panel"><h2>WooCommerce is required</h2><p>WooCommerce must be active to view this order.</p></section>';
            return;
        }

        $order_id = absint(get_query_var('mrcp_order_id'));
        $order = $order_id ? wc_get_order($order_id) : false;
        if (!$order instanceof \WC_Order) {
            echo '<section class="mrcp-panel"><h2>Order not found</h2><p>The requested order is not available.</p><p><a class="mrcp-view-btn" href="' . esc_url($this->url('crm/orders')) . '">Back to Orders</a></p></section>';
            return;
        }

        $customer_id = (int) $order->get_customer_id();
        $customer = $customer_id ? get_userdata($customer_id) : false;
        $customer_name = trim($order->get_formatted_billing_full_name());
        if (!$customer_name) {
            $customer_name = $customer ? $customer->display_name : ($order->get_billing_email() ?: 'Guest Customer');
        }
        $customer_email = $order->get_billing_email();
        $customer_phone = $order->get_billing_phone();
        $order_date = $order->get_date_created() ? $order->get_date_created()->date_i18n('d M Y, h:i A') : '—';
        $payment_status = $order->is_paid() ? 'Paid' : 'Unpaid';
        $payment_class = $order->is_paid() ? 'is-paid' : 'is-unpaid';
        $lifetime_spend = $customer_id ? $this->crm_customer_spend($customer_id) : (float) $order->get_total();
        $membership = $this->crm_membership_from_spend($lifetime_spend);
        $invoice_url = $this->invoice_url($order_id);
        $customer_url = $customer_id ? $this->url('crm/customers/' . $customer_id) : '';

        $tickets = get_posts([
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'orderby' => 'modified',
            'order' => 'DESC',
            'meta_query' => [[
                'key' => '_mrcp_ticket_order_id',
                'value' => $order_id,
                'compare' => '=',
                'type' => 'NUMERIC',
            ]],
        ]);
        $activations = get_posts([
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'orderby' => 'modified',
            'order' => 'DESC',
            'meta_query' => [[
                'key' => '_mrcp_activation_order_id',
                'value' => $order_id,
                'compare' => '=',
                'type' => 'NUMERIC',
            ]],
        ]);

        $subtotal = (float) $order->get_subtotal();
        $discount = max(0, $subtotal - (float) $order->get_total() + (float) $order->get_shipping_total() + (float) $order->get_total_tax());
        ?>
        <section class="mrcp-crm-order-detail">
            <header class="mrcp-crm-v103-head mrcp-crm-order-detail-head">
                <div>
                    <span>Professional Order Details</span>
                    <h1>Order #<?php echo esc_html($order->get_order_number()); ?></h1>
                    <p>Placed on <?php echo esc_html($order_date); ?></p>
                </div>
                <div class="mrcp-crm-order-head-actions">
                    <a class="mrcp-crm-v103-date" href="<?php echo esc_url($this->url('crm/orders')); ?>">← Back to Orders</a>
                    <?php if ($order->has_status('completed')) : ?><a class="mrcp-view-btn" href="<?php echo esc_url($invoice_url); ?>">Download Invoice</a><?php endif; ?>
                </div>
            </header>

            <section class="mrcp-crm-order-summary-grid">
                <article><small>Custom Order Number</small><strong>#<?php echo esc_html($order->get_order_number()); ?></strong></article>
                <article><small>Order Date</small><strong><?php echo esc_html($order_date); ?></strong></article>
                <article><small>Payment Status</small><strong class="mrcp-payment-badge <?php echo esc_attr($payment_class); ?>"><?php echo esc_html($payment_status); ?></strong></article>
                <article><small>Payment Method</small><strong><?php echo esc_html($order->get_payment_method_title() ?: '—'); ?></strong></article>
                <article><small>Order Status</small><strong class="mrcp-order-status status-<?php echo esc_attr($order->get_status()); ?>"><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></strong></article>
                <article><small>Order Total</small><strong class="mrcp-crm-order-grand-total"><?php echo wp_kses_post($this->money($order->get_total())); ?></strong></article>
            </section>

            <div class="mrcp-crm-order-detail-layout">
                <div class="mrcp-crm-order-detail-main">
                    <section class="mrcp-profile-card mrcp-crm-order-products-card">
                        <header><h2>Product Details</h2><span><?php echo esc_html($order->get_item_count()); ?> item(s)</span></header>
                        <div class="mrcp-crm-order-product-table-wrap">
                            <table class="mrcp-crm-order-product-table">
                                <thead><tr><th>Product</th><th>Quantity</th><th>Unit Price</th><th>Discount</th><th>Total</th></tr></thead>
                                <tbody>
                                <?php foreach ($order->get_items('line_item') as $item) :
                                    $product = $item->get_product();
                                    $qty = max(1, (int) $item->get_quantity());
                                    $line_subtotal = (float) $item->get_subtotal();
                                    $line_total = (float) $item->get_total();
                                    $unit_price = $line_subtotal / $qty;
                                    $line_discount = max(0, $line_subtotal - $line_total);
                                    ?>
                                    <tr>
                                        <td data-label="Product"><div class="mrcp-crm-product-cell"><?php echo $product ? wp_kses_post($product->get_image([46,46])) : '<span>📦</span>'; ?><div><strong><?php echo esc_html($item->get_name()); ?></strong><?php if ($product && $product->get_sku()) : ?><small>SKU: <?php echo esc_html($product->get_sku()); ?></small><?php endif; ?><?php if (class_exists('\MRCP\Modules\Orders\LicenseDomainsModule')) { \MRCP\Modules\Orders\LicenseDomainsModule::render_badges($item); } ?></div></div></td>
                                        <td data-label="Quantity"><?php echo esc_html($qty); ?></td>
                                        <td data-label="Unit Price"><?php echo wp_kses_post($this->money($unit_price)); ?></td>
                                        <td data-label="Discount"><?php echo wp_kses_post($this->money($line_discount)); ?></td>
                                        <td data-label="Total"><strong><?php echo wp_kses_post($this->money($line_total)); ?></strong></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mrcp-crm-order-total-box">
                            <p><span>Subtotal</span><strong><?php echo wp_kses_post($this->money($subtotal)); ?></strong></p>
                            <p><span>Discount</span><strong>-<?php echo wp_kses_post($this->money($discount)); ?></strong></p>
                            <?php if ((float) $order->get_shipping_total() > 0) : ?><p><span>Shipping</span><strong><?php echo wp_kses_post($this->money($order->get_shipping_total())); ?></strong></p><?php endif; ?>
                            <?php if ((float) $order->get_total_tax() > 0) : ?><p><span>Tax</span><strong><?php echo wp_kses_post($this->money($order->get_total_tax())); ?></strong></p><?php endif; ?>
                            <p class="is-total"><span>Order Total</span><strong><?php echo wp_kses_post($this->money($order->get_total())); ?></strong></p>
                        </div>
                    </section>

                    <section class="mrcp-crm-order-related-grid">
                        <article class="mrcp-profile-card">
                            <header><h2>Related Support Tickets</h2><a href="<?php echo esc_url($this->url('support')); ?>">View all →</a></header>
                            <?php if ($tickets) : ?><div class="mrcp-crm-related-list">
                                <?php foreach ($tickets as $ticket) : $status = get_post_meta($ticket->ID, '_mrcp_ticket_status', true) ?: 'open'; ?>
                                    <a href="<?php echo esc_url($this->url('ticket/' . $ticket->ID)); ?>"><span><strong>MR-<?php echo esc_html($ticket->ID); ?></strong><small><?php echo esc_html($ticket->post_title); ?></small></span><em class="status-<?php echo esc_attr($status); ?>"><?php echo esc_html(ucwords(str_replace('_',' ',$status))); ?></em></a>
                                <?php endforeach; ?></div><?php else : ?><p class="mrcp-profile-empty">No support tickets are linked to this order.</p><?php endif; ?>
                        </article>
                        <article class="mrcp-profile-card">
                            <header><h2>Related Activation Requests</h2><a href="<?php echo esc_url($this->url('activation')); ?>">View all →</a></header>
                            <?php if ($activations) : ?><div class="mrcp-crm-related-list">
                                <?php foreach ($activations as $activation) : $status = get_post_meta($activation->ID, '_mrcp_activation_status', true) ?: 'pending'; $product = get_post_meta($activation->ID, '_mrcp_activation_product', true) ?: $activation->post_title; ?>
                                    <a href="<?php echo esc_url($this->url('activation/' . $activation->ID)); ?>"><span><strong>ACT-<?php echo esc_html($activation->ID); ?></strong><small><?php echo esc_html($product); ?></small></span><em class="status-<?php echo esc_attr($status); ?>"><?php echo esc_html(ucwords(str_replace('_',' ',$status))); ?></em></a>
                                <?php endforeach; ?></div><?php else : ?><p class="mrcp-profile-empty">No activation requests are linked to this order.</p><?php endif; ?>
                        </article>
                    </section>
                </div>

                <aside class="mrcp-crm-order-detail-side">
                    <section class="mrcp-profile-card">
                        <header><h2>Customer Information</h2><?php if ($customer_url) : ?><a href="<?php echo esc_url($customer_url); ?>">View Profile →</a><?php endif; ?></header>
                        <div class="mrcp-crm-order-customer-card">
                            <?php echo get_avatar($customer_id ?: $customer_email, 68); ?>
                            <div><strong><?php echo esc_html($customer_name); ?></strong><small><?php echo esc_html($customer_email ?: 'No email'); ?></small><?php echo wp_kses_post($this->crm_membership_badge($membership)); ?></div>
                        </div>
                        <div class="mrcp-profile-info-list">
                            <p><span>Phone</span><strong><?php echo esc_html($customer_phone ?: '—'); ?></strong></p>
                            <p><span>Lifetime Spend</span><strong>৳ <?php echo esc_html(number_format_i18n(round($lifetime_spend), 0)); ?></strong></p>
                            <p><span>Membership</span><strong><?php echo esc_html($membership['label']); ?></strong></p>
                        </div>
                    </section>

                    <section class="mrcp-profile-card">
                        <header><h2>Billing Address</h2></header>
                        <div class="mrcp-crm-billing-address"><?php echo wp_kses_post($order->get_formatted_billing_address() ?: '<p>No billing address available.</p>'); ?></div>
                        <?php if ($customer_email || $customer_phone) : ?><p class="mrcp-order-contact"><?php if ($customer_email) : ?>Email: <?php echo esc_html($customer_email); ?><br><?php endif; ?><?php if ($customer_phone) : ?>Phone: <?php echo esc_html($customer_phone); ?><?php endif; ?></p><?php endif; ?>
                    </section>

                    <section class="mrcp-profile-card mrcp-crm-order-quick-actions">
                        <header><h2>Quick Actions</h2></header>
                        <?php if ($order->has_status('completed')) : ?><a href="<?php echo esc_url($invoice_url); ?>">🧾 View / Download Invoice</a><?php endif; ?>
                        <?php if ($customer_url) : ?><a href="<?php echo esc_url($customer_url); ?>">👤 Customer Profile</a><?php endif; ?>
                        <a href="<?php echo esc_url($this->url('support')); ?>">🎫 Support Tickets</a>
                        <a href="<?php echo esc_url($this->url('activation')); ?>">🔑 Activation Requests</a>
                    </section>
                </aside>
            </div>
        </section>
        <?php
    }

    public function clear_crm_membership_analytics_cache() {
        delete_transient('mrcp_crm_membership_analytics_v150');
    }

    private function crm_membership_discount_from_order($order) {
        if (!is_a($order, 'WC_Order')) return 0.0;
        $discount = 0.0;
        foreach ($order->get_items('fee') as $fee) {
            $name = strtolower((string) $fee->get_name());
            $total = (float) $fee->get_total();
            if ($total < 0 && strpos($name, 'membership discount') !== false) {
                $discount += abs($total);
            }
        }
        return $discount;
    }

    private function crm_membership_analytics_dataset() {
        $cached = get_transient('mrcp_crm_membership_analytics_v150');
        if (is_array($cached) && isset($cached['rows'], $cached['summary'])) return $cached;

        $users = get_users([
            'role__in' => ['customer', 'subscriber'],
            'fields' => ['ID', 'display_name', 'user_email', 'user_registered', 'user_login'],
            'orderby' => 'registered',
            'order' => 'DESC',
        ]);
        $order_data = [];
        if ($this->wc_active()) {
            $page = 1;
            $limit = 100;
            do {
                $orders = wc_get_orders([
                    'status' => ['completed'],
                    'limit' => $limit,
                    'paged' => $page,
                    'return' => 'objects',
                    'orderby' => 'date',
                    'order' => 'DESC',
                ]);
                if (!$orders) break;
                foreach ($orders as $order) {
                    if (!is_a($order, 'WC_Order')) continue;
                    $uid = (int) $order->get_customer_id();
                    if ($uid < 1) continue;
                    if (!isset($order_data[$uid])) $order_data[$uid] = ['orders' => 0, 'discount' => 0.0];
                    $order_data[$uid]['orders']++;
                    $order_data[$uid]['discount'] += $this->crm_membership_discount_from_order($order);
                }
                $page++;
            } while (count($orders) === $limit);
        }

        $rows = [];
        $summary = [
            'total_members' => 0,
            'silver' => 0,
            'gold' => 0,
            'diamond' => 0,
            'vip' => 0,
            'total_orders' => 0,
            'total_spent' => 0.0,
            'total_discount' => 0.0,
            'discount_sum_percent' => 0,
        ];

        foreach ($users as $user) {
            $uid = (int) $user->ID;
            $membership = class_exists('MRCP_Membership')
                ? MRCP_Membership::get_customer_membership($uid)
                : $this->membership_data(function_exists('wc_get_customer_total_spent') ? wc_get_customer_total_spent($uid) : 0);
            $level = !empty($membership['key']) ? sanitize_key($membership['key']) : 'silver';
            if (!in_array($level, ['silver','gold','diamond','vip'], true)) $level = 'silver';
            $spent = isset($membership['spent']) ? (float) $membership['spent'] : 0.0;
            $discount_percent = isset($membership['discount']) ? (int) $membership['discount'] : 0;
            $actual = $order_data[$uid] ?? ['orders' => 0, 'discount' => 0.0];
            $status = sanitize_key((string) get_user_meta($uid, '_mrcp_membership_status', true));
            if (!in_array($status, ['active','inactive'], true)) $status = 'active';

            $rows[] = [
                'user_id' => $uid,
                'name' => $user->display_name ?: $user->user_login,
                'email' => $user->user_email,
                'registered' => $user->user_registered,
                'avatar' => get_avatar_url($uid, ['size' => 80]),
                'level' => $level,
                'label' => !empty($membership['short']) ? $membership['short'] : ucfirst($level),
                'icon' => !empty($membership['icon']) ? $membership['icon'] : '🥈',
                'orders' => (int) $actual['orders'],
                'spent' => $spent,
                'discount_percent' => $discount_percent,
                'discount_received' => round((float) $actual['discount'], 2),
                'status' => $status,
            ];
            $summary['total_members']++;
            $summary[$level]++;
            $summary['total_orders'] += (int) $actual['orders'];
            $summary['total_spent'] += $spent;
            $summary['total_discount'] += (float) $actual['discount'];
            $summary['discount_sum_percent'] += $discount_percent;
        }
        $summary['average_discount'] = $summary['total_members'] > 0
            ? round($summary['discount_sum_percent'] / $summary['total_members'], 2)
            : 0;
        $dataset = ['rows' => $rows, 'summary' => $summary];
        set_transient('mrcp_crm_membership_analytics_v150', $dataset, 15 * MINUTE_IN_SECONDS);
        return $dataset;
    }

    private function crm_membership_filtered_rows($rows, $search, $level, $status) {
        $search_lc = function_exists('mb_strtolower') ? mb_strtolower($search) : strtolower($search);
        return array_values(array_filter($rows, static function($row) use ($search_lc, $level, $status) {
            if ($level && $row['level'] !== $level) return false;
            if ($status && $row['status'] !== $status) return false;
            if ($search_lc !== '') {
                $haystack = $row['name'] . ' ' . $row['email'];
                $haystack = function_exists('mb_strtolower') ? mb_strtolower($haystack) : strtolower($haystack);
                if (strpos($haystack, $search_lc) === false) return false;
            }
            return true;
        }));
    }

    public function maybe_export_membership_csv() {
        if (!function_exists('mrc_can') || !mrc_can('crm.exports') || !mrc_can('digital.membership')) {
            return;
        }
        if (!get_query_var('mrcp_dashboard') || get_query_var('mrcp_section') !== 'crm-membership') return;
        if (empty($_GET['mrcp_membership_export'])) return;
        if (!$this->is_support_admin()) wp_die('Access denied.');
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'mrcp_export_membership')) wp_die('Security check failed.');
        $dataset = $this->crm_membership_analytics_dataset();
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=mrcp-membership-report-' . gmdate('Y-m-d') . '.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Member','Email','Membership','Member Since','Completed Orders','Lifetime Spend','Current Discount','Total Discount Received','Status']);
        foreach ($dataset['rows'] as $row) {
            fputcsv($out, [$row['name'],$row['email'],$row['label'],$row['registered'],$row['orders'],$row['spent'],$row['discount_percent'] . '%',$row['discount_received'],ucfirst($row['status'])]);
        }
        fclose($out);
        exit;
    }

    private function render_frontend_crm_membership_page() {
        if (!$this->is_support_admin()) {
            echo '<section class="mrcp-panel"><h2>Access denied</h2><p>You do not have permission to view membership analytics.</p></section>';
            return;
        }
        $search = isset($_GET['mrcp_member_search']) ? sanitize_text_field(wp_unslash($_GET['mrcp_member_search'])) : '';
        $level = isset($_GET['mrcp_membership']) ? sanitize_key(wp_unslash($_GET['mrcp_membership'])) : '';
        $status = isset($_GET['mrcp_member_status']) ? sanitize_key(wp_unslash($_GET['mrcp_member_status'])) : '';
        $paged = isset($_GET['mrcp_page']) ? max(1, absint($_GET['mrcp_page'])) : 1;
        if (!in_array($level, ['', 'silver','gold','diamond','vip'], true)) $level = '';
        if (!in_array($status, ['', 'active','inactive'], true)) $status = '';
        $dataset = $this->crm_membership_analytics_dataset();
        $summary = $dataset['summary'];
        $filtered = $this->crm_membership_filtered_rows($dataset['rows'], $search, $level, $status);
        $per_page = 20;
        $total_pages = max(1, (int) ceil(count($filtered) / $per_page));
        $paged = min($paged, $total_pages);
        $rows = array_slice($filtered, ($paged - 1) * $per_page, $per_page);
        $export_url = wp_nonce_url(add_query_arg('mrcp_membership_export', 1, $this->url('crm/membership')), 'mrcp_export_membership');
        ?>
        <section class="mrcp-membership-admin-v15">
            <header class="mrcp-membership-admin-head">
                <div><span>Customer CRM</span><h1>Membership Overview</h1><p>View every member, tier, spending, discount rate and actual membership discount received.</p></div>
                <div class="mrcp-membership-admin-actions"><a href="<?php echo esc_url($export_url); ?>">⇩ Export Report</a><a href="<?php echo esc_url($this->url('crm')); ?>">← CRM Dashboard</a></div>
            </header>
            <section class="mrcp-membership-admin-kpis">
                <article><i>👥</i><strong><?php echo esc_html(number_format_i18n($summary['total_members'])); ?></strong><b>Total Members</b><small>All registered customer members</small></article>
                <article class="is-gold"><i>🥇</i><strong><?php echo esc_html(number_format_i18n($summary['gold'])); ?></strong><b>Gold Members</b><small><?php echo esc_html($summary['total_members'] ? number_format_i18n(($summary['gold']/$summary['total_members'])*100,1) : 0); ?>% of total members</small></article>
                <article class="is-diamond"><i>💎</i><strong><?php echo esc_html(number_format_i18n($summary['diamond'])); ?></strong><b>Diamond Members</b><small><?php echo esc_html($summary['total_members'] ? number_format_i18n(($summary['diamond']/$summary['total_members'])*100,1) : 0); ?>% of total members</small></article>
                <article class="is-vip"><i>⭐</i><strong><?php echo esc_html(number_format_i18n($summary['vip'])); ?></strong><b>VIP Members</b><small><?php echo esc_html($summary['total_members'] ? number_format_i18n(($summary['vip']/$summary['total_members'])*100,1) : 0); ?>% of total members</small></article>
                <article class="is-discount"><i>💵</i><strong><?php echo wp_kses_post($this->money($summary['total_discount'])); ?></strong><b>Total Discount Given</b><small>Actual membership discount fees</small></article>
            </section>
            <section class="mrcp-membership-admin-panel">
                <div class="mrcp-membership-admin-toolbar">
                    <div><h2>All Members (<?php echo esc_html(number_format_i18n(count($filtered))); ?>)</h2><p>Complete overview of membership level, spending and discounts.</p></div>
                    <form method="get" action="<?php echo esc_url($this->url('crm/membership')); ?>">
                        <select name="mrcp_membership"><option value="">All Memberships</option><?php foreach (['silver'=>'Silver','gold'=>'Gold','diamond'=>'Diamond','vip'=>'VIP'] as $k=>$v): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($level,$k); ?>><?php echo esc_html($v); ?></option><?php endforeach; ?></select>
                        <select name="mrcp_member_status"><option value="">All Status</option><option value="active" <?php selected($status,'active'); ?>>Active</option><option value="inactive" <?php selected($status,'inactive'); ?>>Inactive</option></select>
                        <input type="search" name="mrcp_member_search" value="<?php echo esc_attr($search); ?>" placeholder="Search members...">
                        <button type="submit">Search</button>
                        <?php if ($search || $level || $status): ?><a href="<?php echo esc_url($this->url('crm/membership')); ?>">Reset</a><?php endif; ?>
                    </form>
                </div>
                <div class="mrcp-membership-admin-table-wrap"><table><thead><tr><th>Member</th><th>Membership</th><th>Member Since</th><th>Orders</th><th>Total Spent</th><th>Current Discount</th><th>Discount Received</th><th>Status</th><th>Action</th></tr></thead><tbody>
                <?php if ($rows): foreach ($rows as $row): ?>
                    <tr><td><div class="mrcp-member-person"><img src="<?php echo esc_url($row['avatar']); ?>" alt=""><div><strong><?php echo esc_html($row['name']); ?></strong><small><?php echo esc_html($row['email']); ?></small></div></div></td>
                    <td><span class="mrcp-member-level is-<?php echo esc_attr($row['level']); ?>"><?php echo esc_html($row['icon'].' '.$row['label']); ?></span></td>
                    <td><strong><?php echo esc_html(date_i18n('M d, Y', strtotime($row['registered']))); ?></strong><small><?php echo esc_html(human_time_diff(strtotime($row['registered']), current_time('timestamp'))); ?> ago</small></td>
                    <td><strong><?php echo esc_html(number_format_i18n($row['orders'])); ?></strong></td>
                    <td><strong><?php echo wp_kses_post($this->money($row['spent'])); ?></strong></td>
                    <td><strong class="mrcp-discount-rate"><?php echo esc_html($row['discount_percent']); ?>%</strong></td>
                    <td><strong class="mrcp-discount-money"><?php echo wp_kses_post($this->money($row['discount_received'])); ?></strong></td>
                    <td><span class="mrcp-member-status is-<?php echo esc_attr($row['status']); ?>"><?php echo esc_html(ucfirst($row['status'])); ?></span></td>
                    <td><a class="mrcp-member-view" href="<?php echo esc_url($this->url('crm/customers/'.$row['user_id'])); ?>">View</a></td></tr>
                <?php endforeach; else: ?><tr><td colspan="9"><div class="mrcp-membership-empty">No members found.</div></td></tr><?php endif; ?>
                </tbody></table></div>
                <div class="mrcp-membership-admin-summary"><div><span>👥</span><small>Total Members</small><strong><?php echo esc_html(number_format_i18n($summary['total_members'])); ?></strong></div><div><span>🛒</span><small>Total Orders</small><strong><?php echo esc_html(number_format_i18n($summary['total_orders'])); ?></strong></div><div><span>🪙</span><small>Total Spent</small><strong><?php echo wp_kses_post($this->money($summary['total_spent'])); ?></strong></div><div><span>🏷</span><small>Total Discount Given</small><strong><?php echo wp_kses_post($this->money($summary['total_discount'])); ?></strong></div><div><span>％</span><small>Average Discount</small><strong><?php echo esc_html(number_format_i18n($summary['average_discount'],2)); ?>%</strong></div></div>
                <?php if ($total_pages > 1): ?><nav class="mrcp-membership-pagination"><?php echo wp_kses_post(paginate_links(['base'=>add_query_arg('mrcp_page','%#%'),'format'=>'','current'=>$paged,'total'=>$total_pages,'type'=>'list'])); ?></nav><?php endif; ?>
            </section>
            <div class="mrcp-membership-admin-note"><span>ⓘ</span> Discount is automatically applied based on membership level during checkout.<a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings')); ?>">Manage Membership Settings</a></div>
        </section>
        <?php
    }

    public function clear_crm_product_performance_cache() {
        delete_transient('mrcp_crm_product_performance_v16');
    }

    private function crm_product_performance_analytics() {
        if (!class_exists('\MRCP\Services\ProductIntelligenceService')) {
            return [];
        }

        $source = \MRCP\Services\ProductIntelligenceService::get_all();
        $rows = [];
        foreach ($source as $product_id => $row) {
            $rows[(int) $product_id] = [
                'product_id' => (int) $product_id,
                'lifetime' => [
                    'sold' => (float) $row['periods']['lifetime']['sold'],
                    'earned' => (float) $row['periods']['lifetime']['revenue'],
                ],
                'year' => [
                    'sold' => (float) $row['periods']['year']['sold'],
                    'earned' => (float) $row['periods']['year']['revenue'],
                ],
                'month' => [
                    'sold' => (float) $row['periods']['month']['sold'],
                    'earned' => (float) $row['periods']['month']['revenue'],
                ],
                'week' => [
                    'sold' => (float) $row['periods']['week']['sold'],
                    'earned' => (float) $row['periods']['week']['revenue'],
                ],
                'customer_count' => (int) $row['customer_count'],
                'active_domain_count' => (int) $row['active_domain_count'],
                'license_count' => (int) $row['license_count'],
                'variation_count' => (int) $row['variation_count'],
                'average_selling_price' => (float) $row['average_selling_price'],
                'variations' => $row['variations'],
            ];
        }
        return $rows;
    }

    private function crm_product_price_html($product) {
        if (!$product instanceof WC_Product) {
            return '—';
        }
        $price = $product->get_price_html();
        return $price ? $price : '—';
    }

    private function render_frontend_crm_products_page() {
        if (!$this->is_support_admin()) {
            wp_die(esc_html__('You do not have permission to view product analytics.', 'mr-customer-portal-pro'));
        }

        $analytics = $this->crm_product_performance_analytics();
        $search = isset($_GET['mrcp_product_search']) ? sanitize_text_field(wp_unslash($_GET['mrcp_product_search'])) : '';
        $category = isset($_GET['mrcp_product_category']) ? absint($_GET['mrcp_product_category']) : 0;
        $status = isset($_GET['mrcp_product_status']) ? sanitize_key(wp_unslash($_GET['mrcp_product_status'])) : 'all';
        $sort = isset($_GET['mrcp_product_sort']) ? sanitize_key(wp_unslash($_GET['mrcp_product_sort'])) : 'lifetime_earned';
        $paged = max(1, isset($_GET['mrcp_page']) ? absint($_GET['mrcp_page']) : 1);
        $per_page = 20;

        $product_statuses = ['publish', 'private', 'draft', 'pending'];
        $query_args = [
            'post_type'      => 'product',
            'post_status'    => $status !== 'all' && in_array($status, $product_statuses, true) ? $status : $product_statuses,
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'orderby'        => 'title',
            'order'          => 'ASC',
        ];
        if ($search !== '') {
            $query_args['s'] = $search;
        }
        if ($category > 0) {
            $query_args['tax_query'] = [[
                'taxonomy' => 'product_cat',
                'field'    => 'term_id',
                'terms'    => [$category],
            ]];
        }

        $product_ids = get_posts($query_args);
        $products = [];
        $totals = ['products' => 0, 'lifetime_sold' => 0.0, 'lifetime_earned' => 0.0];
        foreach ($product_ids as $product_id) {
            $product = wc_get_product($product_id);
            if (!$product) {
                continue;
            }
            $metrics = $analytics[$product_id] ?? [
                'lifetime' => ['sold' => 0, 'earned' => 0],
                'year'     => ['sold' => 0, 'earned' => 0],
                'month'    => ['sold' => 0, 'earned' => 0],
                'week'     => ['sold' => 0, 'earned' => 0],
            ];
            $products[] = ['product' => $product, 'metrics' => $metrics];
            $totals['products']++;
            $totals['lifetime_sold'] += $metrics['lifetime']['sold'];
            $totals['lifetime_earned'] += $metrics['lifetime']['earned'];
        }

        $sort_map = [
            'lifetime_earned' => ['lifetime', 'earned'],
            'lifetime_sold'   => ['lifetime', 'sold'],
            'year_earned'     => ['year', 'earned'],
            'year_sold'       => ['year', 'sold'],
            'month_earned'    => ['month', 'earned'],
            'month_sold'      => ['month', 'sold'],
            'week_earned'     => ['week', 'earned'],
            'week_sold'       => ['week', 'sold'],
        ];
        [$sort_period, $sort_metric] = $sort_map[$sort] ?? $sort_map['lifetime_earned'];
        usort($products, static function ($a, $b) use ($sort_period, $sort_metric) {
            $av = (float) $a['metrics'][$sort_period][$sort_metric];
            $bv = (float) $b['metrics'][$sort_period][$sort_metric];
            if ($av === $bv) {
                return strcasecmp($a['product']->get_name(), $b['product']->get_name());
            }
            return $bv <=> $av;
        });

        $best = $products ? $products[0]['product'] : null;
        $total_items = count($products);
        $total_pages = max(1, (int) ceil($total_items / $per_page));
        if ($paged > $total_pages) {
            $paged = $total_pages;
        }
        $products_page = array_slice($products, ($paged - 1) * $per_page, $per_page);
        $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false]);
        ?>
        <section class="mrcp-products-v16">
            <header class="mrcp-products-v16-head">
                <div><span>PRODUCT ANALYTICS</span><h1>Product Performance Center</h1><p>Track product prices, sales volume and net revenue across lifetime, year, month and week.</p></div>
                <a href="<?php echo esc_url(admin_url('post-new.php?post_type=product')); ?>">＋ Add Product</a>
            </header>

            <div class="mrcp-products-v16-kpis">
                <article><i>📦</i><div><small>Total Products</small><strong><?php echo esc_html(number_format_i18n($totals['products'])); ?></strong><span>Products in current result</span></div></article>
                <article><i>🛒</i><div><small>Lifetime Sold</small><strong><?php echo esc_html(number_format_i18n($totals['lifetime_sold'])); ?></strong><span>Net units from paid orders</span></div></article>
                <article><i>💰</i><div><small>Lifetime Earned</small><strong><?php echo wp_kses_post($this->money($totals['lifetime_earned'])); ?></strong><span>Net line revenue, excluding tax</span></div></article>
                <article><i>🏆</i><div><small>Best Seller</small><strong><?php echo esc_html($best ? $best->get_name() : '—'); ?></strong><span>Based on selected sort</span></div></article>
            </div>

            <section class="mrcp-products-v16-panel">
                <form class="mrcp-products-v16-filters" method="get" action="<?php echo esc_url($this->url('crm/products')); ?>">
                    <label><span>⌕</span><input type="search" name="mrcp_product_search" value="<?php echo esc_attr($search); ?>" placeholder="Search product name or keyword..."></label>
                    <select name="mrcp_product_category"><option value="0">All categories</option><?php foreach ($categories as $term): ?><option value="<?php echo esc_attr($term->term_id); ?>" <?php selected($category, $term->term_id); ?>><?php echo esc_html($term->name); ?></option><?php endforeach; ?></select>
                    <select name="mrcp_product_status"><option value="all">All statuses</option><option value="publish" <?php selected($status, 'publish'); ?>>Published</option><option value="draft" <?php selected($status, 'draft'); ?>>Draft</option><option value="private" <?php selected($status, 'private'); ?>>Private</option><option value="pending" <?php selected($status, 'pending'); ?>>Pending</option></select>
                    <select name="mrcp_product_sort"><option value="lifetime_earned" <?php selected($sort, 'lifetime_earned'); ?>>Sort: Lifetime earned</option><option value="lifetime_sold" <?php selected($sort, 'lifetime_sold'); ?>>Sort: Lifetime sold</option><option value="year_earned" <?php selected($sort, 'year_earned'); ?>>Sort: Year earned</option><option value="month_earned" <?php selected($sort, 'month_earned'); ?>>Sort: Month earned</option><option value="week_earned" <?php selected($sort, 'week_earned'); ?>>Sort: Week earned</option></select>
                    <button type="submit">Apply Filters</button>
                    <?php if ($search !== '' || $category || $status !== 'all' || $sort !== 'lifetime_earned'): ?><a href="<?php echo esc_url($this->url('crm/products')); ?>">Reset</a><?php endif; ?>
                </form>

                <div class="mrcp-products-v16-table-wrap">
                    <table class="mrcp-products-v16-table">
                        <thead><tr><th>Product</th><th>Price</th><th>Lifetime</th><th>This Year</th><th>This Month</th><th>This Week</th><th>Status</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php if ($products_page): foreach ($products_page as $row): $product = $row['product']; $metrics = $row['metrics']; ?>
                            <tr>
                                <td><div class="mrcp-products-v16-product"><img src="<?php echo esc_url(wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') ?: wc_placeholder_img_src('thumbnail')); ?>" alt=""><div><strong><?php echo esc_html($product->get_name()); ?></strong><small><?php echo esc_html($product->get_sku() ? 'SKU: '.$product->get_sku() : 'Product #'.$product->get_id()); ?></small></div></div></td>
                                <td><div class="mrcp-products-v16-price"><?php echo wp_kses_post($this->crm_product_price_html($product)); ?></div></td>
                                <?php foreach (['lifetime', 'year', 'month', 'week'] as $period): ?><td><div class="mrcp-products-v16-metric"><small>Sold</small><strong><?php echo esc_html(number_format_i18n($metrics[$period]['sold'])); ?></strong><small>Earned</small><b><?php echo wp_kses_post($this->money($metrics[$period]['earned'])); ?></b></div></td><?php endforeach; ?>
                                <td><span class="mrcp-products-v16-status is-<?php echo esc_attr($product->get_status()); ?>"><?php echo esc_html(ucfirst($product->get_status())); ?></span></td>
                                <td><div class="mrcp-products-v16-actions"><a href="<?php echo esc_url(get_edit_post_link($product->get_id())); ?>">Manage</a><a class="is-secondary" href="<?php echo esc_url($product->get_permalink()); ?>" target="_blank" rel="noopener">View</a></div></td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="7"><div class="mrcp-products-v16-empty">No products found for the selected filters.</div></td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_pages > 1): ?>
                    <nav class="mrcp-products-v16-pagination"><?php echo wp_kses_post(paginate_links(['base' => add_query_arg('mrcp_page', '%#%'), 'format' => '', 'current' => $paged, 'total' => $total_pages, 'type' => 'list'])); ?></nav>
                <?php endif; ?>
            </section>
        </section>
        <?php
    }

    private function render_crm_sidebar($section) {
        $pending_activations = $this->activation_admin_count('pending');
        $pending_tickets = $this->crm_pending_ticket_count();
        $top_products = $this->crm_top_selling_products(5);
        $current_user = wp_get_current_user();
        ?>
        <a class="mrcp-logo mrcp-logo-image mrcp-crm-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Mehedi Rahat Home">
            <img src="<?php echo esc_url(MRCP_PLUGIN_URL . 'assets/images/mehedi-rahat-logo.png'); ?>" alt="Mehedi Rahat - Digital Growth Partner">
        </a>

        <div class="mrcp-v125-sidebar-user">
            <?php echo get_avatar($current_user->ID, 46, '', $current_user->display_name, ['loading' => 'lazy']); ?>
            <div>
                <small>Signed in as</small>
                <strong><?php echo esc_html($current_user->display_name ?: $current_user->user_login); ?></strong>
                <span><i></i> Administrator</span>
            </div>
        </div>

        <nav class="mrcp-nav mrcp-crm-nav">
            <span class="mrcp-v125-nav-label">Main</span>
            <?php $this->crm_nav_item('⌂', 'Dashboard', $this->url(), false); ?>
            <?php $this->crm_nav_item('⌘', 'CRM Dashboard', $this->url('crm'), $section === 'crm'); ?>

            <span class="mrcp-v125-nav-label">Customers</span>
            <?php $this->crm_nav_item('♙', 'Customers', $this->url('crm/customers'), $section === 'crm-customers'); ?>
            <?php $this->crm_nav_item('▣', 'Orders', $this->url('crm/orders'), in_array($section, ['crm-orders','crm-order-view'], true)); ?>
            <?php $this->crm_nav_item('♛', 'Membership', $this->url('crm/membership'), $section === 'crm-membership'); ?>

            <span class="mrcp-v125-nav-label">Operations</span>
            <?php $this->crm_nav_item('▤', 'Activation Requests', $this->url('activation'), false, $pending_activations); ?>
            <?php $this->crm_nav_item('▧', 'Support Tickets', $this->url('support'), false, $pending_tickets); ?>

            <span class="mrcp-v125-nav-label">Business</span>
            <?php $this->crm_nav_item('◇', 'Products', $this->url('crm/products'), $section === 'crm-products'); ?>
            <?php $this->crm_nav_item('⌁', 'Announcements', admin_url('edit.php'), false); ?>
            <?php $this->crm_nav_item('♜', 'Reports', $this->url('crm/reports'), $section === 'crm-reports'); ?>
            <?php $this->crm_nav_item('✉', 'Email Campaigns', '#', false); ?>

            <span class="mrcp-v125-nav-label">System</span>
            <?php $this->crm_nav_item('⚙', 'Settings', admin_url('admin.php?page=wc-settings'), false); ?>
            <?php $this->crm_nav_item('♚', 'Users', admin_url('users.php'), false); ?>
            <?php $this->crm_nav_item('⌘', 'Tools', admin_url('tools.php'), false); ?>
        </nav>

        <div class="mrcp-crm-quick-actions mrcp-v125-quick-actions">
            <h3><span>⚡</span> Quick Actions</h3>
            <a href="<?php echo esc_url(admin_url('user-new.php')); ?>"><span>♙</span> Add New Customer <b>›</b></a>
            <a href="<?php echo esc_url(admin_url('post-new.php')); ?>"><span>▧</span> Create Announcement <b>›</b></a>
            <a href="mailto:support@mehedirahat.com"><span>✉</span> Send Email <b>›</b></a>
        </div>
        <?php
    }

    private function crm_nav_item($icon, $label, $url, $active = false, $badge = null, $suffix = '') {
        echo '<a class="mrcp-crm-nav-item ' . ($active ? 'is-active' : '') . '" href="' . esc_url($url) . '">';
        echo '<span class="mrcp-crm-nav-icon">' . esc_html($icon) . '</span>';
        echo '<strong>' . esc_html($label) . '</strong>';
        if ($badge !== null && (int) $badge > 0) {
            echo '<em>' . esc_html((string) (int) $badge) . '</em>';
        }
        if ($suffix) {
            echo '<i>' . esc_html($suffix) . '</i>';
        }
        echo '</a>';
    }

    private function nav_item($icon, $label, $url, $active = false, $badge = null) {
        echo '<a class="mrcp-nav-item ' . ($active ? 'is-active' : '') . '" href="' . esc_url($url) . '"><span>' . esc_html($icon) . '</span><strong>' . esc_html($label) . '</strong>';
        if ($badge !== null && (int)$badge >= 0 && in_array($label, ['Orders', 'Downloads', 'Support Tickets', 'Activation Requests'], true)) {
            echo '<em>' . esc_html((string)(int)$badge) . '</em>';
        }
        echo '</a>';
    }

    private function stat_card($icon, $number, $label, $link_text, $url, $is_money = false) {
        echo '<article class="mrcp-stat"><div class="mrcp-stat-icon">' . $this->premium_icon($icon) . '</div><h3 class="' . ($is_money ? 'is-money' : '') . '">' . wp_kses_post($number) . '</h3><p>' . esc_html($label) . '</p><a href="' . esc_url($url) . '">' . esc_html($link_text) . '</a></article>';
    }

    private function action_card($icon, $title, $desc, $btn, $url) {
        echo '<a class="mrcp-action" href="' . esc_url($url) . '"><span>' . $this->premium_icon($icon) . '</span><h3>' . esc_html($title) . '</h3><p>' . esc_html($desc) . '</p><b>' . esc_html($btn) . '</b></a>';
    }

    private function order_thumbnail_data($order): array {
        $fallback = function_exists('wc_placeholder_img_src') ? wc_placeholder_img_src('woocommerce_thumbnail') : '';
        $data = [
            'url'  => $fallback,
            'name' => 'WooCommerce Product',
            'more' => 0,
        ];

        if (!$order || !is_a($order, 'WC_Order')) return $data;

        $items = $order->get_items('line_item');
        $count = count($items);
        foreach ($items as $item) {
            if (!$item instanceof WC_Order_Item_Product) continue;
            $product = $item->get_product();
            $data['name'] = $item->get_name() ?: 'WooCommerce Product';
            $data['more'] = max(0, $count - 1);
            if ($product) {
                $image_id = $product->get_image_id();
                if ($image_id) {
                    $image_url = wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail');
                    if ($image_url) $data['url'] = $image_url;
                }
            }
            break;
        }

        return $data;
    }

    private function order_row($order, $show_actions = true) {
        if (!$order || !is_a($order, 'WC_Order')) return;
        $date = $order->get_date_created() ? $order->get_date_created()->date_i18n('F j, Y') : '';
        $status = wc_get_order_status_name($order->get_status());
        $thumb = $this->order_thumbnail_data($order);
        $product_line = $thumb['name'];
        if ($thumb['more'] > 0) $product_line .= ' +' . $thumb['more'] . ' more';
        $actions = '';
        if ($show_actions) {
            $actions = '<span class="mrcp-row-actions"><a href="' . esc_url($this->order_view_url($order->get_id())) . '">View Order</a>' . ($order->has_status('completed') ? '<a class="is-primary" href="' . esc_url($this->invoice_url($order->get_id())) . '">Invoice</a>' : '') . '</span>';
        }
        $order_status = sanitize_html_class($order->get_status());
        echo '<div class="mrcp-row mrcp-order-row mrcp-order-row-status-' . esc_attr($order_status) . ' ' . (!$show_actions ? 'is-compact' : '') . '"><span class="mrcp-row-icon mrcp-order-row-thumb"><img src="' . esc_url($thumb['url']) . '" alt="' . esc_attr($thumb['name']) . '" loading="lazy"></span><div><h4>Order #' . esc_html($order->get_order_number()) . '</h4><p class="mrcp-order-row-product">' . esc_html($product_line) . '</p><p>' . esc_html($date) . '</p></div><strong>' . wp_kses_post($order->get_formatted_order_total()) . '</strong><em class="status-' . esc_attr($order_status) . '">' . esc_html($status) . '</em>' . $actions . '</div>';
    }

    private function download_row($download) {
        $name = isset($download['product_name']) ? $download['product_name'] : (isset($download['download_name']) ? $download['download_name'] : 'Download');
        $url = isset($download['download_url']) ? $download['download_url'] : '#';
        $remaining = isset($download['downloads_remaining']) && $download['downloads_remaining'] !== '' ? $download['downloads_remaining'] : '∞';
        echo '<div class="mrcp-row mrcp-download-row"><span class="mrcp-row-icon">⬇</span><div><h4>' . esc_html($name) . '</h4><p>Remaining downloads: ' . esc_html($remaining) . '</p></div><a href="' . esc_url($url) . '">Download</a></div>';
    }

    private function empty_state($icon, $title, $text) {
        echo '<div class="mrcp-empty"><div>' . esc_html($icon) . '</div><h4>' . esc_html($title) . '</h4><p>' . esc_html($text) . '</p></div>';
    }
}
