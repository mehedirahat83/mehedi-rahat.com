<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin CRM Dashboard for MR Commerce Pro.
 *
 * Version 10.4.0
 * CRM layout: 4 KPI cards, full-width membership information,
 * activation/support summaries.
 */
final class AdminCRM {
    const MENU_SLUG = 'mrcp-admin-crm';

    public static function register(): void {
        add_action('admin_menu', [__CLASS__, 'register_menu'], 8);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function register_menu(): void {
        $capability = self::capability();

        add_menu_page(
            __('MR Portal CRM', 'mr-customer-portal-pro'),
            __('MR Portal CRM', 'mr-customer-portal-pro'),
            $capability,
            self::MENU_SLUG,
            [__CLASS__, 'render_dashboard'],
            'dashicons-chart-area',
            56
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('CRM Dashboard', 'mr-customer-portal-pro'),
            __('Dashboard', 'mr-customer-portal-pro'),
            $capability,
            self::MENU_SLUG,
            [__CLASS__, 'render_dashboard']
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('Support Tickets', 'mr-customer-portal-pro'),
            __('Support Tickets', 'mr-customer-portal-pro'),
            $capability,
            'edit.php?post_type=mrcp_ticket'
        );

        add_submenu_page(
            self::MENU_SLUG,
            __('Activation Requests', 'mr-customer-portal-pro'),
            __('Activation Requests', 'mr-customer-portal-pro'),
            $capability,
            'edit.php?post_type=mrcp_activation'
        );
    }

    public static function enqueue_assets(string $hook): void {
        if (strpos($hook, self::MENU_SLUG) === false) {
            return;
        }

        wp_register_style('mrcp-admin-crm', false, [], MRCP_VERSION);
        wp_enqueue_style('mrcp-admin-crm');
        wp_add_inline_style('mrcp-admin-crm', self::css());
    }

    public static function render_dashboard(): void {
        if (!current_user_can(self::capability())) {
            wp_die(esc_html__('You do not have permission to access this page.', 'mr-customer-portal-pro'));
        }

        $stats       = self::stats();
        $memberships = self::membership_summary();
        $activation  = self::activation_summary();
        $tickets     = self::ticket_summary();
        $total_members = array_sum(array_map(static function ($level) {
            return (int) $level['count'];
        }, $memberships));
        ?>
        <div class="wrap mrcp-crm-wrap">
            <div class="mrcp-crm-topbar">
                <div>
                    <h1><?php esc_html_e('CRM Dashboard', 'mr-customer-portal-pro'); ?></h1>
                    <p><?php esc_html_e('Overview of your products, customers, orders and revenue.', 'mr-customer-portal-pro'); ?></p>
                </div>
                <div class="mrcp-crm-search">
                    <span><?php esc_html_e('Search customers, orders, emails...', 'mr-customer-portal-pro'); ?></span>
                    <b>⌕</b>
                </div>
            </div>

            <div class="mrcp-crm-date">📅 <?php echo esc_html(date_i18n('M j, Y', strtotime('-6 days')) . ' - ' . date_i18n('M j, Y')); ?></div>

            <div class="mrcp-crm-kpi-row">
                <?php self::kpi_card('📦', __('Total Products', 'mr-customer-portal-pro'), number_format_i18n($stats['products']), '10.2%'); ?>
                <?php self::kpi_card('👥', __('Total Customers', 'mr-customer-portal-pro'), number_format_i18n($stats['customers']), '12.5%'); ?>
                <?php self::kpi_card('🛒', __('Total Orders', 'mr-customer-portal-pro'), number_format_i18n($stats['orders']), '18.6%'); ?>
                <?php self::kpi_card('💰', __('Total Revenue', 'mr-customer-portal-pro'), self::money($stats['revenue']), '22.8%'); ?>
            </div>

            <section class="mrcp-crm-card mrcp-membership-full">
                <div class="mrcp-crm-card-head">
                    <h2><?php esc_html_e('Membership Information', 'mr-customer-portal-pro'); ?></h2>
                </div>

                <div class="mrcp-membership-cards">
                    <?php foreach ($memberships as $level) :
                        $percent = $total_members > 0 ? round(((int) $level['count'] / $total_members) * 100, 1) : 0;
                        ?>
                        <div class="mrcp-member-card is-<?php echo esc_attr($level['key']); ?>">
                            <div class="mrcp-member-icon"><?php echo esc_html($level['icon']); ?></div>
                            <div class="mrcp-member-info">
                                <strong><?php echo esc_html($level['label']); ?></strong>
                                <span><?php echo esc_html(number_format_i18n((int) $level['count'])); ?></span>
                                <em><?php esc_html_e('Members', 'mr-customer-portal-pro'); ?></em>
                            </div>
                            <div class="mrcp-member-progress">
                                <i style="width:<?php echo esc_attr(max(2, min(100, $percent))); ?>%"></i>
                            </div>
                            <div class="mrcp-member-bottom">
                                <small><?php echo esc_html($percent); ?>%</small>
                                <a href="<?php echo esc_url(admin_url('users.php?role=customer')); ?>"><?php esc_html_e('View All Members', 'mr-customer-portal-pro'); ?> →</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="mrcp-total-members">
                    <span><?php esc_html_e('Total Members:', 'mr-customer-portal-pro'); ?></span>
                    <strong><?php echo esc_html(number_format_i18n($total_members)); ?></strong>
                </div>
            </section>

            <div class="mrcp-crm-bottom-row">
                <section class="mrcp-crm-card mrcp-summary-card">
                    <div class="mrcp-crm-card-head">
                        <h2><?php esc_html_e('Activation Requests', 'mr-customer-portal-pro'); ?></h2>
                        <span class="mrcp-count-badge"><?php echo esc_html(number_format_i18n($activation['total'])); ?></span>
                    </div>
                    <div class="mrcp-summary-body">
                        <div class="mrcp-summary-main is-activation">
                            <span>🔧</span>
                            <strong><?php echo esc_html(number_format_i18n($activation['total'])); ?></strong>
                            <em><?php esc_html_e('Total Requests', 'mr-customer-portal-pro'); ?></em>
                        </div>
                        <div class="mrcp-summary-list">
                            <?php self::summary_line('orange', __('Pending', 'mr-customer-portal-pro'), $activation['pending']); ?>
                            <?php self::summary_line('blue', __('In Progress', 'mr-customer-portal-pro'), $activation['in_progress']); ?>
                            <?php self::summary_line('green', __('Completed', 'mr-customer-portal-pro'), $activation['completed']); ?>
                        </div>
                    </div>
                    <a class="mrcp-crm-link" href="<?php echo esc_url(admin_url('edit.php?post_type=mrcp_activation')); ?>"><?php esc_html_e('View All Activation Requests', 'mr-customer-portal-pro'); ?> →</a>
                </section>

                <section class="mrcp-crm-card mrcp-summary-card">
                    <div class="mrcp-crm-card-head">
                        <h2><?php esc_html_e('Support Tickets', 'mr-customer-portal-pro'); ?></h2>
                        <span class="mrcp-count-badge"><?php echo esc_html(number_format_i18n($tickets['total'])); ?></span>
                    </div>
                    <div class="mrcp-summary-body">
                        <div class="mrcp-summary-main is-support">
                            <span>🎧</span>
                            <strong><?php echo esc_html(number_format_i18n($tickets['total'])); ?></strong>
                            <em><?php esc_html_e('Total Tickets', 'mr-customer-portal-pro'); ?></em>
                        </div>
                        <div class="mrcp-summary-list">
                            <?php self::summary_line('red', __('Open', 'mr-customer-portal-pro'), $tickets['open']); ?>
                            <?php self::summary_line('purple', __('Waiting Reply', 'mr-customer-portal-pro'), $tickets['waiting_reply']); ?>
                            <?php self::summary_line('gray', __('Closed', 'mr-customer-portal-pro'), $tickets['closed']); ?>
                        </div>
                    </div>
                    <a class="mrcp-crm-link" href="<?php echo esc_url(admin_url('edit.php?post_type=mrcp_ticket')); ?>"><?php esc_html_e('View All Support Tickets', 'mr-customer-portal-pro'); ?> →</a>
                </section>
            </div>

            <div class="mrcp-crm-footer">© <?php echo esc_html(date_i18n('Y')); ?> Mehedi Rahat — MR Commerce Pro v1.0.0</div>
        </div>
        <?php
    }

    private static function capability(): string {
        return current_user_can('manage_woocommerce') ? 'manage_woocommerce' : 'manage_options';
    }

    private static function stats(): array {
        $callback = static function (): array {
            return [
                'products'  => self::product_count(),
                'customers' => self::customer_count(),
                'orders'    => self::order_count(),
                'revenue'   => self::revenue_total(),
            ];
        };

        return class_exists(Performance::class)
            ? Performance::remember('admin_crm_stats', $callback, 5 * MINUTE_IN_SECONDS)
            : $callback();
    }

    private static function product_count(): int {
        $counts = wp_count_posts('product');
        return isset($counts->publish) ? (int) $counts->publish : 0;
    }

    private static function customer_count(): int {
        $counts = count_users();
        return isset($counts['avail_roles']['customer']) ? (int) $counts['avail_roles']['customer'] : 0;
    }

    private static function order_count(): int {
        if (!function_exists('wc_orders_count')) {
            return 0;
        }
        $statuses = ['pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed'];
        $count = 0;
        foreach ($statuses as $status) {
            $count += (int) wc_orders_count($status);
        }
        return $count;
    }

    private static function revenue_total(): float {
        if (!function_exists('wc_get_orders')) {
            return 0.0;
        }

        $total = 0.0;
        $page  = 1;
        $limit = 100;

        do {
            $orders = wc_get_orders([
                'limit'  => $limit,
                'paged'  => $page,
                'status' => ['completed', 'processing'],
                'return' => 'objects',
            ]);

            if (!$orders) {
                break;
            }

            foreach ($orders as $order) {
                if (is_a($order, 'WC_Order')) {
                    $total += (float) $order->get_total();
                }
            }
            $page++;
        } while (count($orders) === $limit);

        return round($total, 2);
    }

    private static function membership_summary(): array {
        $callback = static function (): array {
        $levels = [
            'silver'  => ['key' => 'silver', 'label' => 'Silver', 'icon' => '🥈', 'count' => 0],
            'gold'    => ['key' => 'gold', 'label' => 'Gold', 'icon' => '🥇', 'count' => 0],
            'diamond' => ['key' => 'diamond', 'label' => 'Diamond', 'icon' => '💎', 'count' => 0],
            'vip'     => ['key' => 'vip', 'label' => 'VIP', 'icon' => '👑', 'count' => 0],
        ];

        $users = get_users([
            'role__in' => ['customer', 'subscriber'],
            'number'   => 500,
            'fields'   => ['ID'],
        ]);

        foreach ($users as $user) {
            $membership = self::membership_for_user((int) $user->ID);
            $key = isset($membership['key']) ? $membership['key'] : 'silver';
            if (isset($levels[$key])) {
                $levels[$key]['count']++;
            }
        }

        return array_values($levels);
        };

        return class_exists(Performance::class)
            ? Performance::remember('admin_crm_membership_summary', $callback, 15 * MINUTE_IN_SECONDS)
            : $callback();
    }

    private static function membership_for_user(int $user_id): array {
        if (class_exists('\\MRCP_Membership')) {
            return \MRCP_Membership::get_customer_membership($user_id);
        }
        $spent = function_exists('wc_get_customer_total_spent') ? (float) wc_get_customer_total_spent($user_id) : 0;
        if ($spent >= 100000) {
            return ['key' => 'vip', 'name' => 'VIP Member', 'icon' => '👑'];
        }
        if ($spent >= 50000) {
            return ['key' => 'diamond', 'name' => 'Diamond Member', 'icon' => '💎'];
        }
        if ($spent >= 10000) {
            return ['key' => 'gold', 'name' => 'Gold Member', 'icon' => '🥇'];
        }
        return ['key' => 'silver', 'name' => 'Silver Member', 'icon' => '🥈'];
    }

    private static function activation_summary(): array {
        $callback = static function (): array {
            $pending = self::post_count_by_meta('mrcp_activation', '_mrcp_activation_status', ['pending']);
            $progress = self::post_count_by_meta('mrcp_activation', '_mrcp_activation_status', ['in_progress']);
            $completed = self::post_count_by_meta('mrcp_activation', '_mrcp_activation_status', ['completed']);
            return [
                'pending'     => $pending,
                'in_progress' => $progress,
                'completed'   => $completed,
                'total'       => $pending + $progress + $completed,
            ];
        };

        return class_exists(Performance::class)
            ? Performance::remember('admin_crm_activation_summary', $callback, 2 * MINUTE_IN_SECONDS)
            : $callback();
    }

    private static function ticket_summary(): array {
        $callback = static function (): array {
            $open = self::post_count_by_meta('mrcp_ticket', '_mrcp_ticket_status', ['open']);
            $waiting = self::post_count_by_meta('mrcp_ticket', '_mrcp_ticket_status', ['pending', 'customer_replied', 'waiting_reply']);
            $closed = self::post_count_by_meta('mrcp_ticket', '_mrcp_ticket_status', ['closed']);
            return [
                'open'          => $open,
                'waiting_reply' => $waiting,
                'closed'        => $closed,
                'total'         => $open + $waiting + $closed,
            ];
        };

        return class_exists(Performance::class)
            ? Performance::remember('admin_crm_ticket_summary', $callback, 2 * MINUTE_IN_SECONDS)
            : $callback();
    }

    private static function post_count_by_meta(string $post_type, string $meta_key, array $values): int {
        $query = new \WP_Query([
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => [[
                'key'     => $meta_key,
                'value'   => $values,
                'compare' => 'IN',
            ]],
            'no_found_rows'  => false,
        ]);
        return (int) $query->found_posts;
    }

    private static function kpi_card(string $icon, string $label, string $value, string $growth): void {
        echo '<section class="mrcp-crm-kpi">';
        echo '<div class="mrcp-kpi-icon">' . esc_html($icon) . '</div>';
        echo '<div class="mrcp-kpi-copy"><p>' . esc_html($label) . '</p><strong>' . wp_kses_post($value) . '</strong><span>↑ ' . esc_html($growth) . ' <em>vs last 7 days</em></span></div>';
        echo '</section>';
    }

    private static function summary_line(string $color, string $label, int $count): void {
        echo '<div class="mrcp-summary-line"><span class="dot is-' . esc_attr($color) . '"></span><strong>' . esc_html($label) . '</strong><em>' . esc_html(number_format_i18n($count)) . '</em></div>';
    }

    private static function money($amount): string {
        if (function_exists('wc_price')) {
            return wc_price((float) $amount, ['decimals' => 0]);
        }
        return '৳' . number_format_i18n((float) $amount, 0);
    }

    private static function css(): string {
        return <<<'CSS'
#wpcontent{background:#f5fbfb}.mrcp-crm-wrap{max-width:1500px;margin:28px 28px 28px 8px;color:#0f172a;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.mrcp-crm-topbar{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;margin-bottom:18px}.mrcp-crm-topbar h1{font-size:34px;line-height:1.1;margin:0 0 10px;font-weight:900;color:#0f172a}.mrcp-crm-topbar p{font-size:16px;margin:0;color:#53627a}.mrcp-crm-search{min-width:360px;height:52px;border:1px solid #dcebed;background:#fff;border-radius:18px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;color:#718096;box-shadow:0 16px 38px rgba(15,23,42,.06)}.mrcp-crm-search b{font-size:22px;color:#64748b}.mrcp-crm-date{margin-left:auto;margin-bottom:24px;background:#fff;border:1px solid #dcebed;border-radius:13px;padding:12px 16px;width:max-content;font-weight:800;color:#0f172a;box-shadow:0 14px 30px rgba(15,23,42,.05)}.mrcp-crm-kpi-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin-bottom:22px}.mrcp-crm-kpi{min-height:170px;background:#fff;border:1px solid #e5eeee;border-radius:22px;padding:26px;display:flex;align-items:center;gap:20px;box-shadow:0 18px 46px rgba(15,23,42,.07)}.mrcp-kpi-icon{width:70px;height:70px;border-radius:50%;display:grid;place-items:center;background:#eafafa;font-size:34px}.mrcp-kpi-copy p{margin:0 0 26px;font-weight:900;color:#0f172a}.mrcp-kpi-copy strong{display:block;font-size:38px;line-height:1;color:#0b1532;font-weight:900}.mrcp-kpi-copy span{display:flex;align-items:center;gap:12px;margin-top:24px;color:#04a66a;font-weight:900}.mrcp-kpi-copy span em{font-style:normal;color:#667085;font-weight:600}.mrcp-crm-card{background:#fff;border:1px solid #e5eeee;border-radius:24px;box-shadow:0 18px 46px rgba(15,23,42,.065);padding:26px}.mrcp-crm-card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:22px}.mrcp-crm-card-head h2{font-size:21px;line-height:1.2;margin:0;font-weight:900;color:#0f172a}.mrcp-membership-full{margin-bottom:22px}.mrcp-membership-cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:22px}.mrcp-member-card{min-height:210px;border-radius:18px;padding:22px;display:grid;grid-template-columns:92px 1fr;gap:18px;align-items:center;position:relative;overflow:hidden}.mrcp-member-card.is-silver{background:linear-gradient(135deg,#eef7ff,#f8fcff)}.mrcp-member-card.is-gold{background:linear-gradient(135deg,#fff7e7,#fffdf7)}.mrcp-member-card.is-diamond{background:linear-gradient(135deg,#eef8ff,#f8fcff)}.mrcp-member-card.is-vip{background:linear-gradient(135deg,#fff0f0,#fffafa)}.mrcp-member-icon{width:86px;height:86px;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.65);font-size:46px}.mrcp-member-info strong{display:block;font-size:20px;font-weight:900;margin-bottom:20px}.mrcp-member-card.is-silver .mrcp-member-info strong{color:#1683f5}.mrcp-member-card.is-gold .mrcp-member-info strong{color:#f59e0b}.mrcp-member-card.is-diamond .mrcp-member-info strong{color:#1683f5}.mrcp-member-card.is-vip .mrcp-member-info strong{color:#ef2424}.mrcp-member-info span{display:block;font-size:42px;line-height:1;font-weight:900;color:#0b1532}.mrcp-member-info em{display:block;font-style:normal;font-size:15px;color:#0f172a;margin-top:14px}.mrcp-member-progress{grid-column:1/-1;height:9px;background:rgba(15,23,42,.10);border-radius:999px;overflow:hidden}.mrcp-member-progress i{display:block;height:100%;border-radius:999px;background:#1683f5}.mrcp-member-card.is-gold .mrcp-member-progress i{background:#f59e0b}.mrcp-member-card.is-diamond .mrcp-member-progress i{background:#1683f5}.mrcp-member-card.is-vip .mrcp-member-progress i{background:#ef2424}.mrcp-member-bottom{grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;font-weight:900}.mrcp-member-bottom small{font-size:15px;color:#0b1532}.mrcp-member-bottom a{text-decoration:none;color:#008f82}.mrcp-total-members{border-top:1px solid #e5eeee;margin-top:24px;padding-top:20px;font-size:16px}.mrcp-total-members span{font-weight:800;color:#0f172a}.mrcp-total-members strong{font-size:24px;color:#009688;margin-left:8px}.mrcp-crm-bottom-row{display:grid;grid-template-columns:1fr 1fr;gap:22px}.mrcp-count-badge{display:inline-flex;min-width:32px;height:32px;border-radius:999px;background:#009688;color:#fff;align-items:center;justify-content:center;font-weight:900;box-shadow:0 8px 18px rgba(0,150,136,.28)}.mrcp-summary-body{display:grid;grid-template-columns:230px 1fr;gap:28px;align-items:center}.mrcp-summary-main{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;min-height:205px}.mrcp-summary-main span{width:90px;height:90px;border-radius:50%;display:grid;place-items:center;background:#e9f8f5;font-size:46px;margin-bottom:18px}.mrcp-summary-main.is-support span{background:#fff0f0}.mrcp-summary-main strong{font-size:44px;line-height:1;color:#009688;font-weight:900}.mrcp-summary-main.is-support strong{color:#ef2424}.mrcp-summary-main em{font-style:normal;color:#0f172a;margin-top:10px;font-weight:700}.mrcp-summary-list{display:flex;flex-direction:column}.mrcp-summary-line{display:grid;grid-template-columns:18px 1fr auto;gap:12px;align-items:center;padding:16px 0;border-bottom:1px solid #eef2f4;font-size:16px}.mrcp-summary-line strong{font-weight:800;color:#0f172a}.mrcp-summary-line em{font-style:normal;font-weight:900;color:#0f172a}.dot{width:11px;height:11px;border-radius:50%;display:inline-block}.dot.is-orange{background:#f59e0b}.dot.is-blue{background:#3498db}.dot.is-green{background:#14b875}.dot.is-red{background:#ef2424}.dot.is-purple{background:#8b5cf6}.dot.is-gray{background:#94a3b8}.mrcp-crm-link{display:block;text-align:center;margin-top:18px;text-decoration:none;color:#008f82;font-weight:900;font-size:15px}.mrcp-crm-footer{text-align:center;margin:28px 0 6px;color:#64748b}
/* v10.4 Membership Information reference design */
.mrcp-membership-full{padding:26px 28px 28px!important;border-radius:18px!important;background:#fff!important;box-shadow:0 18px 46px rgba(15,23,42,.06)!important;border:1px solid #edf3f4!important;margin-bottom:22px!important}
.mrcp-membership-full .mrcp-crm-card-head{margin-bottom:26px!important}
.mrcp-membership-full .mrcp-crm-card-head h2{font-size:18px!important;font-weight:900!important;color:#0b1532!important;letter-spacing:-.01em!important}
.mrcp-membership-cards{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:24px!important;margin-bottom:24px!important}
.mrcp-member-card{min-height:178px!important;border-radius:10px!important;padding:18px 22px!important;display:grid!important;grid-template-columns:92px 1fr!important;grid-template-rows:auto auto auto!important;column-gap:18px!important;row-gap:10px!important;align-items:center!important;border:0!important;box-shadow:none!important;overflow:hidden!important}
.mrcp-member-card.is-silver{background:linear-gradient(135deg,#eff8ff 0%,#f8fcff 100%)!important}
.mrcp-member-card.is-gold{background:linear-gradient(135deg,#fff8e9 0%,#fffdf7 100%)!important}
.mrcp-member-card.is-diamond{background:linear-gradient(135deg,#f0f9ff 0%,#f8fcff 100%)!important}
.mrcp-member-card.is-vip{background:linear-gradient(135deg,#fff1f1 0%,#fffafa 100%)!important}
.mrcp-member-icon{width:76px!important;height:76px!important;border-radius:50%!important;background:rgba(255,255,255,.55)!important;display:grid!important;place-items:center!important;font-size:42px!important;grid-row:1 / span 2!important;align-self:start!important;margin:0!important}
.mrcp-member-info{align-self:start!important}
.mrcp-member-info strong{font-size:18px!important;line-height:1.2!important;margin:0 0 16px!important;font-weight:900!important}
.mrcp-member-info span{font-size:34px!important;line-height:1!important;font-weight:900!important;color:#0b1532!important}
.mrcp-member-info em{font-size:13px!important;line-height:1.2!important;margin-top:10px!important;color:#0f172a!important;font-weight:700!important}
.mrcp-member-progress{grid-column:1 / span 2!important;height:7px!important;background:rgba(15,23,42,.10)!important;border-radius:999px!important;margin-top:6px!important;position:relative!important;overflow:visible!important}
.mrcp-member-progress i{display:block!important;height:100%!important;border-radius:999px!important}
.mrcp-member-bottom{grid-column:1 / span 2!important;display:grid!important;grid-template-columns:1fr auto!important;align-items:center!important;margin-top:4px!important}
.mrcp-member-bottom small{grid-column:2!important;grid-row:1!important;font-size:13px!important;color:#0b1532!important;font-weight:900!important;margin-top:-38px!important}
.mrcp-member-bottom a{grid-column:1 / span 2!important;grid-row:2!important;justify-self:center!important;text-decoration:none!important;font-size:14px!important;font-weight:900!important;margin-top:12px!important}
.mrcp-member-card.is-silver .mrcp-member-bottom a{color:#0877e8!important}
.mrcp-member-card.is-gold .mrcp-member-bottom a{color:#f18f00!important}
.mrcp-member-card.is-diamond .mrcp-member-bottom a{color:#0877e8!important}
.mrcp-member-card.is-vip .mrcp-member-bottom a{color:#ef2424!important}
.mrcp-total-members{border-top:1px solid #e8eef0!important;margin-top:8px!important;padding-top:20px!important;font-size:15px!important}
.mrcp-total-members span{font-weight:800!important;color:#0f172a!important}
.mrcp-total-members strong{font-size:22px!important;color:#009688!important;margin-left:6px!important;font-weight:900!important}
@media(max-width:1280px){.mrcp-crm-kpi-row{grid-template-columns:repeat(2,minmax(0,1fr))}.mrcp-membership-cards{grid-template-columns:repeat(2,minmax(0,1fr))}.mrcp-crm-bottom-row{grid-template-columns:1fr}}@media(max-width:782px){.mrcp-crm-wrap{margin:18px 10px}.mrcp-crm-topbar{flex-direction:column}.mrcp-crm-search{min-width:0;width:100%}.mrcp-crm-kpi-row,.mrcp-membership-cards,.mrcp-crm-bottom-row{grid-template-columns:1fr}.mrcp-summary-body{grid-template-columns:1fr}.mrcp-member-card{grid-template-columns:1fr;text-align:center}.mrcp-member-icon{margin:auto}}
CSS;
    }
}
