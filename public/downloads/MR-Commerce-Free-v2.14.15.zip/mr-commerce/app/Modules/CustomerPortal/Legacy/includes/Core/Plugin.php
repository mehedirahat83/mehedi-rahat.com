<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main plugin controller for MR Commerce Pro.
 */
final class Plugin {
    private static $instance = null;

    /** @var Loader */
    private $loader;

    public static function instance(): self {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_core();
        $this->loader = new Loader();
    }

    private function load_core(): void {
        $core_files = [
            'Loader.php',
            'Router.php',
            'Assets.php',
            'Installer.php',
            'Database.php',
            'Security.php',
            'Performance.php',
            'AdminCRM.php',
        ];

        foreach ($core_files as $file) {
            $path = MRCP_PLUGIN_DIR . 'includes/Core/' . $file;
            if (file_exists($path)) {
                require_once $path;
            }
        }
    }

    public function run(): void {
        load_plugin_textdomain('mr-customer-portal-pro', false, dirname(MRCP_PLUGIN_BASENAME) . '/languages');
        $this->loader->register();
    }

    public static function activate(): void {
        require_once MRCP_PLUGIN_DIR . 'includes/Core/Installer.php';
        Installer::activate();
    }

    public static function deactivate(): void {
        require_once MRCP_PLUGIN_DIR . 'includes/Core/Installer.php';
        Installer::deactivate();
    }
}
