<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait MRCP_Portal_Support_Trait {
    private function ticket_url($ticket_id) {
        return home_url('/dashboard/ticket/' . absint($ticket_id) . '/');
    }

    private function ticket_statuses() {
        return [
            'open' => 'Open',
            'pending' => 'Pending',
            'answered' => 'Answered',
            'closed' => 'Closed',
        ];
    }

    private function ticket_categories() {
        return [
            'activation' => 'Activation',
            'download' => 'Download',
            'account' => 'Account',
            'payment' => 'Payment',
            'technical' => 'Technical',
            'other' => 'Other',
        ];
    }

    private function ticket_priorities() {
        return [
            'low' => 'Low',
            'medium' => 'Medium',
            'high' => 'High',
        ];
    }

    private function ticket_count($status = '') {
        $meta_query = [];
        if ($status) {
            $meta_query[] = [
                'key' => '_mrcp_ticket_status',
                'value' => sanitize_key($status),
            ];
        } else {
            $meta_query[] = [
                'key' => '_mrcp_ticket_status',
                'value' => 'closed',
                'compare' => '!=',
            ];
        }
        $args = [
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => $meta_query,
            'no_found_rows' => false,
        ];
        if (!$this->is_support_admin()) {
            $args['author'] = get_current_user_id();
        }
        $q = new WP_Query($args);
        return (int) $q->found_posts;
    }

    private function tickets($limit = 10, $status = '') {
        $meta_query = [];
        if ($status && $status !== 'all') {
            $meta_query[] = [
                'key' => '_mrcp_ticket_status',
                'value' => sanitize_key($status),
            ];
        }
        $args = [
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'numberposts' => $limit,
            'orderby' => 'modified',
            'order' => 'DESC',
            'meta_query' => $meta_query,
        ];
        if (!$this->is_support_admin()) {
            $args['author'] = get_current_user_id();
        }
        return get_posts($args);
    }

    private function get_ticket($ticket_id) {
        $ticket = get_post(absint($ticket_id));
        if (!$ticket || $ticket->post_type !== 'mrcp_ticket') return false;
        if (!$this->is_support_admin() && (int) $ticket->post_author !== get_current_user_id()) return false;
        return $ticket;
    }

    private function ticket_meta($ticket_id) {
        return [
            'status' => get_post_meta($ticket_id, '_mrcp_ticket_status', true) ?: 'open',
            'priority' => get_post_meta($ticket_id, '_mrcp_ticket_priority', true) ?: 'medium',
            'category' => get_post_meta($ticket_id, '_mrcp_ticket_category', true) ?: 'other',
            'order_id' => absint(get_post_meta($ticket_id, '_mrcp_ticket_order_id', true)),
            'attachment' => esc_url_raw(get_post_meta($ticket_id, '_mrcp_ticket_attachment', true)),
        ];
    }

    private function handle_ticket_upload($field_name) {
        if (empty($_FILES[$field_name]) || empty($_FILES[$field_name]['name'])) return '';
        $file = $_FILES[$field_name];
        $allowed = ['jpg','jpeg','png','pdf','zip','txt'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed, true)) return '';
        if (!function_exists('wp_handle_upload')) require_once ABSPATH . 'wp-admin/includes/file.php';
        $uploaded = wp_handle_upload($file, ['test_form' => false]);
        if (!empty($uploaded['url'])) return esc_url_raw($uploaded['url']);
        return '';
    }

    private function handle_ticket_create() {
        if (!isset($_POST['mrcp_ticket_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_ticket_nonce'])), 'mrcp_create_ticket')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }
        $subject = isset($_POST['ticket_subject']) ? sanitize_text_field(wp_unslash($_POST['ticket_subject'])) : '';
        $message = isset($_POST['ticket_message']) ? wp_kses_post(wp_unslash($_POST['ticket_message'])) : '';
        $category = isset($_POST['ticket_category']) ? sanitize_key(wp_unslash($_POST['ticket_category'])) : 'other';
        $priority = 'medium';
        $order_id = isset($_POST['ticket_order_id']) ? absint($_POST['ticket_order_id']) : 0;
        if (!$subject || !$message) {
            $this->set_notice('is-error', 'Please add a subject and message.');
            return;
        }
        if (!array_key_exists($category, $this->ticket_categories())) $category = 'other';
        if ($order_id) {
            $order = wc_get_order($order_id);
            if (!$order || (int) $order->get_customer_id() !== get_current_user_id()) $order_id = 0;
        }
        $ticket_id = wp_insert_post([
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
            'post_title' => $subject,
            'post_content' => $message,
        ], true);
        if (is_wp_error($ticket_id)) {
            $this->set_notice('is-error', $ticket_id->get_error_message());
            return;
        }
        update_post_meta($ticket_id, '_mrcp_ticket_status', 'open');
        update_post_meta($ticket_id, '_mrcp_ticket_priority', $priority);
        update_post_meta($ticket_id, '_mrcp_ticket_category', $category);
        if ($order_id) update_post_meta($ticket_id, '_mrcp_ticket_order_id', $order_id);
        $attachment = $this->handle_ticket_upload('ticket_attachment');
        if ($attachment) update_post_meta($ticket_id, '_mrcp_ticket_attachment', $attachment);
        $this->notify_admin_new_ticket($ticket_id, $subject, $message, $category, $order_id, $attachment);
        $this->notify_customer_ticket_created($ticket_id, $subject);
        wp_safe_redirect($this->ticket_url($ticket_id));
        exit;
    }

    private function handle_ticket_reply() {
        if (!isset($_POST['mrcp_reply_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_reply_nonce'])), 'mrcp_reply_ticket')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }
        $ticket_id = isset($_POST['ticket_id']) ? absint($_POST['ticket_id']) : 0;
        $ticket = $this->get_ticket($ticket_id);
        if (!$ticket) {
            $this->set_notice('is-error', 'Ticket not found.');
            return;
        }
        $message = isset($_POST['reply_message']) ? wp_kses_post(wp_unslash($_POST['reply_message'])) : '';
        if (!$message) {
            $this->set_notice('is-error', 'Please write your reply.');
            return;
        }

        $current = wp_get_current_user();
        $is_admin_reply = $this->is_support_admin();
        $comment_id = wp_insert_comment([
            'comment_post_ID' => $ticket_id,
            'comment_content' => $message,
            'user_id' => get_current_user_id(),
            'comment_author' => $is_admin_reply ? 'Support Team' : $current->display_name,
            'comment_author_email' => $is_admin_reply ? $this->notification_admin_email() : $current->user_email,
            'comment_approved' => 1,
            'comment_type' => 'mrcp_ticket_reply',
        ]);

        $attachment = $this->handle_ticket_upload('reply_attachment');
        if ($comment_id && $attachment) update_comment_meta($comment_id, '_mrcp_reply_attachment', $attachment);

        if ($is_admin_reply) {
            $new_status = !empty($_POST['mrcp_close_after_reply']) ? 'closed' : 'answered';
            update_post_meta($ticket_id, '_mrcp_ticket_status', $new_status);
            update_post_meta($ticket_id, '_mrcp_last_admin_reply', current_time('mysql'));
            $customer_id = (int) $ticket->post_author;
            if ($customer_id) {
                $this->add_notification($customer_id, 'Support replied to Ticket MR-' . $ticket_id, wp_trim_words(wp_strip_all_tags($message), 16), $this->ticket_url($ticket_id), 'ticket_reply');
            }
            $this->notify_customer_admin_reply($ticket_id, $message, $attachment, $new_status);
            $this->set_notice('is-success', 'Reply sent to the customer.');
        } else {
            update_post_meta($ticket_id, '_mrcp_ticket_status', 'pending');
            update_post_meta($ticket_id, '_mrcp_last_customer_reply', current_time('mysql'));
            $this->notify_admin_new_ticket($ticket_id, 'Customer reply on ticket MR-' . $ticket_id, $message, get_post_meta($ticket_id, '_mrcp_ticket_category', true) ?: 'other', absint(get_post_meta($ticket_id, '_mrcp_ticket_order_id', true)), $attachment);
        }

        wp_update_post(['ID' => $ticket_id]);
        wp_safe_redirect($this->ticket_url($ticket_id));
        exit;
    }

    private function process_form_actions($section) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
        if (!is_user_logged_in()) return;

        if (isset($_POST['mrcp_update_account'])) {
            $this->handle_account_update();
            return;
        }

        if (isset($_POST['mrcp_update_addresses'])) {
            $this->handle_address_update();
            return;
        }

        if (isset($_POST['mrcp_payment_action'])) {
            $this->handle_payment_method_action();
            return;
        }

        if (isset($_POST['mrcp_create_activation'])) {
            $this->handle_activation_create();
            return;
        }

        if (isset($_POST['mrcp_update_activation'])) {
            $this->handle_activation_update_from_portal();
            return;
        }

        if (isset($_POST['mrcp_create_ticket'])) {
            $this->handle_ticket_create();
            return;
        }

        if (isset($_POST['mrcp_reply_ticket'])) {
            $this->handle_ticket_reply();
            return;
        }
    }

    private function set_notice($type, $message) {
        $this->notice = ['type' => $type, 'message' => $message];
    }

    private function handle_account_update() {
        if (!isset($_POST['mrcp_account_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_account_nonce'])), 'mrcp_update_account')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }

        $user_id = get_current_user_id();
        $first_name = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
        $last_name = isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '';
        $display_name = isset($_POST['display_name']) ? sanitize_text_field(wp_unslash($_POST['display_name'])) : '';
        $email = isset($_POST['user_email']) ? sanitize_email(wp_unslash($_POST['user_email'])) : '';
        $phone = isset($_POST['billing_phone']) ? sanitize_text_field(wp_unslash($_POST['billing_phone'])) : '';

        if (!$display_name) $display_name = trim($first_name . ' ' . $last_name);
        if (!$display_name) $display_name = wp_get_current_user()->display_name;

        if (!$email || !is_email($email)) {
            $this->set_notice('is-error', 'Please enter a valid email address.');
            return;
        }

        $email_owner = email_exists($email);
        if ($email_owner && (int) $email_owner !== (int) $user_id) {
            $this->set_notice('is-error', 'This email address is already used by another account.');
            return;
        }

        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, 'billing_phone', $phone);

        $result = wp_update_user([
            'ID' => $user_id,
            'display_name' => $display_name,
            'user_email' => $email,
        ]);

        if (is_wp_error($result)) {
            $this->set_notice('is-error', $result->get_error_message());
            return;
        }

        $pass_1 = isset($_POST['password_1']) ? (string) wp_unslash($_POST['password_1']) : '';
        $pass_2 = isset($_POST['password_2']) ? (string) wp_unslash($_POST['password_2']) : '';
        if ($pass_1 || $pass_2) {
            if ($pass_1 !== $pass_2) {
                $this->set_notice('is-error', 'Passwords do not match. Account details were saved, but password was not changed.');
                return;
            }
            if (strlen($pass_1) < 8) {
                $this->set_notice('is-error', 'Password must be at least 8 characters. Account details were saved, but password was not changed.');
                return;
            }
            wp_set_password($pass_1, $user_id);
            wp_set_auth_cookie($user_id, true);
        }

        $this->set_notice('is-success', 'Account details updated successfully.');
    }

    private function address_fields($type) {
        $prefix = $type . '_';
        return [
            $prefix . 'first_name' => 'First name',
            $prefix . 'last_name' => 'Last name',
            $prefix . 'company' => 'Company',
            $prefix . 'country' => 'Country / Region',
            $prefix . 'address_1' => 'Street address',
            $prefix . 'address_2' => 'Apartment, suite, unit',
            $prefix . 'city' => 'Town / City',
            $prefix . 'state' => 'District / State',
            $prefix . 'postcode' => 'Postcode / ZIP',
            $prefix . 'phone' => 'Phone',
            $prefix . 'email' => 'Email address',
        ];
    }

    private function handle_address_update() {
        if (!isset($_POST['mrcp_addresses_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_addresses_nonce'])), 'mrcp_update_addresses')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }

        $user_id = get_current_user_id();
        foreach (['billing', 'shipping'] as $type) {
            foreach ($this->address_fields($type) as $key => $label) {
                if (isset($_POST[$key])) {
                    $value = $key === $type . '_email' ? sanitize_email(wp_unslash($_POST[$key])) : sanitize_text_field(wp_unslash($_POST[$key]));
                    update_user_meta($user_id, $key, $value);
                }
            }
        }
        $this->set_notice('is-success', 'Addresses updated successfully.');
    }

    private function handle_payment_method_action() {
        if (!$this->wc_active() || !class_exists('WC_Payment_Tokens')) {
            $this->set_notice('is-error', 'Payment methods are not available.');
            return;
        }
        if (!isset($_POST['mrcp_payment_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_payment_nonce'])), 'mrcp_payment_action')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }

        $token_id = isset($_POST['token_id']) ? absint($_POST['token_id']) : 0;
        $action = isset($_POST['mrcp_payment_action']) ? sanitize_key(wp_unslash($_POST['mrcp_payment_action'])) : '';
        $token = $token_id ? WC_Payment_Tokens::get($token_id) : false;

        if (!$token || (int) $token->get_user_id() !== get_current_user_id()) {
            $this->set_notice('is-error', 'Payment method not found.');
            return;
        }

        if ($action === 'delete') {
            WC_Payment_Tokens::delete($token_id);
            $this->set_notice('is-success', 'Payment method removed successfully.');
            return;
        }

        if ($action === 'default') {
            WC_Payment_Tokens::set_users_default($token_id, get_current_user_id());
            $this->set_notice('is-success', 'Default payment method updated.');
            return;
        }
    }

    private function activation_url($path = '') {
        return home_url('/dashboard/activation/' . ltrim($path, '/'));
    }

    private function activation_view_url($request_id) {
        return home_url('/dashboard/activation/' . absint($request_id) . '/');
    }

    private function activation_statuses() {
        return [
            'pending' => 'Pending',
            'in_progress' => 'In Progress',
            'completed' => 'Completed',
            'rejected' => 'Rejected',
        ];
    }

    private function activation_status_label($status) {
        $statuses = $this->activation_statuses();
        return isset($statuses[$status]) ? $statuses[$status] : 'Pending';
    }

    private function activation_count($status = '') {
        $meta_query = [];
        if ($status) {
            $meta_query[] = ['key' => '_mrcp_activation_status', 'value' => sanitize_key($status)];
        } else {
            $meta_query[] = ['key' => '_mrcp_activation_status', 'value' => ['pending','in_progress'], 'compare' => 'IN'];
        }

        $args = [
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'fields' => 'ids',
            'numberposts' => -1,
            'meta_query' => $meta_query,
        ];

        // Customers should only see their own activation counts.
        // Admin/support users should see the full activation queue.
        if (!$this->is_support_admin()) {
            $args['author'] = get_current_user_id();
        }

        return count(get_posts($args));
    }

    private function activation_admin_count($status = 'pending') {
        return count(get_posts([
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'fields' => 'ids',
            'numberposts' => -1,
            'meta_key' => '_mrcp_activation_status',
            'meta_value' => sanitize_key($status),
        ]));
    }

    private function activation_requests($limit = 30, $filter = 'all') {
        $args = [
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'numberposts' => $limit,
            'orderby' => 'modified',
            'order' => 'DESC',
        ];
        if (!$this->is_support_admin()) $args['author'] = get_current_user_id();
        if ($filter !== 'all' && array_key_exists($filter, $this->activation_statuses())) {
            $args['meta_key'] = '_mrcp_activation_status';
            $args['meta_value'] = $filter;
        }
        return get_posts($args);
    }

    private function encrypt_secret($value) {
        $value = (string) $value;
        if ($value === '') return '';
        $key = hash('sha256', wp_salt('auth'), true);
        if (function_exists('openssl_encrypt')) {
            $iv = substr(hash('sha256', wp_salt('secure_auth')), 0, 16);
            return 'enc:' . base64_encode(openssl_encrypt($value, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv));
        }
        return 'b64:' . base64_encode($value);
    }

    private function decrypt_secret($value) {
        $value = (string) $value;
        if ($value === '') return '';
        if (strpos($value, 'enc:') === 0 && function_exists('openssl_decrypt')) {
            $key = hash('sha256', wp_salt('auth'), true);
            $iv = substr(hash('sha256', wp_salt('secure_auth')), 0, 16);
            return (string) openssl_decrypt(base64_decode(substr($value, 4)), 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        }
        if (strpos($value, 'b64:') === 0) return (string) base64_decode(substr($value, 4));
        return '';
    }

    private function handle_activation_create() {
        if (!isset($_POST['mrcp_activation_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_activation_nonce'])), 'mrcp_create_activation')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }
        $product = isset($_POST['activation_product']) ? sanitize_text_field(wp_unslash($_POST['activation_product'])) : '';
        $domain = isset($_POST['activation_domain']) ? esc_url_raw(wp_unslash($_POST['activation_domain'])) : '';
        $login_url = isset($_POST['activation_login_url']) ? esc_url_raw(wp_unslash($_POST['activation_login_url'])) : '';
        $username = isset($_POST['activation_username']) ? sanitize_text_field(wp_unslash($_POST['activation_username'])) : '';
        $password = isset($_POST['activation_password']) ? sanitize_text_field(wp_unslash($_POST['activation_password'])) : '';
        $message = isset($_POST['activation_message']) ? wp_kses_post(wp_unslash($_POST['activation_message'])) : '';
        $order_id = isset($_POST['activation_order_id']) ? absint($_POST['activation_order_id']) : 0;
        if (!$product || !$domain) {
            $this->set_notice('is-error', 'Please add product name and website domain.');
            return;
        }
        if ($order_id) {
            $order = wc_get_order($order_id);
            if (!$order || (int) $order->get_customer_id() !== get_current_user_id()) $order_id = 0;
        }
        $title = 'Activation Request: ' . $product;
        $request_id = wp_insert_post([
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
            'post_title' => $title,
            'post_content' => $message,
        ], true);
        if (is_wp_error($request_id)) {
            $this->set_notice('is-error', $request_id->get_error_message());
            return;
        }
        update_post_meta($request_id, '_mrcp_activation_status', 'pending');
        update_post_meta($request_id, '_mrcp_activation_product', $product);
        update_post_meta($request_id, '_mrcp_activation_domain', $domain);
        update_post_meta($request_id, '_mrcp_activation_login_url', $login_url);
        update_post_meta($request_id, '_mrcp_activation_username', $username);
        if ($password) update_post_meta($request_id, '_mrcp_activation_password', $this->encrypt_secret($password));
        if ($order_id) update_post_meta($request_id, '_mrcp_activation_order_id', $order_id);
        $this->notify_admin_new_activation($request_id);
        $this->notify_customer_activation_created($request_id);
        $this->set_notice('is-success', 'Your activation request has been submitted successfully.');
        wp_safe_redirect($this->activation_url());
        exit;
    }

    private function notify_admin_new_activation($request_id) {
        $post = get_post(absint($request_id));
        if (!$post) return;
        $user = get_user_by('id', (int) $post->post_author);
        $order_id = absint(get_post_meta($request_id, '_mrcp_activation_order_id', true));
        $rows = [
            'Request ID' => 'ACT-' . $request_id,
            'Customer' => $user ? $user->display_name : 'Unknown',
            'Customer Email' => $user ? $user->user_email : '',
            'Product' => get_post_meta($request_id, '_mrcp_activation_product', true),
            'Website' => get_post_meta($request_id, '_mrcp_activation_domain', true),
            'Login URL' => get_post_meta($request_id, '_mrcp_activation_login_url', true),
            'Related Order' => $order_id ? '#' . $this->display_order_number($order_id) : 'Not selected',
        ];
        $body = '<p>A new license/plugin activation request has been submitted.</p><table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin:18px 0;">';
        foreach ($rows as $label => $value) $body .= '<tr><td style="padding:9px 0;color:#6b7b7b;width:150px;border-bottom:1px solid #eef3f3;">' . esc_html($label) . '</td><td style="padding:9px 0;font-weight:700;border-bottom:1px solid #eef3f3;">' . esc_html($value) . '</td></tr>';
        $body .= '</table><p><strong>Customer Note:</strong></p>' . wp_kses_post(wpautop($post->post_content));
        wp_mail($this->notification_admin_email(), '🔑 New Activation Request ACT-' . $request_id, $this->html_email('New Activation Request ACT-' . $request_id, $body, 'View Activation Request', admin_url('post.php?post=' . absint($request_id) . '&action=edit')), $this->mail_headers());
    }

    private function notify_customer_activation_created($request_id) {
        $post = get_post(absint($request_id));
        if (!$post) return;
        $user = get_user_by('id', (int) $post->post_author);
        if (!$user || empty($user->user_email)) return;
        $body = '<p>Hello ' . esc_html($user->display_name) . ',</p><p>Your activation request has been received. Our support team will review it and update the status from your dashboard.</p><p><strong>Request ID:</strong> ACT-' . esc_html($request_id) . '</p>';
        wp_mail($user->user_email, 'Your activation request has been received ACT-' . $request_id, $this->html_email('Activation Request Received', $body, 'View Activation Requests', $this->activation_url()), $this->mail_headers());
    }

    private function notify_customer_activation_update($request_id, $status, $note = '') {
        $post = get_post(absint($request_id));
        if (!$post) return;
        $user = get_user_by('id', (int) $post->post_author);
        if (!$user || empty($user->user_email)) return;
        $body = '<p>Hello ' . esc_html($user->display_name) . ',</p><p>Your activation request has been updated.</p><p><strong>Request ID:</strong> ACT-' . esc_html($request_id) . '<br><strong>Status:</strong> ' . esc_html($this->activation_status_label($status)) . '</p>';
        if ($note) $body .= '<p><strong>Support Note:</strong></p>' . wp_kses_post(wpautop($note));
        wp_mail($user->user_email, 'Activation request updated ACT-' . $request_id, $this->html_email('Activation Request Updated', $body, 'View Activation Requests', $this->activation_url()), $this->mail_headers());
    }

    private function render_activation_page() {
        $filter = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : 'all';
        $requests = $this->activation_requests(30, $filter);
        $statuses = $this->activation_statuses();
        echo '<section class="mrcp-module-page mrcp-activation-page">';
        echo '<div class="mrcp-module-head"><div><span>' . ($this->is_support_admin() ? 'Admin License Manager' : 'License Manager') . '</span><h1>Activation Requests</h1><p>' . ($this->is_support_admin() ? 'Review customer activation requests, open details, activate licenses, update status, and notify customers.' : 'Submit plugin/theme activation requests, track status, and link them with your WooCommerce orders.') . '</p></div>' . ($this->is_support_admin() ? '<a href="' . esc_url($this->activation_url()) . '">Refresh</a>' : '<a href="#new-activation">+ New Request</a>') . '</div>';
        echo '<div class="mrcp-ticket-stats mrcp-activation-stats">';
        foreach ($statuses as $key => $label) echo '<div><strong>' . esc_html($this->activation_count($key)) . '</strong><span>' . esc_html($label) . '</span></div>';
        echo '</div><div class="mrcp-ticket-layout mrcp-activation-layout"><div class="mrcp-ticket-list-card">';
        echo '<div class="mrcp-ticket-filter"><a class="' . ($filter === 'all' ? 'is-active' : '') . '" href="' . esc_url($this->activation_url()) . '">All</a>';
        foreach ($statuses as $key => $label) echo '<a class="' . ($filter === $key ? 'is-active' : '') . '" href="' . esc_url(add_query_arg('status', $key, $this->activation_url())) . '">' . esc_html($label) . '</a>';
        echo '</div>';
        if ($requests) {
            if ($this->is_support_admin()) {
                echo '<div class="mrcp-ticket-table mrcp-activation-table mrcp-admin-activation-table"><div class="mrcp-ticket-row is-head mrcp-activation-admin-row"><span>Request ID</span><span>Customer</span><span>Product</span><span>Website</span><span>Status</span><span>Date</span></div>';
            } else {
                echo '<div class="mrcp-ticket-table mrcp-activation-table"><div class="mrcp-ticket-row is-head"><span>Request</span><span>Website</span><span>Status</span><span>Updated</span></div>';
            }
            foreach ($requests as $request) $this->activation_row($request);
            echo '</div>';
        } else {
            $this->empty_state('🔑', 'No activation requests yet', 'Create a new request when you need plugin or theme activation support.');
        }
        echo '</div>';
        if (!$this->is_support_admin()) {
            echo '<form method="post" class="mrcp-new-ticket-card mrcp-activation-form" id="new-activation">';
            wp_nonce_field('mrcp_create_activation', 'mrcp_activation_nonce');
            echo '<input type="hidden" name="mrcp_create_activation" value="1"><h2>Create Activation Request</h2><p>Use temporary WordPress login details and delete the temporary user after activation is completed.</p>';
            echo '<label><span>Product / Theme / Plugin</span><input name="activation_product" required placeholder="Example: Elementor Pro"></label>';
            echo '<label><span>Website Domain</span><input name="activation_domain" type="url" required placeholder="https://example.com"></label>';
            echo '<div class="mrcp-ticket-form-grid">';
            $this->activation_order_select();
            echo '<label><span>WP Login URL <small>Optional</small></span><input name="activation_login_url" type="url" placeholder="https://example.com/wp-admin"></label>';
            echo '</div><div class="mrcp-ticket-form-grid">';
            echo '<label><span>WP Username <small>Optional</small></span><input name="activation_username" placeholder="Temporary admin username"></label>';
            echo '<label><span>WP Password <small>Optional</small></span><input name="activation_password" type="password" placeholder="Temporary admin password"></label>';
            echo '</div>';
            echo '<label><span>Message / Instruction</span><textarea name="activation_message" rows="5" placeholder="Tell us what needs to be activated..."></textarea></label>';
            echo '<button type="submit" class="mrcp-save-btn">Submit Activation Request</button>';
            echo '</form>';
        }
        echo '</div></section>';
    }

    private function activation_order_select() {
        echo '<label><span>Related Order <small>Optional</small></span><select name="activation_order_id"><option value="0">No related order</option>';
        foreach ($this->recent_orders(50) as $order) {
            if (!$order || !is_a($order, 'WC_Order')) continue;
            echo '<option value="' . esc_attr($order->get_id()) . '">#' . esc_html($order->get_order_number()) . ' — ' . wp_kses_post($order->get_formatted_order_total()) . '</option>';
        }
        echo '</select></label>';
    }

    private function activation_row($request) {
        $status = get_post_meta($request->ID, '_mrcp_activation_status', true) ?: 'pending';
        $domain = get_post_meta($request->ID, '_mrcp_activation_domain', true);
        $product = get_post_meta($request->ID, '_mrcp_activation_product', true) ?: $request->post_title;
        if ($this->is_support_admin()) {
            $customer = get_user_by('id', (int) $request->post_author);
            $customer_name = $customer ? $customer->display_name : 'Customer';
            $customer_email = $customer ? $customer->user_email : '';
            $membership_label = '';
            if (class_exists('MRCP_Membership')) {
                $membership_label = MRCP_Membership::get_level_name((int) $request->post_author);
            }
            $order_id = absint(get_post_meta($request->ID, '_mrcp_activation_order_id', true));
            $host = $domain ? (wp_parse_url($domain, PHP_URL_HOST) ?: $domain) : '—';
            echo '<a class="mrcp-ticket-row mrcp-activation-row mrcp-activation-admin-row" href="' . esc_url($this->activation_view_url($request->ID)) . '">';
            echo '<span class="mrcp-request-id"><strong>ACT-' . esc_html($request->ID) . '</strong><small>Open request</small></span>';
            echo '<span class="mrcp-customer-cell"><strong>' . esc_html($customer_name) . '</strong><small>' . esc_html($membership_label ?: $customer_email) . '</small></span>';
            echo '<span class="mrcp-product-cell"><strong>' . esc_html($product) . '</strong><small>' . ($order_id ? 'Order #' . esc_html($this->display_order_number($order_id)) : 'No related order') . '</small></span>';
            echo '<span class="mrcp-website-cell"><strong>' . esc_html($host) . '</strong><small>' . esc_html($domain ?: '') . '</small></span>';
            echo '<span class="mrcp-ticket-status"><b class="activation-status-' . esc_attr($status) . '">' . esc_html($this->activation_status_label($status)) . '</b></span>';
            echo '<span class="mrcp-ticket-date"><strong>' . esc_html(get_the_date('M j, Y', $request)) . '</strong><small>' . esc_html(get_the_modified_date('g:i A', $request)) . '</small></span>';
            echo '</a>';
            return;
        }

        echo '<a class="mrcp-ticket-row mrcp-activation-row" href="' . esc_url($this->activation_view_url($request->ID)) . '">';
        echo '<span class="mrcp-ticket-main"><strong>ACT-' . esc_html($request->ID) . '</strong><small>' . esc_html($product) . '</small></span>';
        echo '<span class="mrcp-ticket-category">' . ($domain ? esc_html(wp_parse_url($domain, PHP_URL_HOST) ?: $domain) : '—') . '</span>';
        echo '<span class="mrcp-ticket-status"><b class="activation-status-' . esc_attr($status) . '">' . esc_html($this->activation_status_label($status)) . '</b></span>';
        echo '<span class="mrcp-ticket-date">' . esc_html(get_the_modified_date('M j, Y', $request)) . '</span>';
        echo '</a>';
    }

    private function get_activation_request($request_id) {
        $request_id = absint($request_id);
        if (!$request_id) return false;
        $request = get_post($request_id);
        if (!$request || $request->post_type !== 'mrcp_activation' || $request->post_status !== 'publish') return false;
        if (!$this->is_support_admin() && (int) $request->post_author !== get_current_user_id()) return false;
        return $request;
    }

    private function handle_activation_update_from_portal() {
        if (!$this->is_support_admin()) {
            $this->set_notice('is-error', 'You do not have permission to update activation requests.');
            return;
        }
        if (!isset($_POST['mrcp_activation_update_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mrcp_activation_update_nonce'])), 'mrcp_update_activation')) {
            $this->set_notice('is-error', 'Security check failed. Please try again.');
            return;
        }
        $request_id = isset($_POST['activation_request_id']) ? absint($_POST['activation_request_id']) : 0;
        $request = $this->get_activation_request($request_id);
        if (!$request) {
            $this->set_notice('is-error', 'Activation request not found.');
            return;
        }
        $old_status = get_post_meta($request_id, '_mrcp_activation_status', true) ?: 'pending';
        $status = isset($_POST['activation_status']) ? sanitize_key(wp_unslash($_POST['activation_status'])) : $old_status;
        if (!empty($_POST['mrcp_mark_activation_complete'])) {
            $status = 'completed';
        }
        if (!array_key_exists($status, $this->activation_statuses())) {
            $status = $old_status;
        }
        $note = isset($_POST['activation_admin_note']) ? wp_kses_post(wp_unslash($_POST['activation_admin_note'])) : '';
        update_post_meta($request_id, '_mrcp_activation_status', $status);
        update_post_meta($request_id, '_mrcp_activation_last_updated_by', get_current_user_id());
        update_post_meta($request_id, '_mrcp_activation_last_updated_at', current_time('mysql'));
        if ($note !== '') {
            update_post_meta($request_id, '_mrcp_activation_admin_note', $note);
            wp_insert_comment([
                'comment_post_ID' => $request_id,
                'comment_content' => $note,
                'user_id' => get_current_user_id(),
                'comment_author' => 'Support Team',
                'comment_author_email' => $this->notification_admin_email(),
                'comment_approved' => 1,
                'comment_type' => 'mrcp_activation_update',
            ]);
        }
        $customer_id = (int) $request->post_author;
        if ($customer_id) {
            $this->add_notification($customer_id, 'Activation request ACT-' . $request_id . ' updated', 'Status: ' . $this->activation_status_label($status), $this->activation_view_url($request_id), 'activation');
        }
        if (!empty($_POST['activation_email_customer'])) {
            $this->notify_customer_activation_update($request_id, $status, $note);
        }
        $this->set_notice('is-success', $status === 'completed' ? 'License activated and request completed.' : 'Activation request updated successfully.');
        wp_safe_redirect($this->activation_view_url($request_id));
        exit;
    }

    private function render_activation_view_page() {
        $request_id = absint(get_query_var('mrcp_activation_id'));
        $request = $this->get_activation_request($request_id);
        if (!$request) {
            echo '<section class="mrcp-module-page">';
            $this->empty_state('🔑', 'Activation request not available', 'This activation request could not be found in your account.');
            echo '</section>';
            return;
        }
        $status = get_post_meta($request_id, '_mrcp_activation_status', true) ?: 'pending';
        $product = get_post_meta($request_id, '_mrcp_activation_product', true) ?: $request->post_title;
        $domain = get_post_meta($request_id, '_mrcp_activation_domain', true);
        $login_url = get_post_meta($request_id, '_mrcp_activation_login_url', true);
        $username = get_post_meta($request_id, '_mrcp_activation_username', true);
        $password = $this->decrypt_secret(get_post_meta($request_id, '_mrcp_activation_password', true));
        $order_id = absint(get_post_meta($request_id, '_mrcp_activation_order_id', true));
        $admin_note = get_post_meta($request_id, '_mrcp_activation_admin_note', true);
        $customer = get_user_by('id', (int) $request->post_author);
        $updates = get_comments(['post_id' => $request_id, 'status' => 'approve', 'type' => 'mrcp_activation_update', 'order' => 'ASC']);

        echo '<section class="mrcp-ticket-view mrcp-activation-view' . (isset($_GET['mrcp_highlight']) ? ' mrcp-notification-highlight' : '') . '">';
        echo '<div class="mrcp-order-toolbar"><div class="mrcp-toolbar-back-links"><a href="' . esc_url($this->activation_url()) . '">← Back to Activation Requests</a>' . (isset($_GET['mrcp_from_notification']) ? '<a class="mrcp-back-dashboard" href="' . esc_url($this->url('crm')) . '">← Back to CRM Dashboard</a>' : '') . '</div><div>' . ($this->is_support_admin() ? '<a class="is-primary" href="#activation-admin-update">Update Request</a>' : '') . '</div></div>';
        echo '<div class="mrcp-ticket-hero"><div><span>Activation Request ACT-' . esc_html($request_id) . '</span><h1>' . esc_html($product) . '</h1><p>Created ' . esc_html(get_the_date('F j, Y', $request)) . ' • Updated ' . esc_html(get_the_modified_date('F j, Y', $request)) . '</p></div><div class="mrcp-ticket-status-card"><small>Status</small><strong class="activation-status-' . esc_attr($status) . '">' . esc_html($this->activation_status_label($status)) . '</strong></div></div>';
        echo '<div class="mrcp-ticket-view-grid">';
        echo '<div class="mrcp-ticket-thread">';
        echo '<article class="mrcp-ticket-message is-customer"><div><strong>' . esc_html($customer ? $customer->display_name : 'Customer') . '</strong><small>' . esc_html(get_the_date('F j, Y g:i A', $request)) . '</small></div><p>' . wp_kses_post(wpautop($request->post_content ?: 'Activation request submitted.')) . '</p></article>';
        if ($updates) {
            foreach ($updates as $update) {
                echo '<article class="mrcp-ticket-message is-admin"><div><strong>Support Team</strong><small>' . esc_html(get_comment_date('F j, Y g:i A', $update)) . '</small></div><p>' . wp_kses_post(wpautop($update->comment_content)) . '</p></article>';
            }
        } elseif ($admin_note) {
            echo '<article class="mrcp-ticket-message is-admin"><div><strong>Support Team</strong><small>Latest update</small></div><p>' . wp_kses_post(wpautop($admin_note)) . '</p></article>';
        }
        echo '<div class="mrcp-order-card"><h2>Request Details</h2><div class="mrcp-admin-activation-grid">';
        echo '<div><span>Product</span><strong>' . esc_html($product) . '</strong></div>';
        echo '<div><span>Website Domain</span><strong>' . ($domain ? '<a target="_blank" href="' . esc_url($domain) . '">' . esc_html($domain) . '</a>' : '—') . '</strong></div>';
        if ($this->is_support_admin()) {
            echo '<div><span>WP Login URL</span><strong>' . ($login_url ? '<a target="_blank" href="' . esc_url($login_url) . '">' . esc_html($login_url) . '</a>' : '—') . '</strong></div>';
            echo '<div><span>WP Username</span><strong>' . esc_html($username ?: '—') . '</strong></div>';
            echo '<div><span>Temporary Password</span><strong>' . esc_html($password ?: 'Not provided') . '</strong></div>';
        }
        echo '</div></div>';

        if ($this->is_support_admin()) {
            echo '<form method="post" class="mrcp-reply-card mrcp-activation-admin-form" id="activation-admin-update">';
            wp_nonce_field('mrcp_update_activation', 'mrcp_activation_update_nonce');
            echo '<input type="hidden" name="mrcp_update_activation" value="1"><input type="hidden" name="activation_request_id" value="' . esc_attr($request_id) . '">';
            echo '<h2>Admin Activation Workflow</h2><p>Open the request, activate the license, update status, and email the customer.</p>';
            echo '<label><span>Status</span><select name="activation_status">';
            foreach ($this->activation_statuses() as $key => $label) {
                echo '<option value="' . esc_attr($key) . '" ' . selected($status, $key, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select></label>';
            echo '<label><span>Admin Note / Reply</span><textarea name="activation_admin_note" rows="5" placeholder="Write update for customer...">' . esc_textarea($admin_note) . '</textarea></label>';
            echo '<label class="mrcp-close-after"><input type="checkbox" name="activation_email_customer" value="1" checked> Email this update to customer</label>';
            echo '<div class="mrcp-admin-action-row"><button type="submit" class="mrcp-save-btn">Update Request</button> <button type="submit" name="mrcp_mark_activation_complete" value="1" class="mrcp-save-btn mrcp-complete-btn">Activate License & Complete Request</button></div>';
            echo '</form>';
        }
        echo '</div>';
        echo '<aside class="mrcp-ticket-info">';
        echo '<div><span>Request ID</span><strong>ACT-' . esc_html($request_id) . '</strong></div>';
        echo '<div><span>Status</span><strong class="activation-status-' . esc_attr($status) . '">' . esc_html($this->activation_status_label($status)) . '</strong></div>';
        if ($order_id) echo '<div><span>Related Order</span><strong><a href="' . esc_url($this->order_view_url($order_id)) . '">#' . esc_html($this->display_order_number($order_id)) . '</a></strong></div>';
        if ($domain) echo '<div><span>Website</span><strong><a target="_blank" href="' . esc_url($domain) . '">' . esc_html(wp_parse_url($domain, PHP_URL_HOST) ?: $domain) . '</a></strong></div>';
        echo '<div class="mrcp-ticket-help"><h3>Activation steps</h3><p>Open the website login, activate the product/license, then mark the request completed and notify the customer.</p></div>';
        echo '</aside></div></section>';
    }
}
