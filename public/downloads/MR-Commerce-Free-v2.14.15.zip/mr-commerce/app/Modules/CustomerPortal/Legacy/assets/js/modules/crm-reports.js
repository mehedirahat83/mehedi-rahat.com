(function () {
    'use strict';

    function qsa(root, selector) {
        return Array.prototype.slice.call(root.querySelectorAll(selector));
    }

    function createTooltip(root) {
        var tooltip = root.querySelector('.mrcp-chart-tooltip');
        if (tooltip) return tooltip;

        tooltip = document.createElement('div');
        tooltip.className = 'mrcp-chart-tooltip';
        tooltip.setAttribute('role', 'status');
        tooltip.setAttribute('aria-live', 'polite');
        tooltip.innerHTML = '<strong></strong><span></span><small></small>';
        root.appendChild(tooltip);
        return tooltip;
    }

    function showTooltip(root, target, title, value, note, event) {
        var tooltip = createTooltip(root);
        tooltip.querySelector('strong').textContent = title || '';
        tooltip.querySelector('span').textContent = value || '';
        tooltip.querySelector('small').textContent = note || '';

        var rootRect = root.getBoundingClientRect();
        var targetRect = target.getBoundingClientRect();
        var left = event && typeof event.clientX === 'number'
            ? event.clientX - rootRect.left
            : targetRect.left - rootRect.left + (targetRect.width / 2);
        var top = event && typeof event.clientY === 'number'
            ? event.clientY - rootRect.top
            : targetRect.top - rootRect.top;

        tooltip.style.left = Math.max(82, Math.min(rootRect.width - 82, left)) + 'px';
        tooltip.style.top = Math.max(16, top - 14) + 'px';
        tooltip.classList.add('is-visible');
    }

    function hideTooltip(root) {
        var tooltip = root.querySelector('.mrcp-chart-tooltip');
        if (tooltip) tooltip.classList.remove('is-visible');
    }

    function animateBars(root) {
        qsa(root, '.mrcp-bi__bar > i, .mrcp-ri__trend-item span > i, .mrcp-ci__growth-chart i > b, .mrcp-oi__trend i > b, .mrcp-pi__bars i > u, .mrcp-ri__weekdays i > b, .mrcp-ri__payment-list i > b, .mrcp-oi__meter-list i > b').forEach(function (bar, index) {
            var target = bar.style.height || bar.style.width || '';
            if (!target) return;
            var vertical = !!bar.style.height;
            bar.style.setProperty('--mrcp-target-size', target);
            bar.style[vertical ? 'height' : 'width'] = '0';
            bar.classList.add('mrcp-chart-animate');
            window.setTimeout(function () {
                bar.style[vertical ? 'height' : 'width'] = target;
            }, 45 + (index * 28));
        });
    }

    function decorateOverviewChart(root) {
        var chart = root.querySelector('.mrcp-bi__chart');
        if (!chart || chart.dataset.chartReady === '1') return;
        chart.dataset.chartReady = '1';
        chart.classList.add('mrcp-chart-shell');

        var items = qsa(chart, '.mrcp-bi__bar');
        var maxValue = -Infinity;
        var maxItem = null;

        items.forEach(function (item) {
            var valueNode = item.querySelector('b');
            var bar = item.querySelector('i');
            var label = item.querySelector('span');
            var note = item.querySelector('small');
            var height = bar ? parseFloat(bar.style.height) || 0 : 0;

            if (height > maxValue) {
                maxValue = height;
                maxItem = item;
            }

            function open(event) {
                showTooltip(chart, item, label ? label.textContent : '', valueNode ? valueNode.textContent : '', note ? note.textContent : '', event);
            }

            item.addEventListener('mouseenter', open);
            item.addEventListener('mousemove', open);
            item.addEventListener('focusin', open);
            item.addEventListener('mouseleave', function () { hideTooltip(chart); });
            item.addEventListener('focusout', function () { hideTooltip(chart); });
            item.setAttribute('tabindex', '0');
        });

        if (maxItem) {
            maxItem.classList.add('is-chart-peak');
            var peak = document.createElement('span');
            peak.className = 'mrcp-chart-peak-label';
            peak.textContent = 'Highest';
            maxItem.appendChild(peak);
        }
    }

    function buildLineOverlay(chart, itemSelector, barSelector) {
        if (!chart || chart.querySelector('.mrcp-chart-line-overlay')) return;
        var items = qsa(chart, itemSelector);
        if (items.length < 2) return;

        window.requestAnimationFrame(function () {
            var chartRect = chart.getBoundingClientRect();
            if (!chartRect.width || !chartRect.height) return;

            var points = [];
            items.forEach(function (item) {
                var bar = item.querySelector(barSelector);
                if (!bar) return;
                var rect = bar.getBoundingClientRect();
                points.push({
                    x: rect.left - chartRect.left + (rect.width / 2),
                    y: rect.top - chartRect.top
                });
            });
            if (points.length < 2) return;

            var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svg.setAttribute('class', 'mrcp-chart-line-overlay');
            svg.setAttribute('viewBox', '0 0 ' + chartRect.width + ' ' + chartRect.height);
            svg.setAttribute('preserveAspectRatio', 'none');
            svg.setAttribute('aria-hidden', 'true');

            var defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
            var gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
            gradient.setAttribute('id', 'mrcpLineGradient' + Math.random().toString(36).slice(2));
            gradient.setAttribute('x1', '0%');
            gradient.setAttribute('x2', '100%');
            var stopOne = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
            stopOne.setAttribute('offset', '0%');
            stopOne.setAttribute('stop-color', '#14b8a6');
            var stopTwo = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
            stopTwo.setAttribute('offset', '100%');
            stopTwo.setAttribute('stop-color', '#2563eb');
            gradient.appendChild(stopOne);
            gradient.appendChild(stopTwo);
            defs.appendChild(gradient);
            svg.appendChild(defs);

            var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            var d = points.map(function (point, index) {
                return (index === 0 ? 'M ' : 'L ') + point.x.toFixed(1) + ' ' + point.y.toFixed(1);
            }).join(' ');
            path.setAttribute('d', d);
            path.setAttribute('class', 'mrcp-chart-line-path');
            path.setAttribute('style', 'stroke:url(#' + gradient.id + ')');
            svg.appendChild(path);

            points.forEach(function (point) {
                var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', point.x.toFixed(1));
                circle.setAttribute('cy', point.y.toFixed(1));
                circle.setAttribute('r', '4');
                circle.setAttribute('class', 'mrcp-chart-line-dot');
                svg.appendChild(circle);
            });

            chart.appendChild(svg);
        });
    }

    function decorateRevenueChart(root) {
        var chart = root.querySelector('.mrcp-ri__trend');
        if (!chart || chart.dataset.chartReady === '1') return;
        chart.dataset.chartReady = '1';
        chart.classList.add('mrcp-chart-shell', 'mrcp-chart-line-enabled');

        qsa(chart, '.mrcp-ri__trend-item').forEach(function (item) {
            var month = item.querySelector('strong');
            var value = item.querySelector('b');
            var note = item.querySelector('small');
            function open(event) {
                showTooltip(chart, item, month ? month.textContent : '', value ? value.textContent : '', note ? note.textContent : '', event);
            }
            item.setAttribute('tabindex', '0');
            item.addEventListener('mouseenter', open);
            item.addEventListener('mousemove', open);
            item.addEventListener('focusin', open);
            item.addEventListener('mouseleave', function () { hideTooltip(chart); });
            item.addEventListener('focusout', function () { hideTooltip(chart); });
        });

        buildLineOverlay(chart, '.mrcp-ri__trend-item', 'span > i');
    }

    function decorateSimpleCharts(root) {
        qsa(root, '.mrcp-ci__growth-chart, .mrcp-oi__trend').forEach(function (chart) {
            chart.classList.add('mrcp-chart-shell');
        });

        // Horizontal progress/list components are not chart canvases. An
        // earlier broad selector added chart grid pseudo-elements to them.
        qsa(root, '.mrcp-pi__bars, .mrcp-ri__weekdays, .mrcp-ri__payment-list').forEach(function (list) {
            list.classList.remove('mrcp-chart-shell');
        });
    }

    function buildPaymentDonut(root) {
        var list = root.querySelector('.mrcp-ri__payment-list');
        if (!list || list.dataset.donutReady === '1') return;
        var rows = qsa(list, ':scope > div');
        if (!rows.length) return;

        var palette = ['#0f9f91', '#2563eb', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4'];
        var values = [];
        var total = 0;
        rows.forEach(function (row) {
            var widthBar = row.querySelector('i > b');
            var value = widthBar ? parseFloat(widthBar.style.width) || 0 : 0;
            values.push(value);
            total += value;
        });
        if (!total) return;

        var segments = [];
        var cursor = 0;
        values.forEach(function (value, index) {
            var share = (value / total) * 100;
            var end = cursor + share;
            segments.push(palette[index % palette.length] + ' ' + cursor.toFixed(2) + '% ' + end.toFixed(2) + '%');
            cursor = end;
            rows[index].style.setProperty('--mrcp-series-color', palette[index % palette.length]);
        });

        var donut = document.createElement('div');
        donut.className = 'mrcp-payment-donut';
        donut.style.background = 'conic-gradient(' + segments.join(',') + ')';
        donut.innerHTML = '<div><strong>' + rows.length + '</strong><span>Methods</span></div>';
        list.parentNode.insertBefore(donut, list);
        list.parentNode.classList.add('mrcp-payment-visual');
        list.dataset.donutReady = '1';
    }

    function initCharts(root) {
        animateBars(root);
        decorateOverviewChart(root);
        decorateRevenueChart(root);
        decorateSimpleCharts(root);
        buildPaymentDonut(root);
    }

    function initBusinessIntelligence() {
        var root = document.querySelector('[data-mrcp-bi]');
        if (!root) return;

        var tabs = qsa(root, '[data-bi-tab]');
        var panels = qsa(root, '[data-bi-panel]');

        function activate(name, updateHash) {
            tabs.forEach(function (tab) {
                var active = tab.getAttribute('data-bi-tab') === name;
                tab.classList.toggle('is-active', active);
                tab.setAttribute('aria-selected', active ? 'true' : 'false');
                tab.setAttribute('tabindex', active ? '0' : '-1');
            });

            panels.forEach(function (panel) {
                var active = panel.getAttribute('data-bi-panel') === name;
                panel.classList.toggle('is-active', active);
                panel.hidden = !active;
                if (active) {
                    window.requestAnimationFrame(function () {
                        initCharts(panel);
                    });
                }
            });

            if (updateHash && window.history && window.history.replaceState) {
                window.history.replaceState(null, '', '#bi-' + name);
            }
        }

        tabs.forEach(function (tab, index) {
            tab.addEventListener('click', function () {
                activate(tab.getAttribute('data-bi-tab'), true);
            });

            tab.addEventListener('keydown', function (event) {
                if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
                event.preventDefault();
                var direction = event.key === 'ArrowRight' ? 1 : -1;
                var next = (index + direction + tabs.length) % tabs.length;
                tabs[next].focus();
                activate(tabs[next].getAttribute('data-bi-tab'), true);
            });
        });

        var initial = window.location.hash.replace('#bi-', '');
        if (!tabs.some(function (tab) { return tab.getAttribute('data-bi-tab') === initial; })) {
            initial = 'overview';
        }
        activate(initial, false);

        var resizeTimer;
        window.addEventListener('resize', function () {
            window.clearTimeout(resizeTimer);
            resizeTimer = window.setTimeout(function () {
                qsa(root, '.mrcp-chart-line-overlay').forEach(function (svg) { svg.remove(); });
                var activePanel = root.querySelector('[data-bi-panel].is-active');
                if (activePanel) decorateRevenueChart(activePanel);
            }, 180);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBusinessIntelligence);
    } else {
        initBusinessIntelligence();
    }
}());
