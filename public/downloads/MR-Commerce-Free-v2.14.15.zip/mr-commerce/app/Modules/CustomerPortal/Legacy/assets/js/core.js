(function(){
  'use strict';
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.mrcp-hero,.mrcp-stat,.mrcp-roadmap,.mrcp-motivation,.mrcp-action,.mrcp-widget,.mrcp-module-page').forEach(function(el,i){
      el.style.opacity='0';
      el.style.transform='translateY(14px)';
      window.setTimeout(function(){
        el.style.transition='opacity .45s ease, transform .45s ease, box-shadow .24s ease';
        el.style.opacity='1';
        el.style.transform='translateY(0)';
      },55*i);
    });
  });
})();
