<?php
/**
 * Real Membership Engine for MR Commerce Pro.
 *
 * Version 7.1.0
 * - Lifetime spending is calculated from WooCommerce completed orders only.
 * - Refund-aware by subtracting refunded amounts from completed orders.
 * - Provides public API for future modules: discounts, notifications, rewards, dashboard.
 */

if (!defined('ABSPATH')) {
    exit;
}

final class MRCP_Membership {
    const CACHE_GROUP = 'mrcp_membership';
    const CACHE_PREFIX = 'mrcp_membership_user_';
    const META_LEVEL = '_mrcp_membership_level';
    const META_SPEND = '_mrcp_lifetime_spend';
    const META_UPDATED = '_mrcp_membership_updated_at';

    /**
     * Boot WooCommerce hooks.
     */
    public static function init() {
        add_action('woocommerce_order_status_changed', [__CLASS__, 'handle_order_status_changed'], 10, 4);
        add_action('woocommerce_order_refunded', [__CLASS__, 'handle_order_refunded'], 10, 2);
        add_action('woocommerce_refund_created', [__CLASS__, 'handle_refund_created'], 10, 2);
        add_action('woocommerce_delete_order', [__CLASS__, 'handle_order_deleted'], 10, 1);
        add_action('deleted_post', [__CLASS__, 'handle_deleted_post'], 10, 1);
    }

    /**
     * Membership rules. Later this can be moved to admin settings.
     */
    public static function rules() {
        $rules = [
            'silver' => [
                'key' => 'silver',
                'name' => 'Silver Member',
                'short' => 'Silver',
                'icon' => '🥈',
                'min' => 0,
                'max' => 10000,
                'discount' => 0,
                'range' => '৳ 0 - ৳ 9,999',
                'next_key' => 'gold',
            ],
            'gold' => [
                'key' => 'gold',
                'name' => 'Gold Member',
                'short' => 'Gold',
                'icon' => '🥇',
                'min' => 10000,
                'max' => 50000,
                'discount' => 10,
                'range' => '৳ 10,000 - ৳ 49,999',
                'next_key' => 'diamond',
            ],
            'diamond' => [
                'key' => 'diamond',
                'name' => 'Diamond Member',
                'short' => 'Diamond',
                'icon' => '💎',
                'min' => 50000,
                'max' => 100000,
                'discount' => 20,
                'range' => '৳ 50,000 - ৳ 99,999',
                'next_key' => 'vip',
            ],
            'vip' => [
                'key' => 'vip',
                'name' => 'VIP Member',
                'short' => 'VIP',
                'icon' => '👑',
                'min' => 100000,
                'max' => null,
                'discount' => 30,
                'range' => '৳ 100,000+',
                'next_key' => null,
            ],
        ];

        /**
         * Filter membership rules.
         *
         * @param array $rules Membership rules.
         */
        return apply_filters('mrcp_membership_rules', $rules);
    }

    /**
     * Public API: full membership data for a customer.
     */
    public static function get_customer_membership($user_id = 0, $force_refresh = false) {
        $user_id = self::normalize_user_id($user_id);
        if (!$user_id) {
            return self::resolve_by_spend(0, 0);
        }

        $cache_key = self::cache_key($user_id);
        if (!$force_refresh) {
            $cached = get_transient($cache_key);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $spent = self::get_lifetime_spend($user_id, $force_refresh);
        $data = self::resolve_by_spend($spent, $user_id);

        set_transient($cache_key, $data, HOUR_IN_SECONDS);

        update_user_meta($user_id, self::META_LEVEL, $data['key']);
        update_user_meta($user_id, self::META_SPEND, $data['spent']);
        update_user_meta($user_id, self::META_UPDATED, current_time('mysql'));

        return $data;
    }

    /**
     * Public API: calculate lifetime spending from completed WooCommerce orders only.
     * Refunded amounts are subtracted from order totals.
     */
    public static function get_lifetime_spend($user_id = 0, $force_refresh = false) {
        $user_id = self::normalize_user_id($user_id);
        if (!$user_id || !self::woocommerce_available()) {
            return 0.0;
        }

        $cache_key = self::cache_key($user_id, 'spend');
        if (!$force_refresh) {
            $cached = get_transient($cache_key);
            if ($cached !== false) {
                return (float) $cached;
            }
        }

        $total = 0.0;
        $page = 1;
        $limit = 50;

        do {
            $orders = wc_get_orders([
                'customer_id' => $user_id,
                'status' => ['completed'],
                'limit' => $limit,
                'paged' => $page,
                'return' => 'objects',
                'orderby' => 'date',
                'order' => 'DESC',
            ]);

            if (empty($orders)) {
                break;
            }

            foreach ($orders as $order) {
                if (!is_a($order, 'WC_Order')) {
                    continue;
                }

                $order_total = (float) $order->get_total();
                $refunded = method_exists($order, 'get_total_refunded') ? (float) $order->get_total_refunded() : 0.0;
                $net_total = max(0, $order_total - $refunded);

                /**
                 * Filter amount counted toward lifetime membership spend per order.
                 */
                $net_total = (float) apply_filters('mrcp_membership_order_spend_amount', $net_total, $order, $user_id);
                $total += max(0, $net_total);
            }

            $page++;
        } while (count($orders) === $limit);

        $total = round($total, 2);
        set_transient($cache_key, $total, HOUR_IN_SECONDS);

        return $total;
    }

    /**
     * Resolve membership data by a spending amount.
     */
    public static function resolve_by_spend($spent, $user_id = 0) {
        $spent = max(0, (float) $spent);
        $rules = self::rules();
        $current_key = 'silver';

        foreach ($rules as $key => $rule) {
            $min = isset($rule['min']) ? (float) $rule['min'] : 0;
            $max = array_key_exists('max', $rule) && $rule['max'] !== null ? (float) $rule['max'] : null;

            if ($spent >= $min && ($max === null || $spent < $max)) {
                $current_key = $key;
                break;
            }
        }

        $current = $rules[$current_key];
        $next_key = !empty($current['next_key']) ? $current['next_key'] : null;
        $next = $next_key && isset($rules[$next_key]) ? $rules[$next_key] : null;

        $needed = 0.0;
        $target = null;
        $progress = 100;

        if ($next) {
            $target = (float) $next['min'];
            $current_min = isset($current['min']) ? (float) $current['min'] : 0;
            $range = max(1, $target - $current_min);
            $needed = max(0, $target - $spent);
            $progress = (int) round(min(100, max(0, (($spent - $current_min) / $range) * 100)));
        }

        $data = [
            'user_id' => absint($user_id),
            'key' => $current_key,
            'level' => $current_key,
            'name' => $current['name'],
            'short' => $current['short'],
            'icon' => $current['icon'],
            'discount' => (int) $current['discount'],
            'spent' => $spent,
            'lifetime_spend' => $spent,
            'formatted_spent' => self::format_money($spent),
            'next' => $next,
            'next_key' => $next_key,
            'target' => $target,
            'needed' => $needed,
            'remaining' => $needed,
            'formatted_needed' => self::format_money($needed),
            'progress' => $progress,
            'progress_percentage' => $progress,
            'vip' => $current_key === 'vip',
            'is_top_level' => $current_key === 'vip',
            'levels' => $rules,
            'updated_at' => current_time('mysql'),
        ];

        return apply_filters('mrcp_customer_membership_data', $data, $user_id, $spent);
    }

    public static function get_level($user_id = 0) {
        $data = self::get_customer_membership($user_id);
        return $data['key'];
    }

    public static function get_level_name($user_id = 0) {
        $data = self::get_customer_membership($user_id);
        return $data['name'];
    }

    public static function get_discount($user_id = 0) {
        $data = self::get_customer_membership($user_id);
        return (int) $data['discount'];
    }

    public static function get_next_level($user_id = 0) {
        $data = self::get_customer_membership($user_id);
        return $data['next'];
    }

    public static function get_remaining_amount($user_id = 0) {
        $data = self::get_customer_membership($user_id);
        return (float) $data['remaining'];
    }

    public static function get_progress_percentage($user_id = 0) {
        $data = self::get_customer_membership($user_id);
        return (int) $data['progress_percentage'];
    }

    /**
     * Clear membership cache for a user.
     */
    public static function clear_cache($user_id) {
        $user_id = absint($user_id);
        if (!$user_id) {
            return;
        }

        delete_transient(self::cache_key($user_id));
        delete_transient(self::cache_key($user_id, 'spend'));

        // Remove pre-v7.3.0 cache keys during the transition.
        delete_transient(self::CACHE_PREFIX . $user_id);
        delete_transient(self::CACHE_PREFIX . 'spend_' . $user_id);
    }

    /**
     * Recalculate and persist user meta snapshot.
     */
    public static function recalculate($user_id) {
        self::clear_cache($user_id);
        return self::get_customer_membership($user_id, true);
    }

    public static function handle_order_status_changed($order_id, $old_status, $new_status, $order) {
        $user_id = self::get_order_user_id($order);
        if ($user_id) {
            self::recalculate($user_id);
        }
    }

    public static function handle_order_refunded($order_id, $refund_id) {
        $order = self::get_order($order_id);
        $user_id = self::get_order_user_id($order);
        if ($user_id) {
            self::recalculate($user_id);
        }
    }

    public static function handle_refund_created($refund_id, $args = []) {
        $refund = function_exists('wc_get_order') ? wc_get_order($refund_id) : null;
        if ($refund && method_exists($refund, 'get_parent_id')) {
            $order = self::get_order($refund->get_parent_id());
            $user_id = self::get_order_user_id($order);
            if ($user_id) {
                self::recalculate($user_id);
            }
        }
    }

    public static function handle_order_deleted($order_id) {
        $order = self::get_order($order_id);
        $user_id = self::get_order_user_id($order);
        if ($user_id) {
            self::recalculate($user_id);
        }
    }

    public static function handle_deleted_post($post_id) {
        if (function_exists('wc_get_order')) {
            $order = wc_get_order($post_id);
            $user_id = self::get_order_user_id($order);
            if ($user_id) {
                self::recalculate($user_id);
            }
        }
    }

    public static function format_money($amount) {
        if (function_exists('wc_price')) {
            return wc_price((float) $amount, ['decimals' => 2]);
        }

        return '৳' . number_format((float) $amount, 2);
    }


    /**
     * Build a versioned cache key so product eligibility changes invalidate all
     * previously calculated membership totals without scanning every customer.
     */
    private static function cache_key($user_id, $type = 'membership') {
        $version = max(1, (int) get_option('mrbp_membership_eligibility_version', 1));
        $suffix = $type === 'spend' ? 'spend_' : '';
        return self::CACHE_PREFIX . $version . '_' . $suffix . absint($user_id);
    }

    private static function normalize_user_id($user_id) {
        $user_id = absint($user_id);
        if (!$user_id && function_exists('get_current_user_id')) {
            $user_id = absint(get_current_user_id());
        }
        return $user_id;
    }

    private static function woocommerce_available() {
        return function_exists('wc_get_orders') && function_exists('wc_get_order');
    }

    private static function get_order($order_id) {
        if (!$order_id || !function_exists('wc_get_order')) {
            return null;
        }
        return wc_get_order($order_id);
    }

    private static function get_order_user_id($order) {
        if (!is_a($order, 'WC_Order')) {
            return 0;
        }
        return absint($order->get_customer_id());
    }
}
