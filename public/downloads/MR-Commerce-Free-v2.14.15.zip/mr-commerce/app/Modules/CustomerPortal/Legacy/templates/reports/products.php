<?php
if (!defined('ABSPATH')) exit;
$pi = $data['product_intelligence'] ?? ['summary'=>[], 'products'=>[], 'insights'=>[]];
$summary = $pi['summary'] ?? [];
$products = $pi['products'] ?? [];
$insights = $pi['insights'] ?? [];
$max_rev = 1.0; foreach ($products as $p) $max_rev=max($max_rev,(float)$p['revenue']);
?>
<div class="mrcp-pi">
  <div class="mrcp-bi__section-head"><div><span>PRODUCT INTELLIGENCE</span><h2>Product performance</h2></div><p>Parent-level sales, revenue, growth, refunds and health across all variations.</p></div>
  <div class="mrcp-pi__kpis">
    <article><i>◈</i><small>Total Products</small><strong><?php echo esc_html(number_format_i18n((int)($summary['products']??0))); ?></strong><em>Parent products</em></article>
    <article><i>▣</i><small>Lifetime Units</small><strong><?php echo esc_html(number_format_i18n((float)($summary['sold']??0))); ?></strong><em>Net of refunded units</em></article>
    <article class="is-primary"><i>৳</i><small>Lifetime Revenue</small><strong><?php echo wp_kses_post($money($summary['revenue']??0)); ?></strong><em>Net product revenue</em></article>
    <article><i>◎</i><small>Average Selling Price</small><strong><?php echo wp_kses_post($money($summary['average_price']??0)); ?></strong><em>Revenue per unit</em></article>
    <article><i>↩</i><small>Refunded Revenue</small><strong><?php echo wp_kses_post($money($summary['refunds']??0)); ?></strong><em><?php echo esc_html(number_format_i18n((float)($summary['refund_rate']??0),1)); ?>% refund rate</em></article>
  </div>

  <div class="mrcp-pi__grid">
    <article class="mrcp-bi-card mrcp-pi__leaders"><header><div><span>REVENUE LEADERS</span><h3>Top products</h3></div><b>Parent-level totals</b></header>
      <div class="mrcp-pi__bars">
      <?php foreach(array_slice($products,0,8) as $idx=>$row): $w=max(3,((float)$row['revenue']/$max_rev)*100); ?>
       <div><b>#<?php echo esc_html($idx+1); ?></b><img src="<?php echo esc_url($row['image']?:wc_placeholder_img_src()); ?>" alt=""><span><strong><?php echo esc_html($row['name']); ?></strong><small><?php echo esc_html(number_format_i18n((float)$row['sold'])); ?> units · <?php echo esc_html((int)$row['variation_count']); ?> variations</small><i><u style="width:<?php echo esc_attr($w); ?>%"></u></i></span><em><?php echo wp_kses_post($money($row['revenue'])); ?></em></div>
      <?php endforeach; ?>
      </div>
    </article>
    <aside class="mrcp-pi__side">
      <article class="mrcp-bi-card"><span>FASTEST GROWTH</span><?php $grow=array_values(array_filter($products,fn($p)=>($p['growth']['direction']??'')==='up')); $g=$grow[0]??null; ?><h3><?php echo esc_html($g['name']??'No growth data'); ?></h3><strong><?php echo $g?'↑ '.esc_html(number_format_i18n((float)$g['growth']['percent'],1)).'%':'—'; ?></strong><small>Current month vs previous month</small></article>
      <article class="mrcp-bi-card"><span>BEST HEALTH SCORE</span><?php $health=$products; usort($health,fn($a,$b)=>$b['health']<=>$a['health']); $h=$health[0]??null; ?><h3><?php echo esc_html($h['name']??'—'); ?></h3><strong><?php echo esc_html($h['health']??0); ?>/100</strong><small><?php echo esc_html($h['health_label']??'No data'); ?></small></article>
    </aside>
  </div>

  <article class="mrcp-bi-card mrcp-pi__table-card"><header><div><span>PRODUCT PERFORMANCE</span><h3>All parent products</h3></div><b>Revenue · units · refunds · health</b></header>
   <div class="mrcp-pi__table">
    <div class="head"><span>Product</span><span>Growth</span><span>Lifetime</span><span>This Month</span><span>Refund</span><span>Customers</span><span>Health</span></div>
    <?php foreach($products as $row): $dir=sanitize_html_class($row['growth']['direction']??'flat'); ?>
    <div class="row">
      <span class="product"><img src="<?php echo esc_url($row['image']?:wc_placeholder_img_src()); ?>" alt=""><b><?php echo esc_html($row['name']); ?></b><small><?php echo $row['variation_count']?esc_html($row['variation_count'].' variations'):'Simple product'; ?></small></span>
      <span><em class="growth is-<?php echo esc_attr($dir); ?>"><?php echo $dir==='up'?'↑':($dir==='down'?'↓':'→'); ?> <?php echo esc_html(number_format_i18n((float)$row['growth']['percent'],1)); ?>%</em></span>
      <span><b><?php echo esc_html(number_format_i18n((float)$row['sold'])); ?> units</b><small><?php echo wp_kses_post($money($row['revenue'])); ?></small></span>
      <span><b><?php echo esc_html(number_format_i18n((float)$row['month_sold'])); ?> units</b><small><?php echo wp_kses_post($money($row['month_revenue'])); ?></small></span>
      <span><b><?php echo wp_kses_post($money($row['refund_revenue'])); ?></b><small><?php echo esc_html(number_format_i18n((float)$row['refund_rate'],1)); ?>%</small></span>
      <span><b><?php echo esc_html(number_format_i18n((int)$row['customers'])); ?></b><small><?php echo esc_html(number_format_i18n((int)$row['domains'])); ?> domains</small></span>
      <span><em class="health h-<?php echo esc_attr($row['health']>=70?'good':($row['health']>=50?'mid':'low')); ?>"><?php echo esc_html($row['health']); ?></em><small><?php echo esc_html($row['health_label']); ?></small></span>
    </div>
    <?php endforeach; ?>
   </div>
  </article>

  <div class="mrcp-pi__bottom">
   <article class="mrcp-bi-card"><header><div><span>SMART PRODUCT INSIGHTS</span><h3>What the data says</h3></div></header><?php foreach($insights as $i): ?><p><i>✦</i><?php echo esc_html($i); ?></p><?php endforeach; ?></article>
   <article class="mrcp-bi-card"><header><div><span>HEALTH MODEL</span><h3>How scores are calculated</h3></div></header><p><b>35%</b> sales volume</p><p><b>30%</b> monthly growth</p><p><b>20%</b> refund performance</p><p><b>15%</b> recent activity</p></article>
  </div>
  <div class="mrcp-ri__footer-note"><i>i</i><span>Variable-product orders are aggregated into the parent product. Revenue and units are net of line-item refunds.</span></div>
</div>
