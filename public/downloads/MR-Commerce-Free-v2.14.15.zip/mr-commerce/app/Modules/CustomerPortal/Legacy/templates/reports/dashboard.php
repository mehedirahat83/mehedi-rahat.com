<?php
if (!defined('ABSPATH')) exit;

$money = static function ($amount) {
    return wc_price((float) $amount);
};

$periods = $data['periods'] ?? [];
$customer_summary = $data['customer_analytics']['summary'] ?? [];
$top_product = $data['top_products'][0] ?? null;
$top_customer = $data['top_customers'][0] ?? null;

$lifetime_revenue = (float) ($periods['all']['revenue'] ?? 0);
$lifetime_orders  = (int) ($periods['all']['orders'] ?? 0);
$total_customers  = (int) ($data['kpis']['customers'] ?? 0);
$refunds          = (float) ($data['kpis']['refunds'] ?? 0);
$aov              = $lifetime_orders > 0 ? $lifetime_revenue / $lifetime_orders : 0;
$refund_rate      = ($lifetime_revenue + $refunds) > 0 ? ($refunds / ($lifetime_revenue + $refunds)) * 100 : 0;
$repeat_rate      = (float) ($customer_summary['returning_rate'] ?? 0);
$health_score     = (int) max(0, min(100, round(82 + min(10, $repeat_rate / 10) - min(12, $refund_rate))));
$health_label     = $health_score >= 85 ? 'Excellent' : ($health_score >= 70 ? 'Healthy' : ($health_score >= 55 ? 'Stable' : 'Needs Attention'));

$tabs = [
    'overview'   => ['Overview', '⌂'],
    'revenue'    => ['Revenue', '৳'],
    'products'   => ['Products', '◈'],
    'customers'  => ['Customers', '♟'],
    'operations' => ['Operations', '⚙'],
    'health'     => ['Business Health', '♡'],
];
?>
<section class="mrcp-bi" data-mrcp-bi data-bi-root>
    <header class="mrcp-bi__hero">
        <div>
            <span class="mrcp-bi__eyebrow">BUSINESS INTELLIGENCE</span>
            <h1>Executive Business Dashboard</h1>
            <p>One place to understand revenue, products, customers, operations and overall business health.</p>
        </div>
        <div class="mrcp-bi__hero-actions">
            <span class="mrcp-bi__updated">Updated <?php echo esc_html($data['generated_at'] ?? wp_date('M j, Y · g:i A')); ?></span>
            <a class="mrcp-bi__export" href="<?php echo esc_url($export_url); ?>">⇩ Export CSV</a>
        </div>
    </header>

    <nav class="mrcp-bi__tabs" role="tablist" aria-label="Business Intelligence sections">
        <?php foreach ($tabs as $key => $tab): ?>
            <button
                type="button"
                class="mrcp-bi__tab<?php echo 'overview' === $key ? ' is-active' : ''; ?>"
                role="tab"
                aria-selected="<?php echo 'overview' === $key ? 'true' : 'false'; ?>"
                aria-controls="mrcp-bi-panel-<?php echo esc_attr($key); ?>"
                data-bi-tab="<?php echo esc_attr($key); ?>"
            ><i><?php echo esc_html($tab[1]); ?></i><span><?php echo esc_html($tab[0]); ?></span></button>
        <?php endforeach; ?>
    </nav>

    <div class="mrcp-bi__panels">
        <section id="mrcp-bi-panel-overview" class="mrcp-bi__panel is-active" role="tabpanel" data-bi-panel="overview">
            <div class="mrcp-bi__section-head">
                <div><span>EXECUTIVE SUMMARY</span><h2>Business at a glance</h2></div>
                <p>Lifetime performance with current-period momentum.</p>
            </div>

            <div class="mrcp-bi__kpis">
                <article><i>৳</i><small>Lifetime Revenue</small><strong><?php echo wp_kses_post($money($lifetime_revenue)); ?></strong><em><?php echo esc_html(number_format_i18n($lifetime_orders)); ?> paid orders</em></article>
                <article><i>▣</i><small>Net Orders</small><strong><?php echo esc_html(number_format_i18n($lifetime_orders)); ?></strong><em>Processing + completed</em></article>
                <article><i>◎</i><small>Average Order Value</small><strong><?php echo wp_kses_post($money($aov)); ?></strong><em>Lifetime average</em></article>
                <article><i>♟</i><small>Total Customers</small><strong><?php echo esc_html(number_format_i18n($total_customers)); ?></strong><em><?php echo esc_html(number_format_i18n((int) ($customer_summary['new_month'] ?? 0))); ?> joined this month</em></article>
                <article><i>↩</i><small>Refunded Revenue</small><strong><?php echo wp_kses_post($money($refunds)); ?></strong><em><?php echo esc_html(number_format_i18n($refund_rate, 1)); ?>% refund rate</em></article>
                <article class="is-health"><i>♡</i><small>Business Health</small><strong><?php echo esc_html($health_score); ?>/100</strong><em><?php echo esc_html($health_label); ?></em></article>
            </div>

            <div class="mrcp-bi__main-grid">
                <article class="mrcp-bi-card mrcp-bi-card--activity">
                    <header><div><span>RECENT BUSINESS ACTIVITY</span><h3>Latest paid orders</h3></div><a href="<?php echo esc_url(home_url('/dashboard/crm/orders/')); ?>">View all orders &rarr;</a></header>
                    <div class="mrcp-bi__activity-list">
                        <?php if (!empty($data['recent_orders'])): ?>
                            <?php foreach (array_slice($data['recent_orders'], 0, 5) as $row): ?>
                                <a class="mrcp-bi__activity-row" href="<?php echo esc_url($row['url'] ?? home_url('/dashboard/crm/orders/')); ?>">
                                    <span class="mrcp-bi__activity-order">
                                        <strong>#<?php echo esc_html($row['number'] ?? ''); ?></strong>
                                        <em class="is-<?php echo esc_attr($row['status_slug'] ?? 'completed'); ?>"><?php echo esc_html($row['status'] ?? 'Completed'); ?></em>
                                    </span>
                                    <span class="mrcp-bi__activity-customer">
                                        <strong><?php echo esc_html($row['customer'] ?? 'Guest'); ?></strong>
                                        <small><?php echo esc_html($row['product'] ?? 'No products'); ?></small>
                                    </span>
                                    <span class="mrcp-bi__activity-payment">
                                        <small>Payment method</small>
                                        <strong><?php echo esc_html($row['payment'] ?? 'Unknown'); ?></strong>
                                    </span>
                                    <span class="mrcp-bi__activity-total">
                                        <strong><?php echo wp_kses_post($money($row['total'] ?? 0)); ?></strong>
                                        <small><?php echo esc_html($row['relative_time'] ?? ($row['date'] ?? '')); ?></small>
                                    </span>
                                    <i aria-hidden="true">&rarr;</i>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="mrcp-bi__activity-empty">No paid order activity is available yet.</div>
                        <?php endif; ?>
                    </div>
                </article>

                <aside class="mrcp-bi__periods">
                    <?php
                    $period_labels = [
                        'today' => 'Today',
                        'week'  => 'This Week',
                        'month' => 'This Month',
                        'year'  => 'This Year',
                    ];
                    foreach ($period_labels as $key => $label):
                        $growth = $data['comparisons'][$key] ?? ['percent' => 0, 'direction' => 'flat'];
                        $direction = sanitize_html_class($growth['direction'] ?? 'flat');
                    ?>
                        <article>
                            <small><?php echo esc_html($label); ?></small>
                            <strong><?php echo wp_kses_post($money($periods[$key]['revenue'] ?? 0)); ?></strong>
                            <span><?php echo esc_html(number_format_i18n((int) ($periods[$key]['orders'] ?? 0))); ?> paid orders</span>
                            <em class="is-<?php echo esc_attr($direction); ?>"><?php echo esc_html(number_format_i18n((float) ($growth['percent'] ?? 0), 1)); ?>% vs previous</em>
                        </article>
                    <?php endforeach; ?>
                </aside>
            </div>

            <div class="mrcp-bi__snapshots">
                <article class="mrcp-bi-card">
                    <header><div><span>TOP PRODUCTS</span><h3>Revenue leaders</h3></div><a href="<?php echo esc_url(home_url('/dashboard/crm/products/')); ?>">View products →</a></header>
                    <?php foreach (array_slice(($data['top_products'] ?? []), 0, 5) as $index => $row): ?>
                        <div class="mrcp-bi__product-row">
                            <b>#<?php echo esc_html($index + 1); ?></b>
                            <img src="<?php echo esc_url($row['image'] ?? wc_placeholder_img_src()); ?>" alt="">
                            <span><strong><?php echo esc_html($row['name'] ?? 'Product'); ?></strong><small><?php echo esc_html(number_format_i18n((int) ($row['sold'] ?? 0))); ?> units sold</small></span>
                            <em><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?></em>
                        </div>
                    <?php endforeach; ?>
                </article>

                <article class="mrcp-bi-card">
                    <header><div><span>TOP CUSTOMERS</span><h3>Highest lifetime value</h3></div><a href="<?php echo esc_url(home_url('/dashboard/crm/customers/')); ?>">View customers →</a></header>
                    <?php foreach (array_slice(($data['top_customers'] ?? []), 0, 5) as $row): ?>
                        <div class="mrcp-bi__customer-row">
                            <img src="<?php echo esc_url($row['avatar'] ?? get_avatar_url(0)); ?>" alt="">
                            <span><strong><?php echo esc_html($row['name'] ?? 'Customer'); ?></strong><small><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?> paid orders</small></span>
                            <em><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?></em>
                        </div>
                    <?php endforeach; ?>
                </article>

                <article class="mrcp-bi-card">
                    <header><div><span>OPERATIONS</span><h3>Current workload</h3></div><a href="<?php echo esc_url(home_url('/dashboard/crm/')); ?>">Open CRM →</a></header>
                    <div class="mrcp-bi__ops">
                        <div><i>🎫</i><span><small>Open Support</small><strong><?php echo esc_html(number_format_i18n((int) ($data['support_open'] ?? 0))); ?></strong></span></div>
                        <div><i>🔑</i><span><small>Activation Requests</small><strong><?php echo esc_html(number_format_i18n((int) ($data['activation_total'] ?? 0))); ?></strong></span></div>
                        <div><i>🏷</i><span><small>Membership Discount</small><strong><?php echo wp_kses_post($money($data['membership_discount'] ?? 0)); ?></strong></span></div>
                        <div><i>↩</i><span><small>Refunded Revenue</small><strong><?php echo wp_kses_post($money($refunds)); ?></strong></span></div>
                    </div>
                </article>
            </div>

            <div class="mrcp-bi__bottom-grid">
                <article class="mrcp-bi-card">
                    <header><div><span>SMART INSIGHTS</span><h3>What needs attention</h3></div></header>
                    <?php foreach (array_slice(($data['insights'] ?? []), 0, 5) as $insight): ?>
                        <div class="mrcp-bi__insight"><i>✦</i><span><?php echo esc_html($insight); ?></span></div>
                    <?php endforeach; ?>
                </article>

                <article class="mrcp-bi-card">
                    <header><div><span>DAILY OVERVIEW</span><h3>This week</h3></div></header>
                    <div class="mrcp-bi__table">
                        <div class="head"><span>Date</span><span>Orders</span><span>Revenue</span><span>Customers</span></div>
                        <?php foreach (($data['daily_overview'] ?? []) as $row): ?>
                            <div><span><?php echo esc_html($row['date'] ?? ''); ?></span><b><?php echo esc_html(number_format_i18n((int) ($row['orders'] ?? 0))); ?></b><strong><?php echo wp_kses_post($money($row['revenue'] ?? 0)); ?></strong><b><?php echo esc_html(number_format_i18n((int) ($row['customers'] ?? 0))); ?></b></div>
                        <?php endforeach; ?>
                    </div>
                </article>
            </div>
        </section>

        <section id="mrcp-bi-panel-revenue" class="mrcp-bi__panel" role="tabpanel" hidden data-bi-panel="revenue">
            <?php
            $revenue_template = MRCP_PLUGIN_DIR . 'templates/reports/revenue.php';
            if (is_readable($revenue_template)) {
                include $revenue_template;
            }
            ?>
        </section>

        <section id="mrcp-bi-panel-products" class="mrcp-bi__panel" role="tabpanel" hidden data-bi-panel="products">
            <?php $product_template = MRCP_PLUGIN_DIR . 'templates/reports/products.php'; if (is_readable($product_template)) include $product_template; ?>
        </section>

        <section id="mrcp-bi-panel-customers" class="mrcp-bi__panel" role="tabpanel" hidden data-bi-panel="customers">
            <?php $customer_template = MRCP_PLUGIN_DIR . 'templates/reports/customers.php'; if (is_readable($customer_template)) include $customer_template; ?>
        </section>

        <section id="mrcp-bi-panel-operations" class="mrcp-bi__panel" role="tabpanel" hidden data-bi-panel="operations">
            <?php $operations_template = MRCP_PLUGIN_DIR . 'templates/reports/operations.php'; if (is_readable($operations_template)) include $operations_template; ?>
        </section>

        <section id="mrcp-bi-panel-health" class="mrcp-bi__panel" role="tabpanel" hidden data-bi-panel="health">
            <?php $health_template = MRCP_PLUGIN_DIR . 'templates/reports/health.php'; if (is_readable($health_template)) include $health_template; ?>
        </section>
    </div>
</section>
