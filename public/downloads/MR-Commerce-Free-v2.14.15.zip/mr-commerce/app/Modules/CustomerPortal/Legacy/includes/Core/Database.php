<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Database helpers and guarded performance-index installer.
 */
final class Database {
    public static function table(string $name): string {
        global $wpdb;
        return $wpdb->prefix . 'mrcp_' . sanitize_key($name);
    }

    public static function version(): string {
        return (string) get_option('mrcp_db_version', '0.0.0');
    }

    /**
     * Add indexes only to MRCP-owned custom tables that already exist.
     * Core WordPress/WooCommerce tables are deliberately left untouched.
     */
    public static function install_performance_indexes(): void {
        global $wpdb;

        $plans = [
            self::table('notifications') => [
                'mrcp_user_read_created' => ['user_id', 'is_read', 'created_at'],
                'mrcp_object_type'       => ['object_id', 'type'],
            ],
            self::table('tickets') => [
                'mrcp_customer_status'   => ['customer_id', 'status'],
                'mrcp_updated_at'        => ['updated_at'],
            ],
            self::table('activation_requests') => [
                'mrcp_customer_status'   => ['customer_id', 'status'],
                'mrcp_order_id'          => ['order_id'],
                'mrcp_updated_at'        => ['updated_at'],
            ],
        ];

        foreach ($plans as $table => $indexes) {
            if (!self::table_exists($table)) {
                continue;
            }

            $columns = self::table_columns($table);
            $existing_indexes = self::table_indexes($table);

            foreach ($indexes as $index_name => $index_columns) {
                if (isset($existing_indexes[$index_name])) {
                    continue;
                }

                $valid_columns = array_values(array_filter($index_columns, static function ($column) use ($columns) {
                    return isset($columns[$column]);
                }));

                if (count($valid_columns) !== count($index_columns)) {
                    continue;
                }

                $column_sql = implode(', ', array_map(static function ($column) {
                    return '`' . esc_sql($column) . '`';
                }, $valid_columns));

                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `{$index_name}` ({$column_sql})");
            }
        }

        update_option('mrcp_performance_indexes_version', defined('MRCP_VERSION') ? MRCP_VERSION : '13.3.0', false);
    }

    private static function table_exists(string $table): bool {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table;
    }

    private static function table_columns(string $table): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results("SHOW COLUMNS FROM `{$table}`", ARRAY_A);
        $columns = [];
        foreach ((array) $rows as $row) {
            if (!empty($row['Field'])) {
                $columns[$row['Field']] = true;
            }
        }
        return $columns;
    }

    private static function table_indexes(string $table): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results("SHOW INDEX FROM `{$table}`", ARRAY_A);
        $indexes = [];
        foreach ((array) $rows as $row) {
            if (!empty($row['Key_name'])) {
                $indexes[$row['Key_name']] = true;
            }
        }
        return $indexes;
    }
}
