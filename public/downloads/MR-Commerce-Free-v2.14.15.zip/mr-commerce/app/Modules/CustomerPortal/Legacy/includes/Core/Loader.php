<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Loads the active compatibility layer and production modules.
 *
 * v13.1 removes deprecated loaders, placeholder classes, and duplicate legacy
 * implementations while preserving all existing portal and CRM features.
 */
final class Loader {
    /** @var object|null */
    private $legacy_portal = null;

    public function register(): void {
        $this->load_compatibility_files();
        $this->load_production_modules();
        $this->boot_core_services();
        $this->boot_legacy_adapter();
    }

    private function load_compatibility_files(): void {
        $files = [
            'includes/functions.php',
            'includes/class-membership.php',
            'includes/Legacy/Traits/MRCP_Portal_Admin_Trait.php',
            'includes/Legacy/Traits/MRCP_Portal_Core_Trait.php',
            'includes/Legacy/Traits/MRCP_Portal_Commerce_Trait.php',
            'includes/Legacy/Traits/MRCP_Portal_Support_Trait.php',
            'includes/Legacy/Traits/MRCP_Portal_CRM_Trait.php',
            'includes/Legacy/class-legacy-portal.php',
        ];

        $this->require_files($files);
    }

    private function load_production_modules(): void {
        $files = [
            'includes/Modules/Customers/CustomersModule.php',
            'includes/Modules/Notifications/NotificationsModule.php',
            'includes/Modules/Orders/LicenseDomainsModule.php',
            'includes/Services/ProductIntelligenceService.php',
            'includes/Modules/Reports/Concerns/ReportsDataTrait.php',
            'includes/Modules/Reports/Concerns/ReportsOperationsTrait.php',
            'includes/Modules/Reports/Concerns/ReportsAnalyticsTrait.php',
            'includes/Modules/Reports/ReportsModule.php',
        ];

        $this->require_files($files);
    }

    private function require_files(array $files): void {
        foreach ($files as $file) {
            $path = MRCP_PLUGIN_DIR . $file;
            if (is_readable($path)) {
                require_once $path;
            }
        }
    }

    private function boot_core_services(): void {
        Router::register();
        Assets::register();

        if (class_exists(Performance::class)) {
            Performance::register();
        }

        if (class_exists(AdminCRM::class)) {
            AdminCRM::register();
        }

        if (class_exists('\MRCP\Modules\Customers\CustomersModule')) {
            \MRCP\Modules\Customers\CustomersModule::register();
        }

        if (class_exists('\MRCP\Modules\Notifications\NotificationsModule')) {
            \MRCP\Modules\Notifications\NotificationsModule::register();
        }

        if (mrc_can('digital.license_domains') && class_exists('\MRCP\Modules\Orders\LicenseDomainsModule')) {
            \MRCP\Modules\Orders\LicenseDomainsModule::register();
        }

        if (class_exists('\MRCP\Services\ProductIntelligenceService')) {
            \MRCP\Services\ProductIntelligenceService::register();
        }

        if (mrc_can('crm.advanced_reports') && class_exists('\MRCP\Modules\Reports\ReportsModule')) {
            \MRCP\Modules\Reports\ReportsModule::register();
        }
    }

    private function boot_legacy_adapter(): void {
        if (mrc_can('digital.membership') && class_exists('MRCP_Membership')) {
            \MRCP_Membership::init();
        }

        if (class_exists('MRCP_Customer_Portal')) {
            $this->legacy_portal = new \MRCP_Customer_Portal();
        }
    }
}
