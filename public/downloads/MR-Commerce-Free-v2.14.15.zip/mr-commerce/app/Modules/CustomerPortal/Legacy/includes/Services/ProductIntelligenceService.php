<?php
namespace MRCP\Services;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shared product intelligence engine.
 *
 * Aggregates every variation into its parent variable product and provides one
 * authoritative dataset for CRM Dashboard, Product Center and Reports.
 * Revenue is net order-line revenue after line-item refunds, excluding tax.
 */
final class ProductIntelligenceService {
    private const CACHE_KEY = 'mrcp_product_intelligence_v18_2';
    private const CACHE_TTL = 600;

    public static function register(): void {
        // Runtime invalidation is handled by the lightweight modern listener.
        add_action('woocommerce_saved_order_items', [self::class, 'clear_cache']);
        add_action('save_post_product', [self::class, 'clear_cache']);
        add_action('save_post_product_variation', [self::class, 'clear_cache']);
        add_action('before_delete_post', [self::class, 'maybe_clear_for_deleted_post']);
    }

    public static function maybe_clear_for_deleted_post($post_id): void {
        $post_type = get_post_type(absint($post_id));
        if (in_array($post_type, ['product', 'product_variation', 'shop_order', 'shop_order_refund'], true)) {
            self::clear_cache();
        }
    }

    public static function clear_cache(...$args): void {
        delete_transient(self::CACHE_KEY);
        for ($limit = 1; $limit <= 20; $limit++) {
            delete_transient('mrcp_lifetime_top_products_v1424_' . $limit);
            delete_transient('mrcp_lifetime_top_products_v1422_' . $limit);
            delete_transient('mrcp_crm_top_products_' . $limit);
        }
        delete_transient('mrcp_crm_product_performance_v16');
        delete_transient('mrcp_reports_customer_v17_2');
    }

    /**
     * Return all parent-level product analytics keyed by parent product ID.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function get_all(bool $force = false): array {
        if (!$force) {
            $cached = get_transient(self::CACHE_KEY);
            if (is_array($cached)) {
                return $cached;
            }
        }

        if (!function_exists('wc_get_orders')) {
            return [];
        }

        $timezone = wp_timezone();
        $now = new \DateTimeImmutable('now', $timezone);
        $starts = [
            'year'  => $now->setDate((int) $now->format('Y'), 1, 1)->setTime(0, 0, 0)->getTimestamp(),
            'month' => $now->modify('first day of this month')->setTime(0, 0, 0)->getTimestamp(),
            'week'  => $now->modify('monday this week')->setTime(0, 0, 0)->getTimestamp(),
            'previous_month' => $now->modify('first day of last month')->setTime(0, 0, 0)->getTimestamp(),
        ];

        $rows = [];
        $page = 1;
        $max_pages = 1;

        do {
            $result = wc_get_orders([
                'limit'    => 200,
                'page'     => $page,
                'paginate' => true,
                'return'   => 'objects',
                'status'   => array_keys(wc_get_order_statuses()),
                'orderby'  => 'date',
                'order'    => 'ASC',
            ]);

            $orders = is_object($result) && isset($result->orders) ? $result->orders : [];
            $max_pages = is_object($result) && isset($result->max_num_pages) ? max(1, (int) $result->max_num_pages) : 1;

            foreach ($orders as $order) {
                if (!$order instanceof \WC_Order) {
                    continue;
                }

                $status = sanitize_key($order->get_status());
                $paid = method_exists($order, 'is_paid') ? $order->is_paid() : false;
                if (!$paid && !$order->get_date_paid() && 'refunded' !== $status) {
                    continue;
                }

                $date = $order->get_date_paid() ?: $order->get_date_completed() ?: $order->get_date_created();
                if (!$date) {
                    continue;
                }
                $timestamp = $date->getTimestamp();
                $customer_key = self::customer_key($order);

                foreach ($order->get_items('line_item') as $item_id => $item) {
                    if (!$item instanceof \WC_Order_Item_Product) {
                        continue;
                    }

                    $identity = self::resolve_identity($item);
                    $parent_id = $identity['parent_id'];
                    if ($parent_id <= 0) {
                        continue;
                    }

                    if (!isset($rows[$parent_id])) {
                        $rows[$parent_id] = self::empty_row($identity);
                    }

                    $quantity = max(0.0, (float) $item->get_quantity());
                    $refunded_quantity = 0.0;
                    if (method_exists($order, 'get_qty_refunded_for_item')) {
                        $refunded_quantity = abs((float) $order->get_qty_refunded_for_item($item_id));
                    }
                    $net_quantity = max(0.0, $quantity - $refunded_quantity);

                    $gross_revenue = max(0.0, (float) $item->get_total());
                    $refunded_revenue = 0.0;
                    if (method_exists($order, 'get_total_refunded_for_item')) {
                        $refunded_revenue = abs((float) $order->get_total_refunded_for_item($item_id));
                    }
                    $net_revenue = max(0.0, $gross_revenue - $refunded_revenue);

                    self::add_metrics($rows[$parent_id]['periods']['lifetime'], $net_quantity, $net_revenue, $refunded_quantity, $refunded_revenue);
                    foreach (['year', 'month', 'week'] as $period) {
                        if ($timestamp >= $starts[$period]) {
                            self::add_metrics($rows[$parent_id]['periods'][$period], $net_quantity, $net_revenue, $refunded_quantity, $refunded_revenue);
                        }
                    }
                    if ($timestamp >= $starts['previous_month'] && $timestamp < $starts['month']) {
                        self::add_metrics($rows[$parent_id]['periods']['previous_month'], $net_quantity, $net_revenue, $refunded_quantity, $refunded_revenue);
                    }

                    $rows[$parent_id]['orders'][(int) $order->get_id()] = true;
                    if ($customer_key !== '') {
                        $rows[$parent_id]['customers'][$customer_key] = true;
                    }

                    $domains = self::get_item_domains($item);
                    foreach ($domains as $domain) {
                        $rows[$parent_id]['domains'][$domain] = true;
                        $rows[$parent_id]['license_count']++;
                    }

                    $variation_id = $identity['variation_id'];
                    if ($variation_id > 0) {
                        if (!isset($rows[$parent_id]['variations'][$variation_id])) {
                            $rows[$parent_id]['variations'][$variation_id] = self::empty_variation_row($identity);
                        }
                        self::add_metrics($rows[$parent_id]['variations'][$variation_id]['periods']['lifetime'], $net_quantity, $net_revenue, $refunded_quantity, $refunded_revenue);
                        foreach (['year', 'month', 'week'] as $period) {
                            if ($timestamp >= $starts[$period]) {
                                self::add_metrics($rows[$parent_id]['variations'][$variation_id]['periods'][$period], $net_quantity, $net_revenue, $refunded_quantity, $refunded_revenue);
                            }
                        }
                        if ($timestamp >= $starts['previous_month'] && $timestamp < $starts['month']) {
                            self::add_metrics($rows[$parent_id]['variations'][$variation_id]['periods']['previous_month'], $net_quantity, $net_revenue, $refunded_quantity, $refunded_revenue);
                        }
                        if ($customer_key !== '') {
                            $rows[$parent_id]['variations'][$variation_id]['customers'][$customer_key] = true;
                        }
                        foreach ($domains as $domain) {
                            $rows[$parent_id]['variations'][$variation_id]['domains'][$domain] = true;
                            $rows[$parent_id]['variations'][$variation_id]['license_count']++;
                        }
                    }
                }
            }

            $page++;
        } while ($page <= $max_pages);

        foreach ($rows as &$row) {
            $row['order_count'] = count($row['orders']);
            $row['customer_count'] = count($row['customers']);
            $row['active_domain_count'] = count($row['domains']);
            $row['variation_count'] = count($row['variations']);
            $row['average_selling_price'] = $row['periods']['lifetime']['sold'] > 0
                ? round($row['periods']['lifetime']['revenue'] / $row['periods']['lifetime']['sold'], wc_get_price_decimals())
                : 0.0;

            unset($row['orders'], $row['customers'], $row['domains']);

            foreach ($row['variations'] as &$variation) {
                $variation['customer_count'] = count($variation['customers']);
                $variation['active_domain_count'] = count($variation['domains']);
                $variation['average_selling_price'] = $variation['periods']['lifetime']['sold'] > 0
                    ? round($variation['periods']['lifetime']['revenue'] / $variation['periods']['lifetime']['sold'], wc_get_price_decimals())
                    : 0.0;
                unset($variation['customers'], $variation['domains']);
            }
            unset($variation);

            uasort($row['variations'], static function ($a, $b) {
                return $b['periods']['lifetime']['sold'] <=> $a['periods']['lifetime']['sold'];
            });
        }
        unset($row);

        set_transient(self::CACHE_KEY, $rows, self::CACHE_TTL);
        return $rows;
    }

    /**
     * Return top products ranked by lifetime sold, then lifetime revenue.
     */
    public static function get_top(int $limit = 5): array {
        $rows = array_values(self::get_all());
        usort($rows, static function ($a, $b) {
            $sold_compare = $b['periods']['lifetime']['sold'] <=> $a['periods']['lifetime']['sold'];
            if (0 !== $sold_compare) {
                return $sold_compare;
            }
            return $b['periods']['lifetime']['revenue'] <=> $a['periods']['lifetime']['revenue'];
        });

        $rows = array_slice($rows, 0, max(1, $limit));
        return array_map([self::class, 'to_legacy_top_row'], $rows);
    }

    public static function get_product(int $parent_id): array {
        $all = self::get_all();
        return $all[$parent_id] ?? [];
    }

    private static function to_legacy_top_row(array $row): array {
        return [
            'id' => $row['id'],
            'name' => $row['name'],
            'sold' => $row['periods']['lifetime']['sold'],
            'revenue' => $row['periods']['lifetime']['revenue'],
            'order_count' => $row['order_count'],
            'customer_count' => $row['customer_count'],
            'active_domain_count' => $row['active_domain_count'],
            'license_count' => $row['license_count'],
            'variation_count' => $row['variation_count'],
            'average_selling_price' => $row['average_selling_price'],
            'variations' => $row['variations'],
            'image' => $row['image'],
            'url' => $row['url'],
        ];
    }

    private static function empty_row(array $identity): array {
        return [
            'id' => $identity['parent_id'],
            'name' => $identity['parent_name'],
            'image' => $identity['image'],
            'url' => $identity['url'],
            'periods' => self::empty_periods(),
            'orders' => [],
            'customers' => [],
            'domains' => [],
            'license_count' => 0,
            'variations' => [],
        ];
    }

    private static function empty_variation_row(array $identity): array {
        return [
            'id' => $identity['variation_id'],
            'name' => $identity['variation_name'],
            'attributes' => $identity['variation_attributes'],
            'periods' => self::empty_periods(),
            'customers' => [],
            'domains' => [],
            'license_count' => 0,
        ];
    }

    private static function empty_periods(): array {
        $empty = ['sold' => 0.0, 'revenue' => 0.0, 'refunded_sold' => 0.0, 'refunded_revenue' => 0.0];
        return [
            'lifetime' => $empty,
            'year' => $empty,
            'month' => $empty,
            'week' => $empty,
            'previous_month' => $empty,
        ];
    }

    private static function add_metrics(array &$period, float $sold, float $revenue, float $refunded_sold, float $refunded_revenue): void {
        $period['sold'] += $sold;
        $period['revenue'] += $revenue;
        $period['refunded_sold'] += $refunded_sold;
        $period['refunded_revenue'] += $refunded_revenue;
    }

    private static function resolve_identity(\WC_Order_Item_Product $item): array {
        $stored_product_id = absint($item->get_product_id());
        $variation_id = absint($item->get_variation_id());
        $parent_id = $stored_product_id;
        $variation = $variation_id > 0 ? wc_get_product($variation_id) : false;
        $stored_product = $stored_product_id > 0 ? wc_get_product($stored_product_id) : false;

        if ($variation instanceof \WC_Product_Variation && $variation->get_parent_id()) {
            $parent_id = absint($variation->get_parent_id());
        } elseif ($stored_product instanceof \WC_Product_Variation && $stored_product->get_parent_id()) {
            $variation_id = $stored_product_id;
            $variation = $stored_product;
            $parent_id = absint($stored_product->get_parent_id());
        }

        $parent = $parent_id > 0 ? wc_get_product($parent_id) : false;
        $parent_name = $parent ? $parent->get_name() : trim((string) $item->get_name());
        $image = ($parent && $parent->get_image_id())
            ? wp_get_attachment_image_url($parent->get_image_id(), 'thumbnail')
            : wc_placeholder_img_src('thumbnail');
        $url = $parent
            ? (get_edit_post_link($parent_id, 'raw') ?: get_permalink($parent_id))
            : admin_url('edit.php?post_type=product');

        $variation_name = $variation ? wc_get_formatted_variation($variation, true, false, true) : '';
        if ($variation_name === '') {
            $variation_name = trim((string) $item->get_name());
        }

        return [
            'parent_id' => $parent_id,
            'parent_name' => $parent_name ?: __('Deleted product', 'mr-customer-portal-pro'),
            'variation_id' => $variation_id,
            'variation_name' => $variation_name,
            'variation_attributes' => $variation instanceof \WC_Product_Variation ? $variation->get_variation_attributes() : [],
            'image' => $image,
            'url' => $url,
        ];
    }

    private static function customer_key(\WC_Order $order): string {
        $customer_id = absint($order->get_customer_id());
        if ($customer_id > 0) {
            return 'user:' . $customer_id;
        }
        $email = sanitize_email($order->get_billing_email());
        return $email ? 'email:' . strtolower($email) : '';
    }

    /** @return string[] */
    private static function get_item_domains(\WC_Order_Item_Product $item): array {
        if (class_exists('\\MRCP\\Modules\\Orders\\LicenseDomainsModule')) {
            return \MRCP\Modules\Orders\LicenseDomainsModule::get_domains($item);
        }

        $raw = (string) $item->get_meta('_mrcp_license_domains', true);
        $domains = preg_split('/[\r\n,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
        if (!$domains) {
            return [];
        }
        return array_values(array_unique(array_filter(array_map(static function ($domain) {
            return strtolower(trim(sanitize_text_field($domain)));
        }, $domains))));
    }
}
