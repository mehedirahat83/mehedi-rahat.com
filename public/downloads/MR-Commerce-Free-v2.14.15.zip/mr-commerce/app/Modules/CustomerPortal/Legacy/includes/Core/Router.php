<?php
namespace MRCP\Core;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Central route registry for customer portal pages.
 * Existing rendering is preserved by the legacy adapter in v9.0.
 */
final class Router {
    public const DASHBOARD_SLUG = 'dashboard';

    public static function register(): void {
        add_action('init', [__CLASS__, 'register_rewrite_rules'], 5);
        add_filter('query_vars', [__CLASS__, 'register_query_vars']);
    }

    public static function register_rewrite_rules(): void {
        $routes = [
            'orders'          => 'orders',
            'downloads'       => 'downloads',
            'invoices'        => 'invoices',
            'support'         => 'support',
            'activation'      => 'activation',
            'membership'      => 'membership',
            'account'         => 'account',
            'addresses'       => 'addresses',
            'payment-methods' => 'payment-methods',
            'wishlist'        => 'wishlist',
            'crm'             => 'crm',
            'crm/customers'   => 'crm-customers',
            'crm/orders'      => 'crm-orders',
            'crm/membership'  => 'crm-membership',
            'crm/products'    => 'crm-products',
            'crm/reports'     => 'crm-reports',
        ];

        add_rewrite_rule('^dashboard/?$', 'index.php?mrcp_dashboard=1', 'top');
        add_rewrite_rule('^dashboard/crm/customers/([0-9]+)/orders/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customer-orders&mrcp_customer_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/crm/order/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-order-view&mrcp_order_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/crm/customers/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=crm-customer-profile&mrcp_customer_id=$matches[1]', 'top');

        foreach ($routes as $path => $section) {
            add_rewrite_rule('^dashboard/' . $path . '/?$', 'index.php?mrcp_dashboard=1&mrcp_section=' . $section, 'top');
        }

        add_rewrite_rule('^dashboard/order/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=order&mrcp_order_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/invoice/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=invoice&mrcp_order_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/ticket/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=ticket-view&mrcp_ticket_id=$matches[1]', 'top');
        add_rewrite_rule('^dashboard/activation/([0-9]+)/?$', 'index.php?mrcp_dashboard=1&mrcp_section=activation-view&mrcp_activation_id=$matches[1]', 'top');
    }

    public static function register_query_vars(array $vars): array {
        $vars[] = 'mrcp_dashboard';
        $vars[] = 'mrcp_section';
        $vars[] = 'mrcp_order_id';
        $vars[] = 'mrcp_ticket_id';
        $vars[] = 'mrcp_activation_id';
        $vars[] = 'mrcp_customer_id';
        return $vars;
    }

    public static function url(string $path = ''): string {
        return home_url('/dashboard/' . ltrim($path, '/'));
    }

    public static function current_section(): string {
        $section = get_query_var('mrcp_section');
        return $section ? sanitize_key((string) $section) : 'dashboard';
    }
}
