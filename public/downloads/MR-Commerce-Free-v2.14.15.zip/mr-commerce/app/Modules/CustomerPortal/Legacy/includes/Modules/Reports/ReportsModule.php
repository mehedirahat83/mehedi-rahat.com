<?php
namespace MRCP\Modules\Reports;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Business Report Foundation for the frontend CRM.
 *
 * Provides cached WooCommerce KPIs, trend data, breakdowns, leaderboards,
 * daily summaries, rule-based insights and a secure CSV export endpoint.
 */
final class ReportsModule {
    use Concerns\ReportsDataTrait;
    use Concerns\ReportsOperationsTrait;
    use Concerns\ReportsAnalyticsTrait;

    private const CACHE_KEY = 'mrcp_reports_health_v18_9';
    private const CACHE_TTL = 600;

    public static function register(): void {
        add_action('template_redirect', [__CLASS__, 'maybe_export_csv'], 4);
        // Runtime invalidation is handled by the lightweight modern listener.
        add_action('profile_update', [__CLASS__, 'clear_cache']);
        add_action('user_register', [__CLASS__, 'clear_cache']);
        add_action('delete_user', [__CLASS__, 'clear_cache']);
    }

    public static function clear_cache(): void {
        delete_transient(self::CACHE_KEY);
        \MRBP\Services\Analytics::clear_weekly_cache();
    }

    private static function can_view(): bool {
        return is_user_logged_in() && (
            current_user_can('manage_woocommerce') ||
            current_user_can('edit_shop_orders') ||
            current_user_can('manage_options')
        );
    }

    public static function render(): void {
        if (!self::can_view()) {
            wp_die(esc_html__('You do not have permission to view business reports.', 'mr-customer-portal-pro'), 403);
        }

        if (!function_exists('wc_get_orders')) {
            echo '<div class="mrcp-reports-empty">WooCommerce is required to display business reports.</div>';
            return;
        }

        try {
            $data = self::get_report_data();
        } catch (\Throwable $error) {
            error_log('[MRCP Reports] ' . $error->getMessage() . ' in ' . $error->getFile() . ':' . $error->getLine());
            echo '<div class="mrcp-reports-empty">' . esc_html__('Reports could not be generated right now. Please refresh once or check the PHP error log.', 'mr-customer-portal-pro') . '</div>';
            return;
        }

        $export_url = wp_nonce_url(
            add_query_arg('mrcp_export', 'reports', home_url('/dashboard/crm/reports/')),
            'mrcp_reports_export',
            '_mrcp_nonce'
        );

        $template = MRCP_PLUGIN_DIR . 'templates/reports/dashboard.php';
        if (is_readable($template)) {
            include $template;
        }
    }

    public static function maybe_export_csv(): void {
        if (!function_exists('mrc_can') || !mrc_can('crm.exports')) {
            return;
        }
        if (!get_query_var('mrcp_dashboard') || 'crm-reports' !== get_query_var('mrcp_section')) {
            return;
        }
        if (!isset($_GET['mrcp_export']) || 'reports' !== sanitize_key(wp_unslash($_GET['mrcp_export']))) {
            return;
        }
        if (!self::can_view()) {
            wp_die(esc_html__('You do not have permission to export reports.', 'mr-customer-portal-pro'), 403);
        }
        check_admin_referer('mrcp_reports_export', '_mrcp_nonce');

        $data = self::get_report_data();
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=mrcp-business-report-' . gmdate('Y-m-d') . '.csv');

        $output = fopen('php://output', 'w');
        if (!$output) {
            exit;
        }
        fputcsv($output, ['MR Commerce Pro - Business Report']);
        fputcsv($output, ['Generated', wp_date('Y-m-d H:i:s')]);
        fputcsv($output, []);
        fputcsv($output, ['Metric', 'Value']);
        fputcsv($output, ['Today Revenue', $data['kpis']['today_revenue']]);
        fputcsv($output, ['Today Orders', $data['kpis']['today_orders']]);
        fputcsv($output, ['Average Order Value', $data['kpis']['aov']]);
        fputcsv($output, ['Total Customers', $data['kpis']['customers']]);
        fputcsv($output, ['Range Refunds', $data['kpis']['refunds']]);
        fputcsv($output, []);
        fputcsv($output, ['Customer Analytics', 'Value']);
        fputcsv($output, ['Total Customers', $data['customer_analytics']['summary']['total_members']]);
        fputcsv($output, ['New Customers This Month', $data['customer_analytics']['summary']['new_month']]);
        fputcsv($output, ['Average Customer Value', $data['customer_analytics']['summary']['average_value']]);
        fputcsv($output, ['Returning Customer Rate', $data['customer_analytics']['summary']['returning_rate'] . '%']);
        fputcsv($output, ['Membership Discount Given', $data['customer_analytics']['summary']['discount_given']]);
        fputcsv($output, []);
        fputcsv($output, ['Business Health', 'Value']);
        fputcsv($output, ['Overall Score', ($data['business_health']['score'] ?? 0) . '/100']);
        fputcsv($output, ['Overall Status', $data['business_health']['label'] ?? '']);
        foreach (($data['business_health']['pillars'] ?? []) as $pillar) {
            fputcsv($output, [$pillar['label'] ?? 'Pillar', ($pillar['score'] ?? 0) . '/100']);
        }
        fputcsv($output, []);
        fputcsv($output, ['Month', 'Revenue', 'Orders']);
        foreach ($data['trend'] as $row) {
            fputcsv($output, [$row['label'], $row['revenue'], $row['orders']]);
        }
        fputcsv($output, []);
        fputcsv($output, ['Top Product', 'Units Sold', 'Revenue']);
        foreach ($data['top_products'] as $row) {
            fputcsv($output, [$row['name'], $row['sold'], $row['revenue']]);
        }
        fputcsv($output, []);
        fputcsv($output, ['Product Intelligence', 'Lifetime Sold', 'Lifetime Revenue', 'Month Growth', 'Refund Revenue', 'Health Score']);
        foreach (($data['product_intelligence']['products'] ?? []) as $row) {
            fputcsv($output, [$row['name'], $row['sold'], $row['revenue'], ($row['growth']['direction'] ?? 'flat') . ' ' . ($row['growth']['percent'] ?? 0) . '%', $row['refund_revenue'], $row['health']]);
        }
        fclose($output);
        exit;
    }























}
