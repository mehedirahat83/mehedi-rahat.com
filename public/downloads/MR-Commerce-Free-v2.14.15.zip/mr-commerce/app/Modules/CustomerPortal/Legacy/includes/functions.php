<?php
if (!defined('ABSPATH')) {
    exit;
}

function mrcp_plugin_url($path = '') {
    return MRCP_PLUGIN_URL . ltrim($path, '/');
}

function mrcp_plugin_path($path = '') {
    return MRCP_PLUGIN_DIR . ltrim($path, '/');
}

function mrcp_view($template, $data = []) {
    $file = mrcp_plugin_path('templates/' . ltrim($template, '/'));
    if (!file_exists($file)) {
        return;
    }
    if (is_array($data)) {
        extract($data, EXTR_SKIP);
    }
    include $file;
}


/**
 * Public helper: full dynamic membership data.
 */
function mrcp_get_customer_membership($user_id = 0) {
    if (class_exists('MRCP_Membership')) {
        return MRCP_Membership::get_customer_membership($user_id);
    }
    return [];
}

/**
 * Public helper: lifetime completed order spend.
 */
function mrcp_get_lifetime_spend($user_id = 0) {
    if (class_exists('MRCP_Membership')) {
        return MRCP_Membership::get_lifetime_spend($user_id);
    }
    return 0;
}

/**
 * Public helper: membership level key.
 */
function mrcp_get_membership_level($user_id = 0) {
    if (class_exists('MRCP_Membership')) {
        return MRCP_Membership::get_level($user_id);
    }
    return 'silver';
}

/**
 * Public helper: current membership discount percentage.
 */
function mrcp_get_membership_discount($user_id = 0) {
    if (class_exists('MRCP_Membership')) {
        return MRCP_Membership::get_discount($user_id);
    }
    return 0;
}
