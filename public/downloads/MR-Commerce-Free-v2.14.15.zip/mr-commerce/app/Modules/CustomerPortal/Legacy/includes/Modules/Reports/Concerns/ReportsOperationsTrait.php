<?php

namespace MRCP\Modules\Reports\Concerns;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait ReportsOperationsTrait {
    private static function build_operations_intelligence(int $now): array {
        $ticket_statuses = ['open' => 0, 'pending' => 0, 'answered' => 0, 'closed' => 0];
        $ticket_priorities = ['low' => 0, 'medium' => 0, 'high' => 0];
        $ticket_categories = [];
        $ticket_recent = [];
        $ticket_customers = [];
        $reply_hours = [];
        $resolution_hours = [];
        $ticket_months = self::month_buckets($now);
        foreach ($ticket_months as &$row) {
            $row['tickets'] = 0;
            $row['activations'] = 0;
            unset($row['revenue'], $row['orders']);
        }
        unset($row);

        $ticket_ids = get_posts([
            'post_type' => 'mrcp_ticket',
            'post_status' => 'publish',
            'numberposts' => -1,
            'fields' => 'ids',
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'suppress_filters' => true,
        ]);

        foreach ($ticket_ids as $ticket_id) {
            $ticket_id = (int) $ticket_id;
            $status = sanitize_key((string) get_post_meta($ticket_id, '_mrcp_ticket_status', true));
            if (!isset($ticket_statuses[$status])) $status = 'open';
            $ticket_statuses[$status]++;

            $priority = sanitize_key((string) get_post_meta($ticket_id, '_mrcp_ticket_priority', true));
            if (!isset($ticket_priorities[$priority])) $priority = 'medium';
            $ticket_priorities[$priority]++;

            $category = sanitize_key((string) get_post_meta($ticket_id, '_mrcp_ticket_category', true));
            if ($category === '') $category = 'other';
            $ticket_categories[$category] = ($ticket_categories[$category] ?? 0) + 1;

            $author = (int) get_post_field('post_author', $ticket_id);
            if ($author) $ticket_customers[$author] = true;

            $created = get_post_time('U', true, $ticket_id);
            $month_key = $created ? wp_date('Y-m', $created) : '';
            if ($month_key && isset($ticket_months[$month_key])) $ticket_months[$month_key]['tickets']++;

            $first_admin_reply = (string) get_post_meta($ticket_id, '_mrcp_last_admin_reply', true);
            if ($created && $first_admin_reply) {
                $reply_ts = strtotime($first_admin_reply);
                if ($reply_ts && $reply_ts >= $created) $reply_hours[] = ($reply_ts - $created) / HOUR_IN_SECONDS;
            }
            if ($status === 'closed' && $created) {
                $modified = get_post_modified_time('U', true, $ticket_id);
                if ($modified && $modified >= $created) $resolution_hours[] = ($modified - $created) / HOUR_IN_SECONDS;
            }

            if (count($ticket_recent) < 5) {
                $user = $author ? get_user_by('id', $author) : false;
                $ticket_recent[] = [
                    'id' => $ticket_id,
                    'title' => get_the_title($ticket_id) ?: ('Ticket MR-' . $ticket_id),
                    'customer' => $user ? $user->display_name : 'Customer',
                    'status' => $status,
                    'priority' => $priority,
                    'category' => $category,
                    'date' => $created ? wp_date('M j, Y', $created) : '—',
                    'url' => home_url('/dashboard/ticket/' . $ticket_id . '/'),
                ];
            }
        }
        arsort($ticket_categories);

        $activation_statuses = ['pending' => 0, 'in_progress' => 0, 'completed' => 0, 'rejected' => 0];
        $activation_recent = [];
        $activation_customers = [];
        $activation_completion_hours = [];
        $activation_ids = get_posts([
            'post_type' => 'mrcp_activation',
            'post_status' => 'publish',
            'numberposts' => -1,
            'fields' => 'ids',
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'suppress_filters' => true,
        ]);

        foreach ($activation_ids as $activation_id) {
            $activation_id = (int) $activation_id;
            $status = sanitize_key((string) get_post_meta($activation_id, '_mrcp_activation_status', true));
            if (!isset($activation_statuses[$status])) $status = 'pending';
            $activation_statuses[$status]++;

            $author = (int) get_post_field('post_author', $activation_id);
            if ($author) $activation_customers[$author] = true;
            $created = get_post_time('U', true, $activation_id);
            $month_key = $created ? wp_date('Y-m', $created) : '';
            if ($month_key && isset($ticket_months[$month_key])) $ticket_months[$month_key]['activations']++;

            if ($status === 'completed' && $created) {
                $updated = (string) get_post_meta($activation_id, '_mrcp_activation_last_updated_at', true);
                $completed_ts = $updated ? strtotime($updated) : get_post_modified_time('U', true, $activation_id);
                if ($completed_ts && $completed_ts >= $created) $activation_completion_hours[] = ($completed_ts - $created) / HOUR_IN_SECONDS;
            }

            if (count($activation_recent) < 5) {
                $user = $author ? get_user_by('id', $author) : false;
                $activation_recent[] = [
                    'id' => $activation_id,
                    'product' => (string) (get_post_meta($activation_id, '_mrcp_activation_product', true) ?: get_the_title($activation_id) ?: ('Activation ACT-' . $activation_id)),
                    'domain' => (string) get_post_meta($activation_id, '_mrcp_activation_domain', true),
                    'customer' => $user ? $user->display_name : 'Customer',
                    'status' => $status,
                    'date' => $created ? wp_date('M j, Y', $created) : '—',
                    'url' => home_url('/dashboard/activation/' . $activation_id . '/'),
                ];
            }
        }

        $ticket_total = array_sum($ticket_statuses);
        $activation_total = array_sum($activation_statuses);
        $closed_rate = $ticket_total > 0 ? round(($ticket_statuses['closed'] / $ticket_total) * 100, 1) : 0.0;
        $completion_rate = $activation_total > 0 ? round(($activation_statuses['completed'] / $activation_total) * 100, 1) : 0.0;
        $avg_reply = $reply_hours ? array_sum($reply_hours) / count($reply_hours) : 0.0;
        $avg_resolution = $resolution_hours ? array_sum($resolution_hours) / count($resolution_hours) : 0.0;
        $avg_activation = $activation_completion_hours ? array_sum($activation_completion_hours) / count($activation_completion_hours) : 0.0;

        $workload = $ticket_statuses['open'] + $ticket_statuses['pending'] + $ticket_statuses['answered'] + $activation_statuses['pending'] + $activation_statuses['in_progress'];
        $health = 100;
        if ($ticket_total > 0) $health -= min(25, (int) round((($ticket_statuses['open'] + $ticket_statuses['pending']) / $ticket_total) * 25));
        if ($activation_total > 0) $health -= min(20, (int) round((($activation_statuses['pending'] + $activation_statuses['in_progress']) / $activation_total) * 20));
        if ($avg_reply > 24) $health -= 15; elseif ($avg_reply > 8) $health -= 8;
        $health = max(0, min(100, $health));

        $insights = [];
        if ($ticket_statuses['open'] > 0) $insights[] = $ticket_statuses['open'] . ' support tickets are waiting for action.';
        if ($ticket_priorities['high'] > 0) $insights[] = $ticket_priorities['high'] . ' high-priority tickets need attention.';
        if (($activation_statuses['pending'] + $activation_statuses['in_progress']) > 0) $insights[] = ($activation_statuses['pending'] + $activation_statuses['in_progress']) . ' activation requests are still in progress.';
        if ($avg_reply > 0) $insights[] = 'Average first admin reply time is ' . number_format_i18n($avg_reply, 1) . ' hours.';
        if ($completion_rate >= 80) $insights[] = 'Activation completion rate is healthy at ' . number_format_i18n($completion_rate, 1) . '%.';
        if (!$insights) $insights[] = 'Operations are running smoothly with no urgent workload.';

        return [
            'summary' => [
                'tickets_total' => $ticket_total,
                'tickets_open' => $ticket_statuses['open'],
                'tickets_unresolved' => $ticket_statuses['open'] + $ticket_statuses['pending'] + $ticket_statuses['answered'],
                'ticket_close_rate' => $closed_rate,
                'avg_reply_hours' => round($avg_reply, 1),
                'avg_resolution_hours' => round($avg_resolution, 1),
                'activation_total' => $activation_total,
                'activation_pending' => $activation_statuses['pending'] + $activation_statuses['in_progress'],
                'activation_completed' => $activation_statuses['completed'],
                'activation_completion_rate' => $completion_rate,
                'avg_activation_hours' => round($avg_activation, 1),
                'customers_served' => count(array_unique(array_merge(array_keys($ticket_customers), array_keys($activation_customers)))),
                'current_workload' => $workload,
                'health_score' => $health,
            ],
            'ticket_statuses' => $ticket_statuses,
            'ticket_priorities' => $ticket_priorities,
            'ticket_categories' => array_slice($ticket_categories, 0, 6, true),
            'activation_statuses' => $activation_statuses,
            'monthly_trend' => array_values($ticket_months),
            'recent_tickets' => $ticket_recent,
            'recent_activations' => $activation_recent,
            'insights' => $insights,
        ];
    }

    private static function build_product_intelligence(): array {
        if (!class_exists('\\MRCP\\Services\\ProductIntelligenceService')) {
            return ['summary' => [], 'products' => [], 'insights' => []];
        }

        $rows = array_values(\MRCP\Services\ProductIntelligenceService::get_all());
        $summary = [
            'products' => count($rows), 'sold' => 0.0, 'revenue' => 0.0,
            'refunds' => 0.0, 'customers' => 0, 'domains' => 0,
        ];
        $products = [];
        foreach ($rows as $row) {
            $life = $row['periods']['lifetime'] ?? [];
            $month = $row['periods']['month'] ?? [];
            $previous = $row['periods']['previous_month'] ?? [];
            $sold = (float) ($life['sold'] ?? 0);
            $revenue = (float) ($life['revenue'] ?? 0);
            $refund_revenue = (float) ($life['refunded_revenue'] ?? 0);
            $refund_sold = (float) ($life['refunded_sold'] ?? 0);
            $month_revenue = (float) ($month['revenue'] ?? 0);
            $previous_revenue = (float) ($previous['revenue'] ?? 0);
            $growth = self::growth($month_revenue, $previous_revenue);
            $refund_rate = ($revenue + $refund_revenue) > 0 ? ($refund_revenue / ($revenue + $refund_revenue)) * 100 : 0;
            $recency_score = $month_revenue > 0 ? 100 : ((float) ($row['periods']['week']['revenue'] ?? 0) > 0 ? 100 : 45);
            $growth_score = 'up' === $growth['direction'] ? min(100, 60 + $growth['percent']) : ('down' === $growth['direction'] ? max(0, 55 - $growth['percent']) : 55);
            $refund_score = max(0, 100 - ($refund_rate * 5));
            $volume_score = min(100, ($sold * 4) + min(40, $revenue / 1000));
            $health = (int) round(($volume_score * .35) + ($growth_score * .30) + ($refund_score * .20) + ($recency_score * .15));
            $health = max(0, min(100, $health));
            $health_label = $health >= 85 ? 'Excellent' : ($health >= 70 ? 'Healthy' : ($health >= 50 ? 'Stable' : ($health >= 30 ? 'Needs Attention' : 'Critical')));

            $products[] = [
                'id' => (int) ($row['id'] ?? 0), 'name' => (string) ($row['name'] ?? 'Product'),
                'image' => (string) ($row['image'] ?? ''), 'url' => (string) ($row['url'] ?? ''),
                'variation_count' => (int) ($row['variation_count'] ?? 0),
                'sold' => $sold, 'revenue' => $revenue,
                'year_sold' => (float) ($row['periods']['year']['sold'] ?? 0),
                'year_revenue' => (float) ($row['periods']['year']['revenue'] ?? 0),
                'month_sold' => (float) ($month['sold'] ?? 0), 'month_revenue' => $month_revenue,
                'week_sold' => (float) ($row['periods']['week']['sold'] ?? 0),
                'week_revenue' => (float) ($row['periods']['week']['revenue'] ?? 0),
                'refund_sold' => $refund_sold, 'refund_revenue' => $refund_revenue,
                'refund_rate' => round($refund_rate, 1), 'growth' => $growth,
                'customers' => (int) ($row['customer_count'] ?? 0),
                'domains' => (int) ($row['active_domain_count'] ?? 0),
                'average_price' => (float) ($row['average_selling_price'] ?? 0),
                'health' => $health, 'health_label' => $health_label,
                'variations' => $row['variations'] ?? [],
            ];
            $summary['sold'] += $sold; $summary['revenue'] += $revenue;
            $summary['refunds'] += $refund_revenue;
            $summary['customers'] += (int) ($row['customer_count'] ?? 0);
            $summary['domains'] += (int) ($row['active_domain_count'] ?? 0);
        }
        usort($products, static fn(array $a, array $b): int => $b['revenue'] <=> $a['revenue']);
        $summary['average_price'] = $summary['sold'] > 0 ? $summary['revenue'] / $summary['sold'] : 0;
        $summary['refund_rate'] = ($summary['revenue'] + $summary['refunds']) > 0 ? ($summary['refunds'] / ($summary['revenue'] + $summary['refunds'])) * 100 : 0;
        $growing = array_filter($products, static fn(array $p): bool => 'up' === ($p['growth']['direction'] ?? 'flat'));
        $attention = array_filter($products, static fn(array $p): bool => $p['health'] < 50);
        $insights = [];
        if ($products) $insights[] = $products[0]['name'] . ' is the highest-revenue product.';
        if ($growing) { $first = reset($growing); $insights[] = $first['name'] . ' is growing this month.'; }
        if ($attention) $insights[] = count($attention) . ' product(s) need attention based on sales, growth and refunds.';
        if ($summary['refund_rate'] > 5) $insights[] = 'Product refund rate is above 5%; review refund-heavy items.';
        return ['summary' => $summary, 'products' => $products, 'insights' => $insights];
    }

    private static function growth(float $current, float $previous): array {
        if ($previous <= 0.0) {
            return [
                'percent' => $current > 0.0 ? 100.0 : 0.0,
                'direction' => $current > 0.0 ? 'up' : 'flat',
            ];
        }
        $percent = (($current - $previous) / $previous) * 100;
        return [
            'percent' => round(abs($percent), 1),
            'direction' => $percent > 0 ? 'up' : ($percent < 0 ? 'down' : 'flat'),
        ];
    }

    private static function add_period_metric(array &$metrics, int $timestamp, float $net, int $today, int $week, int $month, int $year): void {
        $metrics['all']['revenue'] += $net;
        $metrics['all']['orders']++;
        if ($timestamp >= $year) {
            $metrics['year']['revenue'] += $net;
            $metrics['year']['orders']++;
        }
        if ($timestamp >= $month) {
            $metrics['month']['revenue'] += $net;
            $metrics['month']['orders']++;
        }
        if ($timestamp >= $week) {
            $metrics['week']['revenue'] += $net;
            $metrics['week']['orders']++;
        }
        if ($timestamp >= $today) {
            $metrics['today']['revenue'] += $net;
            $metrics['today']['orders']++;
        }
    }
}
