(function () {
    'use strict';

    function ready(callback) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', callback);
        } else {
            callback();
        }
    }

    ready(function () {
        var sidebar = document.querySelector('.mrcp-sidebar');
        var nav = sidebar ? sidebar.querySelector('.mrcp-nav') : null;

        if (sidebar && nav && !sidebar.querySelector('.mrcp-mobile-nav-toggle')) {
            var toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'mrcp-mobile-nav-toggle';
            toggle.setAttribute('aria-expanded', 'false');
            toggle.setAttribute('aria-controls', 'mrcp-mobile-navigation');
            toggle.innerHTML = '<span><b aria-hidden="true">☰</b> Navigation</span><i aria-hidden="true">⌄</i>';
            nav.id = nav.id || 'mrcp-mobile-navigation';
            nav.parentNode.insertBefore(toggle, nav);

            toggle.addEventListener('click', function () {
                var open = !sidebar.classList.contains('is-mobile-open');
                sidebar.classList.toggle('is-mobile-open', open);
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            });

            nav.addEventListener('click', function (event) {
                if (window.innerWidth > 900 || !event.target.closest('a')) return;
                sidebar.classList.remove('is-mobile-open');
                toggle.setAttribute('aria-expanded', 'false');
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth > 900) {
                    sidebar.classList.remove('is-mobile-open');
                    toggle.setAttribute('aria-expanded', 'false');
                }
            });
        }

        function revealActiveReportTab() {
            if (window.innerWidth > 700) return;
            var active = document.querySelector('.mrcp-bi__tabs .mrcp-bi__tab.is-active');
            if (active && typeof active.scrollIntoView === 'function') {
                active.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
            }
        }

        document.addEventListener('click', function (event) {
            if (!event.target.closest('[data-bi-tab]')) return;
            window.setTimeout(revealActiveReportTab, 20);
        });
        window.setTimeout(revealActiveReportTab, 120);
    });
}());
