<?php

namespace MRBP\Modules\CustomerPortal\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\CustomerPortal\Repositories\CustomerActivityRepository;
use MRBP\Modules\CustomerPortal\Repositories\PortalNotificationRepository;
use MRBP\Support\Logger;

final class PaymentCustomerSyncService {

    private CustomerActivityRepository $activities;
    private PortalNotificationRepository $notifications;
    private Logger $logger;

    public function __construct(
        ?CustomerActivityRepository $activities = null,
        ?PortalNotificationRepository $notifications = null,
        ?Logger $logger = null
    ) {
        $this->activities    = $activities ?? new CustomerActivityRepository();
        $this->notifications = $notifications ?? new PortalNotificationRepository();
        $this->logger        = $logger ?? $this->resolve_logger();
    }

    /** @param array<string,mixed> $request */
    public function record_submitted( int $request_id, array $request ): void {
        $user_id = $this->resolve_user_id( $request );
        if ( $user_id <= 0 ) {
            return;
        }

        $payload = $this->base_payload( 'submitted', $request_id, $request );
        $payload['event_key'] = 'payment-submitted-' . $request_id;
        $payload['event']     = 'payment_submitted';
        $payload['title']     = __( 'Payment submitted', 'mr-commerce' );
        $payload['message']   = __( 'Your payment information was submitted for verification.', 'mr-commerce' );

        $this->activities->add_activity( $user_id, $payload );
        $this->activities->add_timeline_event( $user_id, $payload );

        do_action( 'mrbp/customer/activity_added', $user_id, $payload );
        do_action( 'mrbp/customer/history_updated', $user_id, $request_id, 'submitted' );
    }

    /** @param array<string,mixed> $request */
    public function record_review( int $request_id, array $request, string $admin_note = '' ): void {
        $user_id = $this->resolve_user_id( $request );
        if ( $user_id <= 0 ) {
            return;
        }

        $payload = $this->base_payload( 'under_review', $request_id, $request );
        $payload['event_key'] = 'payment-review-' . $request_id;
        $payload['event']     = 'payment_under_review';
        $payload['title']     = __( 'Payment under review', 'mr-commerce' );
        $payload['message']   = '' !== trim( $admin_note )
            ? sprintf( __( 'We are reviewing your payment. Note: %s', 'mr-commerce' ), sanitize_text_field( $admin_note ) )
            : __( 'We are reviewing your payment.', 'mr-commerce' );

        $this->activities->add_activity( $user_id, $payload );
        $this->activities->add_timeline_event( $user_id, $payload );
        $this->notifications->add(
            $user_id,
            $payload['event_key'],
            __( 'Payment Under Review', 'mr-commerce' ),
            __( 'We are reviewing your payment.', 'mr-commerce' ),
            $payload['url']
        );

        do_action( 'mrbp/customer/activity_added', $user_id, $payload );
        do_action( 'mrbp/customer/notification_created', $user_id, $payload );
        do_action( 'mrbp/customer/history_updated', $user_id, $request_id, 'under_review' );
    }

    /** @param array<string,mixed> $request */
    public function record_rejected( int $request_id, array $request, string $admin_note = '' ): void {
        $user_id = $this->resolve_user_id( $request );
        if ( $user_id <= 0 ) {
            return;
        }

        $payload = $this->base_payload( 'rejected', $request_id, $request );
        $payload['event_key'] = 'payment-rejected-' . $request_id;
        $payload['event']     = 'payment_rejected';
        $payload['title']     = __( 'Payment rejected', 'mr-commerce' );
        $payload['message']   = '' !== trim( $admin_note )
            ? sprintf( __( 'Your payment could not be verified. Reason: %s', 'mr-commerce' ), sanitize_text_field( $admin_note ) )
            : __( 'Your payment could not be verified. Please submit it again.', 'mr-commerce' );

        $this->activities->add_activity( $user_id, $payload );
        $this->activities->add_timeline_event( $user_id, $payload );
        $this->notifications->add(
            $user_id,
            $payload['event_key'],
            __( 'Payment Rejected', 'mr-commerce' ),
            $payload['message'],
            $payload['url']
        );

        do_action( 'mrbp/customer/activity_added', $user_id, $payload );
        do_action( 'mrbp/customer/notification_created', $user_id, $payload );
        do_action( 'mrbp/customer/history_updated', $user_id, $request_id, 'rejected' );
    }

    /**
     * @param array<string,mixed> $request
     * @param \WC_Order $order
     */
    public function record_woocommerce_sync( int $order_id, int $request_id, string $decision, array $request, $order ): void {
        if ( 'approved' !== sanitize_key( $decision ) ) {
            return;
        }

        $user_id = $this->resolve_user_id( $request, $order );
        if ( $user_id <= 0 ) {
            return;
        }

        $order_status = is_object( $order ) && method_exists( $order, 'get_status' ) ? sanitize_key( (string) $order->get_status() ) : 'processing';
        $payload      = $this->base_payload( 'verified', $request_id, $request );
        $payload['order_id']  = $order_id;
        $payload['event_key'] = 'payment-verified-' . $request_id;
        $payload['event']     = 'payment_verified';
        $payload['title']     = __( 'Payment verified', 'mr-commerce' );
        $payload['message']   = sprintf(
            __( 'Your payment was verified. Your order is now %s.', 'mr-commerce' ),
            ucwords( str_replace( '-', ' ', $order_status ) )
        );

        $this->activities->add_activity( $user_id, $payload );
        $this->activities->add_timeline_event( $user_id, $payload );
        $this->notifications->add(
            $user_id,
            $payload['event_key'],
            __( 'Payment Verified', 'mr-commerce' ),
            sprintf( __( 'Your order is now %s.', 'mr-commerce' ), ucwords( str_replace( '-', ' ', $order_status ) ) ),
            $payload['url']
        );

        $order_payload              = $payload;
        $order_payload['event_key'] = 'order-status-' . $order_status . '-' . $request_id;
        $order_payload['event']     = 'order_' . $order_status;
        $order_payload['status']    = $order_status;
        $order_payload['title']     = sprintf( __( 'Order %s', 'mr-commerce' ), ucwords( str_replace( '-', ' ', $order_status ) ) );
        $order_payload['message']   = sprintf( __( 'Order #%d moved to %s.', 'mr-commerce' ), $order_id, ucwords( str_replace( '-', ' ', $order_status ) ) );
        $this->activities->add_activity( $user_id, $order_payload );
        $this->activities->add_timeline_event( $user_id, $order_payload );

        $membership_payload              = $payload;
        $membership_payload['event_key'] = 'membership-payment-' . $request_id;
        $membership_payload['event']     = 'membership_payment_verified';
        $membership_payload['title']     = __( 'Verified payment recorded', 'mr-commerce' );
        $membership_payload['message']   = __( 'Your verified payment is available to the membership activity system.', 'mr-commerce' );
        $this->activities->add_membership_activity( $user_id, $membership_payload );

        do_action( 'mrbp/customer/activity_added', $user_id, $payload );
        do_action( 'mrbp/customer/activity_added', $user_id, $order_payload );
        do_action( 'mrbp/customer/notification_created', $user_id, $payload );
        do_action( 'mrbp/customer/membership_activity_added', $user_id, $membership_payload, $order );
        do_action( 'mrbp/customer/history_updated', $user_id, $request_id, 'verified' );

        $this->logger->module(
            'Customer Portal synchronized with verified payment.',
            array(
                'user_id'    => $user_id,
                'request_id' => $request_id,
                'order_id'   => $order_id,
                'status'     => $order_status,
            )
        );
    }

    /** @param array<string,mixed> $request */
    private function base_payload( string $status, int $request_id, array $request ): array {
        $order_id = absint( $request['order_id'] ?? 0 );
        return array(
            'request_id' => $request_id,
            'order_id'   => $order_id,
            'status'     => sanitize_key( $status ),
            'source'     => 'payment_center',
            'amount'     => (float) ( $request['amount'] ?? 0 ),
            'currency'   => strtoupper( sanitize_text_field( (string) ( $request['currency'] ?? 'BDT' ) ) ),
            'gateway'    => sanitize_key( (string) ( $request['gateway'] ?? '' ) ),
            'url'        => $this->history_url(),
            'time'       => current_time( 'timestamp' ),
        );
    }

    /** @param array<string,mixed> $request */
    private function resolve_user_id( array $request, $order = null ): int {
        $user_id = absint( $request['user_id'] ?? 0 );
        if ( $user_id > 0 ) {
            return $user_id;
        }

        if ( ! $order ) {
            $order_id = absint( $request['order_id'] ?? 0 );
            $order    = $order_id > 0 && function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
        }

        return is_object( $order ) && method_exists( $order, 'get_customer_id' ) ? absint( $order->get_customer_id() ) : 0;
    }

    private function history_url(): string {
        return function_exists( 'wc_get_account_endpoint_url' )
            ? wc_get_account_endpoint_url( 'payment-history' )
            : home_url( '/my-account/payment-history/' );
    }

    private function resolve_logger(): Logger {
        if ( function_exists( 'mrbp' ) && mrbp()->container()->has( 'logger' ) ) {
            $logger = mrbp()->container()->get( 'logger' );
            if ( $logger instanceof Logger ) {
                return $logger;
            }
        }

        return new Logger();
    }
}
