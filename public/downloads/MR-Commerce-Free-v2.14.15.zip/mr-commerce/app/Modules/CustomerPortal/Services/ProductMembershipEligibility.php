<?php

namespace MRBP\Modules\CustomerPortal\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WC_Order;
use WC_Order_Item_Product;
use WC_Product;

/**
 * Product-level membership spend eligibility.
 *
 * Products count toward membership by default. Administrators can exclude a
 * product without changing order completion, payment, downloads or fulfilment.
 */
final class ProductMembershipEligibility {
    public const META_KEY = '_mrbp_membership_eligibility';
    public const COUNT = 'count';
    public const EXCLUDE = 'exclude';
    private const CACHE_VERSION_OPTION = 'mrbp_membership_eligibility_version';

    public function register(): void {
        add_filter( 'woocommerce_product_data_tabs', array( $this, 'register_product_tab' ) );
        add_action( 'woocommerce_product_data_panels', array( $this, 'render_product_panel' ) );
        add_action( 'woocommerce_admin_process_product_object', array( $this, 'save_field' ) );
        add_filter( 'mrcp_membership_order_spend_amount', array( $this, 'filter_order_spend' ), 20, 3 );
    }

    /**
     * Register a dedicated Membership tab that remains available for simple and
     * variable products. The setting belongs to the parent product and all
     * variations inherit it.
     *
     * @param array<string, array<string, mixed>> $tabs Product data tabs.
     * @return array<string, array<string, mixed>>
     */
    public function register_product_tab( array $tabs ): array {
        $tabs['mrbp_membership'] = array(
            'label'    => __( 'Membership', 'mr-commerce' ),
            'target'   => 'mrbp_membership_product_data',
            'class'    => array( 'show_if_simple', 'show_if_variable' ),
            'priority' => 65,
        );

        return $tabs;
    }

    /**
     * Render the parent-product membership eligibility panel.
     */
    public function render_product_panel(): void {
        global $product_object;

        $value = self::COUNT;
        if ( $product_object instanceof WC_Product ) {
            $stored = (string) $product_object->get_meta( self::META_KEY, true );
            if ( in_array( $stored, array( self::COUNT, self::EXCLUDE ), true ) ) {
                $value = $stored;
            }
        }
        ?>
        <div id="mrbp_membership_product_data" class="panel woocommerce_options_panel hidden">
            <div class="options_group">
                <?php
                woocommerce_wp_select(
                    array(
                        'id'          => self::META_KEY,
                        'label'       => __( 'Membership Eligibility', 'mr-commerce' ),
                        'value'       => $value,
                        'options'     => array(
                            self::COUNT   => __( 'Count toward Membership (Default)', 'mr-commerce' ),
                            self::EXCLUDE => __( 'Exclude from Membership', 'mr-commerce' ),
                        ),
                        'desc_tip'    => true,
                        'description' => __( 'This parent-product setting applies to all variations. Excluded products still complete normally, but their value does not increase customer lifetime membership spend or upgrade the membership level.', 'mr-commerce' ),
                    )
                );
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Save the product setting and invalidate membership calculations when it changes.
     */
    public function save_field( WC_Product $product ): void {
        $raw = isset( $_POST[ self::META_KEY ] ) ? sanitize_key( wp_unslash( $_POST[ self::META_KEY ] ) ) : self::COUNT;
        $new = in_array( $raw, array( self::COUNT, self::EXCLUDE ), true ) ? $raw : self::COUNT;
        $old = (string) $product->get_meta( self::META_KEY, true );
        $old = in_array( $old, array( self::COUNT, self::EXCLUDE ), true ) ? $old : self::COUNT;

        if ( self::COUNT === $new ) {
            $product->delete_meta_data( self::META_KEY );
        } else {
            $product->update_meta_data( self::META_KEY, $new );
        }

        if ( $new !== $old ) {
            $version = max( 1, (int) get_option( self::CACHE_VERSION_OPTION, 1 ) );
            update_option( self::CACHE_VERSION_OPTION, $version + 1, false );

            do_action( 'mrbp/membership/product_eligibility_changed', $product->get_id(), $old, $new );
        }
    }

    /**
     * Remove excluded product value from the amount counted for an order.
     *
     * The existing order-level total behavior is preserved when every product is
     * eligible. For mixed orders, order-level shipping, fees, tax and refunds are
     * allocated proportionally according to eligible line-item value.
     */
    public function filter_order_spend( float $net_total, $order, int $user_id ): float {
        if ( ! $order instanceof WC_Order || $net_total <= 0 ) {
            return max( 0, $net_total );
        }

        $all_items      = 0.0;
        $eligible_items = 0.0;

        foreach ( $order->get_items( 'line_item' ) as $item ) {
            if ( ! $item instanceof WC_Order_Item_Product ) {
                continue;
            }

            $line_amount = max( 0.0, (float) $item->get_total() + (float) $item->get_total_tax() );
            $all_items  += $line_amount;

            if ( $this->item_is_eligible( $item ) ) {
                $eligible_items += $line_amount;
            }
        }

        // Preserve the original engine for orders without measurable product lines.
        if ( $all_items <= 0 ) {
            return max( 0, $net_total );
        }

        // Preserve exact legacy totals when all products are eligible.
        if ( $eligible_items >= $all_items ) {
            return max( 0, $net_total );
        }

        if ( $eligible_items <= 0 ) {
            return 0.0;
        }

        $eligible_total = $net_total * ( $eligible_items / $all_items );
        $eligible_total = round( max( 0, $eligible_total ), 2 );

        return (float) apply_filters(
            'mrbp_membership_eligible_order_spend_amount',
            $eligible_total,
            $net_total,
            $eligible_items,
            $all_items,
            $order,
            $user_id
        );
    }

    private function item_is_eligible( WC_Order_Item_Product $item ): bool {
        $variation_id = absint( $item->get_variation_id() );
        $product_id   = absint( $item->get_product_id() );

        // Variation-level metadata is supported programmatically; otherwise the
        // parent product setting is inherited.
        if ( $variation_id ) {
            $variation_value = (string) get_post_meta( $variation_id, self::META_KEY, true );
            if ( self::EXCLUDE === $variation_value ) {
                return false;
            }
            if ( self::COUNT === $variation_value ) {
                return true;
            }
        }

        return self::EXCLUDE !== (string) get_post_meta( $product_id, self::META_KEY, true );
    }
}
