<?php
namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Core\RequestContext;

final class LegacyBootstrap {
    private ?LegacyLoader $loader = null;
    private ?LegacyMenus $menus = null;
    private bool $registered = false;
    private bool $booted = false;
    private bool $standalone_conflict = false;

    public function register(): void {
        if ( $this->registered ) {
            return;
        }

        $this->registered = true;
        $this->standalone_conflict = $this->detect_standalone_conflict();

        if ( $this->standalone_conflict ) {
            add_action( 'admin_notices', array( $this, 'render_conflict_notice' ) );
            do_action( 'mrbp/customer_portal/legacy_bridge_conflict', $this );
            return;
        }

        LegacyConstants::define();
        if ( is_admin() ) {
            $this->menus = new LegacyMenus();
            $this->menus->register();
        }
        do_action( 'mrbp/customer_portal/legacy_bridge_registered', $this );
    }

    public function boot(): void {
        if ( $this->booted || $this->standalone_conflict ) {
            return;
        }

        // The 360KB legacy portal and its production modules are not parsed on
        // unrelated frontend requests such as the homepage, blog or shop archive.
        if ( ! RequestContext::needs_customer_portal_legacy() ) {
            do_action( 'mrbp/customer_portal/legacy_bridge_skipped', RequestContext::path(), $this );
            return;
        }

        $this->booted = true;
        $this->loader = new LegacyLoader();
        if ( null === $this->menus ) {
            $this->menus = new LegacyMenus();
        }
        load_textdomain( 'mr-customer-portal-pro', MRCP_PLUGIN_DIR . 'languages/mr-customer-portal-pro-' . determine_locale() . '.mo' );
        $loaded = $this->loader->register();

        if ( $loaded ) {
            $this->menus->suppress_legacy_registrations();
            $this->schedule_rewrite_flush();
        }

        if ( function_exists( 'mrbp' ) && mrbp()->container()->has( 'logger' ) ) {
            $logger = mrbp()->container()->get( 'logger' );
            $loaded
                ? $logger->module( 'Legacy Customer Portal bridge booted.' )
                : $logger->error( 'Legacy Customer Portal bridge failed to load.' );
        }

        do_action( 'mrbp/customer_portal/legacy_bridge_booted', $loaded, $this );
    }

    private function schedule_rewrite_flush(): void {
        add_action( 'admin_init', static function (): void {
            $rewrite_version = '0.5.99.5';

            if ( get_option( 'mrbp_customer_portal_rewrite_version' ) === $rewrite_version ) {
                return;
            }

            flush_rewrite_rules( false );
            update_option( 'mrbp_customer_portal_rewrite_version', $rewrite_version, false );
        }, 99 );
    }

    public function render_conflict_notice(): void {
        if ( ! current_user_can( 'activate_plugins' ) ) {
            return;
        }
        ?>
        <div class="notice notice-error">
            <p>
                <strong><?php esc_html_e( 'MR Commerce Pro Customer Portal was not started.', 'mr-commerce' ); ?></strong>
                <?php esc_html_e( 'The standalone MR Commerce Pro plugin is still active or already loaded. Deactivate the standalone plugin first, then keep the Customer Portal module enabled inside MR Commerce Pro.', 'mr-commerce' ); ?>
            </p>
        </div>
        <?php
    }

    private function detect_standalone_conflict(): bool {
        if ( defined( 'MRCP_PLUGIN_FILE' ) && defined( 'MRBP_FILE' ) ) {
            $legacy_file = wp_normalize_path( (string) MRCP_PLUGIN_FILE );
            $mrbp_file   = wp_normalize_path( (string) MRBP_FILE );

            if ( '' !== $legacy_file && $legacy_file !== $mrbp_file ) {
                return true;
            }
        }

        return class_exists( '\\MRCP\\Core\\Plugin', false )
            || class_exists( '\\MRCP\\Core\\Loader', false )
            || class_exists( 'MRCP_Customer_Portal', false );
    }
}
