<?php

namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Button;
use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Table;
use MRBP\Admin\Components\Tabs;
use MRBP\Admin\Layout\PageRenderer;

final class LegacyMenus {
    private const CORE_PARENT_SLUG = 'mrbp-dashboard';
    private const MODULE_SLUG      = 'mrbp-customer-portal';

    public function register(): void {
        add_action( 'admin_menu', array( $this, 'merge' ), 20 );
    }

    public function suppress_legacy_registrations(): void {
        if ( class_exists( '\\MRCP\\Core\\AdminCRM' ) ) {
            remove_action( 'admin_menu', array( '\\MRCP\\Core\\AdminCRM', 'register_menu' ), 8 );
        }

        if ( class_exists( '\\MRCP\\Modules\\Customers\\CustomersModule' ) ) {
            remove_action( 'admin_menu', array( '\\MRCP\\Modules\\Customers\\CustomersModule', 'register_menu' ), 20 );
        }
    }

    public function merge(): void {
        remove_menu_page( 'mrcp-admin-crm' );
        remove_menu_page( 'edit.php?post_type=mrcp_ticket' );
        remove_menu_page( 'edit.php?post_type=mrcp_activation' );
        remove_submenu_page( 'mrcp-admin-crm', 'mrcp-admin-crm' );
        remove_submenu_page( 'mrcp-admin-crm', 'mrcp-crm-customers' );

        $capability = current_user_can( 'manage_woocommerce' ) ? 'manage_woocommerce' : 'manage_options';

        add_submenu_page(
            self::CORE_PARENT_SLUG,
            __( 'MR Customer Dashboard', 'mr-commerce' ),
            __( 'MR Customer Dashboard', 'mr-commerce' ),
            $capability,
            self::MODULE_SLUG,
            array( $this, 'render_hub' )
        );

        add_submenu_page(
            null,
            __( 'Customer Portal Compatibility', 'mr-commerce' ),
            __( 'Customer Portal Compatibility', 'mr-commerce' ),
            'manage_options',
            'mrbp-cp-compatibility',
            array( CompatibilityReport::class, 'render' )
        );
    }

    public function render_hub(): void {
        $renderer = $this->page_renderer();
        $items    = $this->navigation_items();

        $renderer->render(
            __( 'MR Customer Dashboard', 'mr-commerce' ),
            __( 'Manage the integrated customer portal, CRM, reports and customer-service workflows.', 'mr-commerce' ),
            function () use ( $items ): void {
                $this->render_overview( $items );
            },
            array(
                array( 'label' => __( 'MR Commerce Pro', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=mrbp-dashboard' ) ),
                __( 'MR Customer Dashboard', 'mr-commerce' ),
            ),
            array(
                array(
                    'label' => __( 'Open Customer Dashboard', 'mr-commerce' ),
                    'url'   => home_url( '/dashboard/' ),
                    'class' => 'primary',
                ),
            ),
            current_user_can( 'manage_woocommerce' ) ? 'manage_woocommerce' : 'manage_options'
        );
    }

    /** @param array<int,array<string,string>> $items */
    private function render_overview( array $items ): void {
        $tabs = array(
            'overview' => array(
                'label'   => __( 'Overview', 'mr-commerce' ),
                'content' => $this->capture( function () use ( $items ): void {
                    $this->render_section_cards( $items );
                } ),
            ),
            'workflows' => array(
                'label'   => __( 'Workflows', 'mr-commerce' ),
                'content' => $this->capture( function (): void {
                    $this->render_workflow_table();
                } ),
            ),
            'diagnostics' => array(
                'label'   => __( 'Diagnostics', 'mr-commerce' ),
                'content' => $this->capture( function (): void {
                    Card::make(
                        __( 'Bridge Diagnostics', 'mr-commerce' ),
                        '<p>' . esc_html__( 'Verify legacy constants, database tables, options, routes and loaded services.', 'mr-commerce' ) . '</p>',
                        __( 'Read-only compatibility report', 'mr-commerce' )
                    )->badge( __( 'Safe', 'mr-commerce' ) )->footer(
                        $this->capture( static function (): void {
                            Button::secondary(
                                __( 'Open Compatibility Report', 'mr-commerce' ),
                                admin_url( 'admin.php?page=mrbp-cp-compatibility' )
                            )->render();
                        } )
                    )->render();
                } ),
            ),
        );

        Tabs::make( $tabs, 'overview', 'mrbp-customer-portal-tabs' )->render();
    }

    /** @param array<int,array<string,string>> $items */
    private function render_section_cards( array $items ): void {
        echo '<div class="mrbp-cp-overview-grid">';

        foreach ( $items as $item ) {
            $icon = $this->section_icon( $item['label'] );
            ?>
            <article class="mrbp-module-overview-card">
                <div class="mrbp-module-overview-card__top">
                    <div class="mrbp-module-overview-card__title-row">
                        <span class="mrbp-module-overview-card__icon dashicons <?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
                        <h2 class="mrbp-module-overview-card__title"><?php echo esc_html( $item['label'] ); ?></h2>
                    </div>

                    <div class="mrbp-module-overview-card__meta">
                        <span><?php echo esc_html( $item['group'] ); ?></span>
                        <span class="mrbp-module-overview-card__badge"><?php echo esc_html( $item['badge'] ); ?></span>
                    </div>
                </div>

                <div class="mrbp-module-overview-card__body">
                    <p class="mrbp-module-overview-card__description"><?php echo esc_html( $item['description'] ); ?></p>

                    <a class="mrbp-module-overview-card__action" href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="noopener noreferrer">
                        <span><?php esc_html_e( 'Open', 'mr-commerce' ); ?></span>
                        <span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span>
                    </a>
                </div>
            </article>
            <?php
        }

        echo '</div>';
    }

    private function section_icon( string $label ): string {
        $icons = array(
            'CRM Dashboard'       => 'dashicons-chart-area',
            'Customer Dashboard'  => 'dashicons-admin-home',
            'Products'            => 'dashicons-products',
            'Orders'              => 'dashicons-cart',
            'Customers'           => 'dashicons-groups',
            'Membership'          => 'dashicons-awards',
            'Reports'             => 'dashicons-chart-bar',
            'Activation Requests' => 'dashicons-hammer',
            'Support Tickets'     => 'dashicons-sos',
        );

        return $icons[ $label ] ?? 'dashicons-admin-generic';
    }

    private function render_workflow_table(): void {
        $rows = array(
            array( 'area' => __( 'CRM', 'mr-commerce' ), 'purpose' => __( 'Customers, orders, products and business reports.', 'mr-commerce' ), 'status' => '<span class="mrbp-ui-badge mrbp-ui-badge--info">' . esc_html__( 'Integrated', 'mr-commerce' ) . '</span>' ),
            array( 'area' => __( 'Customer Portal', 'mr-commerce' ), 'purpose' => __( 'Customer dashboard, downloads, invoices and account tools.', 'mr-commerce' ), 'status' => '<span class="mrbp-ui-badge mrbp-ui-badge--info">' . esc_html__( 'Integrated', 'mr-commerce' ) . '</span>' ),
        );

        Table::make(
            array(
                'area'    => __( 'Area', 'mr-commerce' ),
                'purpose' => __( 'Purpose', 'mr-commerce' ),
                'status'  => __( 'Status', 'mr-commerce' ),
            ),
            $rows
        )->render();
    }

    private function page_renderer(): PageRenderer {
        /** @var PageRenderer $renderer */
        $renderer = \mrbp()->container()->get( 'page_renderer' );
        return $renderer;
    }

    /** @param callable():void $callback */
    private function capture( callable $callback ): string {
        ob_start();
        $callback();
        return (string) ob_get_clean();
    }

    /** @return array<int,array<string,string>> */
    private function navigation_items(): array {
        return array(
            array( 'label' => __( 'CRM Dashboard', 'mr-commerce' ), 'description' => __( 'Complete CRM overview and business analytics dashboard.', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/' ), 'group' => __( 'CRM', 'mr-commerce' ), 'badge' => __( 'Overview', 'mr-commerce' ) ),
            array( 'label' => __( 'Customer Dashboard', 'mr-commerce' ), 'description' => __( 'Original customer-facing portal dashboard.', 'mr-commerce' ), 'url' => home_url( '/dashboard/' ), 'group' => __( 'Portal', 'mr-commerce' ), 'badge' => __( 'Frontend', 'mr-commerce' ) ),
            array( 'label' => __( 'Products', 'mr-commerce' ), 'description' => __( 'Product sales, performance and product intelligence.', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/products/' ), 'group' => __( 'CRM', 'mr-commerce' ), 'badge' => __( 'Analytics', 'mr-commerce' ) ),
            array( 'label' => __( 'Orders', 'mr-commerce' ), 'description' => __( 'Manage and review WooCommerce orders from the CRM.', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/orders/' ), 'group' => __( 'CRM', 'mr-commerce' ), 'badge' => __( 'Commerce', 'mr-commerce' ) ),
            array( 'label' => __( 'Customers', 'mr-commerce' ), 'description' => __( 'Customer profiles, spending information and activity.', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/customers/' ), 'group' => __( 'CRM', 'mr-commerce' ), 'badge' => __( 'People', 'mr-commerce' ) ),
            array( 'label' => __( 'Reports', 'mr-commerce' ), 'description' => __( 'Revenue, customer, product and growth reports.', 'mr-commerce' ), 'url' => home_url( '/dashboard/crm/reports/' ), 'group' => __( 'Analytics', 'mr-commerce' ), 'badge' => mrc_can( 'crm.advanced_reports' ) ? __( 'Reports', 'mr-commerce' ) : __( 'Pro Preview', 'mr-commerce' ) ),
        );
    }
}
