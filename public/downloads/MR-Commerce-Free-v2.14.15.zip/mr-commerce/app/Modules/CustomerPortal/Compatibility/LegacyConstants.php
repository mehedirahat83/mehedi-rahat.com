<?php
namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LegacyConstants {
    public static function define(): void {
        $dir = trailingslashit( MRBP_PATH . 'app/Modules/CustomerPortal/Legacy' );
        $url = trailingslashit( MRBP_URL . 'app/Modules/CustomerPortal/Legacy' );
        $constants = array(
            'MRCP_VERSION'         => '18.9.5-bridge',
            'MRCP_DB_VERSION'      => '1.1.0',
            'MRCP_PLUGIN_FILE'     => MRBP_FILE,
            'MRCP_PLUGIN_DIR'      => $dir,
            'MRCP_PLUGIN_URL'      => $url,
            'MRCP_PLUGIN_BASENAME' => MRBP_BASENAME,
        );
        foreach ( $constants as $name => $value ) {
            if ( ! defined( $name ) ) { define( $name, $value ); }
        }
    }
}
