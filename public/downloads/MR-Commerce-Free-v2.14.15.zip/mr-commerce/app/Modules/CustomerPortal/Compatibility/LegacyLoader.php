<?php
namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LegacyLoader {
    private ?object $loader = null;

    public function load(): bool {
        // Never redeclare legacy classes when the standalone plugin is active.
        if ( class_exists( '\\MRCP\\Core\\Loader', false ) ) {
            return false;
        }

        $core = array( 'Loader.php', 'Router.php', 'Assets.php', 'Installer.php', 'Database.php', 'Security.php', 'Performance.php', 'AdminCRM.php' );

        foreach ( $core as $file ) {
            $path = MRCP_PLUGIN_DIR . 'includes/Core/' . $file;

            if ( ! is_readable( $path ) ) {
                return false;
            }

            require_once $path;
        }

        if ( ! class_exists( '\\MRCP\\Core\\Loader', false ) ) {
            return false;
        }

        $this->loader = new \MRCP\Core\Loader();
        return true;
    }

    public function register(): bool {
        if ( ! $this->loader && ! $this->load() ) {
            return false;
        }

        $this->loader->register();
        return true;
    }
}
