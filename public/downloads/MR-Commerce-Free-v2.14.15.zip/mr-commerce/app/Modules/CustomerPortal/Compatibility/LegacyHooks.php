<?php
namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LegacyHooks {
    public static function inventory(): array {
        return array(
            'admin_menu'                        => 'merge',
            'admin_init'                        => 'keep',
            'init'                              => 'keep',
            'current_screen'                    => 'keep',
            'template_redirect'                 => 'keep',
            'wp_enqueue_scripts'                => 'keep',
            'woocommerce_new_order'             => 'keep',
            'woocommerce_order_status_changed'  => 'keep',
            'woocommerce_order_refunded'        => 'keep',
            'woocommerce_refund_created'        => 'keep',
            'save_post'                         => 'keep',
        );
    }
}
