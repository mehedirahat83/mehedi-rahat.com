<?php

namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Table;
use MRBP\Admin\Layout\PageRenderer;

final class CompatibilityReport {
    public static function data(): array {
        $tables  = LegacyDatabase::report();
        $options = array();
        foreach ( LegacySettings::known_options() as $key ) {
            $options[ $key ] = LegacySettings::exists( $key );
        }

        return array(
            'legacy_loaded' => class_exists( '\\MRCP\\Core\\Loader' ),
            'constants'     => defined( 'MRCP_PLUGIN_DIR' ) && defined( 'MRCP_PLUGIN_URL' ),
            'woocommerce'   => class_exists( 'WooCommerce' ),
            'frontend'      => class_exists( 'MRCP_Customer_Portal' ),
            'crm'           => class_exists( '\\MRCP\\Core\\AdminCRM' ),
            'membership'    => class_exists( 'MRCP_Membership' ),
            'tickets'       => post_type_exists( 'mrcp_ticket' ) || ! empty( $tables['tickets'] ),
            'activation'    => post_type_exists( 'mrcp_activation' ) || ! empty( $tables['activation_requests'] ),
            'tables'        => $tables,
            'options'       => $options,
            'hooks'         => LegacyHooks::inventory(),
        );
    }

    public static function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'mr-commerce' ) );
        }

        /** @var PageRenderer $renderer */
        $renderer = \mrbp()->container()->get( 'page_renderer' );
        $data     = self::data();

        $renderer->render(
            __( 'Customer Portal Compatibility', 'mr-commerce' ),
            __( 'Read-only bridge diagnostics. No legacy data is renamed, deleted or migrated.', 'mr-commerce' ),
            static function () use ( $data ): void {
                self::render_content( $data );
            },
            array(
                array( 'label' => __( 'MR Commerce Pro', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=mrbp-dashboard' ) ),
                array( 'label' => __( 'MR Customer Dashboard', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=mrbp-customer-portal' ) ),
                __( 'Compatibility', 'mr-commerce' ),
            )
        );
    }

    private static function render_content( array $data ): void {
        $checks = array();
        foreach ( array( 'legacy_loaded', 'constants', 'woocommerce', 'frontend', 'crm', 'membership', 'tickets', 'activation' ) as $key ) {
            $checks[] = array(
                'check'  => ucwords( str_replace( '_', ' ', $key ) ),
                'status' => ! empty( $data[ $key ] ) ? '<strong>' . esc_html__( 'YES', 'mr-commerce' ) . '</strong>' : '<strong>' . esc_html__( 'NO', 'mr-commerce' ) . '</strong>',
            );
        }

        echo '<div class="mrbp-ui-grid">';
        Card::make( __( 'Bridge Status', 'mr-commerce' ), '<p>' . esc_html__( 'The legacy portal is controlled by the MR Commerce Pro module lifecycle.', 'mr-commerce' ) . '</p>', __( 'Integration health', 'mr-commerce' ) )->badge( __( 'Read Only', 'mr-commerce' ) )->render();
        Card::make( __( 'Data Safety', 'mr-commerce' ), '<p>' . esc_html__( 'Legacy tables and options remain unchanged for rollback compatibility.', 'mr-commerce' ) . '</p>', __( 'No destructive migration', 'mr-commerce' ) )->badge( __( 'Preserved', 'mr-commerce' ) )->render();
        echo '</div>';

        echo '<div class="mrbp-ui-section">';
        Table::make( array( 'check' => __( 'Check', 'mr-commerce' ), 'status' => __( 'Status', 'mr-commerce' ) ), $checks )->render();
        echo '</div>';

        $table_rows = array();
        foreach ( $data['tables'] as $key => $ok ) {
            $table_rows[] = array( 'item' => $key, 'status' => $ok ? esc_html__( 'Found', 'mr-commerce' ) : esc_html__( 'Not found / not yet created', 'mr-commerce' ) );
        }
        echo '<div class="mrbp-ui-section">';
        Card::make( __( 'Legacy Tables', 'mr-commerce' ), self::capture_table( array( 'item' => __( 'Table', 'mr-commerce' ), 'status' => __( 'Status', 'mr-commerce' ) ), $table_rows ) )->render();
        echo '</div>';

        $option_rows = array();
        foreach ( $data['options'] as $key => $ok ) {
            $option_rows[] = array( 'item' => $key, 'status' => $ok ? esc_html__( 'Found', 'mr-commerce' ) : esc_html__( 'Not found', 'mr-commerce' ) );
        }
        echo '<div class="mrbp-ui-section">';
        Card::make( __( 'Legacy Options', 'mr-commerce' ), self::capture_table( array( 'item' => __( 'Option', 'mr-commerce' ), 'status' => __( 'Status', 'mr-commerce' ) ), $option_rows ) )->render();
        echo '</div>';
    }

    private static function capture_table( array $columns, array $rows ): string {
        ob_start();
        Table::make( $columns, $rows )->render();
        return (string) ob_get_clean();
    }
}
