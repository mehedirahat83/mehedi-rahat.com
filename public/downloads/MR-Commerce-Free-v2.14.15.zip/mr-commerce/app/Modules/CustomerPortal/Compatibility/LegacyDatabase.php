<?php
namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LegacyDatabase {
    public static function tables(): array {
        global $wpdb;
        return array(
            'notifications'       => $wpdb->prefix . 'mrcp_notifications',
            'tickets'             => $wpdb->prefix . 'mrcp_tickets',
            'activation_requests' => $wpdb->prefix . 'mrcp_activation_requests',
        );
    }
    public static function table_exists( string $table ): bool {
        global $wpdb;
        return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
    }
    public static function report(): array {
        $report = array();
        foreach ( self::tables() as $key => $table ) { $report[ $key ] = self::table_exists( $table ); }
        return $report;
    }
}
