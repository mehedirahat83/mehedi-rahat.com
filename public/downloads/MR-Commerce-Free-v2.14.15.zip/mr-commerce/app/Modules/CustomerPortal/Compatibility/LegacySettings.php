<?php
namespace MRBP\Modules\CustomerPortal\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class LegacySettings {
    public static function get( string $key, $default = null ) { return get_option( sanitize_key( $key ), $default ); }
    public static function exists( string $key ): bool { return false !== get_option( sanitize_key( $key ), false ); }
    public static function known_options(): array { return array( 'mrcp_version', 'mrcp_db_version', 'mrcp_performance_indexes_version' ); }
}
