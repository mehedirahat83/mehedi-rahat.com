<?php

namespace MRBP\Modules\CustomerPortal;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\ModuleInterface;
use MRBP\Modules\CustomerPortal\Compatibility\LegacyBootstrap;
use MRBP\Modules\CustomerPortal\Listeners\PaymentSyncListener;
use MRBP\Modules\CustomerPortal\Listeners\CacheInvalidationListener;
use MRBP\Modules\CustomerPortal\Frontend\RecentActivity;
use MRBP\Modules\CustomerPortal\Services\ProductMembershipEligibility;

final class CustomerPortalModule implements ModuleInterface {
    private bool $registered = false;
    private bool $booted = false;
    private ?LegacyBootstrap $bootstrap = null;
    private ?PaymentSyncListener $payment_sync = null;
    private ?RecentActivity $recent_activity = null;
    private ?ProductMembershipEligibility $product_membership_eligibility = null;
    private ?CacheInvalidationListener $cache_invalidation = null;

    public function id(): string { return 'customer_portal'; }
    public function name(): string { return __( 'MR Customer Dashboard', 'mr-commerce' ); }
    public function description(): string { return __( 'Legacy-compatible WooCommerce CRM and customer portal.', 'mr-commerce' ); }
    public function dependencies(): array { return array( 'woocommerce' ); }
    public function is_available(): bool { return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' ); }

    public function register(): void {
        if ( $this->registered ) { return; }
        $this->registered = true;
        $this->bootstrap = new LegacyBootstrap();
        $this->bootstrap->register();
        $this->payment_sync = new PaymentSyncListener();
        $this->payment_sync->register();
        $this->recent_activity = new RecentActivity();
        $this->recent_activity->register();
        if ( mrc_can( 'digital.membership' ) ) {
            $this->product_membership_eligibility = new ProductMembershipEligibility();
            $this->product_membership_eligibility->register();
        }
        $this->cache_invalidation = new CacheInvalidationListener();
        $this->cache_invalidation->register();
        do_action( 'mrbp/customer_portal/registered', $this );
    }

    public function boot(): void {
        if ( $this->booted ) { return; }
        $this->booted = true;
        if ( $this->bootstrap ) { $this->bootstrap->boot(); }
        do_action( 'mrbp/customer_portal/booted', $this );
    }
}
