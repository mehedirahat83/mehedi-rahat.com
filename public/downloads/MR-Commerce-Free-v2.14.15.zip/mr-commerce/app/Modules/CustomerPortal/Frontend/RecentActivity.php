<?php

namespace MRBP\Modules\CustomerPortal\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\CustomerPortal\Repositories\CustomerActivityRepository;

final class RecentActivity {

    private CustomerActivityRepository $repository;

    public function __construct( ?CustomerActivityRepository $repository = null ) {
        $this->repository = $repository ?? new CustomerActivityRepository();
    }

    public function register(): void {
        add_action( 'mrbp/customer_portal/dashboard_after_widgets', array( $this, 'render' ) );
        add_shortcode( 'mrbp_customer_activity', array( $this, 'shortcode' ) );
    }

    public function render(): void {
        echo $this->markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Dynamic values are escaped in markup().
    }

    public function shortcode(): string {
        return $this->markup();
    }

    private function markup(): string {
        if ( ! is_user_logged_in() ) {
            return '';
        }

        $items = $this->repository->activities( get_current_user_id(), 8 );
        if ( empty( $items ) ) {
            return '';
        }

        ob_start();
        ?>
        <section class="mrcp-panel mrbp-customer-activity">
            <div class="mrcp-panel-head">
                <h2><?php esc_html_e( 'Recent Activity', 'mr-commerce' ); ?></h2>
                <?php if ( function_exists( 'wc_get_account_endpoint_url' ) ) : ?>
                    <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'payment-history' ) ); ?>"><?php esc_html_e( 'Payment History →', 'mr-commerce' ); ?></a>
                <?php endif; ?>
            </div>
            <div class="mrbp-customer-activity__list">
                <?php foreach ( $items as $item ) : ?>
                    <article class="mrbp-customer-activity__item">
                        <span aria-hidden="true"><?php echo esc_html( $this->icon( sanitize_key( (string) ( $item['event'] ?? '' ) ) ) ); ?></span>
                        <div>
                            <strong><?php echo esc_html( (string) ( $item['title'] ?? '' ) ); ?></strong>
                            <p><?php echo esc_html( (string) ( $item['message'] ?? '' ) ); ?></p>
                        </div>
                        <small><?php echo esc_html( human_time_diff( absint( $item['time'] ?? time() ), current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'mr-commerce' ) ); ?></small>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private function icon( string $event ): string {
        if ( str_contains( $event, 'verified' ) ) {
            return '✓';
        }
        if ( str_contains( $event, 'rejected' ) ) {
            return '×';
        }
        if ( str_contains( $event, 'review' ) ) {
            return '⌛';
        }
        if ( str_contains( $event, 'order_' ) ) {
            return '📦';
        }
        return '💳';
    }
}
