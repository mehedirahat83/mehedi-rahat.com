<?php

namespace MRBP\Modules\CustomerPortal\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class PortalNotificationRepository {

    private const META_KEY = '_mrcp_notifications';

    public function add(
        int $user_id,
        string $event_key,
        string $title,
        string $message,
        string $url = '',
        string $type = 'payment'
    ): bool {
        if ( $user_id <= 0 || '' === sanitize_key( $event_key ) ) {
            return false;
        }

        $items = get_user_meta( $user_id, self::META_KEY, true );
        $items = is_array( $items ) ? $items : array();

        $notification_id = 'mrbp_' . sanitize_key( $event_key );
        foreach ( $items as $existing ) {
            if ( is_array( $existing ) && hash_equals( $notification_id, (string) ( $existing['id'] ?? '' ) ) ) {
                return false;
            }
        }

        array_unshift(
            $items,
            array(
                'id'      => $notification_id,
                'title'   => sanitize_text_field( $title ),
                'message' => sanitize_text_field( $message ),
                'url'     => esc_url_raw( $url ),
                'type'    => sanitize_key( $type ),
                'read'    => false,
                'read_at' => 0,
                'time'    => current_time( 'timestamp' ),
            )
        );

        return false !== update_user_meta( $user_id, self::META_KEY, array_slice( $items, 0, 20 ) );
    }
}
