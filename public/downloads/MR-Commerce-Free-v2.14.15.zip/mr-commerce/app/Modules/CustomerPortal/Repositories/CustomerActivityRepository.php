<?php

namespace MRBP\Modules\CustomerPortal\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class CustomerActivityRepository {

    private const ACTIVITY_META   = '_mrbp_customer_activity';
    private const TIMELINE_META   = '_mrbp_payment_timeline';
    private const MEMBERSHIP_META = '_mrbp_membership_activity';
    private const MAX_ITEMS       = 50;

    /**
     * @param array<string,mixed> $activity
     */
    public function add_activity( int $user_id, array $activity ): bool {
        return $this->prepend_unique( $user_id, self::ACTIVITY_META, $activity, self::MAX_ITEMS );
    }

    /**
     * @param array<string,mixed> $event
     */
    public function add_timeline_event( int $user_id, array $event ): bool {
        return $this->prepend_unique( $user_id, self::TIMELINE_META, $event, 100 );
    }

    /**
     * @param array<string,mixed> $activity
     */
    public function add_membership_activity( int $user_id, array $activity ): bool {
        return $this->prepend_unique( $user_id, self::MEMBERSHIP_META, $activity, 30 );
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    public function activities( int $user_id, int $limit = 10 ): array {
        $items = get_user_meta( $user_id, self::ACTIVITY_META, true );
        return is_array( $items ) ? array_slice( $items, 0, max( 1, $limit ) ) : array();
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    public function timeline_for_request( int $user_id, int $request_id ): array {
        $items = get_user_meta( $user_id, self::TIMELINE_META, true );
        if ( ! is_array( $items ) ) {
            return array();
        }

        return array_values(
            array_filter(
                $items,
                static fn( $item ): bool => is_array( $item ) && absint( $item['request_id'] ?? 0 ) === $request_id
            )
        );
    }

    /**
     * @param array<string,mixed> $item
     */
    private function prepend_unique( int $user_id, string $meta_key, array $item, int $limit ): bool {
        if ( $user_id <= 0 ) {
            return false;
        }

        $event_key = sanitize_key( (string) ( $item['event_key'] ?? '' ) );
        if ( '' === $event_key ) {
            return false;
        }

        $items = get_user_meta( $user_id, $meta_key, true );
        $items = is_array( $items ) ? $items : array();

        foreach ( $items as $existing ) {
            if ( is_array( $existing ) && hash_equals( $event_key, sanitize_key( (string) ( $existing['event_key'] ?? '' ) ) ) ) {
                return false;
            }
        }

        $safe = array(
            'event_key' => $event_key,
            'event'     => sanitize_key( (string) ( $item['event'] ?? 'activity' ) ),
            'title'     => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
            'message'   => sanitize_text_field( (string) ( $item['message'] ?? '' ) ),
            'status'    => sanitize_key( (string) ( $item['status'] ?? '' ) ),
            'source'    => sanitize_key( (string) ( $item['source'] ?? 'payment_center' ) ),
            'request_id'=> absint( $item['request_id'] ?? 0 ),
            'order_id'  => absint( $item['order_id'] ?? 0 ),
            'amount'    => (float) ( $item['amount'] ?? 0 ),
            'currency'  => strtoupper( sanitize_text_field( (string) ( $item['currency'] ?? '' ) ) ),
            'gateway'   => sanitize_key( (string) ( $item['gateway'] ?? '' ) ),
            'url'       => esc_url_raw( (string) ( $item['url'] ?? '' ) ),
            'time'      => absint( $item['time'] ?? current_time( 'timestamp' ) ),
        );

        array_unshift( $items, $safe );
        $items = array_slice( $items, 0, max( 1, $limit ) );

        return false !== update_user_meta( $user_id, $meta_key, $items );
    }
}
