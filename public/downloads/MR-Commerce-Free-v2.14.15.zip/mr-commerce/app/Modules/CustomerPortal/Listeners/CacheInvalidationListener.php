<?php

namespace MRBP\Modules\CustomerPortal\Listeners;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Keeps portal, membership and CRM caches fresh without booting the legacy UI.
 *
 * This listener is intentionally independent of MRCP legacy classes so it can
 * run during WooCommerce REST, cron and background order updates at low cost.
 */
final class CacheInvalidationListener {
    private bool $registered = false;
    private bool $invalidated = false;

    public function register(): void {
        if ( $this->registered ) {
            return;
        }

        $this->registered = true;

        foreach ( array( 'woocommerce_new_order', 'woocommerce_update_order', 'woocommerce_delete_order' ) as $hook ) {
            add_action( $hook, array( $this, 'invalidate_order' ), 20, 1 );
        }
        add_action( 'woocommerce_order_status_changed', array( $this, 'invalidate_order' ), 20, 4 );
        add_action( 'woocommerce_order_refunded', array( $this, 'invalidate_order' ), 20, 2 );
        add_action( 'woocommerce_refund_created', array( $this, 'invalidate_refund' ), 20, 2 );

        add_action( 'save_post_mrcp_ticket', array( $this, 'invalidate_all' ), 20, 3 );
        add_action( 'save_post_mrcp_activation', array( $this, 'invalidate_all' ), 20, 3 );
        add_action( 'save_post_product', array( $this, 'invalidate_all' ), 20, 3 );
        add_action( 'created_product_cat', array( $this, 'invalidate_all' ), 20, 1 );
        add_action( 'edited_product_cat', array( $this, 'invalidate_all' ), 20, 1 );
        add_action( 'delete_product_cat', array( $this, 'invalidate_all' ), 20, 1 );
        add_action( 'user_register', array( $this, 'invalidate_all' ), 20, 1 );
        add_action( 'profile_update', array( $this, 'invalidate_all' ), 20, 1 );
        add_action( 'deleted_user', array( $this, 'invalidate_all' ), 20, 1 );
    }

    public function invalidate_order( $order_id, ...$args ): void {
        $order_id = absint( $order_id );
        $order = $order_id && function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;

        if ( $order && method_exists( $order, 'get_customer_id' ) ) {
            $this->clear_membership( absint( $order->get_customer_id() ) );
        }

        $this->invalidate_all();
    }

    public function invalidate_refund( $refund_id, ...$args ): void {
        $refund = function_exists( 'wc_get_order' ) ? wc_get_order( absint( $refund_id ) ) : null;
        $parent_id = $refund && method_exists( $refund, 'get_parent_id' ) ? absint( $refund->get_parent_id() ) : 0;
        $this->invalidate_order( $parent_id );
    }

    public function invalidate_all( ...$args ): void {
        // Several WooCommerce hooks can fire for one operation. One generation
        // bump per PHP request is sufficient and avoids repeated option writes.
        if ( $this->invalidated ) {
            return;
        }
        $this->invalidated = true;

        $generation = max( 1, (int) get_option( 'mrcp_cache_generation', 1 ) );
        update_option( 'mrcp_cache_generation', $generation + 1, false );

        foreach ( array(
            'mrbp_weekly_sales_completed_sat_v1',
            'mrcp_product_intelligence_v18_2',
            'mrcp_crm_product_performance_v16',
            'mrcp_crm_membership_analytics_v150',
            'mrcp_reports_health_v18_8',
            'mrcp_reports_customer_v17_2',
        ) as $key ) {
            delete_transient( $key );
        }

        foreach ( array( 5, 10, 20 ) as $limit ) {
            delete_transient( 'mrcp_lifetime_top_products_v1424_' . $limit );
            delete_transient( 'mrcp_lifetime_top_products_v1422_' . $limit );
            delete_transient( 'mrcp_crm_top_products_' . $limit );
        }

        if ( function_exists( 'wp_cache_flush_group' ) ) {
            wp_cache_flush_group( 'mrcp' );
        }
    }

    private function clear_membership( int $user_id ): void {
        if ( $user_id < 1 ) {
            return;
        }

        $version = max( 1, (int) get_option( 'mrbp_membership_eligibility_version', 1 ) );
        foreach ( array(
            'mrcp_membership_user_' . $version . '_' . $user_id,
            'mrcp_membership_user_' . $version . '_spend_' . $user_id,
            'mrcp_membership_user_' . $user_id,
            'mrcp_membership_user_spend_' . $user_id,
        ) as $key ) {
            delete_transient( $key );
        }
    }
}
