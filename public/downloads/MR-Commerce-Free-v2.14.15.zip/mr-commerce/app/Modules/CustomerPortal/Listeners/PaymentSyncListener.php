<?php

namespace MRBP\Modules\CustomerPortal\Listeners;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\CustomerPortal\Services\PaymentCustomerSyncService;

final class PaymentSyncListener {

    private PaymentCustomerSyncService $sync;

    public function __construct( ?PaymentCustomerSyncService $sync = null ) {
        $this->sync = $sync ?? new PaymentCustomerSyncService();
    }

    public function register(): void {
        add_action( 'mrbp/payment/submitted', array( $this, 'submitted' ), 20, 2 );
        add_action( 'mrbp/payment/review', array( $this, 'review' ), 30, 6 );
        add_action( 'mrbp/payment/rejected', array( $this, 'rejected' ), 30, 6 );
        add_action( 'mrbp/payment/woocommerce_synced', array( $this, 'woocommerce_synced' ), 30, 5 );
    }

    /** @param array<string,mixed> $request */
    public function submitted( int $request_id, array $request ): void {
        $this->sync->record_submitted( $request_id, $request );
    }

    /** @param array<string,mixed> $request */
    public function review( int $request_id, array $request, string $admin_note ): void {
        $this->sync->record_review( $request_id, $request, $admin_note );
    }

    /** @param array<string,mixed> $request */
    public function rejected( int $request_id, array $request, string $admin_note ): void {
        $this->sync->record_rejected( $request_id, $request, $admin_note );
    }

    /** @param array<string,mixed> $request */
    public function woocommerce_synced( int $order_id, int $request_id, string $decision, array $request, $order ): void {
        $this->sync->record_woocommerce_sync( $order_id, $request_id, $decision, $request, $order );
    }
}
