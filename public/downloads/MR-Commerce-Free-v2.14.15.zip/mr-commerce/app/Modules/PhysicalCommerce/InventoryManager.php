<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;

final class InventoryManager {
    public function register(): void {
        add_action( 'woocommerce_product_set_stock', array( $this, 'log_stock' ) );
        add_action( 'woocommerce_variation_set_stock', array( $this, 'log_stock' ) );
        add_action( 'woocommerce_low_stock', array( $this, 'alert' ) );
        add_action( 'woocommerce_no_stock', array( $this, 'alert' ) );
        add_action( 'woocommerce_product_options_inventory_product_data', array( $this, 'product_fields' ) );
        add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_fields' ) );
        add_action( 'woocommerce_variation_options_inventory', array( $this, 'variation_fields' ), 20, 3 );
        add_action( 'woocommerce_save_product_variation', array( $this, 'save_variation_fields' ), 20, 2 );
        if ( is_admin() ) { add_action( 'admin_menu', array( $this, 'menu' ), 35 ); add_action( 'admin_notices', array( $this, 'notice' ) ); }
    }

    public function log_stock( $product ): void {
        if ( ! $product instanceof \WC_Product || ! mrc_can( 'inventory.movement_log' ) ) { return; }
        $id = $product->get_id(); $current = $product->get_stock_quantity();
        $previous = get_post_meta( $id, '_mrc_last_logged_stock', true );
        if ( '' !== $previous && (int) $previous === (int) $current ) { return; }
        update_post_meta( $id, '_mrc_last_logged_stock', $current );
        $log = (array) get_option( 'mrc_stock_movement_log', array() );
        array_unshift( $log, array( 'time' => current_time( 'mysql', true ), 'product_id' => $id, 'sku' => $product->get_sku(), 'from' => '' === $previous ? null : (int) $previous, 'to' => null === $current ? null : (int) $current, 'user_id' => get_current_user_id() ) );
        update_option( 'mrc_stock_movement_log', array_slice( $log, 0, max( 1, mrc_limit( 'inventory.movement_log' ) ) ), false );
    }

    public function alert( $product ): void {
        if ( ! $product instanceof \WC_Product || ! mrc_can( 'inventory.alerts' ) ) { return; }
        set_transient( 'mrc_stock_alert_' . $product->get_id(), array( 'name' => $product->get_name(), 'stock' => $product->get_stock_quantity() ), WEEK_IN_SECONDS );
        update_option( 'mrc_latest_stock_alert', array( 'name' => $product->get_name(), 'stock' => $product->get_stock_quantity(), 'time' => time() ), false );
    }

    public function notice(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $alert = (array) get_option( 'mrc_latest_stock_alert', array() );
        if ( empty( $alert['time'] ) || (int) $alert['time'] < time() - DAY_IN_SECONDS ) { return; }
        echo '<div class="notice notice-warning"><p>' . esc_html( sprintf( __( 'Stock alert: %1$s now has %2$s units.', 'mr-commerce' ), (string) ( $alert['name'] ?? '' ), (string) ( $alert['stock'] ?? 0 ) ) ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=mrc-stock-dashboard' ) ) . '">' . esc_html__( 'Open Stock Dashboard', 'mr-commerce' ) . '</a></p></div>';
    }

    public function product_fields(): void {
        if ( ! mrc_can( 'inventory.costing' ) ) { return; }
        woocommerce_wp_text_input( array( 'id' => '_mrc_purchase_cost', 'label' => __( 'Purchase cost', 'mr-commerce' ), 'data_type' => 'price' ) );
        if ( mrc_can( 'inventory.suppliers' ) ) {
            woocommerce_wp_text_input( array( 'id' => '_mrc_supplier_name', 'label' => __( 'Supplier name', 'mr-commerce' ) ) );
            woocommerce_wp_text_input( array( 'id' => '_mrc_supplier_contact', 'label' => __( 'Supplier contact', 'mr-commerce' ) ) );
        }
    }

    public function save_product_fields( int $id ): void {
        if ( ! current_user_can( 'edit_post', $id ) || ! mrc_can( 'inventory.costing' ) ) { return; }
        update_post_meta( $id, '_mrc_purchase_cost', wc_format_decimal( wp_unslash( $_POST['_mrc_purchase_cost'] ?? '' ) ) );
        if ( mrc_can( 'inventory.suppliers' ) ) {
            update_post_meta( $id, '_mrc_supplier_name', sanitize_text_field( wp_unslash( $_POST['_mrc_supplier_name'] ?? '' ) ) );
            update_post_meta( $id, '_mrc_supplier_contact', sanitize_text_field( wp_unslash( $_POST['_mrc_supplier_contact'] ?? '' ) ) );
        }
    }

    public function variation_fields( int $loop, array $variation_data, $variation ): void {
        if ( ! mrc_can( 'inventory.costing' ) ) { return; }
        woocommerce_wp_text_input( array( 'id' => "_mrc_variation_cost_{$loop}", 'name' => "_mrc_variation_cost[{$loop}]", 'label' => __( 'Purchase cost', 'mr-commerce' ), 'value' => get_post_meta( $variation->ID, '_mrc_purchase_cost', true ), 'wrapper_class' => 'form-row form-row-first' ) );
        if ( mrc_can( 'inventory.suppliers' ) ) { woocommerce_wp_text_input( array( 'id' => "_mrc_variation_supplier_{$loop}", 'name' => "_mrc_variation_supplier[{$loop}]", 'label' => __( 'Supplier', 'mr-commerce' ), 'value' => get_post_meta( $variation->ID, '_mrc_supplier_name', true ), 'wrapper_class' => 'form-row form-row-last' ) ); }
    }

    public function save_variation_fields( int $variation_id, int $index ): void {
        if ( ! mrc_can( 'inventory.costing' ) ) { return; }
        update_post_meta( $variation_id, '_mrc_purchase_cost', wc_format_decimal( wp_unslash( $_POST['_mrc_variation_cost'][ $index ] ?? '' ) ) );
        if ( mrc_can( 'inventory.suppliers' ) ) { update_post_meta( $variation_id, '_mrc_supplier_name', sanitize_text_field( wp_unslash( $_POST['_mrc_variation_supplier'][ $index ] ?? '' ) ) ); }
    }

    public function menu(): void {
        add_submenu_page( null, __( 'Stock Dashboard', 'mr-commerce' ), __( 'Stock Dashboard', 'mr-commerce' ), 'manage_woocommerce', 'mrc-stock-dashboard', array( $this, 'render' ) );
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $limit = mrc_limit( 'inventory.dashboard' ); if ( 0 === $limit ) { $limit = 50; }
        $products = wc_get_products( array( 'limit' => $limit, 'status' => 'publish', 'type' => array( 'simple', 'variation' ), 'orderby' => 'date', 'order' => 'DESC' ) );
        $low = 0; $out = 0;
        foreach ( $products as $product ) { if ( ! $product->managing_stock() ) { continue; } $qty = (int) $product->get_stock_quantity(); if ( $qty <= 0 ) { $out++; } elseif ( $qty <= (int) get_option( 'woocommerce_notify_low_stock_amount', 2 ) ) { $low++; } }
        ?><div class="wrap"><h1><?php esc_html_e( 'Stock Dashboard', 'mr-commerce' ); ?></h1><p><?php echo esc_html( sprintf( __( 'Low stock: %1$d · Out of stock: %2$d', 'mr-commerce' ), $low, $out ) ); ?></p><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Product / Variation', 'mr-commerce' ); ?></th><th><?php esc_html_e( 'SKU', 'mr-commerce' ); ?></th><th><?php esc_html_e( 'Stock', 'mr-commerce' ); ?></th><th><?php esc_html_e( 'Cost', 'mr-commerce' ); ?></th><th><?php esc_html_e( 'Margin', 'mr-commerce' ); ?></th><th><?php esc_html_e( 'Supplier', 'mr-commerce' ); ?></th></tr></thead><tbody>
        <?php foreach ( $products as $product ) : $cost = (float) get_post_meta( $product->get_id(), '_mrc_purchase_cost', true ); $price = (float) $product->get_price(); $margin = $price > 0 ? ( ( $price - $cost ) / $price ) * 100 : 0; ?><tr><td><a href="<?php echo esc_url( get_edit_post_link( $product->get_id() ) ); ?>"><?php echo esc_html( $product->get_formatted_name() ); ?></a></td><td><?php echo esc_html( $product->get_sku() ); ?></td><td><?php echo esc_html( null === $product->get_stock_quantity() ? '—' : (string) $product->get_stock_quantity() ); ?></td><td><?php echo mrc_can( 'inventory.costing' ) ? wp_kses_post( wc_price( $cost ) ) : 'Pro'; ?></td><td><?php echo mrc_can( 'inventory.costing' ) ? esc_html( number_format_i18n( $margin, 1 ) . '%' ) : 'Pro'; ?></td><td><?php echo mrc_can( 'inventory.suppliers' ) ? esc_html( get_post_meta( $product->get_id(), '_mrc_supplier_name', true ) ) : 'Pro'; ?></td></tr><?php endforeach; ?></tbody></table>
        <?php if ( ! mrc_can( 'inventory.movement_log' ) ) { ProFeature::render( 'inventory.movement_log', __( 'Stock Movement Log', 'mr-commerce' ), __( 'Keep an audit trail of product and variation stock changes.', 'mr-commerce' ) ); } else { $logs = (array) get_option( 'mrc_stock_movement_log', array() ); echo '<h2>' . esc_html__( 'Recent stock movements', 'mr-commerce' ) . '</h2><table class="widefat striped"><thead><tr><th>Time</th><th>Product</th><th>SKU</th><th>From</th><th>To</th></tr></thead><tbody>'; foreach ( array_slice( $logs, 0, 100 ) as $row ) { echo '<tr><td>' . esc_html( $row['time'] ?? '' ) . '</td><td>#' . esc_html( (string) ( $row['product_id'] ?? 0 ) ) . '</td><td>' . esc_html( $row['sku'] ?? '' ) . '</td><td>' . esc_html( (string) ( $row['from'] ?? '—' ) ) . '</td><td>' . esc_html( (string) ( $row['to'] ?? '—' ) ) . '</td></tr>'; } echo '</tbody></table>'; } ?></div><?php
    }
}
