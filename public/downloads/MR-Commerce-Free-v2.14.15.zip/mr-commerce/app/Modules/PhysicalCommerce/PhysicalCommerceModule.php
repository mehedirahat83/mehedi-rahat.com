<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

use MRBP\Modules\ModuleInterface;
use MRBP\Modules\RetentionSuite\CourierIntegrationAdmin;
use MRBP\Modules\RetentionSuite\ProviderManager;

final class PhysicalCommerceModule implements ModuleInterface {
    private bool $registered = false;
    private bool $booted = false;

    public function id(): string { return 'physical_commerce'; }
    public function name(): string { return __( 'MR Commerce', 'mr-commerce' ); }
    public function description(): string { return __( 'Fulfilment, COD, tracking, shipping documents and returns.', 'mr-commerce' ); }
    public function dependencies(): array { return array( 'woocommerce' ); }
    public function is_available(): bool { return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_order' ); }

    public function register(): void {
        if ( $this->registered ) { return; }
        $this->registered = true;
        ( new FulfilmentManager() )->register();
        ( new CodManager() )->register();
        ( new ShippingDocuments() )->register();
        ( new ReturnManager() )->register();
        ( new ShippingManager() )->register();
        ( new CourierManager() )->register();
        ( new InventoryManager() )->register();
        ( new ProviderManager() )->register_courier();
        if ( is_admin() ) { ( new ShippingAdmin() )->register(); }
        if ( is_admin() ) {
            ( new PhysicalCommerceAdmin() )->register();
            ( new CourierIntegrationAdmin() )->register();
        }
    }

    public function boot(): void {
        if ( $this->booted ) { return; }
        $this->booted = true;
        do_action( 'mrbp/physical_commerce/booted', $this );
    }
}
