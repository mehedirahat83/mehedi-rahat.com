<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class ShippingDocuments {
    public function register(): void {
        add_filter( 'woocommerce_admin_order_actions', array( $this, 'actions' ), 20, 2 );
        add_action( 'admin_post_mrc_print_order_document', array( $this, 'render' ) );
    }

    public function actions( array $actions, $order ): array {
        if ( ! $order instanceof \WC_Order || ! PhysicalOrder::contains_shippable( $order ) || ! mrc_can( 'physical.shipping_documents' ) ) { return $actions; }
        foreach ( array( 'packing' => 'Packing slip', 'label' => 'Shipping label' ) as $type => $name ) {
            $actions[ 'mrc_' . $type ] = array(
                'url' => wp_nonce_url( admin_url( 'admin-post.php?action=mrc_print_order_document&type=' . $type . '&order_id=' . $order->get_id() ), 'mrc_document_' . $order->get_id() ),
                'name' => __( $name, 'mr-commerce' ), 'action' => 'view',
            );
        }
        return $actions;
    }

    public function render(): void {
        $order_id = absint( $_GET['order_id'] ?? 0 );
        check_admin_referer( 'mrc_document_' . $order_id );
        if ( ! current_user_can( 'edit_shop_order', $order_id ) || ! mrc_can( 'physical.shipping_documents' ) ) { wp_die( esc_html__( 'Access denied.', 'mr-commerce' ) ); }
        $order = wc_get_order( $order_id );
        if ( ! $order || ! PhysicalOrder::contains_shippable( $order ) ) { wp_die( esc_html__( 'Physical order not found.', 'mr-commerce' ) ); }
        $type = 'label' === sanitize_key( wp_unslash( $_GET['type'] ?? '' ) ) ? 'label' : 'packing';
        nocache_headers();
        ?><!doctype html><html><head><meta charset="utf-8"><title><?php echo esc_html( ucfirst( $type ) . ' #' . $order->get_order_number() ); ?></title><style>body{font:14px Arial;margin:28px;color:#111}h1{font-size:24px}.address{font-size:18px;line-height:1.5;border:2px solid #111;padding:20px}.meta{margin:16px 0}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #ccc;text-align:left}@media print{button{display:none}}</style></head><body><button onclick="window.print()"><?php esc_html_e( 'Print', 'mr-commerce' ); ?></button><h1><?php echo esc_html( 'label' === $type ? __( 'Shipping Label', 'mr-commerce' ) : __( 'Packing Slip', 'mr-commerce' ) ); ?></h1><div class="meta"><?php echo esc_html( '#' . $order->get_order_number() . ' · ' . wc_format_datetime( $order->get_date_created() ) ); ?></div><div class="address"><?php echo wp_kses_post( $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() ); ?><br><?php echo esc_html( $order->get_billing_phone() ); ?></div><?php if ( 'packing' === $type ) : ?><table><thead><tr><th><?php esc_html_e( 'Product', 'mr-commerce' ); ?></th><th><?php esc_html_e( 'Quantity', 'mr-commerce' ); ?></th></tr></thead><tbody><?php foreach ( $order->get_items() as $item ) : ?><tr><td><?php echo esc_html( $item->get_name() ); ?></td><td><?php echo esc_html( (string) $item->get_quantity() ); ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></body></html><?php
        exit;
    }
}
