<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class CourierManager {
    public function register(): void {
        add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'fields' ), 15 );
        add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save' ), 25 );
        add_action( 'admin_post_mrc_create_consignment', array( $this, 'create_consignment' ) );
    }

    public function fields( $order ): void {
        if ( ! $order instanceof \WC_Order || ! PhysicalOrder::contains_shippable( $order ) || ! mrc_can( 'shipping.courier_assignment' ) ) { return; }
        $options = array();
        foreach ( ( new CourierRegistry() )->all() as $id => $adapter ) { $options[ $id ] = $adapter->label(); }
        wp_nonce_field( 'mrc_courier_' . $order->get_id(), 'mrc_courier_nonce' );
        woocommerce_wp_select( array( 'id' => '_mrc_courier_adapter', 'label' => __( 'Courier adapter', 'mr-commerce' ), 'value' => $order->get_meta( '_mrc_courier_adapter' ), 'options' => $options ) );
        woocommerce_wp_text_input( array( 'id' => '_mrc_consignment_id', 'label' => __( 'Consignment ID', 'mr-commerce' ), 'value' => $order->get_meta( '_mrc_consignment_id' ) ) );
        if ( mrc_can( 'shipping.courier_adapters' ) ) {
            echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrc_create_consignment&order_id=' . $order->get_id() ), 'mrc_create_consignment_' . $order->get_id() ) ) . '">' . esc_html__( 'Create courier consignment', 'mr-commerce' ) . '</a></p>';
        }
    }

    public function save( int $order_id ): void {
        if ( empty( $_POST['mrc_courier_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrc_courier_nonce'] ) ), 'mrc_courier_' . $order_id ) || ! current_user_can( 'edit_shop_order', $order_id ) || ! mrc_can( 'shipping.courier_assignment' ) ) { return; }
        $order = wc_get_order( $order_id ); if ( ! $order ) { return; }
        $adapter_id = sanitize_key( wp_unslash( $_POST['_mrc_courier_adapter'] ?? 'manual' ) );
        $consignment = sanitize_text_field( wp_unslash( $_POST['_mrc_consignment_id'] ?? '' ) );
        $adapters = ( new CourierRegistry() )->all();
        if ( ! isset( $adapters[ $adapter_id ] ) ) { $adapter_id = 'manual'; }
        $order->update_meta_data( '_mrc_courier_adapter', $adapter_id );
        $order->update_meta_data( '_mrc_consignment_id', $consignment );
        if ( $consignment && isset( $adapters[ $adapter_id ] ) ) {
            $url = $adapters[ $adapter_id ]->tracking_url( $consignment );
            if ( $url ) { $order->update_meta_data( '_mrc_tracking_url', esc_url_raw( $url ) ); }
            $order->update_meta_data( '_mrc_tracking_number', $consignment );
        }
        $order->save();
    }

    public function create_consignment(): void {
        $order_id = absint( $_GET['order_id'] ?? 0 );
        check_admin_referer( 'mrc_create_consignment_' . $order_id );
        if ( ! current_user_can( 'edit_shop_order', $order_id ) || ! mrc_can( 'shipping.courier_adapters' ) ) { wp_die( esc_html__( 'Access denied.', 'mr-commerce' ) ); }
        $order = wc_get_order( $order_id ); if ( ! $order ) { wp_die( esc_html__( 'Order not found.', 'mr-commerce' ) ); }
        $id = sanitize_key( (string) $order->get_meta( '_mrc_courier_adapter' ) );
        $adapters = ( new CourierRegistry() )->all();
        $result = isset( $adapters[ $id ] ) ? $adapters[ $id ]->create_consignment( $order ) : array( 'success' => false, 'message' => __( 'Choose a connected courier adapter first.', 'mr-commerce' ) );
        if ( ! empty( $result['success'] ) && ! empty( $result['consignment_id'] ) ) {
            $consignment = sanitize_text_field( (string) $result['consignment_id'] );
            $order->update_meta_data( '_mrc_consignment_id', $consignment );
            $order->update_meta_data( '_mrc_tracking_number', $consignment );
            if ( isset( $adapters[ $id ] ) ) { $order->update_meta_data( '_mrc_tracking_url', esc_url_raw( $adapters[ $id ]->tracking_url( $consignment ) ) ); }
            $order->add_order_note( __( 'Courier consignment created by MR Commerce.', 'mr-commerce' ) );
            $order->save();
        }
        wp_safe_redirect( $order->get_edit_order_url() );
        exit;
    }
}
