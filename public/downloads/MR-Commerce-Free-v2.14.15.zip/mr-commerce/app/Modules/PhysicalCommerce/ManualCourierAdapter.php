<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class ManualCourierAdapter implements CourierAdapterInterface {
    public function id(): string { return 'manual'; }
    public function label(): string { return __( 'Manual courier', 'mr-commerce' ); }
    public function create_consignment( \WC_Order $order ): array { return array( 'success' => false, 'message' => __( 'Enter the courier consignment ID manually.', 'mr-commerce' ) ); }
    public function tracking_url( string $consignment_id ): string { return ''; }
}
