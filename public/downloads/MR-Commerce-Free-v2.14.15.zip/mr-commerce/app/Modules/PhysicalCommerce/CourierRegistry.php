<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class CourierRegistry {
    /** @return array<string,CourierAdapterInterface> */
    public function all(): array {
        $adapters = array( 'manual' => new ManualCourierAdapter() );
        if ( mrc_can( 'shipping.courier_adapters' ) ) { $adapters = apply_filters( 'mrc/courier_adapters', $adapters ); }
        return array_filter( $adapters, static fn( $adapter ): bool => $adapter instanceof CourierAdapterInterface );
    }
}
