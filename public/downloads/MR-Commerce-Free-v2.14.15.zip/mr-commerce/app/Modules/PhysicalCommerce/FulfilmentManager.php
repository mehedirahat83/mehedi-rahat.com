<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class FulfilmentManager {
    private const STATUSES = array(
        'mrc-packing'   => 'Packing',
        'mrc-shipped'   => 'Shipped',
        'mrc-delivered' => 'Delivered',
        'mrc-failed'    => 'Delivery Failed',
        'mrc-returned'  => 'Returned',
    );

    public function register(): void {
        add_action( 'init', array( $this, 'register_statuses' ) );
        add_filter( 'wc_order_statuses', array( $this, 'status_list' ) );
        add_action( 'woocommerce_order_details_after_order_table', array( $this, 'render_tracking' ) );
        add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'admin_tracking_fields' ) );
        add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save_tracking_fields' ), 20 );
    }

    public function register_statuses(): void {
        foreach ( self::STATUSES as $key => $label ) {
            register_post_status( 'wc-' . $key, array(
                'label' => _x( $label, 'Order status', 'mr-commerce' ),
                'public' => true, 'exclude_from_search' => false,
                'show_in_admin_all_list' => true, 'show_in_admin_status_list' => true,
                'label_count' => _n_noop( $label . ' <span class="count">(%s)</span>', $label . ' <span class="count">(%s)</span>', 'mr-commerce' ),
            ) );
        }
    }

    public function status_list( array $statuses ): array {
        $out = array();
        foreach ( $statuses as $key => $label ) {
            $out[ $key ] = $label;
            if ( 'wc-processing' === $key ) {
                foreach ( self::STATUSES as $status => $name ) { $out[ 'wc-' . $status ] = __( $name, 'mr-commerce' ); }
            }
        }
        return $out;
    }

    public function admin_tracking_fields( $order ): void {
        if ( ! $order instanceof \WC_Order || ! PhysicalOrder::contains_shippable( $order ) ) { return; }
        wp_nonce_field( 'mrc_tracking_' . $order->get_id(), 'mrc_tracking_nonce' );
        echo '<div class="mrc-physical-fields"><h3>' . esc_html__( 'MR Shipping & Tracking', 'mr-commerce' ) . '</h3>';
        woocommerce_wp_text_input( array( 'id' => '_mrc_courier_name', 'label' => __( 'Courier', 'mr-commerce' ), 'value' => $order->get_meta( '_mrc_courier_name' ) ) );
        woocommerce_wp_text_input( array( 'id' => '_mrc_tracking_number', 'label' => __( 'Tracking number', 'mr-commerce' ), 'value' => $order->get_meta( '_mrc_tracking_number' ) ) );
        woocommerce_wp_text_input( array( 'id' => '_mrc_tracking_url', 'label' => __( 'Tracking URL', 'mr-commerce' ), 'value' => $order->get_meta( '_mrc_tracking_url' ) ) );
        echo '</div>';
    }

    public function save_tracking_fields( int $order_id ): void {
        if ( empty( $_POST['mrc_tracking_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrc_tracking_nonce'] ) ), 'mrc_tracking_' . $order_id ) || ! current_user_can( 'edit_shop_order', $order_id ) ) { return; }
        $order = wc_get_order( $order_id );
        if ( ! $order ) { return; }
        $order->update_meta_data( '_mrc_courier_name', sanitize_text_field( wp_unslash( $_POST['_mrc_courier_name'] ?? '' ) ) );
        $order->update_meta_data( '_mrc_tracking_number', sanitize_text_field( wp_unslash( $_POST['_mrc_tracking_number'] ?? '' ) ) );
        $order->update_meta_data( '_mrc_tracking_url', esc_url_raw( wp_unslash( $_POST['_mrc_tracking_url'] ?? '' ) ) );
        $order->save();
    }

    public function render_tracking( $order ): void {
        if ( ! $order instanceof \WC_Order || ! PhysicalOrder::contains_shippable( $order ) || ! mrc_can( 'physical.tracking' ) ) { return; }
        $number = (string) $order->get_meta( '_mrc_tracking_number' );
        if ( '' === $number ) { return; }
        $courier = (string) $order->get_meta( '_mrc_courier_name' );
        $url = (string) $order->get_meta( '_mrc_tracking_url' );
        echo '<section class="woocommerce-order-details mrc-order-tracking"><h2>' . esc_html__( 'Order tracking', 'mr-commerce' ) . '</h2><p>';
        echo esc_html( trim( $courier . ' ' . $number ) );
        if ( $url ) { echo ' — <a rel="noopener noreferrer" target="_blank" href="' . esc_url( $url ) . '">' . esc_html__( 'Track shipment', 'mr-commerce' ) . '</a>'; }
        echo '</p></section>';
    }
}
