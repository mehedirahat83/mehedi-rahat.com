<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

interface CourierAdapterInterface {
    public function id(): string;
    public function label(): string;
    public function create_consignment( \WC_Order $order ): array;
    public function tracking_url( string $consignment_id ): string;
}
