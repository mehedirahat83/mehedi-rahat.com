<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;
use MRBP\Modules\RetentionSuite\CourierIntegrationAdmin;

final class PhysicalCommerceAdmin {
    public function register(): void {
        add_action( 'admin_menu', array( $this, 'menu' ), 30 );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_action( 'admin_post_mrc_apply_physical_preset', array( $this, 'apply_preset' ) );
        add_filter( 'option_page_capability_mrc_physical_group', static fn(): string => 'manage_woocommerce' );
    }

    public function menu(): void {
        add_submenu_page( 'mrbp-dashboard', __( 'MR Commerce', 'mr-commerce' ), __( 'MR Commerce', 'mr-commerce' ), 'manage_woocommerce', 'mrc-physical-commerce', array( $this, 'render' ) );
    }

    public function settings(): void {
        register_setting( 'mrc_physical_group', 'mrc_physical_settings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize' ), 'default' => array() ) );
    }

    public function sanitize( array $input ): array {
        $old = (array) get_option( 'mrc_physical_settings', array() );
        $out = array(
            // Deprecated in 2.8.0. WooCommerce Core is authoritative for gateway availability.
            'cod_enabled' => $old['cod_enabled'] ?? 'yes',
            'cod_fee' => max( 0, (float) ( $input['cod_fee'] ?? 0 ) ),
            'cod_min' => max( 0, (float) ( $input['cod_min'] ?? 0 ) ),
            'cod_max' => max( 0, (float) ( $input['cod_max'] ?? 0 ) ),
            'cod_shipping_methods' => sanitize_textarea_field( $input['cod_shipping_methods'] ?? '' ),
            'risk_window_hours' => $old['risk_window_hours'] ?? 24,
            'risk_threshold' => $old['risk_threshold'] ?? 2,
        );
        if ( ! mrc_can( 'physical.cod_rules' ) ) {
            foreach ( array( 'cod_fee', 'cod_min', 'cod_max', 'cod_shipping_methods' ) as $key ) { $out[ $key ] = $old[ $key ] ?? $out[ $key ]; }
        }
        return $out;
    }

    private function values(): array {
        return wp_parse_args( get_option( 'mrc_physical_settings', array() ), array( 'cod_enabled' => 'yes', 'cod_fee' => 0, 'cod_min' => 0, 'cod_max' => 0, 'cod_shipping_methods' => '', 'risk_window_hours' => 24, 'risk_threshold' => 2 ) );
    }

    public function apply_preset(): void {
        check_admin_referer( 'mrc_apply_physical_preset' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( esc_html__( 'Access denied.', 'mr-commerce' ) ); }
        update_option( 'woocommerce_manage_stock', 'yes' );
        update_option( 'woocommerce_hold_stock_minutes', '60' );
        update_option( 'woocommerce_calc_taxes', 'yes' );
        $modules = (array) get_option( 'mrbp_enabled_modules', array() );
        $modules['physical_commerce'] = true;
        $modules['sequential_orders'] = true;
        update_option( 'mrbp_enabled_modules', $modules, false );
        $settings = $this->values();
        update_option( 'mrc_physical_settings', $settings, false );
        $cod = (array) get_option( 'woocommerce_cod_settings', array() );
        $cod['enabled'] = 'yes';
        update_option( 'woocommerce_cod_settings', $cod, false );
        wp_safe_redirect( add_query_arg( 'preset', 'applied', admin_url( 'admin.php?page=mrc-physical-commerce' ) ) );
        exit;
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $s = $this->values();
        $cod_core = (array) get_option( 'woocommerce_cod_settings', array() );
        $cod_enabled = 'yes' === ( $cod_core['enabled'] ?? 'no' );
        ?>
        <div class="wrap mrc-ops-wrap mrc-ops-physical">
        <?php \MRBP\Admin\OperationsUi::header( __( 'PHYSICAL STORE CONTROL', 'mr-commerce' ), __( 'MR Commerce', 'mr-commerce' ), __( 'Configure fulfilment, COD, risk controls, shipping documents and returns from one connected workspace.', 'mr-commerce' ), 'dashicons-store', array( __( 'Plan', 'mr-commerce' ) => 'pro' === mrc_plan() ? __( 'Pro', 'mr-commerce' ) : __( 'Free', 'mr-commerce' ), __( 'WooCommerce', 'mr-commerce' ) => __( 'Ready', 'mr-commerce' ) ) ); ?>
        <?php if ( isset( $_GET['preset'] ) ) : ?><div class="notice notice-success is-dismissible mrc-preset-notice"><p><strong><?php esc_html_e( 'Physical Store preset applied.', 'mr-commerce' ); ?></strong> <?php esc_html_e( 'Stock management, stock hold, taxes, fulfilment and sequential orders are ready.', 'mr-commerce' ); ?></p></div><?php endif; ?>
        <div class="card"><?php \MRBP\Admin\OperationsUi::classification( 'core' ); ?><h2><?php esc_html_e( 'Physical Store onboarding', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Configure selected WooCommerce Core inventory, tax and COD defaults, then enable MR fulfilment enhancements. Existing products and orders are not changed.', 'mr-commerce' ); ?></p>
        <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrc_apply_physical_preset' ), 'mrc_apply_physical_preset' ) ); ?>"><?php esc_html_e( 'Apply Physical Store Preset', 'mr-commerce' ); ?></a>
        <?php \MRBP\Admin\OperationsUi::guide( 'নতুন physical store-এর প্রয়োজনীয় WooCommerce settings এক ক্লিকে প্রস্তুত করে।', array( 'Preset প্রয়োগের আগে বর্তমান WooCommerce settings দেখে নিন।', 'Apply Physical Store Preset বাটনে ক্লিক করুন।', 'সফল বার্তা দেখার পর COD, shipping ও stock settings যাচাই করুন।' ), 'নতুন দোকানে stock management, tax এবং COD দ্রুত প্রস্তুত করা যাবে।', 'এটি কোনো product বা order পরিবর্তন করে না, তবে WooCommerce-এর কিছু global setting চালু করে।' ); ?></div>
        <?php ( new ShippingAdmin() )->render_embedded(); ?>
        <form method="post" action="options.php"><?php settings_fields( 'mrc_physical_group' ); ?>
        <div class="card"><?php \MRBP\Admin\OperationsUi::classification( 'enhanced' ); ?><h2><?php esc_html_e( 'Conditional cash on delivery', 'mr-commerce' ); ?></h2>
        <div class="mrc-core-status"><span class="dashicons dashicons-<?php echo $cod_enabled ? 'yes-alt' : 'warning'; ?>"></span><div><strong><?php echo esc_html( $cod_enabled ? __( 'WooCommerce COD is enabled', 'mr-commerce' ) : __( 'WooCommerce COD is disabled', 'mr-commerce' ) ); ?></strong><span><?php esc_html_e( 'Gateway availability is controlled by WooCommerce Core.', 'mr-commerce' ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=cod' ) ); ?>"><?php esc_html_e( 'Manage COD in WooCommerce', 'mr-commerce' ); ?></a></span></div></div>
        <?php if ( mrc_can( 'physical.cod_rules' ) ) : ?>
        <table class="form-table"><tr><th><?php esc_html_e( 'COD fee', 'mr-commerce' ); ?></th><td><input type="number" min="0" step="0.01" name="mrc_physical_settings[cod_fee]" value="<?php echo esc_attr( (string) $s['cod_fee'] ); ?>"></td></tr>
        <tr><th><?php esc_html_e( 'Order total range', 'mr-commerce' ); ?></th><td><input type="number" min="0" step="0.01" name="mrc_physical_settings[cod_min]" value="<?php echo esc_attr( (string) $s['cod_min'] ); ?>" placeholder="Minimum"> <input type="number" min="0" step="0.01" name="mrc_physical_settings[cod_max]" value="<?php echo esc_attr( (string) $s['cod_max'] ); ?>" placeholder="Maximum"></td></tr>
        <tr><th><?php esc_html_e( 'Allowed shipping methods', 'mr-commerce' ); ?></th><td><textarea name="mrc_physical_settings[cod_shipping_methods]" rows="3" class="large-text"><?php echo esc_textarea( (string) $s['cod_shipping_methods'] ); ?></textarea><p class="description"><?php esc_html_e( 'Comma/newline-separated method IDs. Leave empty for all.', 'mr-commerce' ); ?></p></td></tr></table>
        <?php else : ProFeature::render( 'physical.cod_rules', __( 'Conditional COD & Fee', 'mr-commerce' ), __( 'Set a COD fee and restrict COD by order value or shipping method.', 'mr-commerce' ) ); endif; ?>
        <?php \MRBP\Admin\OperationsUi::guide( 'WooCommerce COD-এর উপর অতিরিক্ত fee এবং order/shipping শর্ত প্রয়োগ করে।', array( 'WooCommerce-এ COD gateway চালু আছে কি না নিশ্চিত করুন।', 'প্রয়োজনে COD fee ও order total range দিন।', 'নির্দিষ্ট shipping method ছাড়া COD বন্ধ করতে method ID যোগ করুন।' ), '১০০ টাকার COD fee দিয়ে শুধু নির্দিষ্ট courier method-এ COD দেখানো যায়।', 'WooCommerce COD gateway বন্ধ থাকলে এই নিয়ম COD চালু করবে না।' ); ?></div>
        <div class="card"><?php \MRBP\Admin\OperationsUi::classification( 'exclusive' ); ?><h2><?php esc_html_e( 'MR Fraud Checker', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Bangladesh-focused order risk intelligence. Existing duplicate-window settings are used automatically as migration defaults.', 'mr-commerce' ); ?></p><p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=mrc-fraud-checker' ) ); ?>"><?php esc_html_e( 'Open Fraud Checker', 'mr-commerce' ); ?></a></p><?php \MRBP\Admin\OperationsUi::guide( 'নতুন order-এর ঝুঁকি যাচাই করার জন্য আলাদা Fraud Checker workspace খুলে দেয়।', array( 'Open Fraud Checker ক্লিক করুন।', 'Risk threshold ও detection rules প্রয়োজনমতো ঠিক করুন।', 'High বা Critical order fulfilment-এর আগে যাচাই করুন।' ), 'একই ফোন দিয়ে অল্প সময়ে একাধিক COD order এলে risk score বাড়তে পারে।', 'Risk score নিশ্চিত fraud প্রমাণ করে না; manual verification জরুরি।' ); ?></div>
        <?php if ( ! mrc_can( 'physical.shipping_documents' ) ) { ProFeature::render( 'physical.shipping_documents', __( 'Packing Slips & Shipping Labels', 'mr-commerce' ), __( 'Print fulfilment documents directly from WooCommerce orders.', 'mr-commerce' ) ); } ?>
        <?php if ( ! mrc_can( 'physical.returns' ) ) { ProFeature::render( 'physical.returns', __( 'Returns & Restocking', 'mr-commerce' ), __( 'Record return reasons and safely restore stock once.', 'mr-commerce' ) ); } ?>
        <?php submit_button(); ?></form>
        <?php ( new CourierIntegrationAdmin() )->render_embedded(); ?>
        </div>
        <?php
    }
}
