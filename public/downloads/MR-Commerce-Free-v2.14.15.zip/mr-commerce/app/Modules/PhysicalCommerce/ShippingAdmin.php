<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

use MRBP\Admin\ProFeature;

final class ShippingAdmin {
    public function register(): void {
        add_action( 'admin_menu', array( $this, 'menu' ), 34 );
        add_action( 'admin_init', array( $this, 'settings' ) );
        add_filter( 'option_page_capability_mrc_shipping_group', static fn(): string => 'manage_woocommerce' );
    }

    public function menu(): void {
        add_submenu_page( null, __( 'Shipping Operations', 'mr-commerce' ), __( 'Shipping Operations', 'mr-commerce' ), 'manage_woocommerce', 'mrc-shipping-operations', array( $this, 'render' ) );
    }

    public function settings(): void {
        register_setting( 'mrc_shipping_group', 'mrc_shipping_settings', array( 'type'=>'array', 'sanitize_callback'=>array( $this, 'sanitize' ), 'default'=>array() ) );
    }

    public function sanitize( array $input ): array {
        $old = (array) get_option( 'mrc_shipping_settings', array() );
        $out = array(
            'rules_json'=>(string) ( $old['rules_json'] ?? '[]' ),
            'slots'=>(string) ( $old['slots'] ?? '' ),
            'slots_json'=>(string) ( $old['slots_json'] ?? '[]' ),
        );
        if ( mrc_can( 'shipping.area_rules' ) ) {
            $rules = json_decode( wp_unslash( (string) ( $input['rules_json'] ?? '[]' ) ), true );
            if ( is_array( $rules ) ) { $out['rules_json'] = wp_json_encode( $this->clean_rules( $rules ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ); }
        }
        if ( mrc_can( 'shipping.delivery_slots' ) ) {
            $slots = json_decode( wp_unslash( (string) ( $input['slots_json'] ?? '[]' ) ), true );
            if ( is_array( $slots ) ) { $out['slots_json'] = wp_json_encode( $this->clean_slots( $slots ), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ); }
        }
        return $out;
    }

    private function clean_rules( array $rules ): array {
        $clean = array();
        foreach ( array_slice( $rules, 0, 100 ) as $rule ) {
            if ( ! is_array( $rule ) ) { continue; }
            $row = array(
                'enabled'=>! empty( $rule['enabled'] ), 'district'=>sanitize_title( $rule['district'] ?? '' ),
                'area'=>sanitize_text_field( $rule['area'] ?? '' ), 'amount'=>max( 0, (float) ( $rule['amount'] ?? 0 ) ),
                'min_weight'=>max( 0, (float) ( $rule['min_weight'] ?? 0 ) ), 'min_quantity'=>max( 0, absint( $rule['min_quantity'] ?? 0 ) ),
                'min_value'=>max( 0, (float) ( $rule['min_value'] ?? 0 ) ), 'shipping_class'=>sanitize_title( $rule['shipping_class'] ?? '' ),
                'rate_id'=>sanitize_text_field( $rule['rate_id'] ?? '' ), 'disable'=>'disable' === ( $rule['action'] ?? '' ) || ! empty( $rule['disable'] ),
            );
            if ( ! isset( BangladeshLocations::districts()[ $row['district'] ] ) ) { $row['district'] = ''; }
            $clean[] = $row;
        }
        return $clean;
    }

    private function clean_slots( array $slots ): array {
        $clean = array(); $allowed_days = array( '0','1','2','3','4','5','6' );
        foreach ( array_slice( $slots, 0, 50 ) as $index=>$slot ) {
            if ( ! is_array( $slot ) ) { continue; }
            $days = array_values( array_intersect( $allowed_days, array_map( 'strval', (array) ( $slot['days'] ?? $allowed_days ) ) ) );
            $start = preg_match( '/^\d{2}:\d{2}$/', (string) ( $slot['start'] ?? '' ) ) ? $slot['start'] : '09:00';
            $end = preg_match( '/^\d{2}:\d{2}$/', (string) ( $slot['end'] ?? '' ) ) ? $slot['end'] : '12:00';
            $clean[] = array(
                'id'=>sanitize_key( $slot['id'] ?? 'slot-' . ( $index + 1 ) ), 'enabled'=>! empty( $slot['enabled'] ),
                'label'=>sanitize_text_field( $slot['label'] ?? '' ), 'days'=>$days ?: $allowed_days, 'start'=>$start, 'end'=>$end,
                'capacity'=>max( 0, absint( $slot['capacity'] ?? 0 ) ), 'cutoff_hours'=>max( 0, absint( $slot['cutoff_hours'] ?? 0 ) ),
            );
        }
        return $clean;
    }

    private function legacy_slots( string $raw ): array {
        $slots = array(); $lines = array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', $raw ) ?: array() ) );
        foreach ( $lines as $index=>$line ) {
            $slots[] = array( 'id'=>'legacy-' . ( $index + 1 ), 'enabled'=>true, 'label'=>$line, 'days'=>array( '0','1','2','3','4','5','6' ), 'start'=>'09:00', 'end'=>'12:00', 'capacity'=>0, 'cutoff_hours'=>0 );
        }
        return $slots;
    }

    public function render( bool $embedded = false ): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $s = wp_parse_args( get_option( 'mrc_shipping_settings', array() ), array( 'rules_json'=>'[]', 'slots'=>'9:00 AM–12:00 PM' . "\n" . '12:00 PM–3:00 PM' . "\n" . '3:00 PM–6:00 PM', 'slots_json'=>'[]' ) );
        $rules = json_decode( (string) $s['rules_json'], true ); $rules = is_array( $rules ) ? $rules : array();
        $slots = json_decode( (string) $s['slots_json'], true ); $slots = is_array( $slots ) && $slots ? $slots : $this->legacy_slots( (string) $s['slots'] );
        $classes = function_exists( 'WC' ) && WC()->shipping() ? WC()->shipping()->get_shipping_classes() : array();
        ?>
        <?php if ( $embedded ) : ?><section class="mrc-merged-workspace mrc-merged-workspace--shipping mrc-ops-shipping"><div class="mrc-merged-workspace__header"><span class="dashicons dashicons-location-alt"></span><div><span class="mrc-ops-eyebrow"><?php esc_html_e( 'DELIVERY OPERATIONS', 'mr-commerce' ); ?></span><h2><?php esc_html_e( 'Shipping Operations', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Build district-based shipping rules and professional delivery schedules without editing code.', 'mr-commerce' ); ?></p></div></div><?php else : ?><div class="wrap mrc-ops-wrap mrc-ops-shipping">
            <?php \MRBP\Admin\OperationsUi::header( __( 'DELIVERY OPERATIONS', 'mr-commerce' ), __( 'Shipping Operations', 'mr-commerce' ), __( 'Build district-based shipping rules and professional delivery schedules without editing code.', 'mr-commerce' ), 'dashicons-location-alt', array( __( 'Districts', 'mr-commerce' )=>'64', __( 'Builder', 'mr-commerce' )=>__( 'Visual', 'mr-commerce' ) ) ); ?><?php endif; ?>
            <form method="post" action="options.php"><?php settings_fields( 'mrc_shipping_group' ); ?>
                <?php if ( mrc_can( 'shipping.area_rules' ) ) : ?>
                <div class="card mrc-builder-card"><?php \MRBP\Admin\OperationsUi::classification( 'enhanced' ); ?><div class="mrc-builder-head"><div><h2><?php esc_html_e( 'District shipping rules', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Rules run from top to bottom. Drag to prioritize; the first matching rule wins.', 'mr-commerce' ); ?></p></div><button type="button" class="button button-primary" data-mrc-add-rule><?php esc_html_e( 'Add shipping rule', 'mr-commerce' ); ?></button></div>
                    <input type="hidden" name="mrc_shipping_settings[rules_json]" id="mrc-rules-json" value="<?php echo esc_attr( wp_json_encode( $rules ) ); ?>">
                    <div id="mrc-shipping-rules" class="mrc-builder-list"></div><div class="mrc-builder-empty"><?php esc_html_e( 'No rules yet. Add your first district or conditional shipping rule.', 'mr-commerce' ); ?></div>
                    <?php \MRBP\Admin\OperationsUi::guide( 'জেলা, area, ওজন, quantity বা cart value অনুযায়ী shipping charge নির্ধারণ করে।', array( 'Add shipping rule ক্লিক করুন।', 'District এবং প্রয়োজনীয় condition নির্বাচন করুন।', 'Shipping amount দিয়ে rule-এর priority ঠিক করুন।' ), 'Dhaka-তে ৮০ টাকা এবং অন্য জেলায় ১২০ টাকা shipping charge রাখা যায়।', 'Rule উপর থেকে নিচে পরীক্ষা হয়; প্রথম matching rule কার্যকর হবে।' ); ?>
                </div>
                <?php else : ProFeature::render( 'shipping.area_rules', __( 'Visual Shipping Rule Builder', 'mr-commerce' ), __( 'Build district, weight, quantity, class and cart-value rules without JSON.', 'mr-commerce' ) ); endif; ?>

                <?php if ( mrc_can( 'shipping.delivery_slots' ) ) : ?>
                <div class="card mrc-builder-card"><?php \MRBP\Admin\OperationsUi::classification( 'exclusive' ); ?><div class="mrc-builder-head"><div><h2><?php esc_html_e( 'Delivery schedule', 'mr-commerce' ); ?></h2><p><?php esc_html_e( 'Create customer-friendly time windows by weekday, capacity and order cutoff.', 'mr-commerce' ); ?></p></div><button type="button" class="button button-primary" data-mrc-add-slot><?php esc_html_e( 'Add time slot', 'mr-commerce' ); ?></button></div>
                    <input type="hidden" name="mrc_shipping_settings[slots_json]" id="mrc-slots-json" value="<?php echo esc_attr( wp_json_encode( $slots ) ); ?>">
                    <div id="mrc-delivery-slots" class="mrc-builder-list"></div><div class="mrc-slots-empty"><?php esc_html_e( 'No delivery slots yet. Add a time window customers can select.', 'mr-commerce' ); ?></div>
                    <?php \MRBP\Admin\OperationsUi::guide( 'Customer checkout-এর সময় পছন্দের delivery date ও সময় নির্বাচন করতে পারে।', array( 'Add time slot ক্লিক করে label ও সময় দিন।', 'যে weekday-গুলোতে slot চালু থাকবে সেগুলো নির্বাচন করুন।', 'প্রয়োজনে capacity ও order cutoff নির্ধারণ করুন।' ), '“সকাল ৯টা–দুপুর ১২টা” slot শুধু শনিবার–বৃহস্পতিবার দেখানো যায়।', 'Capacity পূর্ণ বা cutoff পার হলে customer-কে অন্য slot নিতে হবে।' ); ?>
                </div>
                <?php else : ProFeature::render( 'shipping.delivery_slots', __( 'Professional Delivery Schedule', 'mr-commerce' ), __( 'Configure weekday schedules, time windows, capacity and cutoff rules.', 'mr-commerce' ) ); endif; ?>
                <?php if ( ! mrc_can( 'shipping.courier_adapters' ) ) { ProFeature::render( 'shipping.courier_adapters', __( 'Courier Adapter Architecture', 'mr-commerce' ), __( 'Connect courier providers through a stable adapter contract while keeping manual assignment available.', 'mr-commerce' ) ); } ?>
                <?php submit_button(); ?>
            </form>
        <?php if ( $embedded ) : ?></section><?php else : ?></div><?php endif; ?>
        <script type="application/json" id="mrc-shipping-builder-data"><?php echo wp_json_encode( array( 'districts'=>BangladeshLocations::districts(), 'classes'=>array_values( array_map( static fn( $class ): array => array( 'slug'=>$class->slug, 'name'=>$class->name ), $classes ) ) ) ); ?></script>
        <?php
    }

    public function render_embedded(): void {
        $this->render( true );
    }
}
