<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class ShippingManager {
    public function register(): void {
        add_filter( 'woocommerce_checkout_fields', array( $this, 'fields' ) );
        add_action( 'woocommerce_checkout_create_order', array( $this, 'save' ), 20, 2 );
        add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'admin_address' ), 5 );
        add_filter( 'woocommerce_package_rates', array( $this, 'rates' ), 30, 2 );
        add_action( 'woocommerce_after_order_notes', array( $this, 'slot_fields' ) );
        add_action( 'woocommerce_checkout_process', array( $this, 'validate_slot' ) );
        add_action( 'woocommerce_order_details_after_order_table', array( $this, 'show_slot' ), 5 );
        add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
    }

    public function fields( array $fields ): array {
        if ( ! mrc_can( 'shipping.address_fields' ) ) { return $fields; }
        foreach ( array( 'billing', 'shipping' ) as $group ) {
            /*
             * WooCommerce already provides the country-aware state field, which
             * is labelled District for Bangladesh. Reuse it as the canonical
             * district value and add only the missing Area / Thana field.
             */
            $fields[ $group ][ $group . '_area' ] = array(
                'label'    => __( 'Area / Thana', 'mr-commerce' ),
                'required' => true,
                'class'    => array( 'form-row-wide' ),
                'priority' => 72,
            );
        }
        return $fields;
    }

    public function save( $order, array $data ): void {
        foreach ( array( 'billing_area', 'shipping_area' ) as $key ) {
            if ( isset( $data[ $key ] ) ) { $order->update_meta_data( '_' . $key, sanitize_text_field( $data[ $key ] ) ); }
        }
        if ( mrc_can( 'shipping.delivery_slots' ) ) {
            $order->update_meta_data( '_mrc_delivery_date', sanitize_text_field( wp_unslash( $_POST['mrc_delivery_date'] ?? '' ) ) );
            $slot_id = sanitize_key( wp_unslash( $_POST['mrc_delivery_slot'] ?? '' ) );
            $slot = $this->find_slot( $slot_id );
            $order->update_meta_data( '_mrc_delivery_slot_id', $slot_id );
            $order->update_meta_data( '_mrc_delivery_slot', $slot ? $this->slot_label( $slot ) : '' );
        }
    }

    public function admin_address( $order ): void {
        if ( ! $order instanceof \WC_Order ) { return; }
        $district = $order->get_shipping_state()
            ?: $order->get_billing_state()
            ?: $order->get_meta( '_shipping_district' )
            ?: $order->get_meta( '_billing_district' );
        $area = $order->get_meta( '_shipping_area' ) ?: $order->get_meta( '_billing_area' );
        if ( $district || $area ) { echo '<p><strong>' . esc_html__( 'District / Area:', 'mr-commerce' ) . '</strong><br>' . esc_html( trim( $district . ' / ' . $area, ' /' ) ) . '</p>'; }
    }

    public function rates( array $rates, array $package ): array {
        if ( ! mrc_can( 'shipping.area_rules' ) ) { return $rates; }
        $settings = (array) get_option( 'mrc_shipping_settings', array() );
        $rules = json_decode( (string) ( $settings['rules_json'] ?? '[]' ), true );
        if ( ! is_array( $rules ) ) { return $rates; }
        $destination = (array) ( $package['destination'] ?? array() );
        $posted = array();
        if ( isset( $_POST['post_data'] ) ) { parse_str( wp_unslash( $_POST['post_data'] ), $posted ); }
        $area = strtolower( sanitize_text_field( $posted['shipping_area'] ?? $posted['billing_area'] ?? '' ) );
        $district = sanitize_title(
            $posted['shipping_state']
            ?? $posted['billing_state']
            ?? $destination['state']
            ?? $posted['shipping_district']
            ?? $posted['billing_district']
            ?? ''
        );
        $weight = (float) WC()->cart->get_cart_contents_weight();
        $quantity = (int) WC()->cart->get_cart_contents_count();
        $value = (float) WC()->cart->get_subtotal();
        foreach ( $rules as $rule ) {
            if ( ! is_array( $rule ) || ( ! array_key_exists( 'amount', $rule ) && empty( $rule['disable'] ) ) ) { continue; }
            if ( array_key_exists( 'enabled', $rule ) && empty( $rule['enabled'] ) ) { continue; }
            if ( ! empty( $rule['district'] ) && sanitize_title( (string) $rule['district'] ) !== $district ) { continue; }
            if ( ! empty( $rule['area'] ) && ! str_contains( $area, strtolower( (string) $rule['area'] ) ) ) { continue; }
            if ( isset( $rule['min_weight'] ) && $weight < (float) $rule['min_weight'] ) { continue; }
            if ( isset( $rule['min_quantity'] ) && $quantity < (int) $rule['min_quantity'] ) { continue; }
            if ( isset( $rule['min_value'] ) && $value < (float) $rule['min_value'] ) { continue; }
            if ( ! empty( $rule['shipping_class'] ) ) {
                $classes = array();
                foreach ( $package['contents'] ?? array() as $item ) { if ( isset( $item['data'] ) && $item['data'] instanceof \WC_Product ) { $classes[] = $item['data']->get_shipping_class(); } }
                if ( ! in_array( sanitize_title( (string) $rule['shipping_class'] ), $classes, true ) ) { continue; }
            }
            $applied = false;
            foreach ( $rates as $rate_id => $rate ) {
                if ( ! empty( $rule['rate_id'] ) && (string) $rule['rate_id'] !== (string) $rate_id ) { continue; }
                if ( ! empty( $rule['disable'] ) ) { unset( $rates[ $rate_id ] ); } else { $rate->set_cost( max( 0, (float) $rule['amount'] ) ); }
                $applied = true;
            }
            if ( $applied ) { break; }
        }
        return $rates;
    }

    public function slot_fields(): void {
        if ( ! mrc_can( 'shipping.delivery_slots' ) || ! WC()->cart || ! WC()->cart->needs_shipping() ) { return; }
        $slots = array_filter( $this->slots(), static fn( array $slot ): bool => ! empty( $slot['enabled'] ) );
        woocommerce_form_field( 'mrc_delivery_date', array( 'type' => 'date', 'required' => true, 'label' => __( 'Preferred delivery date', 'mr-commerce' ), 'custom_attributes' => array( 'min' => wp_date( 'Y-m-d', strtotime( '+1 day' ) ) ) ) );
        echo '<p class="form-row form-row-wide validate-required" id="mrc_delivery_slot_field"><label for="mrc_delivery_slot">' . esc_html__( 'Delivery time slot', 'mr-commerce' ) . ' <abbr class="required" title="required">*</abbr></label><span class="woocommerce-input-wrapper"><select name="mrc_delivery_slot" id="mrc_delivery_slot"><option value="">' . esc_html__( 'Choose a date first', 'mr-commerce' ) . '</option>';
        foreach ( $slots as $slot ) {
            echo '<option value="' . esc_attr( $slot['id'] ) . '" data-days="' . esc_attr( implode( ',', (array) $slot['days'] ) ) . '">' . esc_html( $this->slot_label( $slot ) ) . '</option>';
        }
        echo '</select></span><small class="mrc-slot-help">' . esc_html__( 'Available windows update automatically for the selected weekday.', 'mr-commerce' ) . '</small></p>';
    }

    public function validate_slot(): void {
        if ( ! mrc_can( 'shipping.delivery_slots' ) || ! WC()->cart || ! WC()->cart->needs_shipping() ) { return; }
        $date = sanitize_text_field( wp_unslash( $_POST['mrc_delivery_date'] ?? '' ) );
        $slot_id = sanitize_key( wp_unslash( $_POST['mrc_delivery_slot'] ?? '' ) );
        $slot = $this->find_slot( $slot_id );
        $timestamp = strtotime( $date . ' 00:00:00' );
        if ( ! $date || ! $slot || ! $timestamp || $timestamp < strtotime( 'tomorrow 00:00:00' ) ) { wc_add_notice( __( 'Please choose a valid future delivery date and time slot.', 'mr-commerce' ), 'error' ); return; }
        if ( ! in_array( (string) wp_date( 'w', $timestamp ), array_map( 'strval', (array) $slot['days'] ), true ) ) { wc_add_notice( __( 'That delivery slot is not available on the selected weekday.', 'mr-commerce' ), 'error' ); return; }
        if ( strtotime( $date . ' ' . $slot['end'] ) <= strtotime( $date . ' ' . $slot['start'] ) ) { wc_add_notice( __( 'That delivery slot has an invalid time range.', 'mr-commerce' ), 'error' ); return; }
        $cutoff = absint( $slot['cutoff_hours'] ?? 0 );
        if ( $cutoff && strtotime( $date . ' ' . $slot['start'] ) - time() < $cutoff * HOUR_IN_SECONDS ) { wc_add_notice( __( 'The order cutoff for that delivery slot has passed.', 'mr-commerce' ), 'error' ); return; }
        $capacity = absint( $slot['capacity'] ?? 0 );
        if ( $capacity ) {
            $booked = wc_get_orders( array( 'limit'=>$capacity, 'return'=>'ids', 'status'=>array_keys( wc_get_order_statuses() ), 'meta_query'=>array( 'relation'=>'AND', array( 'key'=>'_mrc_delivery_date', 'value'=>$date ), array( 'key'=>'_mrc_delivery_slot_id', 'value'=>$slot_id ) ) ) );
            if ( count( $booked ) >= $capacity ) { wc_add_notice( __( 'That delivery slot is fully booked. Please choose another time.', 'mr-commerce' ), 'error' ); }
        }
    }

    public function show_slot( $order ): void {
        if ( ! $order instanceof \WC_Order ) { return; }
        $date = $order->get_meta( '_mrc_delivery_date' ); $slot = $order->get_meta( '_mrc_delivery_slot' );
        if ( $date || $slot ) { echo '<p><strong>' . esc_html__( 'Preferred delivery:', 'mr-commerce' ) . '</strong> ' . esc_html( trim( $date . ' ' . $slot ) ) . '</p>'; }
    }

    public function assets(): void {
        if ( function_exists( 'is_checkout' ) && is_checkout() && ! is_order_received_page() && mrc_can( 'shipping.delivery_slots' ) ) {
            wp_enqueue_script( 'mrc-delivery-slots', MRBP_URL . 'assets/frontend/js/delivery-slots.js', array(), MRBP_VERSION, true );
        }
    }

    private function slots(): array {
        $settings = (array) get_option( 'mrc_shipping_settings', array() );
        $slots = json_decode( (string) ( $settings['slots_json'] ?? '[]' ), true );
        if ( is_array( $slots ) && $slots ) { return $slots; }
        $legacy = array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', (string) ( $settings['slots'] ?? '' ) ) ?: array() ) );
        $out = array();
        foreach ( $legacy as $index=>$label ) { $out[] = array( 'id'=>'legacy-' . ( $index + 1 ), 'enabled'=>true, 'label'=>$label, 'days'=>array( '0','1','2','3','4','5','6' ), 'start'=>'09:00', 'end'=>'12:00', 'capacity'=>0, 'cutoff_hours'=>0 ); }
        return $out;
    }

    private function find_slot( string $id ): ?array {
        foreach ( $this->slots() as $slot ) { if ( ! empty( $slot['enabled'] ) && (string) ( $slot['id'] ?? '' ) === $id ) { return $slot; } }
        return null;
    }

    private function slot_label( array $slot ): string {
        $label = trim( (string) ( $slot['label'] ?? '' ) );
        return $label ?: trim( (string) ( $slot['start'] ?? '' ) . '–' . (string) ( $slot['end'] ?? '' ) );
    }
}
