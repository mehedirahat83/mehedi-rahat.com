<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class ReturnManager {
    public function register(): void {
        add_action( 'woocommerce_order_status_mrc-returned', array( $this, 'record_return' ) );
        add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'fields' ) );
        add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save' ), 30 );
    }

    public function record_return( int $order_id ): void {
        if ( ! mrc_can( 'physical.returns' ) ) { return; }
        $order = wc_get_order( $order_id );
        if ( ! $order || ! PhysicalOrder::contains_shippable( $order ) || $order->get_meta( '_mrc_returned_at' ) ) { return; }
        $order->update_meta_data( '_mrc_returned_at', current_time( 'mysql', true ) );
        $order->add_order_note( __( 'MR Commerce: Return received. Inspect the items before choosing whether WooCommerce should restore stock.', 'mr-commerce' ) );
        $order->save();
    }

    public function fields( $order ): void {
        if ( ! $order instanceof \WC_Order || ! PhysicalOrder::contains_shippable( $order ) || ! mrc_can( 'physical.returns' ) ) { return; }
        wp_nonce_field( 'mrc_return_' . $order->get_id(), 'mrc_return_nonce' );
        echo '<div class="mrc-return-workflow"><p><strong>' . esc_html__( 'MR Return Workflow', 'mr-commerce' ) . '</strong><br><span class="description">' . esc_html__( 'Refunds and stock quantities remain controlled by WooCommerce Core.', 'mr-commerce' ) . '</span></p>';
        woocommerce_wp_select( array( 'id'=>'_mrc_return_reason', 'label'=>__( 'Return reason', 'mr-commerce' ), 'value'=>$order->get_meta( '_mrc_return_reason' ), 'options'=>array( ''=>__( 'Not set', 'mr-commerce' ), 'customer'=>__( 'Customer changed mind', 'mr-commerce' ), 'damaged'=>__( 'Damaged', 'mr-commerce' ), 'wrong_item'=>__( 'Wrong item', 'mr-commerce' ), 'delivery_failed'=>__( 'Delivery failed', 'mr-commerce' ) ) ) );
        woocommerce_wp_select( array( 'id'=>'_mrc_return_condition', 'label'=>__( 'Item condition', 'mr-commerce' ), 'value'=>$order->get_meta( '_mrc_return_condition' ), 'options'=>array( ''=>__( 'Not inspected', 'mr-commerce' ), 'sellable'=>__( 'Sellable — eligible for restock', 'mr-commerce' ), 'damaged'=>__( 'Damaged — do not restock', 'mr-commerce' ), 'partial'=>__( 'Partial/manual adjustment required', 'mr-commerce' ) ) ) );
        if ( 'yes' !== $order->get_meta( '_mrc_restocked' ) ) {
            woocommerce_wp_checkbox( array( 'id'=>'_mrc_restore_stock', 'label'=>__( 'Restore stock', 'mr-commerce' ), 'description'=>__( 'Use WooCommerce Core to restore the order stock once. Select only after inspection.', 'mr-commerce' ) ) );
        } else {
            echo '<p><strong>' . esc_html__( 'Stock status:', 'mr-commerce' ) . '</strong> ' . esc_html__( 'Already restored through WooCommerce Core.', 'mr-commerce' ) . '</p>';
        }
        echo '</div>';
    }

    public function save( int $order_id ): void {
        if ( empty( $_POST['mrc_return_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrc_return_nonce'] ) ), 'mrc_return_' . $order_id ) || ! current_user_can( 'edit_shop_order', $order_id ) || ! mrc_can( 'physical.returns' ) ) { return; }
        $order = wc_get_order( $order_id );
        if ( ! $order ) { return; }
        $reason = sanitize_key( wp_unslash( $_POST['_mrc_return_reason'] ?? '' ) );
        $condition = sanitize_key( wp_unslash( $_POST['_mrc_return_condition'] ?? '' ) );
        $order->update_meta_data( '_mrc_return_reason', in_array( $reason, array( '', 'customer', 'damaged', 'wrong_item', 'delivery_failed' ), true ) ? $reason : '' );
        $order->update_meta_data( '_mrc_return_condition', in_array( $condition, array( '', 'sellable', 'damaged', 'partial' ), true ) ? $condition : '' );
        $order->save();

        if ( ! empty( $_POST['_mrc_restore_stock'] ) && 'sellable' === $condition && 'yes' !== $order->get_meta( '_mrc_restocked' ) ) {
            $stock_reduced = wc_string_to_bool( $order->get_data_store()->get_stock_reduced( $order_id ) );
            if ( $stock_reduced ) {
                wc_maybe_increase_stock_levels( $order_id );
                $order = wc_get_order( $order_id );
                $order->update_meta_data( '_mrc_restocked', 'yes' );
                $order->add_order_note( __( 'MR Commerce: Inspected return stock restored using WooCommerce Core.', 'mr-commerce' ) );
                $order->save();
            }
        }
    }
}
