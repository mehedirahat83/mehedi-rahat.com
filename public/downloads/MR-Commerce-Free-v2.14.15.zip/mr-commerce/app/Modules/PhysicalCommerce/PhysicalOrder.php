<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class PhysicalOrder {
    public static function contains_shippable( \WC_Order $order ): bool {
        foreach ( $order->get_items( 'line_item' ) as $item ) {
            $product = $item->get_product();
            if ( $product && ! $product->is_virtual() ) {
                return true;
            }
        }
        return false;
    }
}
