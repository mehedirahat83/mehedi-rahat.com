<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class BangladeshLocations {
    public static function districts(): array {
        return array(
            'bagerhat'=>'Bagerhat','bandarban'=>'Bandarban','barguna'=>'Barguna','barishal'=>'Barishal','bhola'=>'Bhola','bogura'=>'Bogura',
            'brahmanbaria'=>'Brahmanbaria','chandpur'=>'Chandpur','chapainawabganj'=>'Chapainawabganj','chattogram'=>'Chattogram','chuadanga'=>'Chuadanga',
            'cox-s-bazar'=>"Cox's Bazar",'cumilla'=>'Cumilla','dhaka'=>'Dhaka','dinajpur'=>'Dinajpur','faridpur'=>'Faridpur','feni'=>'Feni',
            'gaibandha'=>'Gaibandha','gazipur'=>'Gazipur','gopalganj'=>'Gopalganj','habiganj'=>'Habiganj','jamalpur'=>'Jamalpur','jashore'=>'Jashore',
            'jhalokati'=>'Jhalokati','jhenaidah'=>'Jhenaidah','joypurhat'=>'Joypurhat','khagrachhari'=>'Khagrachhari','khulna'=>'Khulna',
            'kishoreganj'=>'Kishoreganj','kurigram'=>'Kurigram','kushtia'=>'Kushtia','lakshmipur'=>'Lakshmipur','lalmonirhat'=>'Lalmonirhat',
            'madaripur'=>'Madaripur','magura'=>'Magura','manikganj'=>'Manikganj','meherpur'=>'Meherpur','moulvibazar'=>'Moulvibazar',
            'munshiganj'=>'Munshiganj','mymensingh'=>'Mymensingh','naogaon'=>'Naogaon','narail'=>'Narail','narayanganj'=>'Narayanganj',
            'narsingdi'=>'Narsingdi','natore'=>'Natore','netrokona'=>'Netrokona','nilphamari'=>'Nilphamari','noakhali'=>'Noakhali',
            'pabna'=>'Pabna','panchagarh'=>'Panchagarh','patuakhali'=>'Patuakhali','pirojpur'=>'Pirojpur','rajbari'=>'Rajbari','rajshahi'=>'Rajshahi',
            'rangamati'=>'Rangamati','rangpur'=>'Rangpur','satkhira'=>'Satkhira','shariatpur'=>'Shariatpur','sherpur'=>'Sherpur',
            'sirajganj'=>'Sirajganj','sunamganj'=>'Sunamganj','sylhet'=>'Sylhet','tangail'=>'Tangail','thakurgaon'=>'Thakurgaon',
        );
    }
}
