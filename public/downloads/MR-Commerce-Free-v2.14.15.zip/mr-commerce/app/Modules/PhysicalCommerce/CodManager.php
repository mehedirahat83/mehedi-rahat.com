<?php

namespace MRBP\Modules\PhysicalCommerce;

defined( 'ABSPATH' ) || exit;

final class CodManager {
    public function register(): void {
        add_filter( 'woocommerce_available_payment_gateways', array( $this, 'conditional_cod' ) );
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'add_fee' ) );
    }

    private function settings(): array {
        return wp_parse_args( get_option( 'mrc_physical_settings', array() ), array(
            'cod_enabled' => 'yes', 'cod_fee' => 0, 'cod_min' => 0, 'cod_max' => 0,
            'cod_shipping_methods' => '', 'risk_window_hours' => 24, 'risk_threshold' => 2,
        ) );
    }

    public function conditional_cod( array $gateways ): array {
        if ( ! isset( $gateways['cod'] ) ) { return $gateways; }
        $settings = $this->settings();
        if ( ! mrc_can( 'physical.cod_rules' ) || ! WC()->cart ) { return $gateways; }
        $has_physical = false;
        foreach ( WC()->cart->get_cart() as $item ) {
            if ( isset( $item['data'] ) && $item['data'] instanceof \WC_Product && ! $item['data']->is_virtual() ) { $has_physical = true; break; }
        }
        if ( ! $has_physical ) { unset( $gateways['cod'] ); return $gateways; }
        $total = (float) WC()->cart->get_total( 'edit' );
        if ( (float) $settings['cod_min'] > 0 && $total < (float) $settings['cod_min'] ) { unset( $gateways['cod'] ); }
        if ( (float) $settings['cod_max'] > 0 && $total > (float) $settings['cod_max'] ) { unset( $gateways['cod'] ); }
        $allowed = array_filter( array_map( 'sanitize_text_field', preg_split( '/[\r\n,]+/', (string) $settings['cod_shipping_methods'] ) ) );
        if ( $allowed && WC()->session ) {
            $chosen = (array) WC()->session->get( 'chosen_shipping_methods', array() );
            $matched = false;
            foreach ( $chosen as $method ) {
                $base = explode( ':', (string) $method )[0];
                if ( in_array( $method, $allowed, true ) || in_array( $base, $allowed, true ) ) { $matched = true; break; }
            }
            if ( ! $matched ) { unset( $gateways['cod'] ); }
        }
        return $gateways;
    }

    public function add_fee( $cart ): void {
        if ( ! mrc_can( 'physical.cod_rules' ) || is_admin() && ! wp_doing_ajax() || ! WC()->session ) { return; }
        if ( 'cod' !== WC()->session->get( 'chosen_payment_method' ) ) { return; }
        $fee = (float) $this->settings()['cod_fee'];
        if ( $fee > 0 ) { $cart->add_fee( __( 'Cash on delivery fee', 'mr-commerce' ), $fee, false ); }
    }
}
