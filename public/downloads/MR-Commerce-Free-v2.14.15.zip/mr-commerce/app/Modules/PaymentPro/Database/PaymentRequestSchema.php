<?php

namespace MRBP\Modules\PaymentPro\Database;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class PaymentRequestSchema {

    public static function table_name(): string {
        global $wpdb;

        return $wpdb->prefix . 'mrbp_payment_requests';
    }

    public static function sql(): string {
        global $wpdb;

        $table   = self::table_name();
        $charset = $wpdb->get_charset_collate();

        return "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            gateway varchar(50) NOT NULL DEFAULT '',
            sender_phone varchar(30) NOT NULL DEFAULT '',
            transaction_id varchar(191) NOT NULL DEFAULT '',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'BDT',
            status varchar(40) NOT NULL DEFAULT 'pending',
            customer_note text NULL,
            admin_note text NULL,
            submitted_at datetime NULL,
            reviewed_at datetime NULL,
            reviewed_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY transaction_id (transaction_id),
            KEY order_id (order_id),
            KEY user_id (user_id),
            KEY gateway (gateway),
            KEY status (status),
            KEY submitted_at (submitted_at)
        ) {$charset};";
    }
}
