<?php

namespace MRBP\Modules\PaymentPro\Database;

use MRBP\Core\Database\MigrationManager;

final class Migrations {

    public const VERSION = '1.0.0';

    public static function register( MigrationManager $manager ): void {
        $manager->register(
            'payment_pro',
            self::VERSION,
            array(
                '1.0.0' => static function (): void {
                    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
                    dbDelta( Schema::sql() );
                },
                '1.1.0' => static function (): void {
                    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
                    dbDelta( PaymentRequestSchema::sql() );
                },
            )
        );

        $manager->migrate( 'payment_pro' );
    }
}
