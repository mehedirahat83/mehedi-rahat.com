<?php

namespace MRBP\Modules\PaymentPro\Database;

final class Installer {

    public const DB_VERSION = '0.1.0';

    public function maybe_install(): void {
        if ( self::DB_VERSION === get_option( 'mrbp_payment_db_version' ) ) {
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( Schema::sql() );
        update_option( 'mrbp_payment_db_version', self::DB_VERSION, false );
    }
}
