<?php

namespace MRBP\Modules\PaymentPro\Database;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Schema {

    public static function table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'mrbp_transactions';
    }

    public static function sql(): string {
        global $wpdb;
        $table = self::table_name();
        $charset = $wpdb->get_charset_collate();

        return "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            gateway varchar(50) NOT NULL,
            transaction_id varchar(191) NOT NULL DEFAULT '',
            payment_id varchar(191) NOT NULL DEFAULT '',
            status varchar(40) NOT NULL DEFAULT 'pending',
            amount decimal(18,2) NOT NULL DEFAULT 0.00,
            currency varchar(10) NOT NULL DEFAULT 'BDT',
            response_code varchar(100) NOT NULL DEFAULT '',
            response_message text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY gateway (gateway),
            KEY transaction_id (transaction_id),
            KEY payment_id (payment_id),
            KEY status (status)
        ) {$charset};";
    }
}
