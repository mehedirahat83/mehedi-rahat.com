<?php

namespace MRBP\Modules\PaymentPro\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\DynamicGatewayManager;
use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;
use MRBP\Admin\ProFeature;

final class GatewaysPage {

    private ManualGatewaySettings $settings;
    private DynamicGatewayManager $dynamic;

    public function __construct( ?ManualGatewaySettings $settings = null, ?DynamicGatewayManager $dynamic = null ) {
        $this->settings = $settings ?? new ManualGatewaySettings();
        $this->dynamic  = $dynamic ?? new DynamicGatewayManager();
    }

    public function render(): string {
        $settings = $this->settings->all();
        $option   = $this->settings->option_name();
        $registry = $this->settings->registry();
        $groups   = $registry->grouped( $settings['gateways'] );
        $editing  = isset( $_GET['edit_gateway'] ) ? sanitize_key( wp_unslash( $_GET['edit_gateway'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $edit_def = '' !== $editing ? $this->dynamic->get( $editing ) : array();

        ob_start();
        ?>
        <div class="mrbp-payment-section-heading">
            <div>
                <span class="mrbp-payment-section-kicker"><?php esc_html_e( 'Dynamic Gateway Manager', 'mr-commerce' ); ?></span>
                <h2><?php esc_html_e( 'Manual Payment Gateways', 'mr-commerce' ); ?></h2>
                <p><?php esc_html_e( 'Add and edit mobile banking or bank transfer methods, then enable, search, filter and sort them without changing plugin code.', 'mr-commerce' ); ?></p>
            </div>
        </div>

        <?php $this->render_notice(); ?>

        <div class="mrbp-gateway-manager-toolbar" data-mrbp-gateway-toolbar>
            <div class="mrbp-gateway-manager-search">
                <span class="dashicons dashicons-search mrbp-gateway-search-icon" aria-hidden="true"></span>
                <input type="search" placeholder="<?php esc_attr_e( 'Search by name, account, type or instruction...', 'mr-commerce' ); ?>" aria-label="<?php esc_attr_e( 'Search payment methods', 'mr-commerce' ); ?>" autocomplete="off" data-mrbp-gateway-search>
                <button type="button" class="mrbp-gateway-search-clear" aria-label="<?php esc_attr_e( 'Clear search', 'mr-commerce' ); ?>" title="<?php esc_attr_e( 'Clear search', 'mr-commerce' ); ?>" data-mrbp-gateway-search-clear hidden><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="mrbp-gateway-manager-filters" role="group" aria-label="<?php esc_attr_e( 'Filter payment methods', 'mr-commerce' ); ?>">
                <button type="button" class="button is-active" data-mrbp-gateway-filter="all"><?php esc_html_e( 'All', 'mr-commerce' ); ?> <span data-filter-count="all"></span></button>
                <button type="button" class="button" data-mrbp-gateway-filter="mobile"><?php esc_html_e( 'Mobile', 'mr-commerce' ); ?> <span data-filter-count="mobile"></span></button>
                <button type="button" class="button" data-mrbp-gateway-filter="bank"><?php esc_html_e( 'Bank', 'mr-commerce' ); ?> <span data-filter-count="bank"></span></button>
                <button type="button" class="button" data-mrbp-gateway-filter="disabled"><?php esc_html_e( 'Disabled', 'mr-commerce' ); ?> <span data-filter-count="disabled"></span></button>
            </div>
            <div class="mrbp-gateway-manager-results" aria-live="polite" data-mrbp-gateway-results></div>
        </div>

        <div class="mrbp-ui-notice mrbp-ui-notice--warning mrbp-gateway-unsaved-notice" data-mrbp-gateway-unsaved hidden>
            <span class="dashicons dashicons-warning" aria-hidden="true"></span>
            <p><?php esc_html_e( 'You have unsaved gateway changes. Save Payment Methods before leaving this page.', 'mr-commerce' ); ?></p>
        </div>

        <?php if ( ProFeature::allowed( 'payment.unlimited_gateways' ) ) : ?>
        <section class="mrbp-dynamic-gateway-manager">
            <div class="mrbp-dynamic-gateway-manager__header">
                <div>
                    <span class="mrbp-payment-section-kicker"><?php echo esc_html( empty( $edit_def ) ? __( 'Add gateway', 'mr-commerce' ) : __( 'Edit gateway', 'mr-commerce' ) ); ?></span>
                    <h3><?php echo esc_html( empty( $edit_def ) ? __( 'Create a New Payment Method', 'mr-commerce' ) : sprintf( __( 'Edit %s', 'mr-commerce' ), (string) ( $edit_def['label'] ?? '' ) ) ); ?></h3>
                    <p><?php esc_html_e( 'The saved method will automatically appear in checkout, payment popup, verification, reports and customer history.', 'mr-commerce' ); ?></p>
                </div>
                <?php if ( ! empty( $edit_def ) ) : ?>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=mrbp-payment-center-gateways' ) ); ?>"><?php esc_html_e( 'Cancel Edit', 'mr-commerce' ); ?></a>
                <?php endif; ?>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mrbp-dynamic-gateway-form">
                <input type="hidden" name="action" value="mrbp_save_dynamic_gateway">
                <input type="hidden" name="existing_id" value="<?php echo esc_attr( $editing ); ?>">
                <?php wp_nonce_field( 'mrbp_save_dynamic_gateway' ); ?>

                <div class="mrbp-dynamic-gateway-form__grid">
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Gateway Type', 'mr-commerce' ); ?></label>
                        <select name="type">
                            <option value="mobile" <?php selected( (string) ( $edit_def['type'] ?? 'mobile' ), 'mobile' ); ?>><?php esc_html_e( 'Mobile Banking / Wallet', 'mr-commerce' ); ?></option>
                            <option value="bank" <?php selected( (string) ( $edit_def['type'] ?? '' ), 'bank' ); ?>><?php esc_html_e( 'Bank Account', 'mr-commerce' ); ?></option>
                        </select>
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Gateway Name', 'mr-commerce' ); ?></label>
                        <input type="text" name="label" required value="<?php echo esc_attr( (string) ( $edit_def['label'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Example: Dutch-Bangla Bank', 'mr-commerce' ); ?>">
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Gateway Slug', 'mr-commerce' ); ?></label>
                        <input type="text" name="gateway_id" value="<?php echo esc_attr( (string) ( $edit_def['id'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Auto-generated if empty', 'mr-commerce' ); ?>">
                        <small><?php esc_html_e( 'Use lowercase letters, numbers and underscores.', 'mr-commerce' ); ?></small>
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Logo URL', 'mr-commerce' ); ?></label>
                        <input type="url" name="logo_url" value="<?php echo esc_attr( (string) ( $edit_def['logo_url'] ?? '' ) ); ?>" placeholder="https://example.com/logo.png">
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Short Description', 'mr-commerce' ); ?></label>
                        <input type="text" name="description" value="<?php echo esc_attr( (string) ( $edit_def['description'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Manual transfer payment', 'mr-commerce' ); ?>">
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Display Order', 'mr-commerce' ); ?></label>
                        <input type="number" min="1" name="sort_order" value="<?php echo esc_attr( (string) ( $edit_def['sort_order'] ?? 100 ) ); ?>">
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Account Field Label', 'mr-commerce' ); ?></label>
                        <input type="text" name="account_label" value="<?php echo esc_attr( (string) ( $edit_def['account_label'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Account Number / Send Money Number', 'mr-commerce' ); ?>">
                    </div>
                    <div class="mrbp-payment-field">
                        <label><?php esc_html_e( 'Customer Sender Field', 'mr-commerce' ); ?></label>
                        <input type="text" name="sender_label" value="<?php echo esc_attr( (string) ( $edit_def['sender_label'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Sender Account', 'mr-commerce' ); ?>">
                    </div>
                </div>
                <div class="mrbp-payment-field">
                    <label><?php esc_html_e( 'Default Instructions', 'mr-commerce' ); ?></label>
                    <textarea name="instructions" rows="4"><?php echo esc_textarea( (string) ( $edit_def['instructions'] ?? '' ) ); ?></textarea>
                </div>
                <div class="mrbp-dynamic-gateway-form__actions">
                    <button type="submit" class="button button-primary"><?php echo esc_html( empty( $edit_def ) ? __( 'Add Gateway', 'mr-commerce' ) : __( 'Update Gateway', 'mr-commerce' ) ); ?></button>
                </div>
            </form>
        </section>
        <?php else : ?>
            <?php
            ProFeature::render(
                'payment.unlimited_gateways',
                __( 'Dynamic Gateway Manager', 'mr-commerce' ),
                __( 'Create unlimited custom mobile wallet and bank transfer methods in Pro.', 'mr-commerce' ),
                array(
                    __( 'Custom gateway names, fields and instructions', 'mr-commerce' ),
                    __( 'Unlimited enabled checkout methods', 'mr-commerce' ),
                    __( 'Saved custom methods remain preserved in Free mode', 'mr-commerce' ),
                )
            );
            ?>
        <?php endif; ?>

        <form method="post" action="options.php" class="mrbp-payment-gateways-form">
            <?php settings_fields( $this->settings->group_name() ); ?>

            <?php foreach ( $groups as $group_id => $group ) : ?>
                <section class="mrbp-payment-method-group mrbp-payment-method-group--<?php echo esc_attr( sanitize_html_class( $group_id ) ); ?>">
                    <div class="mrbp-payment-method-group__heading">
                        <div>
                            <h3><?php echo esc_html( (string) $group['label'] ); ?></h3>
                            <p><?php echo esc_html( 'bank' === $group_id ? __( 'Customers transfer funds to your bank account and submit the transaction reference for manual verification.', 'mr-commerce' ) : __( 'Customers send money from their mobile banking app and submit the transaction ID for manual verification.', 'mr-commerce' ) ); ?></p>
                        </div>
                        <span class="mrbp-payment-method-group__count"><?php echo esc_html( (string) count( $group['gateways'] ) ); ?></span>
                    </div>

                    <div class="mrbp-payment-gateway-grid" data-mrbp-gateway-sortable>
                        <?php foreach ( $group['gateways'] as $gateway_id => $gateway ) :
                            $definition = $registry->get( (string) $gateway_id );
                            $gateway_type = sanitize_key( (string) ( $gateway['type'] ?? $definition['type'] ?? 'mobile' ) );
                            $is_bank    = 'bank' === $gateway_type;
                            $is_dynamic = ! empty( $definition['dynamic'] );
                            $logo_url   = '' !== (string) ( $gateway['logo_url'] ?? '' ) ? esc_url( (string) $gateway['logo_url'] ) : $registry->logo_url( (string) $gateway_id );
                            $qr_url     = esc_url( (string) ( $gateway['qr_url'] ?? '' ) );
                        ?>
                            <section class="mrbp-payment-gateway-card mrbp-payment-gateway-card--<?php echo esc_attr( sanitize_html_class( (string) $gateway_id ) ); ?>" draggable="true" data-gateway-id="<?php echo esc_attr( (string) $gateway_id ); ?>" data-gateway-type="<?php echo esc_attr( $is_bank ? 'bank' : 'mobile' ); ?>" data-gateway-status="<?php echo esc_attr( ! empty( $gateway['enabled'] ) ? 'enabled' : 'disabled' ); ?>" data-gateway-name="<?php echo esc_attr( strtolower( (string) $gateway['label'] ) ); ?>" data-gateway-search-text="<?php echo esc_attr( strtolower( implode( ' ', array_filter( array( (string) $gateway['label'], (string) ( $gateway['account_name'] ?? '' ), (string) ( $gateway['account_number'] ?? '' ), (string) ( $gateway['branch_name'] ?? '' ), (string) ( $gateway['instructions'] ?? '' ), $is_bank ? 'bank transfer' : 'mobile banking' ) ) ) ) ); ?>">
                                <div class="mrbp-payment-gateway-card__header">
                                    <button type="button" class="mrbp-gateway-drag-handle" aria-label="<?php esc_attr_e( 'Drag to reorder', 'mr-commerce' ); ?>"><span class="dashicons dashicons-move" aria-hidden="true"></span></button>
                                    <div class="mrbp-payment-gateway-card__brand">
                                        <span class="mrbp-payment-gateway-card__logo-wrap">
                                            <?php if ( '' !== $logo_url ) : ?>
                                                <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( (string) $gateway['label'] ); ?>" class="mrbp-payment-gateway-card__logo">
                                            <?php else : ?>
                                                <span class="dashicons <?php echo $is_bank ? 'dashicons-bank' : 'dashicons-smartphone'; ?>" aria-hidden="true"></span>
                                            <?php endif; ?>
                                        </span>
                                        <div>
                                            <strong class="mrbp-payment-gateway-card__name"><?php echo esc_html( (string) $gateway['label'] ); ?></strong>
                                            <small><?php echo esc_html( (string) ( $definition['description'] ?? '' ) ); ?></small>
                                        </div>
                                    </div>
                                    <label class="mrbp-payment-switch mrbp-payment-gateway-card__toggle">
                                        <input type="checkbox" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][enabled]" value="1" <?php checked( ! empty( $gateway['enabled'] ) ); ?>>
                                        <span class="mrbp-payment-switch__track" aria-hidden="true"><span class="mrbp-payment-switch__thumb"></span></span>
                                        <span class="mrbp-payment-switch__state" aria-hidden="true"></span>
                                        <span class="screen-reader-text"><?php echo esc_html( sprintf( __( 'Enable %s', 'mr-commerce' ), (string) $gateway['label'] ) ); ?></span>
                                    </label>
                                </div>

                                <div class="mrbp-dynamic-gateway-card-actions">
                                    <button type="button" class="button button-small mrbp-gateway-edit-toggle" data-mrbp-edit-gateway aria-expanded="false">
                                        <span class="dashicons dashicons-edit" aria-hidden="true"></span>
                                        <span data-mrbp-edit-label><?php esc_html_e( 'Edit', 'mr-commerce' ); ?></span>
                                    </button>
                                </div>

                                <div class="mrbp-payment-gateway-card__fields">
                                    <div class="mrbp-payment-gateway-card__editor-grid">
                                        <div class="mrbp-payment-field">
                                            <label><?php esc_html_e( 'Gateway Name', 'mr-commerce' ); ?></label>
                                            <input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][label]" value="<?php echo esc_attr( (string) $gateway['label'] ); ?>">
                                        </div>
                                        <div class="mrbp-payment-field">
                                            <label><?php esc_html_e( 'Gateway Type', 'mr-commerce' ); ?></label>
                                            <select name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][type]">
                                                <option value="mobile" <?php selected( $gateway_type, 'mobile' ); ?>><?php esc_html_e( 'Mobile Banking / Wallet', 'mr-commerce' ); ?></option>
                                                <option value="bank" <?php selected( $gateway_type, 'bank' ); ?>><?php esc_html_e( 'Bank Transfer', 'mr-commerce' ); ?></option>
                                            </select>
                                        </div>
                                        <div class="mrbp-payment-field">
                                            <label><?php esc_html_e( 'Group Name', 'mr-commerce' ); ?></label>
                                            <input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][group_label]" value="<?php echo esc_attr( (string) ( $gateway['group_label'] ?? ( $is_bank ? __( 'Bank Transfer', 'mr-commerce' ) : __( 'Mobile Banking', 'mr-commerce' ) ) ) ); ?>">
                                        </div>
                                        <div class="mrbp-payment-field">
                                            <label><?php esc_html_e( 'Short Description', 'mr-commerce' ); ?></label>
                                            <input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][description]" value="<?php echo esc_attr( (string) ( $gateway['description'] ?? $definition['description'] ?? '' ) ); ?>">
                                        </div>
                                    </div>

                                    <?php $this->render_media_field( $option, (string) $gateway_id, 'logo', __( 'Gateway Logo', 'mr-commerce' ), $logo_url, absint( $gateway['logo_id'] ?? 0 ) ); ?>
                                    <?php $this->render_media_field( $option, (string) $gateway_id, 'qr', __( 'QR Code (Optional)', 'mr-commerce' ), $qr_url, absint( $gateway['qr_id'] ?? 0 ) ); ?>

                                    <div class="mrbp-payment-field mrbp-hidden-legacy-label">
                                        <label><?php esc_html_e( 'Display Name', 'mr-commerce' ); ?></label>
                                        <input type="hidden" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][legacy_label]" value="1">
                                    </div>
                                    <div class="mrbp-payment-field">
                                        <label><?php echo esc_html( $is_bank ? __( 'Account Holder Name', 'mr-commerce' ) : __( 'Account Name', 'mr-commerce' ) ); ?></label>
                                        <input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][account_name]" value="<?php echo esc_attr( (string) $gateway['account_name'] ); ?>">
                                    </div>
                                    <div class="mrbp-payment-field">
                                        <label><?php echo esc_html( (string) ( $definition['account_label'] ?? __( 'Account Number', 'mr-commerce' ) ) ); ?></label>
                                        <input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][account_number]" value="<?php echo esc_attr( (string) $gateway['account_number'] ); ?>">
                                    </div>
                                    <div class="mrbp-payment-field mrbp-payment-field--inline">
                                        <label><?php esc_html_e( 'Account Type', 'mr-commerce' ); ?></label>
                                        <select name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][account_type]">
                                            <?php foreach ( (array) ( $definition['account_types'] ?? array() ) as $type ) : ?>
                                                <option value="<?php echo esc_attr( sanitize_key( (string) $type ) ); ?>" <?php selected( sanitize_key( (string) $type ), $gateway['account_type'] ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', (string) $type ) ) ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="mrbp-payment-field mrbp-payment-field--inline">
                                        <label><?php esc_html_e( 'Display Order', 'mr-commerce' ); ?></label>
                                        <input type="number" min="1" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][sort_order]" value="<?php echo esc_attr( (string) ( $gateway['sort_order'] ?? 100 ) ); ?>">
                                    </div>

                                    <?php if ( mrc_can( 'payment.cashout_fee' ) ) : ?>
                                    <div class="mrbp-payment-field mrbp-payment-field--inline">
                                        <label><?php esc_html_e( 'Cash-out Charge', 'mr-commerce' ); ?></label>
                                        <label class="mrbp-payment-switch">
                                            <input type="checkbox" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][cashout_charge_enabled]" value="1" <?php checked( ! empty( $gateway['cashout_charge_enabled'] ) ); ?>>
                                            <span class="mrbp-payment-switch__track" aria-hidden="true"><span class="mrbp-payment-switch__thumb"></span></span>
                                            <span class="mrbp-payment-switch__state" aria-hidden="true"></span>
                                            <span class="screen-reader-text"><?php esc_html_e( 'Enable cash-out charge', 'mr-commerce' ); ?></span>
                                        </label>
                                    </div>
                                    <div class="mrbp-payment-field mrbp-payment-field--inline">
                                        <label><?php esc_html_e( 'Charge Type', 'mr-commerce' ); ?></label>
                                        <select name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][cashout_charge_type]">
                                            <option value="percentage" <?php selected( (string) ( $gateway['cashout_charge_type'] ?? 'percentage' ), 'percentage' ); ?>><?php esc_html_e( 'Percentage (%)', 'mr-commerce' ); ?></option>
                                            <option value="fixed" <?php selected( (string) ( $gateway['cashout_charge_type'] ?? 'percentage' ), 'fixed' ); ?>><?php esc_html_e( 'Fixed Amount', 'mr-commerce' ); ?></option>
                                        </select>
                                    </div>
                                    <div class="mrbp-payment-field mrbp-payment-field--inline">
                                        <label><?php esc_html_e( 'Charge Value', 'mr-commerce' ); ?></label>
                                        <input type="number" min="0" step="0.01" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][cashout_charge_value]" value="<?php echo esc_attr( (string) ( $gateway['cashout_charge_value'] ?? 0 ) ); ?>">
                                        <small><?php esc_html_e( 'Example: enter 1.85 for 1.85%, or 10 for a fixed charge.', 'mr-commerce' ); ?></small>
                                    </div>
                                    <?php else : ?>
                                    <div class="mrbp-payment-field mrbp-payment-field--inline">
                                        <label><?php esc_html_e( 'Cash-out Charge', 'mr-commerce' ); ?> <span class="mrbp-ui-badge mrbp-ui-badge--warning"><?php esc_html_e( 'PRO', 'mr-commerce' ); ?></span></label>
                                        <small><?php esc_html_e( 'Saved charge settings are paused in Free mode.', 'mr-commerce' ); ?></small>
                                    </div>
                                    <?php endif; ?>

                                    <?php if ( $is_bank ) : ?>
                                        <div class="mrbp-payment-bank-fields">
                                            <div class="mrbp-payment-field"><label><?php esc_html_e( 'Branch Name', 'mr-commerce' ); ?></label><input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][branch_name]" value="<?php echo esc_attr( (string) ( $gateway['branch_name'] ?? '' ) ); ?>"></div>
                                            <div class="mrbp-payment-field"><label><?php esc_html_e( 'Routing Number', 'mr-commerce' ); ?></label><input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][routing_number]" value="<?php echo esc_attr( (string) ( $gateway['routing_number'] ?? '' ) ); ?>"></div>
                                            <div class="mrbp-payment-field"><label><?php esc_html_e( 'SWIFT Code (Optional)', 'mr-commerce' ); ?></label><input type="text" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][swift_code]" value="<?php echo esc_attr( (string) ( $gateway['swift_code'] ?? '' ) ); ?>"></div>
                                        </div>
                                    <?php endif; ?>

                                    <details class="mrbp-payment-instructions">
                                        <summary><span class="dashicons dashicons-media-text" aria-hidden="true"></span><?php esc_html_e( 'Instructions', 'mr-commerce' ); ?></summary>
                                        <textarea rows="5" name="<?php echo esc_attr( $option ); ?>[gateways][<?php echo esc_attr( (string) $gateway_id ); ?>][instructions]" class="large-text"><?php echo esc_textarea( (string) $gateway['instructions'] ); ?></textarea>
                                    </details>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>

            <div class="mrbp-gateway-empty-state" data-mrbp-gateway-empty hidden>
                <span class="dashicons dashicons-search" aria-hidden="true"></span>
                <h3><?php esc_html_e( 'No payment methods found', 'mr-commerce' ); ?></h3>
                <p><?php esc_html_e( 'Try a different search term or reset the active filter.', 'mr-commerce' ); ?></p>
                <button type="button" class="button" data-mrbp-gateway-reset><?php esc_html_e( 'Reset Search & Filters', 'mr-commerce' ); ?></button>
            </div>

            <div class="mrbp-payment-help-strip"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><p><?php esc_html_e( 'Enabled methods automatically appear in checkout. Display Order controls their position inside each payment group.', 'mr-commerce' ); ?></p></div>
            <div class="mrbp-payment-savebar"><?php submit_button( __( 'Save Payment Methods', 'mr-commerce' ), 'primary', 'submit', false ); ?></div>
        </form>

        <?php
        return (string) ob_get_clean();
    }


    private function render_media_field( string $option, string $gateway_id, string $kind, string $label, string $url, int $attachment_id ): void {
        $base = $option . '[gateways][' . $gateway_id . ']';
        ?>
        <div class="mrbp-gateway-media" data-mrbp-media-field data-media-kind="<?php echo esc_attr( $kind ); ?>">
            <label class="mrbp-gateway-media__label"><?php echo esc_html( $label ); ?></label>
            <div class="mrbp-gateway-media__body">
                <div class="mrbp-gateway-media__preview<?php echo '' === $url ? ' is-empty' : ''; ?>" data-mrbp-media-preview>
                    <?php if ( '' !== $url ) : ?>
                        <img src="<?php echo esc_url( $url ); ?>" alt="">
                    <?php else : ?>
                        <span class="dashicons dashicons-format-image" aria-hidden="true"></span>
                        <small><?php esc_html_e( 'No image selected', 'mr-commerce' ); ?></small>
                    <?php endif; ?>
                </div>
                <div class="mrbp-gateway-media__controls">
                    <input type="hidden" name="<?php echo esc_attr( $base . '[' . $kind . '_id]' ); ?>" value="<?php echo esc_attr( (string) $attachment_id ); ?>" data-mrbp-media-id>
                    <input type="hidden" name="<?php echo esc_attr( $base . '[' . $kind . '_url]' ); ?>" value="<?php echo esc_attr( $url ); ?>" data-mrbp-media-url>
                    <button type="button" class="button" data-mrbp-media-choose data-media-title="<?php echo esc_attr( $label ); ?>"><?php echo esc_html( '' === $url ? __( 'Add Image', 'mr-commerce' ) : __( 'Replace Image', 'mr-commerce' ) ); ?></button>
                    <button type="button" class="button button-link-delete<?php echo '' === $url ? ' is-hidden' : ''; ?>" data-mrbp-media-remove><?php esc_html_e( 'Remove', 'mr-commerce' ); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    private function render_notice(): void {
        $notice = isset( $_GET['mrbp_gateway_notice'] ) ? sanitize_key( wp_unslash( $_GET['mrbp_gateway_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $messages = array(
            'saved'   => __( 'Gateway saved successfully. Configure its account information below, then enable it.', 'mr-commerce' ),
            'invalid' => __( 'Gateway name and a valid slug are required.', 'mr-commerce' ),
            'missing' => __( 'The requested custom gateway could not be found.', 'mr-commerce' ),
        );
        if ( isset( $messages[ $notice ] ) ) {
            $success = 'saved' === $notice;
            echo '<div class="mrbp-ui-notice mrbp-ui-notice--' . esc_attr( $success ? 'success' : 'danger' ) . ' mrbp-gateway-notice" role="status">';
            echo '<span class="dashicons ' . esc_attr( $success ? 'dashicons-yes-alt' : 'dashicons-warning' ) . '" aria-hidden="true"></span>';
            echo '<div><strong>' . esc_html( $success ? __( 'Gateway updated', 'mr-commerce' ) : __( 'Gateway action failed', 'mr-commerce' ) ) . '</strong><p>' . esc_html( $messages[ $notice ] ) . '</p></div>';
            echo '</div>';
        }
    }
}
