<?php

namespace MRBP\Modules\PaymentPro\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\ApprovalService;
use MRBP\Modules\PaymentPro\Services\ReviewService;
use MRBP\Modules\PaymentPro\Services\RejectService;

final class PaymentDecisionController {

    private ApprovalService $approval;
    private ReviewService $review;
    private RejectService $reject;

    public function __construct(
        ?ApprovalService $approval = null,
        ?ReviewService $review = null,
        ?RejectService $reject = null
    ) {
        $this->approval = $approval ?? new ApprovalService();
        $this->review   = $review ?? new ReviewService();
        $this->reject   = $reject ?? new RejectService();
    }

    public function register(): void {
        add_action( 'wp_ajax_mrbp_payment_decision', array( $this, 'handle' ) );
    }

    public function handle(): void {
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            wp_send_json_error( array( 'code' => 'method_not_allowed', 'message' => __( 'Invalid request method.', 'mr-commerce' ) ), 405 );
        }

        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'code' => 'forbidden', 'message' => __( 'You are not allowed to review payments.', 'mr-commerce' ) ), 403 );
        }

        check_ajax_referer( 'mrbp_payment_decision', 'nonce' );

        $request_id = isset( $_POST['request_id'] ) ? absint( $_POST['request_id'] ) : 0;
        $action     = isset( $_POST['decision'] ) ? sanitize_key( wp_unslash( $_POST['decision'] ) ) : '';
        $admin_note = isset( $_POST['admin_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['admin_note'] ) ) : '';
        $reason     = isset( $_POST['reason'] ) ? sanitize_key( wp_unslash( $_POST['reason'] ) ) : '';

        if ( $request_id < 1 ) {
            wp_send_json_error( array( 'code' => 'invalid_request', 'message' => __( 'A valid payment request is required.', 'mr-commerce' ) ), 400 );
        }

        $allowed_actions = array( 'approve', 'review', 'reject' );
        if ( ! in_array( $action, $allowed_actions, true ) ) {
            wp_send_json_error( array( 'code' => 'invalid_action', 'message' => __( 'Invalid payment decision.', 'mr-commerce' ) ), 400 );
        }

        $allowed_reasons = array( 'wrong_amount', 'duplicate_transaction', 'invalid_transaction', 'wrong_gateway', 'payment_not_found', 'fraud_suspected', 'other' );
        if ( 'reject' === $action && ! in_array( $reason, $allowed_reasons, true ) ) {
            $reason = 'other';
        }

        switch ( $action ) {
            case 'approve':
                $result = $this->approval->approve( $request_id, $admin_note );
                break;
            case 'review':
                $result = $this->review->review( $request_id, $admin_note );
                break;
            case 'reject':
                $result = $this->reject->reject( $request_id, $reason, $admin_note );
                break;
            default:
                $result = array( 'success' => false, 'code' => 'invalid_action', 'request_id' => $request_id );
        }

        if ( empty( $result['success'] ) ) {
            wp_send_json_error( $result, 409 );
        }

        $messages = array(
            'approve' => __( 'Payment approved successfully.', 'mr-commerce' ),
            'review'  => __( 'Payment moved to review successfully.', 'mr-commerce' ),
            'reject'  => __( 'Payment rejected successfully.', 'mr-commerce' ),
        );

        $result['message'] = $messages[ $action ] ?? __( 'Payment request updated successfully.', 'mr-commerce' );

        wp_send_json_success( $result );
    }
}
