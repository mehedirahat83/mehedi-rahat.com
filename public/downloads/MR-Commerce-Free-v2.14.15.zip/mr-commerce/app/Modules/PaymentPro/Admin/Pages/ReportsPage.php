<?php

namespace MRBP\Modules\PaymentPro\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Database\PaymentRequestSchema;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;
use MRBP\Security\Database;

final class ReportsPage {

    public function render(): string {
        global $wpdb;

        $gateways = function_exists( 'mrbp' ) ? mrbp()->gateways() : new GatewayCatalog();
        $table    = Database::table_name( PaymentRequestSchema::table_name() );
        $rows     = $wpdb->get_results(
            "SELECT gateway,
                    COUNT(*) AS request_count,
                    SUM(CASE WHEN status = 'verified' THEN amount ELSE 0 END) AS verified_amount,
                    SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) AS verified_count,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_count
             FROM {$table}
             GROUP BY gateway
             ORDER BY request_count DESC",
            ARRAY_A
        );
        $rows = is_array( $rows ) ? $rows : array();

        ob_start();
        ?>
        <section class="mrbp-payment-report-card">
            <div class="mrbp-payment-section-heading">
                <div>
                    <span class="mrbp-payment-section-kicker"><?php esc_html_e( 'Payment reports', 'mr-commerce' ); ?></span>
                    <h2><?php esc_html_e( 'Gateway Performance', 'mr-commerce' ); ?></h2>
                    <p><?php esc_html_e( 'A compact overview of manual mobile banking and bank transfer submissions.', 'mr-commerce' ); ?></p>
                </div>
            </div>

            <?php if ( empty( $rows ) ) : ?>
                <div class="mrbp-payment-history-empty">
                    <strong><?php esc_html_e( 'No payment data yet', 'mr-commerce' ); ?></strong>
                    <p><?php esc_html_e( 'Gateway statistics will appear after customers submit manual payments.', 'mr-commerce' ); ?></p>
                </div>
            <?php else : ?>
                <div class="mrbp-ui-table-wrap">
                    <table class="mrbp-ui-table widefat striped">
                        <thead><tr>
                            <th><?php esc_html_e( 'Method', 'mr-commerce' ); ?></th>
                            <th><?php esc_html_e( 'Type', 'mr-commerce' ); ?></th>
                            <th><?php esc_html_e( 'Requests', 'mr-commerce' ); ?></th>
                            <th><?php esc_html_e( 'Verified', 'mr-commerce' ); ?></th>
                            <th><?php esc_html_e( 'Rejected', 'mr-commerce' ); ?></th>
                            <th><?php esc_html_e( 'Verified Amount', 'mr-commerce' ); ?></th>
                        </tr></thead>
                        <tbody>
                        <?php foreach ( $rows as $row ) :
                            $gateway_id = sanitize_key( (string) ( $row['gateway'] ?? '' ) );
                            $definition = $gateways->get( $gateway_id );
                            $label      = $gateways->label( $gateway_id );
                            ?>
                            <tr>
                                <td><span class="mrbp-payment-gateway-badge mrbp-payment-gateway-badge--<?php echo esc_attr( sanitize_html_class( $gateway_id ) ); ?>"><?php echo esc_html( $label ); ?></span></td>
                                <td><?php echo esc_html( 'bank' === ( $definition['type'] ?? '' ) ? __( 'Bank Transfer', 'mr-commerce' ) : __( 'Mobile Banking', 'mr-commerce' ) ); ?></td>
                                <td><?php echo esc_html( number_format_i18n( (int) ( $row['request_count'] ?? 0 ) ) ); ?></td>
                                <td><?php echo esc_html( number_format_i18n( (int) ( $row['verified_count'] ?? 0 ) ) ); ?></td>
                                <td><?php echo esc_html( number_format_i18n( (int) ( $row['rejected_count'] ?? 0 ) ) ); ?></td>
                                <td><?php echo wp_kses_post( wc_price( (float) ( $row['verified_amount'] ?? 0 ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }
}
