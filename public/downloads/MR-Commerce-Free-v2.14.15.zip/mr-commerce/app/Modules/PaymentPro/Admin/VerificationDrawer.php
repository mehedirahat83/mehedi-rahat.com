<?php

namespace MRBP\Modules\PaymentPro\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;
use MRBP\Modules\PaymentPro\Services\ValidationService;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;
use MRBP\Modules\PaymentPro\Services\RejectService;
use MRBP\Modules\PaymentPro\Support\RequestLookupToken;
use MRBP\Support\Logger;

final class VerificationDrawer {
    private PaymentRequestRepository $repository;
    private ValidationService $validation;
    private GatewayCatalog $gateways;
    private RequestLookupToken $lookup_token;
    private Logger $logger;

    public function __construct( ?PaymentRequestRepository $repository = null, ?ValidationService $validation = null, ?RequestLookupToken $lookup_token = null, ?Logger $logger = null ) {
        $this->repository   = $repository ?? new PaymentRequestRepository();
        $this->validation   = $validation ?? new ValidationService();
        $this->lookup_token = $lookup_token ?? new RequestLookupToken();
        $this->logger       = $logger ?? new Logger();
        $this->gateways     = function_exists( 'mrbp' ) ? mrbp()->gateways() : new GatewayCatalog();
    }

    public function register(): void {
        add_action( 'wp_ajax_mrbp_payment_request_details', array( $this, 'ajax_details' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    public function enqueue_assets(): void {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        if ( 'mrbp-payment-center-requests' !== $page && 'mrbp-payment-center' !== $page ) { return; }

        wp_enqueue_style( 'mrbp-design-tokens', MRBP_URL . 'assets/css/design-tokens.css', array(), MRBP_VERSION );
        wp_enqueue_style( 'mrbp-verification-drawer', MRBP_URL . 'app/Modules/PaymentPro/Assets/css/verification-drawer.css', array( 'mrbp-design-tokens' ), MRBP_VERSION );
        wp_enqueue_script( 'mrbp-verification-drawer', MRBP_URL . 'app/Modules/PaymentPro/Assets/js/verification-drawer.js', array(), MRBP_VERSION, true );
        wp_localize_script( 'mrbp-verification-drawer', 'MRBPVerificationDrawer', array(
            'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
            'nonce'         => wp_create_nonce( 'mrbp_payment_request_details' ),
            'decisionNonce' => wp_create_nonce( 'mrbp_payment_decision' ),
            'loading'       => __( 'Loading payment details…', 'mr-commerce' ),
            'error'         => __( 'Could not load payment details.', 'mr-commerce' ),
            'processing'    => __( 'Processing…', 'mr-commerce' ),
            'approveTitle'  => __( 'Approve Payment?', 'mr-commerce' ),
            'reviewTitle'   => __( 'Place Payment Under Review', 'mr-commerce' ),
            'rejectTitle'   => __( 'Reject Payment', 'mr-commerce' ),
            'genericError'  => __( 'Unable to update this payment request.', 'mr-commerce' ),
            'reasons'       => array(
                'wrong_amount'          => __( 'Wrong Amount', 'mr-commerce' ),
                'duplicate_transaction' => __( 'Duplicate Transaction', 'mr-commerce' ),
                'invalid_transaction'   => __( 'Invalid Transaction', 'mr-commerce' ),
                'wrong_gateway'         => __( 'Wrong Gateway', 'mr-commerce' ),
                'payment_not_found'     => __( 'Payment Not Found', 'mr-commerce' ),
                'fraud_suspected'       => __( 'Fraud Suspected', 'mr-commerce' ),
                'other'                 => __( 'Other', 'mr-commerce' ),
            ),
        ) );
    }

    public function ajax_details(): void {
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) { wp_send_json_error( array( 'message' => __( 'Invalid request method.', 'mr-commerce' ) ), 405 ); }
        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => __( 'You are not allowed to view payment requests.', 'mr-commerce' ) ), 403 ); }
        check_ajax_referer( 'mrbp_payment_request_details', 'nonce' );

        $request_id    = isset( $_POST['request_id'] ) ? absint( $_POST['request_id'] ) : 0;
        $order_id      = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
        $transaction_id = isset( $_POST['transaction_id'] )
            ? strtoupper( sanitize_text_field( wp_unslash( $_POST['transaction_id'] ) ) )
            : '';
        $request_token = isset( $_POST['request_token'] )
            ? sanitize_text_field( wp_unslash( $_POST['request_token'] ) )
            : '';

        $lookup  = 'repository_resolve';
        $request = $this->repository->resolve( $request_id, $order_id, $transaction_id );

        // The list page already loaded this exact row. A short-lived signed snapshot
        // provides a secure fallback when a migrated database row cannot be resolved
        // again during the separate AJAX request.
        if ( ! $request && '' !== $request_token ) {
            $lookup  = 'signed_snapshot';
            $request = $this->lookup_token->verify( $request_token );
        }

        if ( ! $request ) {
            wp_send_json_error(
                array(
                    'message' => __( 'Payment request not found. Refresh the Payment Requests page and try again.', 'mr-commerce' ),
                    'code'    => 'request_not_found',
                ),
                404
            );
        }

        $order = wc_get_order( absint( $request['order_id'] ?? 0 ) );
        if ( ! $order || $order instanceof \WC_Order_Refund ) { wp_send_json_error( array( 'message' => __( 'The related WooCommerce order is unavailable.', 'mr-commerce' ) ), 404 ); }

        $validation = $this->validation->validate( $request );
        wp_send_json_success(
            array(
                'html'       => $this->render_html( $request, $order, $validation ),
                'request_id' => absint( $request['request_id'] ?? $request['id'] ?? 0 ),
            )
        );
    }

    private function render_html( array $request, \WC_Order $order, $validation ): string {
        $customer_name = trim( (string) ( $request['customer_name'] ?? '' ) );
        if ( '' === $customer_name ) { $customer_name = trim( (string) $order->get_formatted_billing_full_name() ); }
        if ( '' === $customer_name ) { $customer_name = __( 'Guest Customer', 'mr-commerce' ); }
        $email = sanitize_email( (string) ( $request['customer_email'] ?? $order->get_billing_email() ) );
        $products = array();
        foreach ( $order->get_items() as $item ) {
            $products[] = array( 'name' => $item->get_name(), 'qty' => $item->get_quantity(), 'total' => $order->get_formatted_line_subtotal( $item ) );
        }

        ob_start();
        ?>
        <div class="mrbp-verification-drawer__header">
            <div><span class="mrbp-verification-eyebrow"><?php esc_html_e( 'Payment Request', 'mr-commerce' ); ?></span><h2><?php echo esc_html( sprintf( __( 'Order #%s', 'mr-commerce' ), $order->get_order_number() ) ); ?></h2><p><?php echo esc_html( $this->format_date( (string) ( $request['submitted_at'] ?? '' ) ) ); ?></p></div>
            <span class="mrbp-payment-status mrbp-payment-status--<?php echo esc_attr( sanitize_html_class( (string) ( $request['status'] ?? 'submitted' ) ) ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', (string) ( $request['status'] ?? 'submitted' ) ) ) ); ?></span>
        </div>

        <div class="mrbp-readiness mrbp-readiness--<?php echo esc_attr( $validation->level() ); ?>"><div><strong><?php esc_html_e( 'Verification Readiness', 'mr-commerce' ); ?></strong><span><?php echo esc_html( strtoupper( $validation->level() ) . ' ' . __( 'RISK', 'mr-commerce' ) ); ?></span></div><b><?php echo esc_html( $validation->score() . '%' ); ?></b></div>

        <section class="mrbp-drawer-section"><h3><?php esc_html_e( 'Customer Details', 'mr-commerce' ); ?></h3><div class="mrbp-detail-grid"><div><span><?php esc_html_e( 'Customer', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $customer_name ); ?></strong></div><div><span><?php esc_html_e( 'Email', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $email ?: '—' ); ?></strong></div><div><span><?php esc_html_e( 'Billing Phone', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $order->get_billing_phone() ?: '—' ); ?></strong></div><div><span><?php esc_html_e( 'Customer Type', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $order->get_customer_id() ? __( 'Registered', 'mr-commerce' ) : __( 'Guest', 'mr-commerce' ) ); ?></strong></div></div></section>

        <section class="mrbp-drawer-section"><h3><?php esc_html_e( 'Products', 'mr-commerce' ); ?></h3><div class="mrbp-product-list"><?php foreach ( $products as $product ) : ?><div><span><strong><?php echo esc_html( $product['name'] ); ?></strong><small><?php echo esc_html( sprintf( __( 'Quantity: %d', 'mr-commerce' ), $product['qty'] ) ); ?></small></span><b><?php echo wp_kses_post( $product['total'] ); ?></b></div><?php endforeach; ?></div></section>

        <section class="mrbp-drawer-section"><h3><?php esc_html_e( 'Payment Information', 'mr-commerce' ); ?></h3><div class="mrbp-amount-compare"><div><span><?php esc_html_e( 'Expected Amount', 'mr-commerce' ); ?></span><strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong></div><div><span><?php esc_html_e( 'Submitted Amount', 'mr-commerce' ); ?></span><strong><?php echo esc_html( number_format_i18n( (float) ( $request['amount'] ?? 0 ), 2 ) . ' ' . (string) ( $request['currency'] ?? '' ) ); ?></strong></div></div><div class="mrbp-detail-grid"><div><span><?php esc_html_e( 'Gateway', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $this->gateways->label( (string) ( $request['gateway'] ?? '' ) ) ); ?></strong></div><div><span><?php esc_html_e( 'Sender Phone', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) ( $request['sender_phone'] ?? '' ) ); ?></strong></div><div><span><?php esc_html_e( 'Transaction ID', 'mr-commerce' ); ?></span><strong><code><?php echo esc_html( (string) ( $request['transaction_id'] ?? '' ) ); ?></code></strong></div><div><span><?php esc_html_e( 'Currency', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) ( $request['currency'] ?? '' ) ); ?></strong></div></div></section>

        <section class="mrbp-drawer-section"><h3><?php esc_html_e( 'Customer Note', 'mr-commerce' ); ?></h3><p class="mrbp-customer-note"><?php echo esc_html( (string) ( $request['customer_note'] ?? '' ) ?: __( 'No customer note was submitted.', 'mr-commerce' ) ); ?></p></section>

        <section class="mrbp-drawer-section"><h3><?php esc_html_e( 'Validation Panel', 'mr-commerce' ); ?></h3><div class="mrbp-validation-list"><?php foreach ( $validation->checks() as $check ) : ?><div class="mrbp-validation-item mrbp-validation-item--<?php echo esc_attr( $check['severity'] ); ?>"><span class="dashicons <?php echo esc_attr( $check['passed'] ? 'dashicons-yes-alt' : 'dashicons-warning' ); ?>"></span><span><?php echo esc_html( $check['message'] ); ?></span></div><?php endforeach; ?></div></section>

        <section class="mrbp-drawer-section"><h3><?php esc_html_e( 'Timeline Preview', 'mr-commerce' ); ?></h3><div class="mrbp-timeline-preview"><span class="is-complete"><?php esc_html_e( 'Submitted', 'mr-commerce' ); ?></span><span><?php esc_html_e( 'Pending Review', 'mr-commerce' ); ?></span></div></section>

        <section class="mrbp-drawer-section mrbp-admin-decision-section">
            <h3><?php esc_html_e( 'Admin Decision', 'mr-commerce' ); ?></h3>
            <label class="mrbp-admin-note-label" for="mrbp-admin-note-<?php echo esc_attr( (string) absint( $request['id'] ?? 0 ) ); ?>"><?php esc_html_e( 'Admin Note', 'mr-commerce' ); ?></label>
            <textarea id="mrbp-admin-note-<?php echo esc_attr( (string) absint( $request['id'] ?? 0 ) ); ?>" class="mrbp-admin-note" rows="4" placeholder="<?php esc_attr_e( 'Optional note for approval. Add context for review or rejection.', 'mr-commerce' ); ?>"><?php echo esc_textarea( (string) ( $request['admin_note'] ?? '' ) ); ?></textarea>
            <div class="mrbp-decision-actions" data-request-id="<?php echo esc_attr( (string) absint( $request['id'] ?? 0 ) ); ?>" data-order="<?php echo esc_attr( (string) $order->get_order_number() ); ?>" data-gateway="<?php echo esc_attr( $this->gateways->label( (string) ( $request['gateway'] ?? '' ) ) ); ?>" data-amount="<?php echo esc_attr( wp_strip_all_tags( $order->get_formatted_order_total() ) ); ?>" data-transaction="<?php echo esc_attr( (string) ( $request['transaction_id'] ?? '' ) ); ?>">
                <?php if ( in_array( (string) ( $request['status'] ?? '' ), array( 'submitted', 'under_review', 'pending' ), true ) ) : ?>
                    <button type="button" class="button button-primary mrbp-decision-button mrbp-decision-approve" data-decision="approve"><?php esc_html_e( 'Approve', 'mr-commerce' ); ?></button>
                    <button type="button" class="button mrbp-decision-button mrbp-decision-review" data-decision="review"><?php esc_html_e( 'Under Review', 'mr-commerce' ); ?></button>
                    <button type="button" class="button mrbp-decision-button mrbp-decision-reject" data-decision="reject"><?php esc_html_e( 'Reject', 'mr-commerce' ); ?></button>
                <?php else : ?>
                    <span class="mrbp-decision-locked"><?php esc_html_e( 'This payment request has already been processed.', 'mr-commerce' ); ?></span>
                <?php endif; ?>
            </div>
        </section>

        <div class="mrbp-verification-drawer__footer"><a class="button" href="<?php echo esc_url( $order->get_edit_order_url() ); ?>"><?php esc_html_e( 'View WooCommerce Order', 'mr-commerce' ); ?></a><span><?php esc_html_e( 'Payment decisions are protected by capability checks, nonces and duplicate-action prevention.', 'mr-commerce' ); ?></span></div>
        <?php
        return (string) ob_get_clean();
    }

    private function format_date( string $date ): string {
        $timestamp = '' !== $date ? strtotime( $date . ' UTC' ) : false;
        return $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : '—';
    }
}
