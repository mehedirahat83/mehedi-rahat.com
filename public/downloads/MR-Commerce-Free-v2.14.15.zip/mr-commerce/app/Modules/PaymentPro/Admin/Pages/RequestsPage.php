<?php

namespace MRBP\Modules\PaymentPro\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Table;
use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;
use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;
use MRBP\Modules\PaymentPro\Support\RequestLookupToken;

final class RequestsPage {

    private const STATUSES = array( 'pending', 'submitted', 'under_review', 'verified', 'rejected', 'expired' );
    private const DATES    = array( 'today', 'week', 'month' );

    private PaymentRequestRepository $repository;
    private ManualGatewaySettings $settings;
    private GatewayCatalog $gateways;
    private RequestLookupToken $lookup_token;

    public function __construct( ?PaymentRequestRepository $repository = null, ?RequestLookupToken $lookup_token = null, ?ManualGatewaySettings $settings = null ) {
        $this->repository   = $repository ?? new PaymentRequestRepository();
        $this->lookup_token = $lookup_token ?? new RequestLookupToken();
        $this->settings     = $settings ?? new ManualGatewaySettings();
        $this->gateways     = function_exists( 'mrbp' ) ? mrbp()->gateways() : new GatewayCatalog( $this->settings->registry(), $this->settings );
    }

    public function render(): string {
        $filters = $this->filters();
        $result  = $this->repository->search( $filters );
        $rows    = array();

        foreach ( $result['items'] as $request ) {
            $order_id = absint( $request['order_id'] ?? 0 );
            $order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
            $order_number = $order && is_callable( array( $order, 'get_order_number' ) )
                ? (string) $order->get_order_number()
                : (string) $order_id;
            $customer = trim( (string) ( $request['customer_name'] ?? '' ) );
            $email    = sanitize_email( (string) ( $request['customer_email'] ?? '' ) );

            if ( '' === $customer && $order && is_callable( array( $order, 'get_formatted_billing_full_name' ) ) ) {
                $customer = trim( (string) $order->get_formatted_billing_full_name() );
                $email    = sanitize_email( (string) $order->get_billing_email() );
            }
            if ( '' === $customer ) {
                $customer = __( 'Guest Customer', 'mr-commerce' );
            }

            $order_link = $order && is_callable( array( $order, 'get_edit_order_url' ) )
                ? (string) $order->get_edit_order_url()
                : admin_url( 'post.php?post=' . $order_id . '&action=edit' );

            $request_id = absint( $request['request_id'] ?? $request['id'] ?? 0 );
            if ( 0 === $request_id && $order && is_callable( array( $order, 'get_meta' ) ) ) {
                $request_id = absint( $order->get_meta( '_mrbp_payment_request_id', true ) );
            }

            // Normalize identifiers before issuing the signed fallback. This is
            // required for migrated rows where only one ID alias is populated.
            $request['request_id'] = $request_id;
            $request['id']         = $request_id;
            $request_token = $this->lookup_token->issue( $request );

            $rows[] = array(
                'order'       => '<strong>#' . esc_html( $order_number ) . '</strong>',
                'customer'    => '<strong>' . esc_html( $customer ) . '</strong>' . ( '' !== $email ? '<br><small>' . esc_html( $email ) . '</small>' : '' ),
                'gateway'     => '<span class="mrbp-payment-gateway-badge mrbp-payment-gateway-badge--' . esc_attr( sanitize_html_class( (string) ( $request['gateway'] ?? '' ) ) ) . '">' . esc_html( $this->gateways->label( (string) ( $request['gateway'] ?? '' ) ) ) . '</span>',
                'amount'      => '<strong>' . esc_html( number_format_i18n( (float) ( $request['amount'] ?? 0 ), 2 ) ) . '</strong> ' . esc_html( (string) ( $request['currency'] ?? 'BDT' ) ),
                'phone'       => esc_html( (string) ( $request['sender_phone'] ?? '' ) ),
                'transaction' => '<code>' . esc_html( (string) ( $request['transaction_id'] ?? '' ) ) . '</code>',
                'status'      => $this->status_badge( (string) ( $request['status'] ?? 'pending' ) ),
                'submitted'   => $this->format_date( (string) ( $request['submitted_at'] ?? '' ) ),
                'action'      => '<button id="mrbp-verify-' . esc_attr( (string) $request_id ) . '" type="button" value="' . esc_attr( $request_token ) . '" class="button button-primary button-small mrbp-open-verification" data-request-id="' . esc_attr( (string) $request_id ) . '" data-order-id="' . esc_attr( (string) $order_id ) . '" data-transaction-id="' . esc_attr( (string) ( $request['transaction_id'] ?? '' ) ) . '" data-request-token="' . esc_attr( $request_token ) . '">' . esc_html__( 'Verify Details', 'mr-commerce' ) . '</button><a class="button button-small" href="' . esc_url( $order_link ) . '">' . esc_html__( 'View Order', 'mr-commerce' ) . '</a>',
            );
        }

        ob_start();
        ?>
        <div class="mrbp-payment-requests">
            <?php $this->render_filters( $filters, (int) $result['total'] ); ?>
            <?php
            Table::make(
                array(
                    'order'       => __( 'Order', 'mr-commerce' ),
                    'customer'    => __( 'Customer', 'mr-commerce' ),
                    'gateway'     => __( 'Gateway', 'mr-commerce' ),
                    'amount'      => __( 'Amount', 'mr-commerce' ),
                    'phone'       => __( 'Sender Phone', 'mr-commerce' ),
                    'transaction' => __( 'Transaction ID', 'mr-commerce' ),
                    'status'      => __( 'Status', 'mr-commerce' ),
                    'submitted'   => __( 'Submitted', 'mr-commerce' ),
                    'action'      => __( 'Action', 'mr-commerce' ),
                ),
                $rows,
                __( 'No payment requests match the selected filters.', 'mr-commerce' )
            )->render();
            ?>
            <?php $this->render_pagination( $result, $filters ); ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /** @return array<string,mixed> */
    private function filters(): array {
        $status  = isset( $_GET['payment_status'] ) ? sanitize_key( wp_unslash( $_GET['payment_status'] ) ) : '';
        $gateway = isset( $_GET['payment_gateway'] ) ? sanitize_key( wp_unslash( $_GET['payment_gateway'] ) ) : '';
        $date    = isset( $_GET['payment_date'] ) ? sanitize_key( wp_unslash( $_GET['payment_date'] ) ) : '';
        $search  = isset( $_GET['payment_search'] ) ? sanitize_text_field( wp_unslash( $_GET['payment_search'] ) ) : '';
        $page    = isset( $_GET['payment_page'] ) ? max( 1, absint( $_GET['payment_page'] ) ) : 1;

        return array(
            'status'   => in_array( $status, self::STATUSES, true ) ? $status : '',
            'gateway'  => $this->gateways->has( $gateway ) ? $gateway : '',
            'date'     => in_array( $date, self::DATES, true ) ? $date : '',
            'search'   => $search,
            'page'     => $page,
            'per_page' => 20,
        );
    }

    /** @param array<string,mixed> $filters */
    private function render_filters( array $filters, int $total ): void {
        ?>
        <div class="mrbp-payment-filter-card">
            <div class="mrbp-payment-filter-card__heading">
                <div>
                    <h3><?php esc_html_e( 'Payment Requests', 'mr-commerce' ); ?></h3>
                    <p><?php echo esc_html( sprintf( _n( '%d request found', '%d requests found', $total, 'mr-commerce' ), $total ) ); ?></p>
                </div>
                <?php if ( '' !== $filters['search'] || '' !== $filters['status'] || '' !== $filters['gateway'] || '' !== $filters['date'] ) : ?>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=mrbp-payment-center-requests' ) ); ?>"><?php esc_html_e( 'Clear Filters', 'mr-commerce' ); ?></a>
                <?php endif; ?>
            </div>
            <form method="get" class="mrbp-payment-filter-form">
                <input type="hidden" name="page" value="mrbp-payment-center-requests">
                <label>
                    <span><?php esc_html_e( 'Search', 'mr-commerce' ); ?></span>
                    <input type="search" name="payment_search" value="<?php echo esc_attr( (string) $filters['search'] ); ?>" placeholder="<?php esc_attr_e( 'Order, customer, email, phone or transaction ID', 'mr-commerce' ); ?>">
                </label>
                <label>
                    <span><?php esc_html_e( 'Status', 'mr-commerce' ); ?></span>
                    <select name="payment_status">
                        <option value=""><?php esc_html_e( 'All statuses', 'mr-commerce' ); ?></option>
                        <?php foreach ( self::STATUSES as $status ) : ?>
                            <option value="<?php echo esc_attr( $status ); ?>" <?php selected( $filters['status'], $status ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $status ) ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    <span><?php esc_html_e( 'Gateway', 'mr-commerce' ); ?></span>
                    <select name="payment_gateway">
                        <option value=""><?php esc_html_e( 'All gateways', 'mr-commerce' ); ?></option>
                        <?php foreach ( $this->gateways->all() as $gateway => $definition ) : ?>
                            <option value="<?php echo esc_attr( (string) $gateway ); ?>" <?php selected( $filters['gateway'], $gateway ); ?>><?php echo esc_html( $this->gateways->label( (string) $gateway ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>
                    <span><?php esc_html_e( 'Date', 'mr-commerce' ); ?></span>
                    <select name="payment_date">
                        <option value=""><?php esc_html_e( 'Any date', 'mr-commerce' ); ?></option>
                        <option value="today" <?php selected( $filters['date'], 'today' ); ?>><?php esc_html_e( 'Today', 'mr-commerce' ); ?></option>
                        <option value="week" <?php selected( $filters['date'], 'week' ); ?>><?php esc_html_e( 'Last 7 days', 'mr-commerce' ); ?></option>
                        <option value="month" <?php selected( $filters['date'], 'month' ); ?>><?php esc_html_e( 'Last 30 days', 'mr-commerce' ); ?></option>
                    </select>
                </label>
                <button type="submit" class="button button-primary"><?php esc_html_e( 'Apply Filters', 'mr-commerce' ); ?></button>
            </form>
        </div>
        <?php
    }

    /** @param array<string,mixed> $result @param array<string,mixed> $filters */
    private function render_pagination( array $result, array $filters ): void {
        if ( (int) $result['pages'] <= 1 ) {
            return;
        }

        $base_args = array_filter(
            array(
                'page'            => 'mrbp-payment-center-requests',
                'payment_search'  => $filters['search'],
                'payment_status'  => $filters['status'],
                'payment_gateway' => $filters['gateway'],
                'payment_date'    => $filters['date'],
                'payment_page'    => '%#%',
            ),
            static fn( $value ): bool => '' !== $value
        );

        $links = paginate_links(
            array(
                'base'      => add_query_arg( $base_args, admin_url( 'admin.php' ) ),
                'format'    => '',
                'current'   => (int) $result['page'],
                'total'     => (int) $result['pages'],
                'type'      => 'list',
                'prev_text' => '‹',
                'next_text' => '›',
            )
        );

        if ( is_string( $links ) ) {
            echo '<nav class="mrbp-payment-pagination" aria-label="' . esc_attr__( 'Payment request pagination', 'mr-commerce' ) . '">' . wp_kses_post( $links ) . '</nav>';
        }
    }

    private function status_badge( string $status ): string {
        $status = sanitize_key( $status );
        $map = array(
            'pending'      => 'warning',
            'submitted'    => 'info',
            'under_review' => 'warning',
            'verified'     => 'success',
            'rejected'     => 'danger',
            'expired'      => 'muted',
        );
        $variant = $map[ $status ] ?? 'muted';

        return '<span class="mrbp-ui-badge mrbp-ui-badge--' . esc_attr( $variant ) . '">' . esc_html( ucwords( str_replace( '_', ' ', $status ) ) ) . '</span>';
    }

    private function format_date( string $date ): string {
        if ( '' === $date ) {
            return '—';
        }
        $timestamp = strtotime( $date . ' UTC' );
        if ( false === $timestamp ) {
            return esc_html( $date );
        }

        return esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) );
    }
}
