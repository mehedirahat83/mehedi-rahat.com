<?php

namespace MRBP\Modules\PaymentPro\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Card;
use MRBP\Admin\Components\Table;
use MRBP\Modules\PaymentPro\Services\PaymentCenterService;

final class DashboardPage {

    private PaymentCenterService $service;

    public function __construct( ?PaymentCenterService $service = null ) {
        $this->service = $service ?? new PaymentCenterService();
    }

    public function render(): string {
        $stats = $this->service->dashboard_stats();

        ob_start();
        ?>
        <div class="mrbp-ui-notice mrbp-ui-notice--info">
            <p><strong><?php esc_html_e( 'Manual payment workflow:', 'mr-commerce' ); ?></strong> <?php esc_html_e( 'Customer submission, admin verification and WooCommerce synchronization are available for release-candidate testing.', 'mr-commerce' ); ?></p>
        </div>
        <div class="mrbp-module-overview-grid mrbp-module-overview-grid--four">
            <?php
            $cards = array(
                array( __( 'Pending Requests', 'mr-commerce' ), (string) $stats['pending'], __( 'Waiting for review.', 'mr-commerce' ), 'dashicons-clock', __( 'Payments', 'mr-commerce' ), __( 'Queue', 'mr-commerce' ) ),
                array( __( 'Under Review', 'mr-commerce' ), (string) $stats['under_review'], __( 'Currently being checked.', 'mr-commerce' ), 'dashicons-search', __( 'Payments', 'mr-commerce' ), __( 'Review', 'mr-commerce' ) ),
                array( __( 'Verified', 'mr-commerce' ), (string) $stats['verified'], __( 'Approved payment requests.', 'mr-commerce' ), 'dashicons-yes-alt', __( 'Payments', 'mr-commerce' ), __( 'Approved', 'mr-commerce' ) ),
                array( __( 'Rejected', 'mr-commerce' ), (string) $stats['rejected'], __( 'Rejected payment requests.', 'mr-commerce' ), 'dashicons-dismiss', __( 'Payments', 'mr-commerce' ), __( 'Rejected', 'mr-commerce' ) ),
            );
            foreach ( $cards as $card ) :
            ?>
                <article class="mrbp-module-overview-card">
                    <div class="mrbp-module-overview-card__top">
                        <div class="mrbp-module-overview-card__title-row">
                            <span class="mrbp-module-overview-card__icon dashicons <?php echo esc_attr( $card[3] ); ?>" aria-hidden="true"></span>
                            <h2 class="mrbp-module-overview-card__title"><?php echo esc_html( $card[0] ); ?></h2>
                        </div>
                        <div class="mrbp-module-overview-card__meta">
                            <span><?php echo esc_html( $card[4] ); ?></span>
                            <span class="mrbp-module-overview-card__badge"><?php echo esc_html( $card[5] ); ?></span>
                        </div>
                    </div>
                    <div class="mrbp-module-overview-card__body">
                        <strong class="mrbp-module-overview-card__value"><?php echo esc_html( $card[1] ); ?></strong>
                        <p class="mrbp-module-overview-card__description"><?php echo esc_html( $card[2] ); ?></p>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        Table::make(
            array(
                'milestone' => __( 'Milestone', 'mr-commerce' ),
                'scope'     => __( 'Scope', 'mr-commerce' ),
                'status'    => __( 'Status', 'mr-commerce' ),
            ),
            array(
                array( 'milestone' => 'v0.7.0-alpha.1', 'scope' => __( 'Skeleton, schema, navigation, admin pages and services', 'mr-commerce' ), 'status' => '<span class="mrbp-ui-badge mrbp-ui-badge--success">' . esc_html__( 'Ready', 'mr-commerce' ) . '</span>' ),
                array( 'milestone' => 'v0.7.0-alpha.2', 'scope' => __( 'Responsive payment popup, gateway selection and merchant information', 'mr-commerce' ), 'status' => '<span class="mrbp-ui-badge mrbp-ui-badge--success">' . esc_html__( 'Ready', 'mr-commerce' ) . '</span>' ),
                array( 'milestone' => 'v0.7.0-beta.1', 'scope' => __( 'Manual payment submission, validation and customer payment history', 'mr-commerce' ), 'status' => '<span class="mrbp-ui-badge mrbp-ui-badge--success">' . esc_html__( 'Ready', 'mr-commerce' ) . '</span>' ),
                array( 'milestone' => 'v0.7.0', 'scope' => __( 'Stable manual payment workflow for WooCommerce and Customer Portal', 'mr-commerce' ), 'status' => '<span class="mrbp-ui-badge mrbp-ui-badge--success">' . esc_html__( 'Stable', 'mr-commerce' ) . '</span>' ),
            )
        )->render();

        return (string) ob_get_clean();
    }
}
