<?php

namespace MRBP\Modules\PaymentPro\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Tabs;
use MRBP\Admin\Layout\PageRenderer;
use MRBP\Admin\Navigation\NavigationRegistry;
use MRBP\Admin\ProFeature;
use MRBP\Modules\PaymentPro\Admin\Pages\DashboardPage;
use MRBP\Modules\PaymentPro\Admin\Pages\GatewaysPage;
use MRBP\Modules\PaymentPro\Admin\Pages\ReportsPage;
use MRBP\Modules\PaymentPro\Admin\Pages\RequestsPage;
use MRBP\Modules\PaymentPro\Admin\Pages\SettingsPage;
use MRBP\Modules\PaymentPro\Admin\Pages\TransactionsPage;
use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;

final class PaymentCenterAdmin {

    private const PARENT_SLUG = 'mrbp-payment-center';

    private DashboardPage $dashboard;
    private RequestsPage $requests;
    private GatewaysPage $gateways;
    private ReportsPage $reports;
    private SettingsPage $settings;
    private TransactionsPage $transactions;
    private ManualGatewaySettings $manual_settings;

    public function __construct( ?ManualGatewaySettings $manual_settings = null ) {
        $this->manual_settings = $manual_settings ?? new ManualGatewaySettings();
        $this->dashboard = new DashboardPage();
        $this->requests  = new RequestsPage();
        $this->gateways  = new GatewaysPage( $this->manual_settings );
        $this->reports   = new ReportsPage();
        $this->settings  = new SettingsPage( $this->manual_settings );
        $this->transactions = new TransactionsPage();
    }

    public function register(): void {
        add_action( 'admin_menu', array( $this, 'register_menu' ), 62 );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    /**
     * Load Payment Center assets before the admin page is rendered.
     *
     * The Payment Center renders every tab into the page and switches tabs on the
     * client. Therefore the Gateway Manager script must be available on every
     * Payment Center route, not only when the Gateways route was loaded directly.
     */
    public function enqueue_assets( string $hook_suffix = '' ): void {
        unset( $hook_suffix );

        $page = isset( $_GET['page'] )
            ? sanitize_key( wp_unslash( $_GET['page'] ) )
            : '';

        if ( self::PARENT_SLUG !== $page && ! str_starts_with( $page, self::PARENT_SLUG . '-' ) ) {
            return;
        }

        wp_enqueue_media();

        $admin_css = MRBP_PATH . 'app/Modules/PaymentPro/Assets/css/admin.css';
        $manager_js = MRBP_PATH . 'app/Modules/PaymentPro/Assets/js/gateway-manager.js';

        wp_enqueue_style(
            'mrbp-payment-admin',
            MRBP_URL . 'app/Modules/PaymentPro/Assets/css/admin.css',
            array( 'mrbp-design-tokens' ),
            is_readable( $admin_css ) ? (string) filemtime( $admin_css ) : MRBP_VERSION
        );

        wp_enqueue_script(
            'mrbp-gateway-manager',
            MRBP_URL . 'app/Modules/PaymentPro/Assets/js/gateway-manager.js',
            array( 'jquery' ),
            is_readable( $manager_js ) ? (string) filemtime( $manager_js ) : MRBP_VERSION,
            true
        );
    }

    public function register_menu(): void {
        $capability = 'manage_woocommerce';

        add_submenu_page(
            'mrbp-dashboard',
            __( 'MR Payment Center', 'mr-commerce' ),
            __( 'MR Payment Center', 'mr-commerce' ),
            $capability,
            self::PARENT_SLUG,
            array( $this, 'render_dashboard' )
        );

        foreach ( $this->routes() as $slug => $route ) {
            add_submenu_page( null, $route['label'], $route['label'], $capability, $slug, array( $this, $route['callback'] ) );
        }
    }

    public function render_dashboard(): void { $this->render_page( 'dashboard' ); }
    public function render_requests(): void { $this->render_page( 'requests' ); }
    public function render_transactions(): void { $this->render_page( 'transactions' ); }
    public function render_gateways(): void { $this->render_page( 'gateways' ); }
    public function render_reports(): void { $this->render_page( 'reports' ); }
    public function render_settings(): void { $this->render_page( 'settings' ); }
    public function render_logs(): void { $this->render_page( 'logs' ); }

    private function render_page( string $active ): void {
        $renderer = mrbp()->container()->get( 'page_renderer' );

        if ( ! $renderer instanceof PageRenderer ) {
            wp_die( esc_html__( 'The admin page renderer is unavailable.', 'mr-commerce' ) );
        }

        $renderer->render(
            __( 'MR Payment Center', 'mr-commerce' ),
            __( 'Manual payment verification foundation for WooCommerce, Customer Portal and future gateway APIs.', 'mr-commerce' ),
            function () use ( $active ): void {
                echo '<div class="mrbp-payment-center-ui mrbp-payment-center-ui--' . esc_attr( $active ) . '">';
                Tabs::make( $this->tabs(), $active, 'mrbp-payment-center-tabs' )->render();
                echo '</div>';
            },
            array(
                array( 'label' => __( 'MR Commerce Pro', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=mrbp-dashboard' ) ),
                array( 'label' => __( 'MR Payment Center', 'mr-commerce' ), 'url' => admin_url( 'admin.php?page=' . self::PARENT_SLUG ) ),
                $this->label_for( $active ),
            ),
            array(),
            'manage_woocommerce'
        );
    }

    private function tabs(): array {
        return array(
            'dashboard'    => array( 'label' => __( 'Dashboard', 'mr-commerce' ), 'content' => $this->dashboard->render() ),
            'requests'     => array( 'label' => __( 'Payment Requests', 'mr-commerce' ), 'content' => $this->pro_content( 'payment.verification', __( 'Payment Verification Queue', 'mr-commerce' ), fn (): string => $this->requests->render() ) ),
            'transactions' => array( 'label' => __( 'Transactions', 'mr-commerce' ), 'content' => $this->pro_content( 'payment.verification', __( 'Payment Transaction Ledger', 'mr-commerce' ), fn (): string => $this->transactions->render() ) ),
            'gateways'     => array( 'label' => __( 'Gateways', 'mr-commerce' ), 'content' => $this->gateways->render() . $this->gateway_limit_preview() ),
            'reports'      => array( 'label' => __( 'Reports', 'mr-commerce' ), 'content' => $this->pro_content( 'payment.reports', __( 'Payment Reports', 'mr-commerce' ), fn (): string => $this->reports->render() ) ),
            'settings'     => array( 'label' => __( 'Settings', 'mr-commerce' ), 'content' => $this->settings->render() ),
            'logs'         => array( 'label' => __( 'Logs', 'mr-commerce' ), 'content' => $this->pro_content( 'payment.reports', __( 'Payment Logs', 'mr-commerce' ), fn (): string => $this->logs_content() ) ),
        );
    }

    private function pro_content( string $feature, string $title, callable $content ): string {
        if ( ProFeature::allowed( $feature ) ) {
            return (string) $content();
        }

        ob_start();
        ProFeature::render(
            $feature,
            $title,
            __( 'Use the dedicated Pro workflow while all existing payment records remain safely stored.', 'mr-commerce' ),
            array(
                __( 'Purpose-built administration workflow', 'mr-commerce' ),
                __( 'Complete history and operational reporting', 'mr-commerce' ),
                __( 'Settings and records return automatically after Pro activation', 'mr-commerce' ),
            )
        );
        return (string) ob_get_clean();
    }

    private function gateway_limit_preview(): string {
        if ( ProFeature::allowed( 'payment.unlimited_gateways' ) ) {
            return '';
        }

        ob_start();
        ProFeature::render(
            'payment.unlimited_gateways',
            __( 'Unlimited Payment Methods', 'mr-commerce' ),
            __( 'Free checkout uses the first enabled gateway. Upgrade to offer all configured mobile and bank methods.', 'mr-commerce' ),
            array(
                __( 'Unlimited enabled gateways', 'mr-commerce' ),
                __( 'Dynamic mobile and bank gateway definitions', 'mr-commerce' ),
                __( 'Existing extra gateways stay saved during Free mode', 'mr-commerce' ),
            )
        );
        return (string) ob_get_clean();
    }

    private function routes(): array {
        return array(
            'mrbp-payment-center-requests'     => array( 'label' => __( 'Payment Requests', 'mr-commerce' ), 'callback' => 'render_requests' ),
            'mrbp-payment-center-transactions' => array( 'label' => __( 'Transactions', 'mr-commerce' ), 'callback' => 'render_transactions' ),
            'mrbp-payment-center-gateways'     => array( 'label' => __( 'Gateways', 'mr-commerce' ), 'callback' => 'render_gateways' ),
            'mrbp-payment-center-reports'      => array( 'label' => __( 'Reports', 'mr-commerce' ), 'callback' => 'render_reports' ),
            'mrbp-payment-center-settings'     => array( 'label' => __( 'Settings', 'mr-commerce' ), 'callback' => 'render_settings' ),
            'mrbp-payment-center-logs'         => array( 'label' => __( 'Logs', 'mr-commerce' ), 'callback' => 'render_logs' ),
        );
    }

    private function navigation_items(): array {
        return array(
            'dashboard'    => array( 'label' => __( 'Dashboard', 'mr-commerce' ), 'slug' => self::PARENT_SLUG, 'icon' => 'dashicons-dashboard' ),
            'requests'     => array( 'label' => __( 'Payment Requests', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-requests', 'icon' => 'dashicons-list-view' ),
            'transactions' => array( 'label' => __( 'Transactions', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-transactions', 'icon' => 'dashicons-media-spreadsheet' ),
            'gateways'     => array( 'label' => __( 'Gateways', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-gateways', 'icon' => 'dashicons-admin-settings' ),
            'reports'      => array( 'label' => __( 'Reports', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-reports', 'icon' => 'dashicons-chart-bar' ),
            'settings'     => array( 'label' => __( 'Settings', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-settings', 'icon' => 'dashicons-admin-generic' ),
            'logs'         => array( 'label' => __( 'Logs', 'mr-commerce' ), 'slug' => 'mrbp-payment-center-logs', 'icon' => 'dashicons-text-page' ),
        );
    }

    private function label_for( string $active ): string {
        $labels = array(
            'dashboard' => __( 'Dashboard', 'mr-commerce' ), 'requests' => __( 'Payment Requests', 'mr-commerce' ),
            'transactions' => __( 'Transactions', 'mr-commerce' ), 'gateways' => __( 'Gateways', 'mr-commerce' ),
            'reports' => __( 'Reports', 'mr-commerce' ), 'settings' => __( 'Settings', 'mr-commerce' ), 'logs' => __( 'Logs', 'mr-commerce' ),
        );
        return $labels[ $active ] ?? $labels['dashboard'];
    }

    private function logs_content(): string {
        return '<div class="mrbp-ui-notice mrbp-ui-notice--info"><p>' . esc_html__( 'Payment Center events use the central MR Commerce Pro logger. Debug logging can be enabled in Advanced Settings.', 'mr-commerce' ) . '</p></div>';
    }
}
