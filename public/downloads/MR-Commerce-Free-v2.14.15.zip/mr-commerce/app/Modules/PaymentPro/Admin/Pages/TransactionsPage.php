<?php

namespace MRBP\Modules\PaymentPro\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Admin\Components\Table;
use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;
use MRBP\Modules\PaymentPro\Services\TransactionManager;

final class TransactionsPage {

    private TransactionManager $transactions;
    private PaymentRequestRepository $requests;

    public function __construct( ?TransactionManager $transactions = null, ?PaymentRequestRepository $requests = null ) {
        $this->transactions = $transactions ?? new TransactionManager();
        $this->requests     = $requests ?? new PaymentRequestRepository();
    }

    public function render(): string {
        $rows = array();

        $this->backfill_legacy_requests();

        foreach ( $this->transactions->recent( 50 ) as $record ) {
            $order_id     = absint( $record['order_id'] ?? 0 );
            $order        = $order_id > 0 && function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
            $order_number = $order && is_callable( array( $order, 'get_order_number' ) )
                ? (string) $order->get_order_number()
                : (string) $order_id;
            $rows[] = array(
                'id'          => esc_html( (string) ( $record['id'] ?? '' ) ),
                'order'       => '#' . esc_html( $order_number ),
                'gateway'     => esc_html( strtoupper( (string) ( $record['gateway'] ?? '' ) ) ),
                'transaction' => esc_html( (string) ( $record['transaction_id'] ?? '' ) ),
                'status'      => '<span class="mrbp-ui-badge mrbp-ui-badge--info">' . esc_html( (string) ( $record['status'] ?? 'pending' ) ) . '</span>',
                'amount'      => esc_html( (string) ( $record['amount'] ?? '0.00' ) . ' ' . (string) ( $record['currency'] ?? 'BDT' ) ),
                'created'     => esc_html( (string) ( $record['created_at'] ?? '' ) ),
            );
        }

        ob_start();
        Table::make(
            array(
                'id'          => __( 'ID', 'mr-commerce' ),
                'order'       => __( 'Order', 'mr-commerce' ),
                'gateway'     => __( 'Gateway', 'mr-commerce' ),
                'transaction' => __( 'Transaction ID', 'mr-commerce' ),
                'status'      => __( 'Status', 'mr-commerce' ),
                'amount'      => __( 'Amount', 'mr-commerce' ),
                'created'     => __( 'Created', 'mr-commerce' ),
            ),
            $rows,
            __( 'No gateway transaction records have been created.', 'mr-commerce' )
        )->render();

        return (string) ob_get_clean();
    }

    /** Backfill existing requests once; new requests are synchronized at write time. */
    private function backfill_legacy_requests(): void {
        $backfill_key = 'mrbp_transactions_backfilled_1_3_6';
        if ( get_option( $backfill_key, false ) ) {
            return;
        }

        $page = 1;
        $backfill_complete = true;
        do {
            $result = $this->requests->search(
                array(
                    'page'     => $page,
                    'per_page' => 100,
                )
            );

            foreach ( $result['items'] as $request ) {
                $request_id = absint( $request['request_id'] ?? $request['id'] ?? 0 );
                if ( $request_id > 0 ) {
                    if ( $this->transactions->sync_payment_request( $request_id, $request ) < 1 ) {
                        $backfill_complete = false;
                    }
                }
            }

            $page++;
            $pages = max( 1, absint( $result['pages'] ?? 1 ) );
        } while ( $page <= $pages );

        if ( $backfill_complete ) {
            update_option( $backfill_key, current_time( 'mysql', true ), false );
        }
    }
}
