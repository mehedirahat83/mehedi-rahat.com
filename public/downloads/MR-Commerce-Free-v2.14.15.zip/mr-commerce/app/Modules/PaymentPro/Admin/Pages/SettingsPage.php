<?php

namespace MRBP\Modules\PaymentPro\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;
use MRBP\Admin\ProFeature;

final class SettingsPage {

    private ManualGatewaySettings $settings;

    public function __construct( ?ManualGatewaySettings $settings = null ) {
        $this->settings = $settings ?? new ManualGatewaySettings();
    }

    public function render(): string {
        $general = $this->settings->general();
        $option = $this->settings->option_name();

        ob_start();
        ?>
        <form method="post" action="options.php" class="mrbp-ui-form">
            <?php settings_fields( $this->settings->group_name() ); ?>
            <section class="mrbp-ui-card">
                <div class="mrbp-ui-card__header">
                    <div>
                        <h3><?php esc_html_e( 'Payment Experience Settings', 'mr-commerce' ); ?></h3>
                        <p><?php esc_html_e( 'Configure checkout branding, initial order status and the status applied after manual verification.', 'mr-commerce' ); ?></p>
                    </div>
                    <span class="mrbp-ui-badge mrbp-ui-badge--info"><?php esc_html_e( 'RC Ready', 'mr-commerce' ); ?></span>
                </div>
                <div class="mrbp-settings-grid">
                    <div class="mrbp-settings-field"><label><?php esc_html_e( 'Brand Name', 'mr-commerce' ); ?></label><input type="text" class="regular-text" name="<?php echo esc_attr( $option ); ?>[general][brand_name]" value="<?php echo esc_attr( (string) $general['brand_name'] ); ?>"></div>
                    <div class="mrbp-settings-field"><label><?php esc_html_e( 'Tagline', 'mr-commerce' ); ?></label><input type="text" class="regular-text" name="<?php echo esc_attr( $option ); ?>[general][tagline]" value="<?php echo esc_attr( (string) $general['tagline'] ); ?>"></div>
                    <div class="mrbp-settings-field"><label><?php esc_html_e( 'Support Phone', 'mr-commerce' ); ?></label><input type="text" class="regular-text" name="<?php echo esc_attr( $option ); ?>[general][support_phone]" value="<?php echo esc_attr( (string) $general['support_phone'] ); ?>"></div>
                    <div class="mrbp-settings-field"><label><?php esc_html_e( 'WhatsApp Number', 'mr-commerce' ); ?></label><input type="text" class="regular-text" name="<?php echo esc_attr( $option ); ?>[general][whatsapp_number]" value="<?php echo esc_attr( (string) $general['whatsapp_number'] ); ?>"></div>
                    <div class="mrbp-settings-field"><label><?php esc_html_e( 'Popup Title', 'mr-commerce' ); ?></label><input type="text" class="regular-text" name="<?php echo esc_attr( $option ); ?>[general][popup_title]" value="<?php echo esc_attr( (string) $general['popup_title'] ); ?>"></div>
                    <div class="mrbp-settings-field"><label><?php esc_html_e( 'Accent Color', 'mr-commerce' ); ?></label><input type="color" name="<?php echo esc_attr( $option ); ?>[general][accent_color]" value="<?php echo esc_attr( (string) $general['accent_color'] ); ?>"></div>
                </div>
                <div class="mrbp-settings-field"><label><?php esc_html_e( 'Footer Note', 'mr-commerce' ); ?></label><textarea rows="4" class="large-text" name="<?php echo esc_attr( $option ); ?>[general][footer_note]"><?php echo esc_textarea( (string) $general['footer_note'] ); ?></textarea></div>
                <?php if ( ProFeature::allowed( 'payment.verification' ) ) : ?>
                <div class="mrbp-settings-field mrbp-initial-status-setting">
                    <label><?php esc_html_e( 'Initial Order Status', 'mr-commerce' ); ?></label>
                    <select name="<?php echo esc_attr( $option ); ?>[general][initial_order_status]">
                        <option value="on-hold" <?php selected( (string) ( $general['initial_order_status'] ?? 'on-hold' ), 'on-hold' ); ?>><?php esc_html_e( 'On Hold (Default)', 'mr-commerce' ); ?></option>
                        <option value="processing" <?php selected( (string) ( $general['initial_order_status'] ?? 'on-hold' ), 'processing' ); ?>><?php esc_html_e( 'Processing', 'mr-commerce' ); ?></option>
                        <option value="mrbp-verification" <?php selected( (string) ( $general['initial_order_status'] ?? 'on-hold' ), 'mrbp-verification' ); ?>><?php esc_html_e( 'Pending Payment Verification', 'mr-commerce' ); ?></option>
                    </select>
                    <p class="description"><?php esc_html_e( 'Choose the status applied immediately after customers submit manual payment details at checkout.', 'mr-commerce' ); ?></p>
                    <div class="mrbp-ui-notice mrbp-ui-notice--warning"><p><?php esc_html_e( 'Processing may trigger fulfilment, shipping, downloads, licences or other automations before an administrator verifies the payment.', 'mr-commerce' ); ?></p></div>
                </div>
                <div class="mrbp-settings-field">
                    <label><?php esc_html_e( 'After Verification', 'mr-commerce' ); ?></label>
                    <select name="<?php echo esc_attr( $option ); ?>[general][after_verification_status]">
                        <option value="processing" <?php selected( (string) ( $general['after_verification_status'] ?? 'processing' ), 'processing' ); ?>><?php esc_html_e( 'Processing', 'mr-commerce' ); ?></option>
                        <option value="completed" <?php selected( (string) ( $general['after_verification_status'] ?? 'processing' ), 'completed' ); ?>><?php esc_html_e( 'Completed', 'mr-commerce' ); ?></option>
                    </select>
                    <p class="description"><?php esc_html_e( 'Choose the WooCommerce order status applied after a manual payment is verified.', 'mr-commerce' ); ?></p>
                </div>
                <?php else : ?>
                    <?php
                    ProFeature::render(
                        'payment.verification',
                        __( 'Payment Verification Workflow', 'mr-commerce' ),
                        __( 'Free keeps submitted manual-payment orders safely on hold. Pro unlocks verification queues and automatic post-verification status changes.', 'mr-commerce' )
                    );
                    ?>
                <?php endif; ?>
                <div class="mrbp-ui-notice mrbp-ui-notice--info"><p><?php esc_html_e( 'Manual payment details are collected directly in checkout. Orders keep the selected initial status until an administrator verifies the payment.', 'mr-commerce' ); ?></p></div>
            </section>
            <?php submit_button( __( 'Save Payment Settings', 'mr-commerce' ) ); ?>
        </form>
        <?php
        return (string) ob_get_clean();
    }
}
