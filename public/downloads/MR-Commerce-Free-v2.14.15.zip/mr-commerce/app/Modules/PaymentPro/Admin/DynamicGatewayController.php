<?php

namespace MRBP\Modules\PaymentPro\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\DynamicGatewayManager;
use MRBP\Modules\PaymentPro\Services\GatewayRegistry;
use MRBP\Admin\ProFeature;

final class DynamicGatewayController {

    private DynamicGatewayManager $manager;
    private GatewayRegistry $registry;

    public function __construct( ?DynamicGatewayManager $manager = null, ?GatewayRegistry $registry = null ) {
        $this->manager  = $manager ?? new DynamicGatewayManager();
        $this->registry = $registry ?? new GatewayRegistry( $this->manager );
    }

    public function register(): void {
        add_action( 'admin_post_mrbp_save_dynamic_gateway', array( $this, 'save' ) );
    }

    public function save(): void {
        $this->authorize( 'mrbp_save_dynamic_gateway' );
        ProFeature::deny_action( 'payment.unlimited_gateways', __( 'Creating custom payment gateways requires MR Commerce Pro.', 'mr-commerce' ) );
        $gateway_id = $this->manager->upsert( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
        $status     = '' !== $gateway_id ? 'saved' : 'invalid';
        wp_safe_redirect( add_query_arg( array( 'page' => 'mrbp-payment-center-gateways', 'mrbp_gateway_notice' => $status ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function authorize( string $nonce_action ): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You are not allowed to manage payment gateways.', 'mr-commerce' ) );
        }
        check_admin_referer( $nonce_action );
    }
}
