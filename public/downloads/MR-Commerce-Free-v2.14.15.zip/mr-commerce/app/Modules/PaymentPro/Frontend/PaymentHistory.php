<?php

namespace MRBP\Modules\PaymentPro\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;

final class PaymentHistory {

    private const ENDPOINT = 'payment-history';
    private PaymentRequestRepository $repository;
    private GatewayCatalog $gateways;

    public function __construct( ?PaymentRequestRepository $repository = null ) {
        $this->repository = $repository ?? new PaymentRequestRepository();
        $this->gateways   = function_exists( 'mrbp' ) ? mrbp()->gateways() : new GatewayCatalog();
    }

    public function register(): void {
        add_action( 'init', array( $this, 'register_endpoint' ) );
        add_filter( 'woocommerce_account_menu_items', array( $this, 'add_menu_item' ), 45 );
        add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( $this, 'render_account_page' ) );
        add_shortcode( 'mrbp_payment_history', array( $this, 'shortcode' ) );
        add_action( 'admin_init', array( $this, 'maybe_flush_rewrite_rules' ) );
    }

    public function register_endpoint(): void {
        add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
    }

    public function add_menu_item( array $items ): array {
        if ( ! is_user_logged_in() ) {
            return $items;
        }

        $logout = $items['customer-logout'] ?? null;
        unset( $items['customer-logout'] );
        $items[ self::ENDPOINT ] = __( 'Payments', 'mr-commerce' );
        if ( null !== $logout ) {
            $items['customer-logout'] = $logout;
        }
        return $items;
    }

    public function render_account_page(): void {
        echo $this->render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes dynamic values.
    }

    public function shortcode(): string {
        return $this->render();
    }

    public function maybe_flush_rewrite_rules(): void {
        $version = '1.0.0';
        if ( get_option( 'mrbp_payment_history_rewrite_version' ) === $version ) {
            return;
        }
        flush_rewrite_rules( false );
        update_option( 'mrbp_payment_history_rewrite_version', $version, false );
    }

    private function render(): string {
        wp_enqueue_style( 'mrbp-design-tokens', MRBP_URL . 'assets/css/design-tokens.css', array(), MRBP_VERSION );
        wp_enqueue_style( 'mrbp-payment-popup', MRBP_URL . 'app/Modules/PaymentPro/Assets/css/payment-popup.css', array( 'mrbp-design-tokens' ), MRBP_VERSION );

        if ( ! is_user_logged_in() ) {
            return '<div class="mrbp-payment-history-empty">' . esc_html__( 'Please log in to view your payment history.', 'mr-commerce' ) . '</div>';
        }

        $rows = $this->repository->for_user( get_current_user_id(), 50 );

        ob_start();
        ?>
        <section class="mrbp-payment-history">
            <div class="mrbp-payment-history__header">
                <div>
                    <span><?php esc_html_e( 'Payment Center', 'mr-commerce' ); ?></span>
                    <h2><?php esc_html_e( 'Payment History', 'mr-commerce' ); ?></h2>
                </div>
                <p><?php esc_html_e( 'Track submitted manual payments and their verification status.', 'mr-commerce' ); ?></p>
            </div>

            <?php if ( empty( $rows ) ) : ?>
                <div class="mrbp-payment-history-empty">
                    <strong><?php esc_html_e( 'No payments submitted yet', 'mr-commerce' ); ?></strong>
                    <p><?php esc_html_e( 'Your manual payment submissions will appear here.', 'mr-commerce' ); ?></p>
                </div>
            <?php else : ?>
                <div class="mrbp-payment-history-list">
                    <?php foreach ( $rows as $row ) :
                        $order = wc_get_order( absint( $row['order_id'] ?? 0 ) );
                        $status = sanitize_key( (string) ( $row['status'] ?? 'submitted' ) );
                        ?>
                        <article class="mrbp-payment-history-card">
                            <div class="mrbp-payment-history-card__top">
                                <div>
                                    <small><?php esc_html_e( 'Order', 'mr-commerce' ); ?></small>
                                    <strong>#<?php echo esc_html( $order ? $order->get_order_number() : (string) ( $row['order_id'] ?? 0 ) ); ?></strong>
                                </div>
                                <span class="mrbp-payment-status mrbp-payment-status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $status ) ) ); ?></span>
                            </div>
                            <dl>
                                <div><dt><?php esc_html_e( 'Method', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( $this->gateways->label( (string) ( $row['gateway'] ?? '' ) ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Amount', 'mr-commerce' ); ?></dt><dd><?php echo wp_kses_post( wc_price( (float) ( $row['amount'] ?? 0 ), array( 'currency' => (string) ( $row['currency'] ?? 'BDT' ) ) ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Transaction ID', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( (string) ( $row['transaction_id'] ?? '' ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Submitted', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( $this->format_date( (string) ( $row['submitted_at'] ?? '' ) ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Verified', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( 'verified' === $status ? $this->format_date( (string) ( $row['reviewed_at'] ?? '' ) ) : '—' ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Timeline', 'mr-commerce' ); ?></dt><dd><?php echo wp_kses_post( $this->timeline( $status, $order ) ); ?></dd></div>
                            </dl>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    private function timeline( string $status, $order ): string {
        $steps = array(
            'submitted' => __( 'Submitted', 'mr-commerce' ),
        );

        if ( 'under_review' === $status ) {
            $steps['under_review'] = __( 'Under Review', 'mr-commerce' );
        } elseif ( 'verified' === $status ) {
            $steps['verified'] = __( 'Verified', 'mr-commerce' );
            if ( $order && ! $order instanceof \WC_Order_Refund ) {
                $steps[ sanitize_key( (string) $order->get_status() ) ] = wc_get_order_status_name( $order->get_status() );
            }
        } elseif ( 'rejected' === $status ) {
            $steps['rejected'] = __( 'Rejected', 'mr-commerce' );
        }

        $labels = array_map( 'esc_html', array_values( $steps ) );
        return '<span class="mrbp-payment-timeline">' . implode( ' <b aria-hidden="true">→</b> ', $labels ) . '</span>';
    }

    private function format_date( string $date ): string {
        if ( '' === $date ) {
            return '—';
        }
        $timestamp = strtotime( $date . ' UTC' );
        return $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : $date;
    }
}
