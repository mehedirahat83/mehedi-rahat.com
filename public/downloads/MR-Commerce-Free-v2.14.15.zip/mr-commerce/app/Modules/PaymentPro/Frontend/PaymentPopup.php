<?php

namespace MRBP\Modules\PaymentPro\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;
use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;
use MRBP\Modules\PaymentPro\Services\GatewayRegistry;

final class PaymentPopup {

    private ManualGatewaySettings $settings;
    private PaymentRequestRepository $repository;
    private GatewayRegistry $registry;
    private bool $assets_enqueued = false;

    public function __construct(
        ?ManualGatewaySettings $settings = null,
        ?PaymentRequestRepository $repository = null
    ) {
        $this->registry   = new GatewayRegistry();
        $this->settings   = $settings ?? new ManualGatewaySettings( $this->registry );
        $this->repository = $repository ?? new PaymentRequestRepository();
    }

    public function register(): void {
        add_shortcode( 'mrbp_payment_center', array( $this, 'shortcode' ) );
        add_action( 'woocommerce_thankyou', array( $this, 'render_for_order' ), 25 );
    }

    public function shortcode( array $atts = array() ): string {
        $atts = shortcode_atts(
            array(
                'order_id'  => 0,
                'amount'    => '',
                'reference' => '',
                'button'    => __( 'Complete Payment', 'mr-commerce' ),
            ),
            $atts,
            'mrbp_payment_center'
        );

        $order = $this->resolve_order( absint( $atts['order_id'] ) );

        if ( $order && ! $this->can_view_order( $order ) ) {
            return '';
        }

        $amount    = $order ? (float) $order->get_total() : (float) wc_format_decimal( (string) $atts['amount'] );
        $currency  = $order ? $order->get_currency() : get_woocommerce_currency();
        $reference = $order ? sprintf( 'Order #%s', $order->get_order_number() ) : sanitize_text_field( (string) $atts['reference'] );

        return $this->render(
            $amount,
            $currency,
            $reference,
            sanitize_text_field( (string) $atts['button'] ),
            $order ? $order->get_id() : 0,
            $order ? $order->get_order_key() : ''
        );
    }

    public function render_for_order( int $order_id ): void {
        $order = wc_get_order( $order_id );

        if (
            ! $order
            || $order instanceof \WC_Order_Refund
            || $order->is_paid()
            || \MRBP\Modules\PaymentPro\WooCommerce\ManualPaymentGateway::ID !== $order->get_payment_method()
            || ! $this->can_view_order( $order )
        ) {
            return;
        }

        echo $this->render( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Renderer escapes all dynamic values.
            (float) $order->get_total(),
            (string) $order->get_currency(),
            sprintf( 'Order #%s', $order->get_order_number() ),
            __( 'Pay with MR Payment Pro', 'mr-commerce' ),
            $order->get_id(),
            $order->get_order_key()
        );
    }

    private function render(
        float $amount,
        string $currency,
        string $reference,
        string $button_label,
        int $order_id,
        string $order_key
    ): string {
        $gateways = $this->settings->enabled_gateways();
        $general  = $this->settings->general();

        if ( empty( $gateways ) ) {
            if ( current_user_can( 'manage_woocommerce' ) ) {
                return '<div class="mrbp-payment-setup-notice">' . esc_html__( 'Configure at least one manual gateway in Payment Center → Gateways to preview the payment popup.', 'mr-commerce' ) . '</div>';
            }
            return '';
        }

        $this->enqueue_assets( (string) ( $general['accent_color'] ?? '#1e8a8a' ) );
        $modal_id = 'mrbp-payment-modal-' . wp_unique_id();
        $first_id = (string) array_key_first( $gateways );
        if ( $order_id > 0 ) {
            $order = wc_get_order( $order_id );
            $preferred_gateway = $order ? sanitize_key( (string) $order->get_meta( '_mrbp_preferred_gateway', true ) ) : '';
            if ( '' !== $preferred_gateway && isset( $gateways[ $preferred_gateway ] ) ) {
                $first_id = $preferred_gateway;
            }
        }
        $existing = $order_id > 0 ? $this->repository->latest_for_order( $order_id ) : null;
        $open_statuses = array( 'pending', 'submitted', 'under_review' );
        $has_open_request = $existing && in_array( (string) ( $existing['status'] ?? '' ), $open_statuses, true );

        ob_start();
        ?>
        <div class="mrbp-payment-launcher" data-mrbp-payment-launcher>
            <button type="button" class="mrbp-payment-open" data-mrbp-payment-open="<?php echo esc_attr( $modal_id ); ?>">
                <?php echo esc_html( $button_label ); ?>
            </button>
        </div>

        <div id="<?php echo esc_attr( $modal_id ); ?>" class="mrbp-payment-modal" hidden aria-hidden="true"<?php echo ( $order_id > 0 && ! $has_open_request ) ? ' data-mrbp-auto-open="1"' : ''; ?>>
            <div class="mrbp-payment-backdrop" data-mrbp-payment-close></div>
            <section class="mrbp-payment-dialog" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $modal_id ); ?>-title">
                <header class="mrbp-payment-dialog__header">
                    <button type="button" class="mrbp-payment-icon-button" data-mrbp-payment-back aria-label="<?php esc_attr_e( 'Go back', 'mr-commerce' ); ?>">&larr;</button>
                    <div class="mrbp-payment-brand">
                        <span class="mrbp-payment-brand__mark">MR</span>
                        <div>
                            <strong><?php echo esc_html( (string) ( $general['brand_name'] ?? get_bloginfo( 'name' ) ) ); ?></strong>
                            <small><?php echo esc_html( (string) ( $general['tagline'] ?? '' ) ); ?></small>
                        </div>
                    </div>
                    <button type="button" class="mrbp-payment-icon-button" data-mrbp-payment-close aria-label="<?php esc_attr_e( 'Close payment window', 'mr-commerce' ); ?>">&times;</button>
                </header>

                <div class="mrbp-payment-support">
                    <?php if ( ! empty( $general['whatsapp_number'] ) ) : ?>
                        <a href="<?php echo esc_url( 'https://wa.me/' . preg_replace( '/\D+/', '', (string) $general['whatsapp_number'] ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'WhatsApp', 'mr-commerce' ); ?></a>
                    <?php endif; ?>
                    <?php if ( ! empty( $general['support_phone'] ) ) : ?>
                        <a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', (string) $general['support_phone'] ) ); ?>"><?php esc_html_e( 'Call', 'mr-commerce' ); ?></a>
                    <?php endif; ?>
                    <span><?php esc_html_e( 'Secure Payment', 'mr-commerce' ); ?></span>
                </div>

                <div class="mrbp-payment-dialog__body">
                    <div class="mrbp-payment-progress" aria-label="<?php esc_attr_e( 'Payment progress', 'mr-commerce' ); ?>">
                        <span class="is-active" data-mrbp-progress="1">1</span>
                        <i></i>
                        <span data-mrbp-progress="2">2</span>
                    </div>

                    <?php if ( $has_open_request ) : ?>
                        <div class="mrbp-payment-submitted-state">
                            <span class="mrbp-payment-submitted-state__icon">✓</span>
                            <h2><?php esc_html_e( 'Payment Already Submitted', 'mr-commerce' ); ?></h2>
                            <p><?php esc_html_e( 'This order already has a payment request awaiting review.', 'mr-commerce' ); ?></p>
                            <dl>
                                <div><dt><?php esc_html_e( 'Transaction ID', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( (string) ( $existing['transaction_id'] ?? '' ) ); ?></dd></div>
                                <div><dt><?php esc_html_e( 'Status', 'mr-commerce' ); ?></dt><dd><?php echo esc_html( ucwords( str_replace( '_', ' ', (string) ( $existing['status'] ?? 'submitted' ) ) ) ); ?></dd></div>
                            </dl>
                        </div>
                    <?php else : ?>
                        <div data-mrbp-payment-step="1">
                            <div class="mrbp-payment-heading">
                                <span><?php esc_html_e( 'Payment Methods', 'mr-commerce' ); ?></span>
                                <h2 id="<?php echo esc_attr( $modal_id ); ?>-title"><?php echo esc_html( (string) ( $general['popup_title'] ?? __( 'Complete Your Payment', 'mr-commerce' ) ) ); ?></h2>
                            </div>

                            <div class="mrbp-payment-gateways" role="tablist" aria-label="<?php esc_attr_e( 'Payment methods', 'mr-commerce' ); ?>">
                                <?php foreach ( $gateways as $gateway_id => $gateway ) : ?>
                                    <?php
                                    $definition = $this->registry->get( (string) $gateway_id );
                                    $logo_url   = $this->registry->logo_url( (string) $gateway_id );
                                    ?>
                                    <button type="button" class="mrbp-payment-gateway<?php echo $gateway_id === $first_id ? ' is-active' : ''; ?>"
                                        data-mrbp-gateway="<?php echo esc_attr( $gateway_id ); ?>"
                                        data-mrbp-gateway-type="<?php echo esc_attr( (string) ( $definition['type'] ?? 'mobile' ) ); ?>"
                                        data-mrbp-sender-label="<?php echo esc_attr( (string) ( $definition['sender_label'] ?? __( 'Sender Account / Mobile Number', 'mr-commerce' ) ) ); ?>"
                                        data-mrbp-sender-help="<?php echo esc_attr( (string) ( $definition['sender_help'] ?? '' ) ); ?>"
                                        data-mrbp-sender-placeholder="<?php echo esc_attr( (string) ( $definition['sender_placeholder'] ?? '' ) ); ?>"
                                        aria-selected="<?php echo $gateway_id === $first_id ? 'true' : 'false'; ?>">
                                        <span class="mrbp-payment-gateway__logo"><img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( (string) $gateway['label'] ); ?>"></span>
                                        <?php echo esc_html( (string) $gateway['label'] ); ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>

                            <div class="mrbp-payment-summary">
                                <span><?php esc_html_e( 'Amount to pay', 'mr-commerce' ); ?></span>
                                <strong><?php echo wp_kses_post( wc_price( $amount, array( 'currency' => $currency ) ) ); ?></strong>
                                <?php if ( '' !== $reference ) : ?><small><?php echo esc_html( $reference ); ?></small><?php endif; ?>
                            </div>

                            <?php foreach ( $gateways as $gateway_id => $gateway ) : ?>
                                <div class="mrbp-payment-panel<?php echo $gateway_id === $first_id ? ' is-active' : ''; ?>" data-mrbp-panel="<?php echo esc_attr( $gateway_id ); ?>"<?php echo $gateway_id === $first_id ? '' : ' hidden'; ?>>
                                    <div class="mrbp-payment-detail">
                                        <span><?php echo esc_html( (string) ( $this->registry->get( (string) $gateway_id )['account_label'] ?? __( 'Account Number', 'mr-commerce' ) ) ); ?></span>
                                        <strong><?php echo esc_html( (string) $gateway['account_number'] ); ?></strong>
                                        <button type="button" class="mrbp-payment-copy" data-mrbp-copy="<?php echo esc_attr( (string) $gateway['account_number'] ); ?>"><?php esc_html_e( 'Copy', 'mr-commerce' ); ?></button>
                                    </div>
                                    <?php if ( ! empty( $gateway['account_name'] ) ) : ?><div class="mrbp-payment-meta"><span><?php esc_html_e( 'Account Name', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) $gateway['account_name'] ); ?></strong></div><?php endif; ?>
                                    <div class="mrbp-payment-meta"><span><?php esc_html_e( 'Account Type', 'mr-commerce' ); ?></span><strong><?php echo esc_html( ucfirst( (string) $gateway['account_type'] ) ); ?></strong></div>
                                    <?php if ( $this->registry->is_bank( (string) $gateway_id ) ) : ?>
                                        <?php if ( ! empty( $gateway['branch_name'] ) ) : ?><div class="mrbp-payment-meta"><span><?php esc_html_e( 'Branch', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) $gateway['branch_name'] ); ?></strong></div><?php endif; ?>
                                        <?php if ( ! empty( $gateway['routing_number'] ) ) : ?><div class="mrbp-payment-meta"><span><?php esc_html_e( 'Routing Number', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) $gateway['routing_number'] ); ?></strong></div><?php endif; ?>
                                        <?php if ( ! empty( $gateway['swift_code'] ) ) : ?><div class="mrbp-payment-meta"><span><?php esc_html_e( 'SWIFT Code', 'mr-commerce' ); ?></span><strong><?php echo esc_html( (string) $gateway['swift_code'] ); ?></strong></div><?php endif; ?>
                                    <?php endif; ?>
                                    <?php if ( '' !== $reference ) : ?>
                                        <div class="mrbp-payment-detail mrbp-payment-detail--reference"><span><?php esc_html_e( 'Reference', 'mr-commerce' ); ?></span><strong><?php echo esc_html( $reference ); ?></strong><button type="button" class="mrbp-payment-copy" data-mrbp-copy="<?php echo esc_attr( $reference ); ?>"><?php esc_html_e( 'Copy', 'mr-commerce' ); ?></button></div>
                                    <?php endif; ?>
                                    <div class="mrbp-payment-instructions"><strong><?php echo esc_html( sprintf( __( 'How to pay with %s', 'mr-commerce' ), (string) $gateway['label'] ) ); ?></strong><p><?php echo esc_html( (string) $gateway['instructions'] ); ?></p></div>
                                </div>
                            <?php endforeach; ?>

                            <button type="button" class="mrbp-payment-continue" data-mrbp-continue<?php echo $order_id > 0 ? '' : ' disabled aria-disabled="true"'; ?>><?php esc_html_e( 'Continue to Submit Transaction', 'mr-commerce' ); ?></button>
                            <?php if ( 0 === $order_id ) : ?><p class="mrbp-payment-alpha-note"><?php esc_html_e( 'A WooCommerce order is required to submit payment information. This shortcode is currently in preview mode.', 'mr-commerce' ); ?></p><?php endif; ?>
                        </div>

                        <div data-mrbp-payment-step="2" hidden>
                            <div class="mrbp-payment-heading">
                                <span><?php esc_html_e( 'Payment Details', 'mr-commerce' ); ?></span>
                                <h2><?php esc_html_e( 'Submit Your Transaction', 'mr-commerce' ); ?></h2>
                            </div>
                            <div class="mrbp-payment-selected-summary"><span><?php esc_html_e( 'Selected method', 'mr-commerce' ); ?></span><strong data-mrbp-selected-gateway-label><?php echo esc_html( (string) $gateways[ $first_id ]['label'] ); ?></strong><small><?php echo wp_kses_post( wc_price( $amount, array( 'currency' => $currency ) ) ); ?> · <?php echo esc_html( $reference ); ?></small></div>

                            <form class="mrbp-payment-form" data-mrbp-payment-form novalidate>
                                <input type="hidden" name="action" value="mrbp_submit_manual_payment">
                                <input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'mrbp_manual_payment_submit' ) ); ?>">
                                <input type="hidden" name="order_id" value="<?php echo esc_attr( (string) $order_id ); ?>">
                                <input type="hidden" name="order_key" value="<?php echo esc_attr( $order_key ); ?>">
                                <input type="hidden" name="gateway" value="<?php echo esc_attr( $first_id ); ?>" data-mrbp-selected-gateway>

                                <?php $first_definition = $this->registry->get( $first_id ); ?>
                                <label><span data-mrbp-sender-label><?php echo esc_html( (string) ( $first_definition['sender_label'] ?? __( 'Sender Account / Mobile Number', 'mr-commerce' ) ) ); ?></span><input type="text" name="sender_phone" autocomplete="off" placeholder="<?php echo esc_attr( (string) ( $first_definition['sender_placeholder'] ?? '' ) ); ?>" required minlength="4" maxlength="30" pattern="[A-Za-z0-9+ -]{4,30}" aria-describedby="<?php echo esc_attr( $modal_id ); ?>-phone-help"><small id="<?php echo esc_attr( $modal_id ); ?>-phone-help" class="mrbp-payment-field-help" data-mrbp-sender-help><?php echo esc_html( (string) ( $first_definition['sender_help'] ?? '' ) ); ?></small></label>
                                <label><span><?php esc_html_e( 'Transaction ID', 'mr-commerce' ); ?></span><input type="text" name="transaction_id" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Example: 9ABCD2345" required minlength="6" maxlength="40" pattern="[A-Za-z0-9-]{6,40}" aria-describedby="<?php echo esc_attr( $modal_id ); ?>-trx-help"><small id="<?php echo esc_attr( $modal_id ); ?>-trx-help" class="mrbp-payment-field-help"><?php esc_html_e( 'Use the transaction ID or bank transfer reference shown by your payment provider.', 'mr-commerce' ); ?></small></label>
                                <div class="mrbp-payment-form-message" data-mrbp-payment-message role="status" aria-live="polite" hidden></div>
                                <button type="submit" class="mrbp-payment-submit"><span><?php esc_html_e( 'Submit Payment', 'mr-commerce' ); ?></span><i aria-hidden="true"></i></button>
                            </form>
                        </div>

                        <div data-mrbp-payment-step="success" hidden>
                            <div class="mrbp-payment-submitted-state">
                                <span class="mrbp-payment-submitted-state__icon">✓</span>
                                <h2><?php esc_html_e( 'Payment Submitted Successfully', 'mr-commerce' ); ?></h2>
                                <p data-mrbp-success-message><?php esc_html_e( 'Your payment request has been received. We will verify it shortly.', 'mr-commerce' ); ?></p>
                                <dl class="mrbp-payment-success-details">
                                    <div><dt><?php esc_html_e( 'Transaction ID', 'mr-commerce' ); ?></dt><dd data-mrbp-success-transaction>—</dd></div>
                                    <div><dt><?php esc_html_e( 'Status', 'mr-commerce' ); ?></dt><dd data-mrbp-success-status><?php esc_html_e( 'Submitted', 'mr-commerce' ); ?></dd></div>
                                </dl>
                                <div class="mrbp-payment-success-actions">
                                    <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'payment-history' ) ); ?>" class="mrbp-payment-history-link"><?php esc_html_e( 'View Payment History', 'mr-commerce' ); ?></a>
                                    <button type="button" class="mrbp-payment-close-button" data-mrbp-payment-close><?php esc_html_e( 'Close', 'mr-commerce' ); ?></button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <p class="mrbp-payment-alpha-note"><?php echo esc_html( (string) ( $general['footer_note'] ?? '' ) ); ?></p>
                    <div class="mrbp-payment-toast" data-mrbp-payment-toast role="status" aria-live="polite" hidden></div>
                </div>
            </section>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private function enqueue_assets( string $accent_color ): void {
        if ( $this->assets_enqueued ) {
            return;
        }
        $this->assets_enqueued = true;

        wp_enqueue_style( 'mrbp-design-tokens', MRBP_URL . 'assets/css/design-tokens.css', array(), MRBP_VERSION );
        wp_enqueue_style( 'mrbp-payment-popup', MRBP_URL . 'app/Modules/PaymentPro/Assets/css/payment-popup.css', array( 'mrbp-design-tokens' ), MRBP_VERSION );
        wp_enqueue_script( 'mrbp-payment-popup', MRBP_URL . 'app/Modules/PaymentPro/Assets/js/payment-popup.js', array(), MRBP_VERSION, true );
        wp_add_inline_style( 'mrbp-payment-popup', ':root{--mrbp-payment-accent:' . esc_attr( $accent_color ) . ';}' );
        wp_localize_script(
            'mrbp-payment-popup',
            'MRBPPaymentPopup',
            array(
                'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
                'copied'     => __( 'Number copied', 'mr-commerce' ),
                'copy'       => __( 'Copy', 'mr-commerce' ),
                'submitting' => __( 'Submitting…', 'mr-commerce' ),
                'submit'     => __( 'Submit Payment', 'mr-commerce' ),
                'networkError' => __( 'Could not connect to the server. Please try again.', 'mr-commerce' ),
                'invalidPhone' => __( 'Enter a valid mobile number using 10 to 15 digits.', 'mr-commerce' ),
                'invalidTransaction' => __( 'Enter a valid transaction ID using 6 to 40 letters, numbers or hyphens.', 'mr-commerce' ),
            )
        );
    }

    private function resolve_order( int $order_id ) {
        if ( $order_id > 0 ) {
            return wc_get_order( $order_id );
        }
        $received_id = absint( get_query_var( 'order-received' ) );
        return $received_id > 0 ? wc_get_order( $received_id ) : false;
    }

    private function can_view_order( $order ): bool {
        if ( current_user_can( 'manage_woocommerce' ) ) {
            return true;
        }
        $customer_id = (int) $order->get_customer_id();
        if ( $customer_id > 0 ) {
            return is_user_logged_in() && get_current_user_id() === $customer_id;
        }
        $provided_key = isset( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : '';
        return '' !== $provided_key && hash_equals( (string) $order->get_order_key(), $provided_key );
    }
}
