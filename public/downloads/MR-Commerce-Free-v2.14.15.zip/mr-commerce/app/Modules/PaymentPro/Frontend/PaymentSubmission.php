<?php

namespace MRBP\Modules\PaymentPro\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\PaymentRequestService;

final class PaymentSubmission {

    private PaymentRequestService $service;

    public function __construct( ?PaymentRequestService $service = null ) {
        $this->service = $service ?? new PaymentRequestService();
    }

    public function register(): void {
        add_action( 'wp_ajax_mrbp_submit_manual_payment', array( $this, 'handle' ) );
        add_action( 'wp_ajax_nopriv_mrbp_submit_manual_payment', array( $this, 'handle' ) );
    }

    public function handle(): void {
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            wp_send_json_error( array( 'code' => 'method_not_allowed', 'message' => __( 'Invalid request method.', 'mr-commerce' ) ), 405 );
        }

        check_ajax_referer( 'mrbp_manual_payment_submit', 'nonce' );

        $order_id  = absint( $_POST['order_id'] ?? 0 );
        $order_key = isset( $_POST['order_key'] ) ? wc_clean( wp_unslash( $_POST['order_key'] ) ) : '';
        $order     = wc_get_order( $order_id );
        $transaction_id = isset( $_POST['transaction_id'] )
            ? strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', (string) wp_unslash( $_POST['transaction_id'] ) ) )
            : '';

        if ( ! $order || $order instanceof \WC_Order_Refund ) {
            wp_send_json_error( array( 'code' => 'invalid_order', 'message' => __( 'The order could not be found.', 'mr-commerce' ) ), 404 );
        }

        if ( ! $this->can_submit_for_order( $order, $order_key ) ) {
            wp_send_json_error( array( 'code' => 'forbidden', 'message' => __( 'You are not allowed to submit payment for this order.', 'mr-commerce' ) ), 403 );
        }

        $result = $this->service->submit(
            array(
                'order_id'       => $order_id,
                'gateway'        => sanitize_key( (string) wp_unslash( $_POST['gateway'] ?? '' ) ),
                'sender_phone'   => sanitize_text_field( (string) wp_unslash( $_POST['sender_phone'] ?? '' ) ),
                'transaction_id' => sanitize_text_field( $transaction_id ),
                'customer_note'  => sanitize_textarea_field( (string) wp_unslash( $_POST['customer_note'] ?? '' ) ),
            )
        );

        if ( empty( $result['success'] ) ) {
            $code = sanitize_key( (string) ( $result['code'] ?? 'submission_failed' ) );
            wp_send_json_error( array( 'code' => $code, 'message' => $this->message_for_code( $code ) ), 422 );
        }

        wp_send_json_success(
            array(
                'request_id' => absint( $result['request_id'] ?? 0 ),
                'status'     => 'submitted',
                'status_label' => __( 'Submitted', 'mr-commerce' ),
                'transaction_id' => $transaction_id,
                'message'    => __( 'Payment information submitted successfully. We will verify it shortly.', 'mr-commerce' ),
            )
        );
    }

    private function can_submit_for_order( $order, string $provided_key ): bool {
        if ( current_user_can( 'manage_woocommerce' ) ) {
            return true;
        }

        $customer_id = (int) $order->get_customer_id();
        if ( $customer_id > 0 ) {
            return is_user_logged_in() && get_current_user_id() === $customer_id;
        }

        return '' !== $provided_key && hash_equals( (string) $order->get_order_key(), $provided_key );
    }

    private function message_for_code( string $code ): string {
        $messages = array(
            'invalid_order'            => __( 'The order could not be found.', 'mr-commerce' ),
            'order_already_paid'       => __( 'This order is already marked as paid.', 'mr-commerce' ),
            'invalid_gateway'          => __( 'Please choose an available payment method.', 'mr-commerce' ),
            'invalid_phone'            => __( 'Enter a valid sender account or mobile number.', 'mr-commerce' ),
            'invalid_transaction_id'   => __( 'Enter a valid transaction ID with at least 6 letters or numbers.', 'mr-commerce' ),
            'duplicate_transaction_id' => __( 'This transaction ID has already been submitted.', 'mr-commerce' ),
            'open_request_exists'      => __( 'A payment request for this order is already awaiting review.', 'mr-commerce' ),
            'database_error'           => __( 'The payment request could not be saved. Please try again.', 'mr-commerce' ),
        );

        return $messages[ $code ] ?? __( 'Payment information could not be submitted. Please review the form and try again.', 'mr-commerce' );
    }
}
