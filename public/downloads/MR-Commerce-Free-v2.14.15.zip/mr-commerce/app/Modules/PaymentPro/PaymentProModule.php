<?php

namespace MRBP\Modules\PaymentPro;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Core\RequestContext;
use MRBP\Modules\ModuleInterface;
use MRBP\Modules\PaymentPro\Admin\PaymentCenterAdmin;
use MRBP\Modules\PaymentPro\Admin\VerificationDrawer;
use MRBP\Modules\PaymentPro\Admin\PaymentDecisionController;
use MRBP\Modules\PaymentPro\Admin\DynamicGatewayController;
use MRBP\Modules\PaymentPro\Database\Migrations;
use MRBP\Modules\PaymentPro\Frontend\PaymentHistory;
use MRBP\Modules\PaymentPro\Frontend\PaymentPopup;
use MRBP\Modules\PaymentPro\Frontend\PaymentSubmission;
use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;
use MRBP\Modules\PaymentPro\Services\GatewayRegistry;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;
use MRBP\Modules\PaymentPro\Services\PaymentLogger;
use MRBP\Modules\PaymentPro\Services\PaymentRequestService;
use MRBP\Modules\PaymentPro\Services\WooCommerceOrderSyncService;
use MRBP\Modules\PaymentPro\Webhooks\WebhookHandler;
use MRBP\Modules\PaymentPro\WooCommerce\GatewayRegistrar;
use MRBP\Modules\PaymentPro\WooCommerce\GatewayCashoutFee;
use MRBP\Modules\PaymentPro\WooCommerce\OrderStatusRegistrar;

final class PaymentProModule implements ModuleInterface {

    private bool $registered = false;
    private bool $booted = false;
    private array $services = array();

    public function id(): string { return 'payment_pro'; }
    public function name(): string { return __( 'MR Payment Center', 'mr-commerce' ); }
    public function description(): string { return __( 'Manual payment verification center with API-ready gateway architecture.', 'mr-commerce' ); }
    public function dependencies(): array { return array( 'woocommerce', 'openssl' ); }
    public function is_available(): bool { return class_exists( 'WooCommerce' ) && class_exists( 'WC_Payment_Gateway' ) && extension_loaded( 'openssl' ); }

    public function register(): void {
        if ( $this->registered ) { return; }
        $this->registered = true;

        // Only the small shared services are created during the global plugin boot.
        // Admin screens, drawers, gateway adapters and webhook services are loaded
        // later when their request context actually needs them.
        $registry        = new GatewayRegistry();
        $manual_settings = new ManualGatewaySettings( $registry );
        $gateways        = new GatewayCatalog( $registry, $manual_settings );
        $logger          = new PaymentLogger();
        $requests        = new PaymentRequestService( null, $logger, $manual_settings );

        $this->services = array(
            'manual_settings' => $manual_settings,
            'gateways'        => $gateways,
            'logger'          => $logger,
            'payment_requests'=> $requests,
            'gateway_registrar' => new GatewayRegistrar(),
            'order_status_registrar' => new OrderStatusRegistrar(),
        );

        if ( function_exists( 'mrbp' ) ) {
            mrbp()->container()->set( 'payment_gateways', $gateways );
        }

        do_action( 'mrbp/payment_pro/services_registered', $this->services, $this );
        do_action( 'mrbp/payment_pro/registered', $this );
    }

    public function boot(): void {
        if ( $this->booted ) { return; }
        $this->booted = true;

        $manual_settings = $this->services['manual_settings'];
        $logger          = $this->services['logger'];
        $requests        = $this->services['payment_requests'];

        // WooCommerce must know the gateway and the manual-verification status.
        $this->services['gateway_registrar']->register();
        $this->services['order_status_registrar']->register();
        ( new GatewayCashoutFee( $manual_settings ) )->register();

        // Lightweight public registrations preserve shortcode and account endpoint
        // compatibility while their assets/data are loaded only when rendered.
        // v1.0.0-rc.1: inline checkout remains active; CartFlows gateway grid polished to five columns.
        ( new PaymentHistory( $requests->repository() ) )->register();

        // The submission handler is registered only for its AJAX request.
        if ( RequestContext::is_payment_ajax() && 'mrbp_submit_manual_payment' === RequestContext::action() ) {
            ( new PaymentSubmission( $requests ) )->register();
        }

        // Order synchronization is needed only where decisions/background events run.
        if ( mrc_can( 'payment.verification' ) && ( is_admin() || RequestContext::is_ajax() || RequestContext::is_cron() || RequestContext::is_rest() ) ) {
            ( new WooCommerceOrderSyncService( $manual_settings, $logger ) )->register();
        }

        // Database migrations are never checked during ordinary frontend traffic.
        if ( ( is_admin() || RequestContext::is_cron() || RequestContext::is_cli() )
            && function_exists( 'mrbp' )
            && mrbp()->container()->has( 'migration_manager' ) ) {
            Migrations::register( mrbp()->container()->get( 'migration_manager' ) );
        }

        // Webhook foundation is loaded only for REST requests.
        if ( RequestContext::is_rest() ) {
            ( new WebhookHandler( $logger ) )->register();
        }

        if ( is_admin() ) {
            $manual_settings->register();
            ( new PaymentCenterAdmin( $manual_settings ) )->register();
            ( new DynamicGatewayController() )->register();

            // Drawer/controller code is restricted to Payment Center screens or
            // their AJAX calls instead of every wp-admin page.
            if ( mrc_can( 'payment.verification' ) && ( RequestContext::is_payment_admin_screen() || RequestContext::is_payment_ajax() ) ) {
                ( new VerificationDrawer() )->register();
                ( new PaymentDecisionController() )->register();
            }
        }

        do_action( 'mrbp/payment_pro/booted', $this );
    }
}
