<?php

namespace MRBP\Modules\PaymentPro\Webhooks;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\PaymentLogger;

final class WebhookHandler {

    private PaymentLogger $logger;

    public function __construct( ?PaymentLogger $logger = null ) {
        $this->logger = $logger ?? new PaymentLogger();
    }

    public function register(): void {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route(
            'mrbp/v1',
            '/payment/webhook/(?P<gateway>[a-z0-9_-]+)',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'handle' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'gateway' => array( 'sanitize_callback' => 'sanitize_key' ),
                ),
            )
        );
    }

    public function handle( \WP_REST_Request $request ): \WP_REST_Response {
        $gateway = sanitize_key( (string) $request['gateway'] );
        $this->logger->warning( 'Webhook received before gateway signature verification is implemented.', array( 'gateway' => $gateway ) );

        return new \WP_REST_Response(
            array(
                'success' => false,
                'code'    => 'not_implemented',
                'message' => __( 'Payment webhook verification is not available for this gateway.', 'mr-commerce' ),
            ),
            501
        );
    }
}
