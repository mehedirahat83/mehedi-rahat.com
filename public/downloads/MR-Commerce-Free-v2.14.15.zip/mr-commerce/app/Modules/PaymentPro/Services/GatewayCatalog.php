<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Public, hydrated gateway catalogue used across Payment Pro.
 *
 * Registry definitions and saved merchant settings are merged here so every
 * consumer receives the same gateway name, type, group, logo, QR, account
 * details, instructions, enable state and sort order.
 */
final class GatewayCatalog {

    private GatewayRegistry $registry;
    private ManualGatewaySettings $settings;

    public function __construct( ?GatewayRegistry $registry = null, ?ManualGatewaySettings $settings = null ) {
        $this->registry = $registry ?? new GatewayRegistry();
        $this->settings = $settings ?? new ManualGatewaySettings( $this->registry );
    }

    /** @return array<string,array<string,mixed>> */
    public function all(): array {
        $saved = $this->settings->all();
        $saved = isset( $saved['gateways'] ) && is_array( $saved['gateways'] ) ? $saved['gateways'] : array();
        $all   = array();

        foreach ( $this->registry->all() as $gateway_id => $definition ) {
            $gateway_id = sanitize_key( (string) $gateway_id );
            $merchant   = isset( $saved[ $gateway_id ] ) && is_array( $saved[ $gateway_id ] ) ? $saved[ $gateway_id ] : array();
            $all[ $gateway_id ] = $this->hydrate( $gateway_id, $definition, $merchant );
        }

        uasort(
            $all,
            static fn( array $a, array $b ): int => (int) ( $a['sort_order'] ?? 100 ) <=> (int) ( $b['sort_order'] ?? 100 )
        );

        return apply_filters( 'mrbp/payment/gateways/all', $all, $this );
    }

    /** @return array<string,array<string,mixed>> */
    public function enabled(): array {
        $enabled = array_filter(
            $this->all(),
            static fn( array $gateway ): bool => ! empty( $gateway['enabled'] ) && '' !== trim( (string) ( $gateway['account_number'] ?? '' ) )
        );

        return apply_filters( 'mrbp/payment/gateways/enabled', $enabled, $this );
    }

    /** @return array<string,mixed> */
    public function get( string $gateway_id ): array {
        $gateway_id = sanitize_key( $gateway_id );
        $all        = $this->all();
        return isset( $all[ $gateway_id ] ) && is_array( $all[ $gateway_id ] ) ? $all[ $gateway_id ] : array();
    }

    public function has( string $gateway_id ): bool {
        return ! empty( $this->get( $gateway_id ) );
    }

    public function label( string $gateway_id ): string {
        $gateway = $this->get( $gateway_id );
        $label   = sanitize_text_field( (string) ( $gateway['label'] ?? '' ) );
        return '' !== $label ? $label : ucwords( str_replace( '_', ' ', sanitize_key( $gateway_id ) ) );
    }

    public function logo_url( string $gateway_id ): string {
        $gateway = $this->get( $gateway_id );
        return esc_url_raw( (string) ( $gateway['logo_url'] ?? '' ) );
    }

    public function qr_url( string $gateway_id ): string {
        $gateway = $this->get( $gateway_id );
        return esc_url_raw( (string) ( $gateway['qr_url'] ?? '' ) );
    }

    public function type( string $gateway_id ): string {
        $gateway = $this->get( $gateway_id );
        return sanitize_key( (string) ( $gateway['type'] ?? 'mobile' ) );
    }

    public function is_bank( string $gateway_id ): bool {
        return 'bank' === $this->type( $gateway_id );
    }

    /**
     * @param array<string,array<string,mixed>>|null $gateways
     * @return array<string,array{label:string,gateways:array<string,array<string,mixed>>}>
     */
    public function grouped( ?array $gateways = null ): array {
        return $this->registry->grouped( null === $gateways ? $this->enabled() : $gateways );
    }

    public function registry(): GatewayRegistry {
        return $this->registry;
    }

    public function settings(): ManualGatewaySettings {
        return $this->settings;
    }

    /** @param array<string,mixed> $definition @param array<string,mixed> $merchant @return array<string,mixed> */
    private function hydrate( string $gateway_id, array $definition, array $merchant ): array {
        $gateway = array_replace( $definition, $merchant );
        $gateway['id']           = $gateway_id;
        $gateway['enabled']      = ! empty( $merchant['enabled'] );
        $gateway['dynamic']      = ! empty( $definition['dynamic'] );
        $gateway['type']         = sanitize_key( (string) ( $merchant['type'] ?? $definition['type'] ?? 'mobile' ) );
        $gateway['group_label']  = sanitize_text_field( (string) ( $merchant['group_label'] ?? $definition['group_label'] ?? __( 'Other Methods', 'mr-commerce' ) ) );
        $gateway['label']        = sanitize_text_field( (string) ( $merchant['label'] ?? $definition['label'] ?? ucwords( str_replace( '_', ' ', $gateway_id ) ) ) );
        $gateway['logo_url']     = '' !== esc_url_raw( (string) ( $merchant['logo_url'] ?? '' ) )
            ? esc_url_raw( (string) $merchant['logo_url'] )
            : $this->registry->logo_url( $gateway_id );
        $gateway['qr_url']       = esc_url_raw( (string) ( $merchant['qr_url'] ?? $definition['qr_url'] ?? '' ) );
        $gateway['instructions'] = sanitize_textarea_field( (string) ( $merchant['instructions'] ?? $definition['instructions'] ?? '' ) );
        $gateway['sort_order']   = absint( $merchant['sort_order'] ?? $definition['sort_order'] ?? 100 );

        return $gateway;
    }
}
