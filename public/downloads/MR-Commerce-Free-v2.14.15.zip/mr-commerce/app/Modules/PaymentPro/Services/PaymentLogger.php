<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Support\Logger;

final class PaymentLogger {

    private Logger $logger;

    public function __construct( ?Logger $logger = null ) {
        $this->logger = $logger ?? new Logger();
    }

    public function info( string $message, array $context = array() ): void {
        $this->logger->payment( '[Payment Center] ' . $message, $this->redact( $context ) );
    }

    public function warning( string $message, array $context = array() ): void {
        $this->logger->payment( '[Payment Center][Warning] ' . $message, $this->redact( $context ) );
    }

    public function error( string $message, array $context = array() ): void {
        $this->logger->error( '[Payment Center] ' . $message, $this->redact( $context ) );
    }

    private function redact( array $context ): array {
        foreach ( $context as $key => $value ) {
            if ( preg_match( '/secret|password|token|authorization|credential|app_key/i', (string) $key ) ) {
                $context[ $key ] = '[redacted]';
            }
        }
        return $context;
    }
}
