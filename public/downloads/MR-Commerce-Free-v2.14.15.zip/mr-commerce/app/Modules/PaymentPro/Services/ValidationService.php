<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\ValidationRepository;

final class ValidationService {
    private ValidationRepository $repository;
    private ManualGatewaySettings $settings;

    public function __construct( ?ValidationRepository $repository = null, ?ManualGatewaySettings $settings = null ) {
        $this->repository = $repository ?? new ValidationRepository();
        $this->settings   = $settings ?? new ManualGatewaySettings();
    }

    public function validate( array $request ): ValidationResult {
        $checks = array();
        $score  = 100;
        $order  = function_exists( 'wc_get_order' ) ? wc_get_order( absint( $request['order_id'] ?? 0 ) ) : false;

        $checks[] = $this->check( 'order_exists', __( 'Order found', 'mr-commerce' ), (bool) $order && ! $order instanceof \WC_Order_Refund, 'error' );
        if ( ! $order || $order instanceof \WC_Order_Refund ) {
            return new ValidationResult( $checks, 15, 'high' );
        }

        $paid = $order->is_paid();
        $checks[] = $this->check( 'order_paid', $paid ? __( 'Order is already marked as paid', 'mr-commerce' ) : __( 'Order is not already paid', 'mr-commerce' ), ! $paid, $paid ? 'warning' : 'success' );
        if ( $paid ) { $score -= 25; }

        $refunded = (float) $order->get_total_refunded() > 0 || $order->has_status( 'refunded' );
        $checks[] = $this->check( 'order_refunded', $refunded ? __( 'Order has refund activity', 'mr-commerce' ) : __( 'No refund warning', 'mr-commerce' ), ! $refunded, $refunded ? 'error' : 'success' );
        if ( $refunded ) { $score -= 35; }

        $expected  = (float) $order->get_total();
        $submitted = (float) ( $request['amount'] ?? 0 );
        $amount_ok = abs( $expected - $submitted ) < 0.01;
        $checks[] = $this->check( 'amount_match', $amount_ok ? __( 'Amount matches the order', 'mr-commerce' ) : __( 'Submitted amount does not match the order', 'mr-commerce' ), $amount_ok, $amount_ok ? 'success' : 'error' );
        if ( ! $amount_ok ) { $score -= 35; }

        $currency_ok = strtoupper( (string) $order->get_currency() ) === strtoupper( (string) ( $request['currency'] ?? '' ) );
        $checks[] = $this->check( 'currency_match', $currency_ok ? __( 'Currency matches', 'mr-commerce' ) : __( 'Currency mismatch', 'mr-commerce' ), $currency_ok, $currency_ok ? 'success' : 'error' );
        if ( ! $currency_ok ) { $score -= 20; }

        $gateways = $this->settings->enabled_gateways();
        $gateway  = sanitize_key( (string) ( $request['gateway'] ?? '' ) );
        $gateway_ok = isset( $gateways[ $gateway ] );
        $checks[] = $this->check( 'gateway_enabled', $gateway_ok ? __( 'Gateway is enabled', 'mr-commerce' ) : __( 'Gateway is disabled or unavailable', 'mr-commerce' ), $gateway_ok, $gateway_ok ? 'success' : 'warning' );
        if ( ! $gateway_ok ) { $score -= 15; }

        $duplicate = $this->repository->duplicate_transaction( (string) ( $request['transaction_id'] ?? '' ), absint( $request['id'] ?? 0 ) );
        $unique    = null === $duplicate;
        $message   = $unique ? __( 'Transaction ID is unique', 'mr-commerce' ) : sprintf( __( 'Transaction ID was also used for order #%d', 'mr-commerce' ), absint( $duplicate['order_id'] ?? 0 ) );
        $checks[]  = $this->check( 'transaction_unique', $message, $unique, $unique ? 'success' : 'error' );
        if ( ! $unique ) { $score -= 45; }

        $phone_uses = $this->repository->phone_usage_count( (string) ( $request['sender_phone'] ?? '' ), absint( $request['id'] ?? 0 ) );
        $checks[] = $this->check( 'phone_usage', $phone_uses > 0 ? sprintf( _n( 'Sender number appears in %d other request', 'Sender number appears in %d other requests', $phone_uses, 'mr-commerce' ), $phone_uses ) : __( 'Sender number has no other request history', 'mr-commerce' ), true, $phone_uses > 0 ? 'warning' : 'success' );
        if ( $phone_uses > 2 ) { $score -= 10; }

        $score = max( 0, min( 100, $score ) );
        $level = $score >= 80 ? 'low' : ( $score >= 55 ? 'medium' : 'high' );
        return new ValidationResult( $checks, $score, $level );
    }

    private function check( string $key, string $message, bool $passed, string $severity ): array {
        return array( 'key' => $key, 'message' => $message, 'passed' => $passed, 'severity' => sanitize_key( $severity ) );
    }
}
