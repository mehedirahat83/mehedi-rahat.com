<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class DynamicGatewayManager {

    private const OPTION_NAME = 'mrbp_dynamic_gateways';

    /** @return array<string,array<string,mixed>> */
    public function all(): array {
        $saved = get_option( self::OPTION_NAME, array() );
        $saved = is_array( $saved ) ? $saved : array();
        $clean = array();

        foreach ( $saved as $gateway_id => $gateway ) {
            if ( ! is_array( $gateway ) ) {
                continue;
            }
            $gateway_id = sanitize_key( (string) $gateway_id );
            if ( '' === $gateway_id ) {
                continue;
            }
            $clean[ $gateway_id ] = $this->sanitize_definition( $gateway_id, $gateway );
        }

        uasort(
            $clean,
            static fn( array $a, array $b ): int => (int) ( $a['sort_order'] ?? 100 ) <=> (int) ( $b['sort_order'] ?? 100 )
        );

        return $clean;
    }

    public function get( string $gateway_id ): array {
        $gateways   = $this->all();
        $gateway_id = sanitize_key( $gateway_id );
        return isset( $gateways[ $gateway_id ] ) ? $gateways[ $gateway_id ] : array();
    }

    public function upsert( array $input ): string {
        $existing_id = sanitize_key( (string) ( $input['existing_id'] ?? '' ) );
        $label       = sanitize_text_field( (string) ( $input['label'] ?? '' ) );
        $gateway_id  = sanitize_key( (string) ( $input['gateway_id'] ?? '' ) );

        if ( '' === $gateway_id ) {
            $gateway_id = sanitize_key( $label );
        }
        if ( '' === $gateway_id || '' === $label ) {
            return '';
        }

        $reserved = array( 'bkash', 'nagad', 'rocket', 'upay', 'city_bank', 'bank_asia' );
        if ( in_array( $gateway_id, $reserved, true ) && $existing_id !== $gateway_id ) {
            return '';
        }

        $all = $this->all();
        if ( '' !== $existing_id && $existing_id !== $gateway_id ) {
            unset( $all[ $existing_id ] );
        }

        $all[ $gateway_id ] = $this->sanitize_definition( $gateway_id, $input );
        update_option( self::OPTION_NAME, $all, false );

        return $gateway_id;
    }

    private function sanitize_definition( string $gateway_id, array $gateway ): array {
        $type = sanitize_key( (string) ( $gateway['type'] ?? 'mobile' ) );
        $type = in_array( $type, array( 'mobile', 'bank' ), true ) ? $type : 'mobile';

        $default_account_types = 'bank' === $type
            ? array( 'savings', 'current', 'business' )
            : array( 'personal', 'agent', 'merchant' );

        return array(
            'id'                 => $gateway_id,
            'label'              => sanitize_text_field( (string) ( $gateway['label'] ?? ucfirst( str_replace( '_', ' ', $gateway_id ) ) ) ),
            'type'               => $type,
            'group_label'        => 'bank' === $type ? __( 'Bank Transfer', 'mr-commerce' ) : __( 'Mobile Banking', 'mr-commerce' ),
            'description'        => sanitize_text_field( (string) ( $gateway['description'] ?? ( 'bank' === $type ? __( 'Manual bank transfer.', 'mr-commerce' ) : __( 'Manual mobile payment.', 'mr-commerce' ) ) ) ),
            'account_label'      => sanitize_text_field( (string) ( $gateway['account_label'] ?? ( 'bank' === $type ? __( 'Account Number', 'mr-commerce' ) : __( 'Send Money Number', 'mr-commerce' ) ) ) ),
            'sender_label'       => sanitize_text_field( (string) ( $gateway['sender_label'] ?? ( 'bank' === $type ? __( 'Sender Account', 'mr-commerce' ) : __( 'Sender Mobile Number', 'mr-commerce' ) ) ) ),
            'sender_help'        => sanitize_text_field( (string) ( $gateway['sender_help'] ?? __( 'Enter the account or mobile number used for this payment.', 'mr-commerce' ) ) ),
            'sender_placeholder' => sanitize_text_field( (string) ( $gateway['sender_placeholder'] ?? ( 'bank' === $type ? __( 'Account or mobile number', 'mr-commerce' ) : '01XXXXXXXXX' ) ) ),
            'account_types'      => $default_account_types,
            'default_type'       => sanitize_key( (string) ( $gateway['default_type'] ?? $default_account_types[0] ) ),
            'instructions'       => sanitize_textarea_field( (string) ( $gateway['instructions'] ?? __( 'Send the exact order amount and submit the transaction reference for manual verification.', 'mr-commerce' ) ) ),
            'logo_id'            => absint( $gateway['logo_id'] ?? 0 ),
            'logo_url'           => esc_url_raw( (string) ( $gateway['logo_url'] ?? '' ) ),
            'qr_id'              => absint( $gateway['qr_id'] ?? 0 ),
            'qr_url'             => esc_url_raw( (string) ( $gateway['qr_url'] ?? '' ) ),
            'sort_order'         => max( 1, absint( $gateway['sort_order'] ?? 100 ) ),
            'dynamic'            => true,
        );
    }
}
