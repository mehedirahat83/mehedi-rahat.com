<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class RequestLockService {

    private const PREFIX = 'mrbp_payment_request_lock_';
    private const TTL    = 30;

    public function acquire( int $request_id ): ?string {
        $request_id = absint( $request_id );
        if ( 0 === $request_id ) {
            return null;
        }

        $option = self::PREFIX . $request_id;
        $token  = wp_generate_uuid4();
        $now    = time();
        $value  = array(
            'token'      => $token,
            'expires_at' => $now + self::TTL,
            'user_id'    => get_current_user_id(),
        );

        if ( add_option( $option, $value, '', false ) ) {
            return $token;
        }

        $current = get_option( $option, array() );
        $expired = ! is_array( $current ) || absint( $current['expires_at'] ?? 0 ) < $now;
        if ( $expired ) {
            delete_option( $option );
            if ( add_option( $option, $value, '', false ) ) {
                return $token;
            }
        }

        return null;
    }

    public function release( int $request_id, string $token ): void {
        $option  = self::PREFIX . absint( $request_id );
        $current = get_option( $option, array() );

        if ( is_array( $current ) && hash_equals( (string) ( $current['token'] ?? '' ), $token ) ) {
            delete_option( $option );
        }
    }
}
