<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class CredentialCipher {

    private const PREFIX = 'mrbp_enc:';

    public function encrypt( string $value ): string {
        if ( '' === $value || str_starts_with( $value, self::PREFIX ) ) {
            return $value;
        }

        if ( ! function_exists( 'openssl_encrypt' ) ) {
            return '';
        }

        try {
            $key = hash( 'sha256', wp_salt( 'auth' ), true );
            $iv = random_bytes( 12 );
            $tag = '';
            $ciphertext = openssl_encrypt( $value, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
            if ( false === $ciphertext ) {
                return '';
            }
            return self::PREFIX . base64_encode( $iv . $tag . $ciphertext );
        } catch ( \Throwable $error ) {
            return '';
        }
    }

    public function decrypt( string $value ): string {
        if ( '' === $value || ! str_starts_with( $value, self::PREFIX ) ) {
            return $value;
        }

        if ( ! function_exists( 'openssl_decrypt' ) ) {
            return '';
        }

        $decoded = base64_decode( substr( $value, strlen( self::PREFIX ) ), true );
        if ( false === $decoded || strlen( $decoded ) < 29 ) {
            return '';
        }

        $iv = substr( $decoded, 0, 12 );
        $tag = substr( $decoded, 12, 16 );
        $ciphertext = substr( $decoded, 28 );
        $key = hash( 'sha256', wp_salt( 'auth' ), true );
        $plain = openssl_decrypt( $ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
        return false === $plain ? '' : $plain;
    }
}
