<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;

final class PaymentActionValidator {

    private PaymentRequestRepository $repository;
    private StatusTransitionService $transitions;

    public function __construct(
        ?PaymentRequestRepository $repository = null,
        ?StatusTransitionService $transitions = null
    ) {
        $this->repository  = $repository ?? new PaymentRequestRepository();
        $this->transitions = $transitions ?? new StatusTransitionService();
    }

    /**
     * @return array{success:bool,code:string,request?:array<string,mixed>}
     */
    public function validate( int $request_id, string $target_status ): array {
        $request_id    = absint( $request_id );
        $target_status = sanitize_key( $target_status );

        if ( 0 === $request_id ) {
            return array( 'success' => false, 'code' => 'invalid_request_id' );
        }

        $request = $this->repository->find( $request_id );
        if ( ! $request ) {
            return array( 'success' => false, 'code' => 'request_not_found' );
        }

        $current_status = sanitize_key( (string) ( $request['status'] ?? '' ) );
        if ( $current_status === $target_status ) {
            return array( 'success' => false, 'code' => 'duplicate_action' );
        }

        if ( ! $this->transitions->can_transition( $current_status, $target_status ) ) {
            return array( 'success' => false, 'code' => 'invalid_status_transition' );
        }

        return array(
            'success' => true,
            'code'    => 'valid',
            'request' => $request,
        );
    }
}
