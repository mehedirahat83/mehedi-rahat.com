<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WooCommerceOrderSyncService {

    private const META_STATUS      = '_mrbp_payment_status';
    private const META_GATEWAY     = '_mrbp_payment_gateway';
    private const META_REQUEST     = '_mrbp_payment_request';
    private const META_VERIFIED_BY = '_mrbp_verified_by';
    private const META_VERIFIED_AT = '_mrbp_verified_at';
    private const META_TRANSACTION = '_mrbp_transaction';
    private const META_SYNCED      = '_mrbp_payment_last_sync';

    private ManualGatewaySettings $settings;
    private PaymentLogger $logger;

    public function __construct( ?ManualGatewaySettings $settings = null, ?PaymentLogger $logger = null ) {
        $this->settings = $settings ?? new ManualGatewaySettings();
        $this->logger   = $logger ?? new PaymentLogger();
    }

    public function register(): void {
        add_action( 'mrbp/payment/approved', array( $this, 'sync_approved' ), 20, 6 );
        add_action( 'mrbp/payment/review', array( $this, 'sync_review' ), 20, 6 );
        add_action( 'mrbp/payment/rejected', array( $this, 'sync_rejected' ), 20, 6 );
    }

    public function sync_approved( int $request_id, array $request, string $admin_note, string $old_status, string $new_status ): void {
        $this->sync( 'approved', $request_id, $request, $admin_note, $old_status, $new_status );
    }

    public function sync_review( int $request_id, array $request, string $admin_note, string $old_status, string $new_status ): void {
        $this->sync( 'review', $request_id, $request, $admin_note, $old_status, $new_status );
    }

    public function sync_rejected( int $request_id, array $request, string $admin_note, string $old_status, string $new_status ): void {
        $this->sync( 'rejected', $request_id, $request, $admin_note, $old_status, $new_status );
    }

    private function sync( string $decision, int $request_id, array $request, string $admin_note, string $old_status, string $new_status ): void {
        if ( ! function_exists( 'wc_get_order' ) ) {
            $this->logger->warning( 'WooCommerce order sync skipped because WooCommerce is unavailable.', array( 'request_id' => $request_id ) );
            return;
        }

        $order_id = absint( $request['order_id'] ?? 0 );
        $order    = $order_id > 0 ? wc_get_order( $order_id ) : false;

        if ( ! $order || $order instanceof \WC_Order_Refund ) {
            $this->logger->error( 'WooCommerce order sync failed because the order was not found.', array( 'request_id' => $request_id, 'order_id' => $order_id ) );
            return;
        }

        $sync_key = sanitize_key( $decision . '-' . $request_id . '-' . $new_status );
        if ( $sync_key === (string) $order->get_meta( self::META_SYNCED, true ) ) {
            return;
        }

        $admin_id = get_current_user_id();
        $now      = current_time( 'mysql', true );
        $gateway  = sanitize_key( (string) ( $request['gateway'] ?? '' ) );
        $trx_id   = strtoupper( sanitize_text_field( (string) ( $request['transaction_id'] ?? '' ) ) );

        $order->update_meta_data( self::META_STATUS, sanitize_key( $new_status ) );
        $order->update_meta_data( self::META_GATEWAY, $gateway );
        $order->update_meta_data( self::META_REQUEST, $request_id );
        $order->update_meta_data( self::META_TRANSACTION, $trx_id );
        $order->update_meta_data( self::META_SYNCED, $sync_key );

        if ( 'approved' === $decision ) {
            $order->update_meta_data( self::META_VERIFIED_BY, $admin_id );
            $order->update_meta_data( self::META_VERIFIED_AT, $now );
        }

        $order->save();

        if ( 'approved' === $decision ) {
            $target_status = $this->settings->after_verification_status();
            if ( $order->get_status() !== $target_status ) {
                $order->update_status( $target_status, '', true );
            }
            $note = sprintf(
                "Manual payment verified.\nGateway: %s\nTransaction: %s\nVerified By: %s",
                $this->gateway_label( $gateway ),
                $trx_id,
                $this->admin_label( $admin_id )
            );
        } elseif ( 'review' === $decision ) {
            $note = __( 'Payment placed under review.', 'mr-commerce' );
            if ( '' !== $admin_note ) {
                $note .= "\n" . sprintf( __( 'Admin Note: %s', 'mr-commerce' ), $admin_note );
            }
        } else {
            $note = __( 'Payment rejected.', 'mr-commerce' );
            if ( '' !== $admin_note ) {
                $note .= "\n" . sprintf( __( 'Reason: %s', 'mr-commerce' ), $admin_note );
            }
        }

        $order->add_order_note( $note, false, true );

        $context = array(
            'request_id' => $request_id,
            'order_id'   => $order_id,
            'decision'   => $decision,
            'from'       => sanitize_key( $old_status ),
            'to'         => sanitize_key( $new_status ),
            'admin_id'   => $admin_id,
        );
        $this->logger->info( 'WooCommerce order synchronized with payment decision.', $context );

        do_action( 'mrbp/payment/woocommerce_synced', $order_id, $request_id, $decision, $request, $order );
    }

    private function gateway_label( string $gateway ): string {
        $config = $this->settings->gateway( $gateway );
        return sanitize_text_field( (string) ( $config['label'] ?? ucfirst( $gateway ) ) );
    }

    private function admin_label( int $admin_id ): string {
        $user = $admin_id > 0 ? get_userdata( $admin_id ) : false;
        return $user ? sanitize_text_field( $user->display_name ) : __( 'Administrator', 'mr-commerce' );
    }
}
