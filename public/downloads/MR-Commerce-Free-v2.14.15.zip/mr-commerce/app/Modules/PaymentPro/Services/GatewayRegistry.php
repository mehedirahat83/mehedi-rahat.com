<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class GatewayRegistry {

    private DynamicGatewayManager $dynamic;

    public function __construct( ?DynamicGatewayManager $dynamic = null ) {
        $this->dynamic = $dynamic ?? new DynamicGatewayManager();
    }

    /**
     * @return array<string,array<string,mixed>>
     */
    public function all(): array {
        $gateways = array(
            'bkash' => array(
                'id'                 => 'bkash',
                'label'              => 'bKash',
                'type'               => 'mobile',
                'group_label'        => __( 'Mobile Banking', 'mr-commerce' ),
                'description'        => __( 'Manual Send Money payment.', 'mr-commerce' ),
                'account_label'      => __( 'Send Money Number', 'mr-commerce' ),
                'sender_label'       => __( 'Sender Mobile Number', 'mr-commerce' ),
                'sender_help'        => __( 'Enter the mobile number used to send the payment.', 'mr-commerce' ),
                'sender_placeholder' => '01XXXXXXXXX',
                'account_types'      => array( 'personal', 'agent', 'merchant' ),
                'default_type'       => 'personal',
                'sort_order'         => 10,
                'dynamic'            => false,
                'logo_url'           => '',
                'instructions'       => __( 'Open bKash, choose Send Money, enter the number and pay the exact order amount.', 'mr-commerce' ),
            ),
            'nagad' => array(
                'id'                 => 'nagad',
                'label'              => 'Nagad',
                'type'               => 'mobile',
                'group_label'        => __( 'Mobile Banking', 'mr-commerce' ),
                'description'        => __( 'Manual Send Money payment.', 'mr-commerce' ),
                'account_label'      => __( 'Send Money Number', 'mr-commerce' ),
                'sender_label'       => __( 'Sender Mobile Number', 'mr-commerce' ),
                'sender_help'        => __( 'Enter the mobile number used to send the payment.', 'mr-commerce' ),
                'sender_placeholder' => '01XXXXXXXXX',
                'account_types'      => array( 'personal', 'agent', 'merchant' ),
                'default_type'       => 'personal',
                'sort_order'         => 20,
                'dynamic'            => false,
                'logo_url'           => '',
                'instructions'       => __( 'Open Nagad, choose Send Money, enter the number and pay the exact order amount.', 'mr-commerce' ),
            ),
            'rocket' => array(
                'id'                 => 'rocket',
                'label'              => 'Rocket',
                'type'               => 'mobile',
                'group_label'        => __( 'Mobile Banking', 'mr-commerce' ),
                'description'        => __( 'Manual Send Money payment.', 'mr-commerce' ),
                'account_label'      => __( 'Send Money Number', 'mr-commerce' ),
                'sender_label'       => __( 'Sender Mobile Number', 'mr-commerce' ),
                'sender_help'        => __( 'Enter the mobile number used to send the payment.', 'mr-commerce' ),
                'sender_placeholder' => '01XXXXXXXXX',
                'account_types'      => array( 'personal', 'agent', 'merchant' ),
                'default_type'       => 'personal',
                'sort_order'         => 30,
                'dynamic'            => false,
                'logo_url'           => '',
                'instructions'       => __( 'Open Rocket, choose Send Money, enter the number and pay the exact order amount.', 'mr-commerce' ),
            ),
            'upay' => array(
                'id'                 => 'upay',
                'label'              => 'Upay',
                'type'               => 'mobile',
                'group_label'        => __( 'Mobile Banking', 'mr-commerce' ),
                'description'        => __( 'Manual Send Money payment.', 'mr-commerce' ),
                'account_label'      => __( 'Send Money Number', 'mr-commerce' ),
                'sender_label'       => __( 'Sender Mobile Number', 'mr-commerce' ),
                'sender_help'        => __( 'Enter the mobile number used to send the payment.', 'mr-commerce' ),
                'sender_placeholder' => '01XXXXXXXXX',
                'account_types'      => array( 'personal', 'agent', 'merchant' ),
                'default_type'       => 'personal',
                'sort_order'         => 40,
                'dynamic'            => false,
                'logo_url'           => '',
                'instructions'       => __( 'Open Upay, choose Send Money, enter the number and pay the exact order amount.', 'mr-commerce' ),
            ),
            'city_bank' => array(
                'id'                 => 'city_bank',
                'label'              => 'City Bank',
                'type'               => 'bank',
                'group_label'        => __( 'Bank Transfer', 'mr-commerce' ),
                'description'        => __( 'Manual bank transfer.', 'mr-commerce' ),
                'account_label'      => __( 'Account Number', 'mr-commerce' ),
                'sender_label'       => __( 'Sender Account', 'mr-commerce' ),
                'sender_help'        => __( 'Enter the sender account number or mobile number used for the transfer.', 'mr-commerce' ),
                'sender_placeholder' => __( 'Account or mobile number', 'mr-commerce' ),
                'account_types'      => array( 'savings', 'current', 'business' ),
                'default_type'       => 'savings',
                'sort_order'         => 50,
                'dynamic'            => false,
                'logo_url'           => '',
                'instructions'       => __( 'Transfer the exact order amount to the bank account above. Keep the transaction or transfer reference and submit it for verification.', 'mr-commerce' ),
            ),
            'bank_asia' => array(
                'id'                 => 'bank_asia',
                'label'              => 'Bank Asia',
                'type'               => 'bank',
                'group_label'        => __( 'Bank Transfer', 'mr-commerce' ),
                'description'        => __( 'Manual bank transfer.', 'mr-commerce' ),
                'account_label'      => __( 'Account Number', 'mr-commerce' ),
                'sender_label'       => __( 'Sender Account', 'mr-commerce' ),
                'sender_help'        => __( 'Enter the sender account number or mobile number used for the transfer.', 'mr-commerce' ),
                'sender_placeholder' => __( 'Account or mobile number', 'mr-commerce' ),
                'account_types'      => array( 'savings', 'current', 'business' ),
                'default_type'       => 'savings',
                'sort_order'         => 60,
                'dynamic'            => false,
                'logo_url'           => '',
                'instructions'       => __( 'Transfer the exact order amount to the bank account above. Keep the transaction or transfer reference and submit it for verification.', 'mr-commerce' ),
            ),
        );

        $gateways = array_replace( $gateways, $this->dynamic->all() );

        uasort(
            $gateways,
            static fn( array $a, array $b ): int => (int) ( $a['sort_order'] ?? 100 ) <=> (int) ( $b['sort_order'] ?? 100 )
        );

        return apply_filters( 'mrbp/payment/gateway_registry', $gateways );
    }

    public function get( string $gateway_id ): array {
        $gateways   = $this->all();
        $gateway_id = sanitize_key( $gateway_id );
        return isset( $gateways[ $gateway_id ] ) && is_array( $gateways[ $gateway_id ] ) ? $gateways[ $gateway_id ] : array();
    }

    public function is_bank( string $gateway_id ): bool {
        $gateway = $this->get( $gateway_id );
        return 'bank' === ( $gateway['type'] ?? '' );
    }

    public function logo_url( string $gateway_id ): string {
        $gateway = $this->get( $gateway_id );
        $custom  = esc_url_raw( (string) ( $gateway['logo_url'] ?? '' ) );
        if ( '' !== $custom ) {
            return $custom;
        }

        $filename = sanitize_file_name( sanitize_key( $gateway_id ) . '.png' );
        $path     = MRBP_PATH . 'app/Modules/PaymentPro/Assets/images/gateways/' . $filename;
        return is_readable( $path )
            ? MRBP_URL . 'app/Modules/PaymentPro/Assets/images/gateways/' . rawurlencode( $filename )
            : '';
    }

    public function qr_url( string $gateway_id ): string {
        $gateway = $this->get( $gateway_id );
        return esc_url_raw( (string) ( $gateway['qr_url'] ?? '' ) );
    }

    /**
     * Group gateway configurations by payment type and sort each group using
     * its own display order. Mobile banking is always rendered before bank
     * transfer, followed by any future custom gateway type.
     *
     * @return array<string,array{label:string,gateways:array<string,array<string,mixed>>}>
     */
    public function grouped( array $gateways ): array {
        $groups = array();

        foreach ( $gateways as $gateway_id => $settings ) {
            $gateway_id = sanitize_key( (string) $gateway_id );
            $definition = $this->get( $gateway_id );
            $type       = sanitize_key( (string) ( $settings['type'] ?? $definition['type'] ?? 'other' ) );

            if ( '' === $type ) {
                $type = 'other';
            }

            if ( ! isset( $groups[ $type ] ) ) {
                $groups[ $type ] = array(
                    'label'    => (string) ( $settings['group_label'] ?? $definition['group_label'] ?? __( 'Other Methods', 'mr-commerce' ) ),
                    'gateways' => array(),
                );
            }

            $groups[ $type ]['gateways'][ $gateway_id ] = $settings;
        }

        foreach ( $groups as &$group ) {
            uasort(
                $group['gateways'],
                static fn( array $a, array $b ): int => (int) ( $a['sort_order'] ?? 100 ) <=> (int) ( $b['sort_order'] ?? 100 )
            );
        }
        unset( $group );

        $preferred_order = array( 'mobile', 'bank' );
        $ordered         = array();

        foreach ( $preferred_order as $type ) {
            if ( isset( $groups[ $type ] ) ) {
                $ordered[ $type ] = $groups[ $type ];
                unset( $groups[ $type ] );
            }
        }

        foreach ( $groups as $type => $group ) {
            $ordered[ $type ] = $group;
        }

        return $ordered;
    }
}
