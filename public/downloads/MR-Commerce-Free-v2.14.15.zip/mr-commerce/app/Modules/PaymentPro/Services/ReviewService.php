<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ReviewService extends PaymentDecisionService {

    /**
     * @return array{success:bool,code:string,request_id:int,status?:string}
     */
    public function review( int $request_id, string $admin_note = '' ): array {
        return $this->decide( $request_id, 'under_review', $admin_note );
    }

    protected function fire_hook( int $request_id, array $request, string $old_status, string $new_status, string $admin_note ): void {
        do_action( 'mrbp/payment/review', $request_id, $request, $admin_note, $old_status, $new_status );
    }
}
