<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;

final class PaymentRequestService {

    private PaymentRequestRepository $repository;
    private PaymentLogger $logger;
    private ManualGatewaySettings $settings;
    private GatewayCatalog $gateways;

    public function __construct(
        ?PaymentRequestRepository $repository = null,
        ?PaymentLogger $logger = null,
        ?ManualGatewaySettings $settings = null
    ) {
        $this->repository = $repository ?? new PaymentRequestRepository();
        $this->logger     = $logger ?? new PaymentLogger();
        $this->settings   = $settings ?? new ManualGatewaySettings();
        $this->gateways   = function_exists( 'mrbp' ) ? mrbp()->gateways() : new GatewayCatalog( $this->settings->registry(), $this->settings );
    }

    public function submit( array $data ): array {
        $validated = $this->validate( $data );

        if ( empty( $validated['success'] ) ) {
            return $validated;
        }

        $clean = $validated['data'];

        if ( $this->repository->transaction_exists( $clean['transaction_id'] ) ) {
            return array( 'success' => false, 'code' => 'duplicate_transaction_id' );
        }

        if ( $this->repository->has_open_request_for_order( $clean['order_id'] ) ) {
            return array( 'success' => false, 'code' => 'open_request_exists' );
        }

        $request_id = $this->repository->create( $clean );

        if ( 0 === $request_id ) {
            $this->logger->error( 'Could not create manual payment request.', array( 'order_id' => $clean['order_id'] ) );
            return array( 'success' => false, 'code' => 'database_error' );
        }

        $order = wc_get_order( $clean['order_id'] );
        if ( $order && ! $order instanceof \WC_Order_Refund ) {
            $order->update_meta_data( '_mrbp_payment_request_id', $request_id );
            $order->update_meta_data( '_mrbp_payment_status', 'submitted' );
            $order->update_meta_data( '_mrbp_payment_gateway', $clean['gateway'] );
            $order->update_meta_data( '_mrbp_transaction_id', $clean['transaction_id'] );
            $order->save();
            $order->add_order_note(
                sprintf(
                    /* translators: 1: gateway name, 2: transaction ID. */
                    __( 'Manual payment submitted via %1$s. Transaction ID: %2$s. Awaiting verification.', 'mr-commerce' ),
                    $this->gateways->label( $clean['gateway'] ),
                    $clean['transaction_id']
                )
            );
        }

        ( new TransactionManager( $this->logger ) )->sync_payment_request(
            $request_id,
            array_merge( $clean, array( 'status' => 'submitted' ) )
        );

        $this->logger->info(
            'Manual payment request submitted.',
            array(
                'request_id' => $request_id,
                'order_id'   => $clean['order_id'],
                'gateway'    => $clean['gateway'],
                'status'     => 'submitted',
            )
        );

        do_action( 'mrbp/payment/submitted', $request_id, $clean );

        return array(
            'success'    => true,
            'request_id' => $request_id,
            'status'     => 'submitted',
        );
    }

    public function repository(): PaymentRequestRepository {
        return $this->repository;
    }

    private function validate( array $data ): array {
        $order_id       = absint( $data['order_id'] ?? 0 );
        $gateway        = sanitize_key( (string) ( $data['gateway'] ?? '' ) );
        $sender_phone   = trim( preg_replace( '/[^A-Za-z0-9+ \-]/', '', (string) ( $data['sender_phone'] ?? '' ) ) );
        $transaction_id = strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', (string) ( $data['transaction_id'] ?? '' ) ) );
        $customer_note  = sanitize_textarea_field( (string) ( $data['customer_note'] ?? '' ) );

        $order = wc_get_order( $order_id );
        if ( ! $order || $order instanceof \WC_Order_Refund ) {
            return array( 'success' => false, 'code' => 'invalid_order' );
        }

        if ( $order->is_paid() ) {
            return array( 'success' => false, 'code' => 'order_already_paid' );
        }

        $gateways = $this->settings->enabled_gateways();
        if ( '' === $gateway || ! isset( $gateways[ $gateway ] ) ) {
            return array( 'success' => false, 'code' => 'invalid_gateway' );
        }

        if ( ! preg_match( '/^[A-Za-z0-9+ \-]{4,30}$/', $sender_phone ) ) {
            return array( 'success' => false, 'code' => 'invalid_phone' );
        }

        if ( ! preg_match( '/^[A-Z0-9-]{6,40}$/', $transaction_id ) ) {
            return array( 'success' => false, 'code' => 'invalid_transaction_id' );
        }

        return array(
            'success' => true,
            'data'    => array(
                'order_id'       => $order_id,
                'user_id'        => (int) $order->get_customer_id(),
                'gateway'        => $gateway,
                'sender_phone'   => $sender_phone,
                'transaction_id' => $transaction_id,
                'amount'         => (float) $order->get_total(),
                'currency'       => (string) $order->get_currency(),
                'status'         => 'submitted',
                'customer_note'  => $customer_note,
                'submitted_at'   => current_time( 'mysql', true ),
            ),
        );
    }
}
