<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ManualGatewaySettings {

    private const OPTION_NAME = 'mrbp_manual_gateway_settings';
    private const GROUP_NAME  = 'mrbp_manual_gateway_group';

    private GatewayRegistry $registry;

    public function __construct( ?GatewayRegistry $registry = null ) {
        $this->registry = $registry ?? new GatewayRegistry();
    }

    public function register(): void {
        register_setting(
            self::GROUP_NAME,
            self::OPTION_NAME,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( $this, 'sanitize' ),
                'default'           => $this->defaults(),
            )
        );
    }

    public function option_name(): string { return self::OPTION_NAME; }
    public function group_name(): string { return self::GROUP_NAME; }
    public function registry(): GatewayRegistry { return $this->registry; }

    public function all(): array {
        $saved    = get_option( self::OPTION_NAME, array() );
        $saved    = is_array( $saved ) ? $saved : array();
        $defaults = $this->defaults();
        $merged   = array_replace_recursive( $defaults, $saved );
        $allowed  = array_keys( $this->registry->all() );

        $merged['gateways'] = array_intersect_key(
            isset( $merged['gateways'] ) && is_array( $merged['gateways'] ) ? $merged['gateways'] : array(),
            array_flip( $allowed )
        );

        uasort(
            $merged['gateways'],
            static fn( array $a, array $b ): int => (int) ( $a['sort_order'] ?? 100 ) <=> (int) ( $b['sort_order'] ?? 100 )
        );

        return $merged;
    }

    public function general(): array {
        $settings = $this->all();
        return isset( $settings['general'] ) && is_array( $settings['general'] ) ? $settings['general'] : array();
    }

    public function gateway( string $gateway_id ): array {
        $settings   = $this->all();
        $gateway_id = sanitize_key( $gateway_id );
        return isset( $settings['gateways'][ $gateway_id ] ) && is_array( $settings['gateways'][ $gateway_id ] )
            ? $settings['gateways'][ $gateway_id ]
            : array();
    }

    public function initial_order_status(): string {
        if ( function_exists( 'mrc_can' ) && ! mrc_can( 'payment.verification' ) ) {
            return 'on-hold';
        }

        $general = $this->general();
        $status  = sanitize_key( (string) ( $general['initial_order_status'] ?? 'on-hold' ) );
        $allowed = array( 'on-hold', 'processing', 'mrbp-verification' );

        return in_array( $status, $allowed, true ) ? $status : 'on-hold';
    }

    public function after_verification_status(): string {
        $general = $this->general();
        $status  = sanitize_key( (string) ( $general['after_verification_status'] ?? 'processing' ) );
        return in_array( $status, array( 'processing', 'completed' ), true ) ? $status : 'processing';
    }

    /**
     * Return enabled, fully-hydrated gateway configurations.
     *
     * The registry is the source of truth for gateway identity, type, labels,
     * logo and customer-facing field definitions. Saved merchant settings are
     * layered on top so every consumer (checkout, popup, verification, reports
     * and history) receives the same shape for built-in and dynamic gateways.
     *
     * @return array<string,array<string,mixed>>
     */
    public function enabled_gateways(): array {
        $settings = $this->all();
        $enabled  = array();

        foreach ( $this->registry->all() as $gateway_id => $definition ) {
            $gateway = isset( $settings['gateways'][ $gateway_id ] ) && is_array( $settings['gateways'][ $gateway_id ] )
                ? $settings['gateways'][ $gateway_id ]
                : array();

            if ( empty( $gateway['enabled'] ) || '' === trim( (string) ( $gateway['account_number'] ?? '' ) ) ) {
                continue;
            }

            $enabled[ $gateway_id ] = array_replace(
                $definition,
                $gateway,
                array(
                    'id'        => (string) $gateway_id,
                    'logo_url'  => '' !== (string) ( $gateway['logo_url'] ?? '' ) ? esc_url_raw( (string) $gateway['logo_url'] ) : $this->registry->logo_url( (string) $gateway_id ),
                    'qr_url'    => esc_url_raw( (string) ( $gateway['qr_url'] ?? '' ) ),
                    'dynamic'   => ! empty( $definition['dynamic'] ),
                    'type'      => (string) ( $definition['type'] ?? 'mobile' ),
                    'group_label' => (string) ( $definition['group_label'] ?? __( 'Other Methods', 'mr-commerce' ) ),
                )
            );
        }

        uasort(
            $enabled,
            static fn( array $a, array $b ): int => (int) ( $a['sort_order'] ?? 100 ) <=> (int) ( $b['sort_order'] ?? 100 )
        );

        $limit = function_exists( 'mrc_limit' ) ? mrc_limit( 'payment.manual_gateway' ) : -1;
        if ( $limit >= 0 ) {
            $enabled = array_slice( $enabled, 0, $limit, true );
        }

        return apply_filters( 'mrbp/payment/enabled_gateways', $enabled, $this );
    }

    public function label( string $gateway_id ): string {
        $gateway_id = sanitize_key( $gateway_id );
        $settings   = $this->gateway( $gateway_id );
        $definition = $this->registry->get( $gateway_id );
        $label      = (string) ( $settings['label'] ?? $definition['label'] ?? '' );

        return '' !== trim( $label )
            ? sanitize_text_field( $label )
            : ucwords( str_replace( '_', ' ', $gateway_id ) );
    }

    public function sanitize( $input ): array {
        $input    = is_array( $input ) ? wp_unslash( $input ) : array();
        $defaults = $this->defaults();
        $clean    = $defaults;

        $general = isset( $input['general'] ) && is_array( $input['general'] ) ? $input['general'] : array();
        $clean['general']['brand_name'] = sanitize_text_field( (string) ( $general['brand_name'] ?? '' ) );
        $clean['general']['tagline'] = sanitize_text_field( (string) ( $general['tagline'] ?? '' ) );
        $clean['general']['support_phone'] = preg_replace( '/[^0-9+\-\s]/', '', (string) ( $general['support_phone'] ?? '' ) );
        $clean['general']['whatsapp_number'] = preg_replace( '/[^0-9+]/', '', (string) ( $general['whatsapp_number'] ?? '' ) );
        $clean['general']['accent_color'] = sanitize_hex_color( (string) ( $general['accent_color'] ?? '' ) ) ?: '#1e8a8a';
        $clean['general']['popup_title'] = sanitize_text_field( (string) ( $general['popup_title'] ?? '' ) );
        $clean['general']['footer_note'] = sanitize_textarea_field( (string) ( $general['footer_note'] ?? '' ) );
        $initial_status = sanitize_key( (string) ( $general['initial_order_status'] ?? 'on-hold' ) );
        $clean['general']['initial_order_status'] = in_array( $initial_status, array( 'on-hold', 'processing', 'mrbp-verification' ), true ) ? $initial_status : 'on-hold';

        $after_status = sanitize_key( (string) ( $general['after_verification_status'] ?? 'processing' ) );
        $clean['general']['after_verification_status'] = in_array( $after_status, array( 'processing', 'completed' ), true ) ? $after_status : 'processing';

        foreach ( $this->registry->all() as $gateway_id => $definition ) {
            $gateway = isset( $input['gateways'][ $gateway_id ] ) && is_array( $input['gateways'][ $gateway_id ] )
                ? $input['gateways'][ $gateway_id ]
                : array();

            $allowed_types = array_map( 'sanitize_key', (array) ( $definition['account_types'] ?? array() ) );
            $default_type  = sanitize_key( (string) ( $definition['default_type'] ?? ( $allowed_types[0] ?? 'personal' ) ) );
            $account_type  = sanitize_key( (string) ( $gateway['account_type'] ?? $default_type ) );
            if ( ! in_array( $account_type, $allowed_types, true ) ) {
                $account_type = $default_type;
            }


            $gateway_type = sanitize_key( (string) ( $gateway['type'] ?? $definition['type'] ?? 'mobile' ) );
            $gateway_type = in_array( $gateway_type, array( 'mobile', 'bank' ), true ) ? $gateway_type : 'mobile';
            $group_label  = sanitize_text_field( (string) ( $gateway['group_label'] ?? ( 'bank' === $gateway_type ? __( 'Bank Transfer', 'mr-commerce' ) : __( 'Mobile Banking', 'mr-commerce' ) ) ) );
            $logo         = $this->sanitize_image_reference( $gateway['logo_id'] ?? 0, $gateway['logo_url'] ?? '' );
            $qr           = $this->sanitize_image_reference( $gateway['qr_id'] ?? 0, $gateway['qr_url'] ?? '' );

            $clean['gateways'][ $gateway_id ]['enabled']        = ! empty( $gateway['enabled'] );
            $clean['gateways'][ $gateway_id ]['type']           = $gateway_type;
            $clean['gateways'][ $gateway_id ]['group_label']    = $group_label;
            $clean['gateways'][ $gateway_id ]['description']    = sanitize_text_field( (string) ( $gateway['description'] ?? $definition['description'] ?? '' ) );
            $clean['gateways'][ $gateway_id ]['logo_id']        = $logo['id'];
            $clean['gateways'][ $gateway_id ]['logo_url']       = $logo['url'];
            $clean['gateways'][ $gateway_id ]['qr_id']          = $qr['id'];
            $clean['gateways'][ $gateway_id ]['qr_url']         = $qr['url'];
            $clean['gateways'][ $gateway_id ]['label']          = sanitize_text_field( (string) ( $gateway['label'] ?? $definition['label'] ) );
            $clean['gateways'][ $gateway_id ]['account_name']   = sanitize_text_field( (string) ( $gateway['account_name'] ?? '' ) );
            $clean['gateways'][ $gateway_id ]['account_number'] = preg_replace( '/[^A-Za-z0-9+\-\s]/', '', (string) ( $gateway['account_number'] ?? '' ) );
            $clean['gateways'][ $gateway_id ]['account_type']   = $account_type;
            $clean['gateways'][ $gateway_id ]['branch_name']    = sanitize_text_field( (string) ( $gateway['branch_name'] ?? '' ) );
            $clean['gateways'][ $gateway_id ]['routing_number'] = preg_replace( '/[^A-Za-z0-9\-]/', '', (string) ( $gateway['routing_number'] ?? '' ) );
            $clean['gateways'][ $gateway_id ]['swift_code']     = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $gateway['swift_code'] ?? '' ) ) );
            $clean['gateways'][ $gateway_id ]['instructions']   = sanitize_textarea_field( (string) ( $gateway['instructions'] ?? $definition['instructions'] ) );
            $clean['gateways'][ $gateway_id ]['sort_order']     = max( 1, absint( $gateway['sort_order'] ?? $definition['sort_order'] ?? 100 ) );
            $charge_type = sanitize_key( (string) ( $gateway['cashout_charge_type'] ?? 'percentage' ) );
            $charge_type = in_array( $charge_type, array( 'percentage', 'fixed' ), true ) ? $charge_type : 'percentage';
            $charge_value = max( 0, (float) wc_format_decimal( $gateway['cashout_charge_value'] ?? 0 ) );
            if ( 'percentage' === $charge_type ) {
                $charge_value = min( 100, $charge_value );
            }
            $current_gateway = $this->gateway( (string) $gateway_id );
            $cashout_allowed = ! function_exists( 'mrc_can' ) || mrc_can( 'payment.cashout_fee' );
            $clean['gateways'][ $gateway_id ]['cashout_charge_enabled'] = $cashout_allowed ? ! empty( $gateway['cashout_charge_enabled'] ) : ! empty( $current_gateway['cashout_charge_enabled'] );
            $clean['gateways'][ $gateway_id ]['cashout_charge_type']    = $cashout_allowed ? $charge_type : (string) ( $current_gateway['cashout_charge_type'] ?? 'percentage' );
            $clean['gateways'][ $gateway_id ]['cashout_charge_value']   = $cashout_allowed ? $charge_value : (float) ( $current_gateway['cashout_charge_value'] ?? 0 );
        }

        return $clean;
    }


    /** @return array{id:int,url:string} */
    private function sanitize_image_reference( $attachment_id, $url ): array {
        $attachment_id = absint( $attachment_id );
        if ( $attachment_id > 0 && wp_attachment_is_image( $attachment_id ) ) {
            $attachment_url = wp_get_attachment_url( $attachment_id );
            if ( is_string( $attachment_url ) && '' !== $attachment_url ) {
                return array( 'id' => $attachment_id, 'url' => esc_url_raw( $attachment_url ) );
            }
        }

        $url = esc_url_raw( (string) $url );
        return array( 'id' => 0, 'url' => $url );
    }

    private function defaults(): array {
        $gateways = array();
        foreach ( $this->registry->all() as $gateway_id => $definition ) {
            $gateways[ $gateway_id ] = array(
                'enabled'        => false,
                'type'           => (string) ( $definition['type'] ?? 'mobile' ),
                'group_label'    => (string) ( $definition['group_label'] ?? '' ),
                'description'    => (string) ( $definition['description'] ?? '' ),
                'logo_id'        => absint( $definition['logo_id'] ?? 0 ),
                'logo_url'       => esc_url_raw( (string) ( $definition['logo_url'] ?? '' ) ),
                'qr_id'          => absint( $definition['qr_id'] ?? 0 ),
                'qr_url'         => esc_url_raw( (string) ( $definition['qr_url'] ?? '' ) ),
                'label'          => (string) $definition['label'],
                'account_name'   => '',
                'account_number' => '',
                'account_type'   => (string) $definition['default_type'],
                'branch_name'    => '',
                'routing_number' => '',
                'swift_code'     => '',
                'instructions'   => (string) $definition['instructions'],
                'sort_order'     => max( 1, absint( $definition['sort_order'] ?? 100 ) ),
                'cashout_charge_enabled' => false,
                'cashout_charge_type'    => 'percentage',
                'cashout_charge_value'   => 0,
            );
        }

        return array(
            'general' => array(
                'brand_name'               => get_bloginfo( 'name' ),
                'tagline'                  => __( 'Secure manual payment', 'mr-commerce' ),
                'support_phone'            => '',
                'whatsapp_number'          => '',
                'accent_color'             => '#1e8a8a',
                'popup_title'              => __( 'Complete Your Payment', 'mr-commerce' ),
                'footer_note'              => __( 'After sending money or making a bank transfer, submit your sender account/mobile number and transaction reference. Verification is completed manually by the store administrator.', 'mr-commerce' ),
                'initial_order_status'     => 'on-hold',
                'after_verification_status'=> 'processing',
            ),
            'gateways' => $gateways,
        );
    }
}
