<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Database\Schema;
use MRBP\Security\Database;

final class TransactionManager {

    private PaymentLogger $logger;

    public function __construct( ?PaymentLogger $logger = null ) {
        $this->logger = $logger ?? new PaymentLogger();
    }

    public function create( array $data ): int {
        global $wpdb;

        $now = current_time( 'mysql', true );
        $created_at = $this->normalize_datetime( (string) ( $data['created_at'] ?? '' ), $now );
        $updated_at = $this->normalize_datetime( (string) ( $data['updated_at'] ?? '' ), $created_at );
        $record = array(
            'order_id'         => absint( $data['order_id'] ?? 0 ),
            'gateway'          => sanitize_key( (string) ( $data['gateway'] ?? '' ) ),
            'transaction_id'   => sanitize_text_field( (string) ( $data['transaction_id'] ?? '' ) ),
            'payment_id'       => sanitize_text_field( (string) ( $data['payment_id'] ?? '' ) ),
            'status'           => sanitize_key( (string) ( $data['status'] ?? 'pending' ) ),
            'amount'           => number_format( (float) ( $data['amount'] ?? 0 ), 2, '.', '' ),
            'currency'         => strtoupper( sanitize_text_field( (string) ( $data['currency'] ?? 'BDT' ) ) ),
            'response_code'    => sanitize_text_field( (string) ( $data['response_code'] ?? '' ) ),
            'response_message' => sanitize_textarea_field( (string) ( $data['response_message'] ?? '' ) ),
            'created_at'       => $created_at,
            'updated_at'       => $updated_at,
        );

        $inserted = $wpdb->insert(
            Schema::table_name(),
            $record,
            array( '%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s' )
        );
        if ( false === $inserted ) {
            $this->logger->error( 'Could not create transaction record.', array( 'order_id' => $record['order_id'], 'gateway' => $record['gateway'] ) );
            return 0;
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Create or refresh the transaction projection for a manual payment request.
     * The stable payment_id makes repeated hooks and backfills idempotent.
     */
    public function sync_payment_request( int $request_id, array $request ): int {
        global $wpdb;

        $request_id = absint( $request_id );
        if ( $request_id < 1 ) {
            return 0;
        }

        $payment_id    = 'manual_request_' . $request_id;
        $transaction_id = strtoupper( sanitize_text_field( (string) ( $request['transaction_id'] ?? '' ) ) );
        $existing      = $this->find_by_payment_id( $payment_id );

        // Older projections may predate the stable manual-request payment ID.
        if ( null === $existing && '' !== $transaction_id ) {
            $existing = $this->find_by_transaction_id( $transaction_id );
        }

        $data = array(
            'order_id'       => absint( $request['order_id'] ?? 0 ),
            'gateway'        => sanitize_key( (string) ( $request['gateway'] ?? '' ) ),
            'transaction_id' => $transaction_id,
            'payment_id'     => $payment_id,
            'status'         => sanitize_key( (string) ( $request['status'] ?? 'submitted' ) ),
            'amount'         => (float) ( $request['amount'] ?? 0 ),
            'currency'       => strtoupper( sanitize_text_field( (string) ( $request['currency'] ?? 'BDT' ) ) ),
            'created_at'     => (string) ( $request['submitted_at'] ?? $request['created_at'] ?? '' ),
            'updated_at'     => (string) ( $request['updated_at'] ?? '' ),
        );

        if ( null === $existing ) {
            return $this->create( $data );
        }

        $now = current_time( 'mysql', true );
        $updated = $wpdb->update(
            Schema::table_name(),
            array(
                'order_id'       => $data['order_id'],
                'gateway'        => $data['gateway'],
                'transaction_id' => $data['transaction_id'],
                'payment_id'     => $data['payment_id'],
                'status'         => $data['status'],
                'amount'         => number_format( $data['amount'], 2, '.', '' ),
                'currency'       => $data['currency'],
                'updated_at'     => $this->normalize_datetime( $data['updated_at'], $now ),
            ),
            array( 'id' => absint( $existing['id'] ?? 0 ) ),
            array( '%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s' ),
            array( '%d' )
        );

        if ( false === $updated ) {
            $this->logger->error( 'Could not synchronize transaction record.', array( 'request_id' => $request_id, 'order_id' => $data['order_id'] ) );
            return 0;
        }

        return absint( $existing['id'] ?? 0 );
    }

    public function update_status( int $transaction_id, string $status, array $response = array() ): bool {
        global $wpdb;

        $previous = $this->find_by_id( $transaction_id );
        $status = sanitize_key( $status );
        $updated = $wpdb->update(
            Schema::table_name(),
            array(
                'status'           => $status,
                'response_code'    => sanitize_text_field( (string) ( $response['code'] ?? '' ) ),
                'response_message' => sanitize_textarea_field( (string) ( $response['message'] ?? '' ) ),
                'updated_at'       => current_time( 'mysql', true ),
            ),
            array( 'id' => absint( $transaction_id ) ),
            array( '%s', '%s', '%s', '%s' ),
            array( '%d' )
        );

        if ( false === $updated ) {
            return false;
        }

        $completed_statuses = array( 'completed', 'paid', 'success' );
        $was_completed = is_array( $previous ) && in_array( (string) $previous['status'], $completed_statuses, true );

        if ( ! $was_completed && in_array( $status, $completed_statuses, true ) ) {
            $transaction = $this->find_by_id( $transaction_id );
            if ( is_array( $transaction ) ) {
                do_action( 'mrbp/payment/completed', (int) $transaction['order_id'], $transaction );
            }
        }

        return true;
    }


    public function find_by_id( int $transaction_id ): ?array {
        global $wpdb;
        $table = Database::table_name( Schema::table_name() );
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint( $transaction_id ) ),
            ARRAY_A
        );
        return is_array( $row ) ? $row : null;
    }

    public function find_by_payment_id( string $payment_id ): ?array {
        global $wpdb;
        $table = Database::table_name( Schema::table_name() );
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE payment_id = %s LIMIT 1", $payment_id ),
            ARRAY_A
        );
        return is_array( $row ) ? $row : null;
    }

    public function find_by_transaction_id( string $transaction_id ): ?array {
        global $wpdb;
        $table = Database::table_name( Schema::table_name() );
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE transaction_id = %s ORDER BY id DESC LIMIT 1", strtoupper( sanitize_text_field( $transaction_id ) ) ),
            ARRAY_A
        );
        return is_array( $row ) ? $row : null;
    }

    public function recent( int $limit = 50 ): array {
        global $wpdb;
        $table = Database::table_name( Schema::table_name() );
        $limit = max( 1, min( 200, $limit ) );
        $rows = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} ORDER BY created_at DESC, id DESC LIMIT %d", $limit ),
            ARRAY_A
        );
        return is_array( $rows ) ? $rows : array();
    }

    private function normalize_datetime( string $value, string $fallback ): string {
        $value = sanitize_text_field( $value );
        if ( '' === $value || false === strtotime( $value ) ) {
            return $fallback;
        }
        return gmdate( 'Y-m-d H:i:s', strtotime( $value ) );
    }
}
