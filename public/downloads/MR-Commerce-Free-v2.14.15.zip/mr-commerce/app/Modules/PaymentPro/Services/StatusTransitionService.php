<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class StatusTransitionService {

    /**
     * @var array<string,array<int,string>>
     */
    private array $transitions = array(
        'pending'      => array( 'submitted' ),
        'submitted'    => array( 'under_review', 'verified', 'rejected' ),
        'under_review' => array( 'verified', 'rejected' ),
        'rejected'     => array(),
        'verified'     => array(),
        'expired'      => array(),
    );

    public function can_transition( string $from, string $to ): bool {
        $from = sanitize_key( $from );
        $to   = sanitize_key( $to );

        return isset( $this->transitions[ $from ] ) && in_array( $to, $this->transitions[ $from ], true );
    }

    /**
     * @return array<int,string>
     */
    public function allowed_from( string $status ): array {
        return $this->transitions[ sanitize_key( $status ) ] ?? array();
    }

    public function terminal( string $status ): bool {
        return in_array( sanitize_key( $status ), array( 'verified', 'rejected', 'expired' ), true );
    }
}
