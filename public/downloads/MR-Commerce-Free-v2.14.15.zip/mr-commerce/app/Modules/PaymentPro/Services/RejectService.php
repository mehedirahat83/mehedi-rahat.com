<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class RejectService extends PaymentDecisionService {

    private const REASONS = array(
        'wrong_amount',
        'duplicate_transaction',
        'invalid_transaction',
        'wrong_gateway',
        'payment_not_found',
        'fraud_suspected',
        'other',
    );

    /**
     * @return array{success:bool,code:string,request_id:int,status?:string}
     */
    public function reject( int $request_id, string $reason, string $admin_note = '' ): array {
        $reason = sanitize_key( $reason );
        if ( ! in_array( $reason, self::REASONS, true ) ) {
            return array( 'success' => false, 'code' => 'invalid_reject_reason', 'request_id' => absint( $request_id ) );
        }

        $note = trim( $reason . ( '' !== trim( $admin_note ) ? ': ' . $admin_note : '' ) );

        return $this->decide( $request_id, 'rejected', $note );
    }

    /**
     * @return array<int,string>
     */
    public static function reasons(): array {
        return self::REASONS;
    }

    protected function fire_hook( int $request_id, array $request, string $old_status, string $new_status, string $admin_note ): void {
        do_action( 'mrbp/payment/rejected', $request_id, $request, $admin_note, $old_status, $new_status );
    }
}
