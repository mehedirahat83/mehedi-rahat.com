<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ValidationResult {
    private array $checks;
    private int $score;
    private string $level;

    public function __construct( array $checks, int $score, string $level ) {
        $this->checks = $checks;
        $this->score  = max( 0, min( 100, $score ) );
        $this->level  = sanitize_key( $level );
    }

    public function checks(): array { return $this->checks; }
    public function score(): int { return $this->score; }
    public function level(): string { return $this->level; }
}
