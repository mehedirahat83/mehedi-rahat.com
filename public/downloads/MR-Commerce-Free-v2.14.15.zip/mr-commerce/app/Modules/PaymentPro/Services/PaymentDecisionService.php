<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;

abstract class PaymentDecisionService {

    protected PaymentRequestRepository $repository;
    protected PaymentActionValidator $validator;
    protected RequestLockService $locks;
    protected PaymentLogger $logger;

    public function __construct(
        ?PaymentRequestRepository $repository = null,
        ?PaymentActionValidator $validator = null,
        ?RequestLockService $locks = null,
        ?PaymentLogger $logger = null
    ) {
        $this->repository = $repository ?? new PaymentRequestRepository();
        $this->validator  = $validator ?? new PaymentActionValidator( $this->repository );
        $this->locks      = $locks ?? new RequestLockService();
        $this->logger     = $logger ?? new PaymentLogger();
    }

    /**
     * @return array{success:bool,code:string,request_id:int,status?:string}
     */
    protected function decide( int $request_id, string $target_status, string $admin_note = '' ): array {
        $request_id    = absint( $request_id );
        $target_status = sanitize_key( $target_status );
        $admin_note    = sanitize_textarea_field( $admin_note );

        $validated = $this->validator->validate( $request_id, $target_status );
        if ( empty( $validated['success'] ) || empty( $validated['request'] ) ) {
            return array(
                'success'    => false,
                'code'       => (string) ( $validated['code'] ?? 'validation_failed' ),
                'request_id' => $request_id,
            );
        }

        $token = $this->locks->acquire( $request_id );
        if ( null === $token ) {
            return array( 'success' => false, 'code' => 'request_locked', 'request_id' => $request_id );
        }

        try {
            // Re-read after obtaining the lock to prevent stale decisions.
            $validated = $this->validator->validate( $request_id, $target_status );
            if ( empty( $validated['success'] ) || empty( $validated['request'] ) ) {
                return array(
                    'success'    => false,
                    'code'       => (string) ( $validated['code'] ?? 'validation_failed' ),
                    'request_id' => $request_id,
                );
            }

            $request    = $validated['request'];
            $old_status = sanitize_key( (string) ( $request['status'] ?? '' ) );
            $updated    = $this->repository->transition_status(
                $request_id,
                $old_status,
                $target_status,
                get_current_user_id(),
                $admin_note
            );

            if ( ! $updated ) {
                return array( 'success' => false, 'code' => 'concurrent_update', 'request_id' => $request_id );
            }

            $this->logger->info(
                'Payment decision recorded.',
                array(
                    'request_id' => $request_id,
                    'order_id'   => absint( $request['order_id'] ?? 0 ),
                    'from'       => $old_status,
                    'to'         => $target_status,
                    'admin_id'   => get_current_user_id(),
                )
            );

            ( new TransactionManager( $this->logger ) )->sync_payment_request(
                $request_id,
                array_merge(
                    $request,
                    array(
                        'status'     => $target_status,
                        'updated_at' => current_time( 'mysql', true ),
                    )
                )
            );

            $this->fire_hook( $request_id, $request, $old_status, $target_status, $admin_note );

            return array(
                'success'    => true,
                'code'       => 'decision_recorded',
                'request_id' => $request_id,
                'status'     => $target_status,
            );
        } finally {
            $this->locks->release( $request_id, $token );
        }
    }

    /**
     * @param array<string,mixed> $request
     */
    abstract protected function fire_hook( int $request_id, array $request, string $old_status, string $new_status, string $admin_note ): void;
}
