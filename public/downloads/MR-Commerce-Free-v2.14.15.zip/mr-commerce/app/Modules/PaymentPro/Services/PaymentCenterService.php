<?php

namespace MRBP\Modules\PaymentPro\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Repositories\PaymentRequestRepository;

final class PaymentCenterService {

    private PaymentRequestRepository $requests;

    public function __construct( ?PaymentRequestRepository $requests = null ) {
        $this->requests = $requests ?? new PaymentRequestRepository();
    }

    public function dashboard_stats(): array {
        return array(
            'pending'      => $this->requests->count_by_status( 'pending' ) + $this->requests->count_by_status( 'submitted' ),
            'under_review' => $this->requests->count_by_status( 'under_review' ),
            'verified'     => $this->requests->count_by_status( 'verified' ),
            'rejected'     => $this->requests->count_by_status( 'rejected' ),
        );
    }
}
