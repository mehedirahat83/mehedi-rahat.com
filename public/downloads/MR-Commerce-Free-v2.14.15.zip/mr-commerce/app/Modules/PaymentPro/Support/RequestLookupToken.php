<?php

namespace MRBP\Modules\PaymentPro\Support;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class RequestLookupToken {

    private const TTL = 900;

    /**
     * @param array<string,mixed> $request
     */
    public function issue( array $request ): string {
        $payload = array(
            'request_id'     => absint( $request['request_id'] ?? $request['id'] ?? 0 ),
            'id'             => absint( $request['id'] ?? $request['request_id'] ?? 0 ),
            'order_id'       => absint( $request['order_id'] ?? 0 ),
            'user_id'        => absint( $request['user_id'] ?? 0 ),
            'gateway'        => sanitize_key( (string) ( $request['gateway'] ?? '' ) ),
            'sender_phone'   => sanitize_text_field( (string) ( $request['sender_phone'] ?? '' ) ),
            'transaction_id' => strtoupper( sanitize_text_field( (string) ( $request['transaction_id'] ?? '' ) ) ),
            'amount'         => (float) ( $request['amount'] ?? 0 ),
            'currency'       => strtoupper( sanitize_text_field( (string) ( $request['currency'] ?? 'BDT' ) ) ),
            'status'         => sanitize_key( (string) ( $request['status'] ?? 'submitted' ) ),
            'customer_note'  => sanitize_textarea_field( (string) ( $request['customer_note'] ?? '' ) ),
            'admin_note'     => sanitize_textarea_field( (string) ( $request['admin_note'] ?? '' ) ),
            'submitted_at'   => sanitize_text_field( (string) ( $request['submitted_at'] ?? '' ) ),
            'reviewed_at'    => sanitize_text_field( (string) ( $request['reviewed_at'] ?? '' ) ),
            'reviewed_by'    => absint( $request['reviewed_by'] ?? 0 ),
            'customer_name'  => sanitize_text_field( (string) ( $request['customer_name'] ?? '' ) ),
            'customer_email' => sanitize_email( (string) ( $request['customer_email'] ?? '' ) ),
            'uid'            => get_current_user_id(),
            'exp'            => time() + self::TTL,
        );

        $json = wp_json_encode( $payload );
        if ( ! is_string( $json ) ) {
            return '';
        }

        $encoded   = rtrim( strtr( base64_encode( $json ), '+/', '-_' ), '=' );
        $signature = hash_hmac( 'sha256', $encoded, wp_salt( 'nonce' ) );

        return $encoded . '.' . $signature;
    }

    /**
     * @return array<string,mixed>|null
     */
    public function verify( string $token ): ?array {
        $token = trim( $token );
        if ( '' === $token || false === strpos( $token, '.' ) ) {
            return null;
        }

        list( $encoded, $signature ) = array_pad( explode( '.', $token, 2 ), 2, '' );
        $expected = hash_hmac( 'sha256', $encoded, wp_salt( 'nonce' ) );

        if ( '' === $signature || ! hash_equals( $expected, $signature ) ) {
            return null;
        }

        $padding = strlen( $encoded ) % 4;
        if ( $padding ) {
            $encoded .= str_repeat( '=', 4 - $padding );
        }

        $json = base64_decode( strtr( $encoded, '-_', '+/' ), true );
        if ( false === $json ) {
            return null;
        }

        $payload = json_decode( $json, true );
        if ( ! is_array( $payload ) ) {
            return null;
        }

        if ( absint( $payload['uid'] ?? 0 ) !== get_current_user_id() ) {
            return null;
        }

        if ( absint( $payload['exp'] ?? 0 ) < time() ) {
            return null;
        }

        if ( absint( $payload['order_id'] ?? 0 ) < 1 || absint( $payload['request_id'] ?? $payload['id'] ?? 0 ) < 1 ) {
            return null;
        }

        unset( $payload['uid'], $payload['exp'] );

        return $payload;
    }
}
