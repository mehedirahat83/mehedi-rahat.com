(function(){
'use strict';
var cfg=window.MRBPVerificationDrawer||{};
var activeRequestId=0;

function esc(value){
    return String(value==null?'':value).replace(/[&<>'"]/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch];});
}
function ensure(){
    var el=document.getElementById('mrbp-verification-drawer');
    if(el)return el;
    el=document.createElement('div');
    el.id='mrbp-verification-drawer';
    el.className='mrbp-verification-drawer';
    el.innerHTML='<div class="mrbp-verification-drawer__backdrop" data-close></div><aside class="mrbp-verification-drawer__panel" role="dialog" aria-modal="true" aria-label="Payment verification details"><button type="button" class="mrbp-verification-drawer__close" data-close aria-label="Close">×</button><div class="mrbp-verification-drawer__notice" aria-live="polite"></div><div class="mrbp-verification-drawer__content"></div></aside>';
    document.body.appendChild(el);
    el.addEventListener('click',function(e){if(e.target.closest('[data-close]'))close(el);});
    return el;
}
function close(el){el.classList.remove('is-open');document.body.classList.remove('mrbp-drawer-open');closeDialog();}
function notice(type,message){
    var el=ensure().querySelector('.mrbp-verification-drawer__notice');
    el.innerHTML='<div class="mrbp-decision-notice mrbp-decision-notice--'+esc(type)+'">'+esc(message)+'</div>';
    window.setTimeout(function(){el.innerHTML='';},5000);
}
function open(id,orderId,transactionId,requestToken){
    activeRequestId=parseInt(id,10)||0;
    var el=ensure(),content=el.querySelector('.mrbp-verification-drawer__content');
    content.innerHTML='<div class="mrbp-drawer-loading"><span class="spinner is-active"></span><p>'+esc(cfg.loading||'Loading…')+'</p></div>';
    el.classList.add('is-open');document.body.classList.add('mrbp-drawer-open');
    var data=new URLSearchParams();data.append('action','mrbp_payment_request_details');data.append('nonce',cfg.nonce||'');data.append('request_id',activeRequestId);data.append('order_id',parseInt(orderId,10)||0);data.append('transaction_id',transactionId||'');data.append('request_token',requestToken||'');
    fetch(cfg.ajaxUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:data.toString()})
        .then(function(r){return r.json();})
        .then(function(r){if(!r.success)throw new Error((r.data&&r.data.message)||cfg.error);activeRequestId=parseInt(r.data&&r.data.request_id,10)||activeRequestId;content.innerHTML=r.data.html;})
        .catch(function(err){content.innerHTML='<div class="notice notice-error inline"><p>'+esc(err.message||cfg.error)+'</p></div>';});
}
function closeDialog(){var d=document.getElementById('mrbp-decision-dialog');if(d)d.remove();}
function dialogMarkup(decision,meta,note){
    var title=decision==='approve'?cfg.approveTitle:(decision==='review'?cfg.reviewTitle:cfg.rejectTitle);
    var confirmLabel=decision==='approve'?'Approve':(decision==='review'?'Save Review':'Reject');
    var reasons='';
    if(decision==='reject'){
        reasons='<label class="mrbp-dialog-label" for="mrbp-reject-reason">Reason <span aria-hidden="true">*</span></label><select id="mrbp-reject-reason" class="mrbp-dialog-select"><option value="">Select a reason</option>';
        Object.keys(cfg.reasons||{}).forEach(function(key){reasons+='<option value="'+esc(key)+'">'+esc(cfg.reasons[key])+'</option>';});
        reasons+='</select>';
    }
    return '<div id="mrbp-decision-dialog" class="mrbp-decision-dialog" role="dialog" aria-modal="true" aria-labelledby="mrbp-dialog-title"><div class="mrbp-decision-dialog__backdrop" data-dialog-close></div><div class="mrbp-decision-dialog__card"><button type="button" class="mrbp-decision-dialog__close" data-dialog-close aria-label="Close">×</button><h2 id="mrbp-dialog-title">'+esc(title)+'</h2><div class="mrbp-dialog-summary"><div><span>Order</span><strong>#'+esc(meta.order)+'</strong></div><div><span>Gateway</span><strong>'+esc(meta.gateway)+'</strong></div><div><span>Amount</span><strong>'+esc(meta.amount)+'</strong></div><div><span>Transaction</span><strong>'+esc(meta.transaction)+'</strong></div></div>'+reasons+'<label class="mrbp-dialog-label" for="mrbp-dialog-note">Admin Note</label><textarea id="mrbp-dialog-note" rows="4" placeholder="Add an internal note">'+esc(note)+'</textarea><div class="mrbp-dialog-error" aria-live="polite"></div><div class="mrbp-decision-dialog__actions"><button type="button" class="button" data-dialog-close>Cancel</button><button type="button" class="button '+(decision==='approve'?'button-primary':(decision==='reject'?'mrbp-danger-button':'mrbp-review-button'))+'" data-confirm-decision="'+esc(decision)+'">'+esc(confirmLabel)+'</button></div></div></div>';
}
function openDecisionDialog(button){
    var wrap=button.closest('.mrbp-decision-actions');if(!wrap)return;
    var decision=button.getAttribute('data-decision');
    var note=document.querySelector('#mrbp-admin-note-'+wrap.getAttribute('data-request-id'));
    var meta={order:wrap.getAttribute('data-order'),gateway:wrap.getAttribute('data-gateway'),amount:wrap.getAttribute('data-amount'),transaction:wrap.getAttribute('data-transaction')};
    closeDialog();document.body.insertAdjacentHTML('beforeend',dialogMarkup(decision,meta,note?note.value:''));
    var d=document.getElementById('mrbp-decision-dialog');window.setTimeout(function(){d.classList.add('is-open');var first=d.querySelector(decision==='reject'?'select':'textarea');if(first)first.focus();},10);
}
function setBusy(dialog,busy){
    dialog.querySelectorAll('button,select,textarea').forEach(function(el){el.disabled=busy;});
    var btn=dialog.querySelector('[data-confirm-decision]');
    if(btn){if(!btn.dataset.label)btn.dataset.label=btn.textContent;btn.textContent=busy?(cfg.processing||'Processing…'):btn.dataset.label;btn.classList.toggle('is-loading',busy);}
}
function errorMessage(data){
    if(data&&data.message)return data.message;
    var code=data&&data.code?data.code:'';
    var map={request_locked:'This request is being processed by another administrator.',concurrent_update:'This request was already updated. Refresh and try again.',already_processed:'This payment request has already been processed.',invalid_transition:'This action is not allowed for the current status.',invalid_reject_reason:'Please select a valid rejection reason.',request_not_found:'Payment request not found.',forbidden:'You are not allowed to review payments.'};
    return map[code]||cfg.genericError||'Unable to update this payment request.';
}
function submitDecision(button){
    var dialog=button.closest('.mrbp-decision-dialog');
    var decision=button.getAttribute('data-confirm-decision');
    var reasonEl=dialog.querySelector('#mrbp-reject-reason');
    var noteEl=dialog.querySelector('#mrbp-dialog-note');
    var errorEl=dialog.querySelector('.mrbp-dialog-error');
    var reason=reasonEl?reasonEl.value:'';
    if(decision==='reject'&&!reason){errorEl.textContent='Please select a rejection reason.';reasonEl.focus();return;}
    errorEl.textContent='';setBusy(dialog,true);
    var data=new URLSearchParams();
    data.append('action','mrbp_payment_decision');data.append('nonce',cfg.decisionNonce||'');data.append('request_id',activeRequestId);data.append('decision',decision);data.append('admin_note',noteEl?noteEl.value:'');data.append('reason',reason);
    fetch(cfg.ajaxUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:data.toString()})
        .then(function(r){return r.json();})
        .then(function(r){if(!r.success)throw r.data||{};closeDialog();notice('success',(r.data&&r.data.message)||'Payment request updated successfully.');var trigger=document.querySelector('.mrbp-open-verification[data-request-id="'+activeRequestId+'"]');open(activeRequestId,trigger?trigger.getAttribute('data-order-id'):0,trigger?trigger.getAttribute('data-transaction-id'):'',trigger?trigger.getAttribute('data-request-token'):'');refreshRow(activeRequestId,r.data&&r.data.status);})
        .catch(function(err){setBusy(dialog,false);errorEl.textContent=errorMessage(err);});
}
function refreshRow(id,status){
    var trigger=document.querySelector('.mrbp-open-verification[data-request-id="'+id+'"]');
    var row=trigger?trigger.closest('tr'):null;
    if(!row||!status)return;
    var badge=row.querySelector('.mrbp-payment-status');
    if(badge){badge.className='mrbp-payment-status mrbp-payment-status--'+status;badge.textContent=status.replace(/_/g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();});}
}
document.addEventListener('click',function(e){
    var btn=e.target.closest('.mrbp-open-verification');if(btn){e.preventDefault();var fallbackId=(btn.id||'').replace(/^mrbp-verify-/, '');open(btn.getAttribute('data-request-id')||fallbackId,btn.getAttribute('data-order-id'),btn.getAttribute('data-transaction-id'),btn.getAttribute('data-request-token')||btn.value||'');return;}
    var action=e.target.closest('.mrbp-decision-button');if(action){e.preventDefault();openDecisionDialog(action);return;}
    if(e.target.closest('[data-dialog-close]')){e.preventDefault();closeDialog();return;}
    var confirm=e.target.closest('[data-confirm-decision]');if(confirm){e.preventDefault();submitDecision(confirm);}
});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){var dialog=document.getElementById('mrbp-decision-dialog');if(dialog){closeDialog();return;}var el=document.getElementById('mrbp-verification-drawer');if(el)close(el);}});
})();
