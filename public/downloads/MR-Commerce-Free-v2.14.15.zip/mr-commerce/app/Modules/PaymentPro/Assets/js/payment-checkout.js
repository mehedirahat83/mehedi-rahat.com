(function ($) {
    'use strict';

    var storageKey = 'mrbp_checkout_gateway';
    var checkoutUpdateTimer = null;
    var checkoutUpdatePending = false;
    var lastCheckoutGateway = '';

    function scope() {
        return $('.payment_method_mrbp_manual_payment');
    }

    function cards() {
        return scope().find('.mrbp-checkout-gateway');
    }

    function inputs() {
        return scope().find('input[name="mrbp_checkout_gateway"]');
    }

    function mirror() {
        return scope().find('input[name="mrbp_checkout_gateway_value"]');
    }

    function panels() {
        return scope().find('[data-mrbp-inline-panel]');
    }

    function hasGateway(value) {
        return !!value && inputs().filter(function () {
            return this.value === value;
        }).length > 0;
    }

    function remember(value) {
        try {
            window.sessionStorage.setItem(storageKey, value);
        } catch (error) {
            // Checkout POST remains authoritative when storage is unavailable.
        }
    }

    function showPanel(value) {
        panels().each(function () {
            var active = $(this).attr('data-mrbp-inline-panel') === value;
            $(this)
                .toggleClass('is-active', active)
                .attr('aria-hidden', active ? 'false' : 'true');
        });
    }

    function updateVisualState(value) {
        cards().each(function () {
            var $card = $(this);
            var active = $card.attr('data-gateway') === value;
            $card.toggleClass('is-selected', active).attr('aria-checked', active ? 'true' : 'false');
        });
    }

    function selectGateway(value, persist) {
        if (!hasGateway(value)) {
            return;
        }

        inputs().each(function () {
            this.checked = this.value === value;
        });

        mirror().val(value);
        updateVisualState(value);
        showPanel(value);

        if (persist !== false) {
            remember(value);
            requestCheckoutUpdate(value);
        }

        $(document.body).trigger('mrbp_gateway_changed', [value]);
    }

    function requestCheckoutUpdate(value) {
        if (!value || checkoutUpdatePending || lastCheckoutGateway === value) {
            return;
        }

        window.clearTimeout(checkoutUpdateTimer);
        checkoutUpdateTimer = window.setTimeout(function () {
            checkoutUpdatePending = true;
            lastCheckoutGateway = value;
            $(document.body).trigger('update_checkout');
        }, 120);
    }

    function selectedValue() {
        var value = inputs().filter(':checked').val() || mirror().val() || '';
        if (!value) {
            try {
                value = window.sessionStorage.getItem(storageKey) || '';
            } catch (error) {
                value = '';
            }
        }
        return hasGateway(value) ? value : (inputs().first().val() || '');
    }

    function restoreSelection() {
        var value = selectedValue();
        if (value) {
            selectGateway(value, false);
        }
    }

    function activePanel() {
        var value = selectedValue();
        return panels().filter('[data-mrbp-inline-panel="' + value.replace(/"/g, '\\"') + '"]');
    }

    function clearInlineErrors($panel) {
        $panel.find('.mrbp-inline-field-error').removeClass('mrbp-inline-field-error');
        $panel.find('.mrbp-inline-validation').remove();
    }

    function validateInlineUi(event) {
        if (!$('#payment_method_mrbp_manual_payment').is(':checked')) {
            return true;
        }

        var value = selectedValue();
        var $panel = activePanel();
        var $sender = $panel.find('[data-mrbp-inline-sender]');
        var $transaction = $panel.find('[data-mrbp-inline-transaction]');
        var messages = [];

        clearInlineErrors($panel);

        if (!value || !$panel.length) {
            messages.push('Please select a payment method.');
        }
        if (!$sender.val() || !$.trim($sender.val())) {
            messages.push('Please enter the sender number or account reference.');
            $sender.addClass('mrbp-inline-field-error');
        }
        if (!$transaction.val() || !$.trim($transaction.val())) {
            messages.push('Please enter the transaction ID or reference.');
            $transaction.addClass('mrbp-inline-field-error');
        }

        if (!messages.length) {
            return true;
        }

        event.preventDefault();
        event.stopImmediatePropagation();
        $panel.prepend('<div class="woocommerce-error mrbp-inline-validation" role="alert">' + messages.join('<br>') + '</div>');
        $('html, body').animate({ scrollTop: Math.max(0, $panel.offset().top - 120) }, 220);
        return false;
    }

    $(document.body)
        .off('click.mrbpInlineCheckout', '.payment_method_mrbp_manual_payment .mrbp-checkout-gateway')
        .on('click.mrbpInlineCheckout', '.payment_method_mrbp_manual_payment .mrbp-checkout-gateway', function (event) {
            if ($(event.target).is('a, button, input, textarea, select')) {
                return;
            }
            event.preventDefault();
            selectGateway($(this).attr('data-gateway') || '', true);
        })
        .off('change.mrbpInlineCheckout', '.payment_method_mrbp_manual_payment input[name="mrbp_checkout_gateway"]')
        .on('change.mrbpInlineCheckout', '.payment_method_mrbp_manual_payment input[name="mrbp_checkout_gateway"]', function () {
            if (this.checked) {
                selectGateway(this.value, true);
            }
        })
        .off('keydown.mrbpInlineCheckout', '.payment_method_mrbp_manual_payment .mrbp-checkout-gateway')
        .on('keydown.mrbpInlineCheckout', '.payment_method_mrbp_manual_payment .mrbp-checkout-gateway', function (event) {
            if (event.key !== 'Enter' && event.key !== ' ') {
                return;
            }
            event.preventDefault();
            selectGateway($(this).attr('data-gateway') || '', true);
        })
        .off('click.mrbpInlineCopy', '.mrbp-inline-copy')
        .on('click.mrbpInlineCopy', '.mrbp-inline-copy', function () {
            var button = this;
            var value = $(button).attr('data-copy-value') || '';
            if (!value) {
                return;
            }

            function complete() {
                var original = $(button).data('original-label') || $(button).text();
                $(button).data('original-label', original).text('Copied ✓').addClass('is-copied');
                window.setTimeout(function () {
                    $(button).text(original).removeClass('is-copied');
                }, 1600);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(value).then(complete);
                return;
            }

            var area = document.createElement('textarea');
            area.value = value;
            area.setAttribute('readonly', 'readonly');
            area.style.position = 'fixed';
            area.style.opacity = '0';
            document.body.appendChild(area);
            area.select();
            document.execCommand('copy');
            document.body.removeChild(area);
            complete();
        })
        .off('updated_checkout.mrbpInlineCheckout checkout_error.mrbpInlineCheckout')
        .on('updated_checkout.mrbpInlineCheckout checkout_error.mrbpInlineCheckout', function () {
            checkoutUpdatePending = false;
            restoreSelection();
        });

    $(document).off('checkout_place_order_mrbp_manual_payment.mrbpInlineCheckout')
        .on('checkout_place_order_mrbp_manual_payment.mrbpInlineCheckout', validateInlineUi);

    $(restoreSelection);
}(jQuery));
