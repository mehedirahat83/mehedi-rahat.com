(function () {
    'use strict';

    var submittingForms = new WeakSet();

    function openModal(modal) {
        if (!modal) return;
        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        document.documentElement.classList.add('mrbp-payment-modal-open');
        var closeButton = modal.querySelector('[data-mrbp-payment-close]');
        if (closeButton) closeButton.focus();
    }

    function closeModal(modal) {
        if (!modal) return;
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');
        document.documentElement.classList.remove('mrbp-payment-modal-open');
    }

    function setStep(dialog, step) {
        dialog.querySelectorAll('[data-mrbp-payment-step]').forEach(function (panel) {
            panel.hidden = panel.getAttribute('data-mrbp-payment-step') !== String(step);
        });
        dialog.querySelectorAll('[data-mrbp-progress]').forEach(function (item) {
            var current = parseInt(item.getAttribute('data-mrbp-progress'), 10);
            item.classList.toggle('is-active', step === 'success' || current <= parseInt(step, 10));
        });
    }

    function selectedGateway(dialog) {
        return dialog.querySelector('[data-mrbp-gateway].is-active');
    }

    function showMessage(form, message, type) {
        var box = form.querySelector('[data-mrbp-payment-message]');
        if (!box) return;
        box.hidden = false;
        box.className = 'mrbp-payment-form-message is-' + type;
        box.textContent = message;
    }

    function clearMessage(form) {
        var box = form.querySelector('[data-mrbp-payment-message]');
        if (!box) return;
        box.hidden = true;
        box.textContent = '';
    }

    function showToast(dialog, message) {
        var toast = dialog.querySelector('[data-mrbp-payment-toast]');
        if (!toast) return;
        toast.textContent = message;
        toast.hidden = false;
        toast.classList.add('is-visible');
        window.clearTimeout(toast._mrbpTimer);
        toast._mrbpTimer = window.setTimeout(function () {
            toast.classList.remove('is-visible');
            toast.hidden = true;
        }, 1800);
    }

    function fallbackCopy(value) {
        var input = document.createElement('textarea');
        input.value = value;
        input.setAttribute('readonly', 'readonly');
        input.style.position = 'fixed';
        input.style.opacity = '0';
        document.body.appendChild(input);
        input.select();
        var copied = false;
        try { copied = document.execCommand('copy'); } catch (error) { copied = false; }
        document.body.removeChild(input);
        return Promise.resolve(copied);
    }

    function copyText(value) {
        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(value).then(function () { return true; });
        }
        return fallbackCopy(value);
    }

    function validateForm(form) {
        var phone = form.querySelector('[name="sender_phone"]');
        var transaction = form.querySelector('[name="transaction_id"]');
        var phoneValue = phone ? phone.value.trim().replace(/[^A-Za-z0-9+ -]/g, '') : '';
        var transactionValue = transaction ? transaction.value.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '') : '';

        if (phone) phone.value = phoneValue;
        if (transaction) transaction.value = transactionValue;

        if (!/^[A-Za-z0-9+ -]{4,30}$/.test(phoneValue)) {
            showMessage(form, MRBPPaymentPopup.invalidPhone || 'Enter a valid mobile number.', 'error');
            if (phone) phone.focus();
            return false;
        }
        if (!/^[A-Z0-9-]{6,40}$/.test(transactionValue)) {
            showMessage(form, MRBPPaymentPopup.invalidTransaction || 'Enter a valid transaction ID.', 'error');
            if (transaction) transaction.focus();
            return false;
        }
        return true;
    }

    document.addEventListener('input', function (event) {
        var phone = event.target.closest('[name="sender_phone"]');
        if (phone) phone.value = phone.value.replace(/[^A-Za-z0-9+ -]/g, '').slice(0, 30);

        var transaction = event.target.closest('[name="transaction_id"]');
        if (transaction) transaction.value = transaction.value.toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 40);
    });

    document.addEventListener('click', function (event) {
        var opener = event.target.closest('[data-mrbp-payment-open]');
        if (opener) {
            var modal = document.getElementById(opener.getAttribute('data-mrbp-payment-open'));
            openModal(modal);
            return;
        }

        var close = event.target.closest('[data-mrbp-payment-close]');
        if (close) {
            closeModal(close.closest('.mrbp-payment-modal'));
            return;
        }

        var back = event.target.closest('[data-mrbp-payment-back]');
        if (back) {
            var backDialog = back.closest('.mrbp-payment-dialog');
            var stepTwo = backDialog.querySelector('[data-mrbp-payment-step="2"]');
            if (stepTwo && !stepTwo.hidden) setStep(backDialog, 1);
            else closeModal(backDialog.closest('.mrbp-payment-modal'));
            return;
        }

        var gateway = event.target.closest('[data-mrbp-gateway]');
        if (gateway) {
            var dialog = gateway.closest('.mrbp-payment-dialog');
            var gatewayId = gateway.getAttribute('data-mrbp-gateway');
            dialog.querySelectorAll('[data-mrbp-gateway]').forEach(function (button) {
                var active = button === gateway;
                button.classList.toggle('is-active', active);
                button.setAttribute('aria-selected', active ? 'true' : 'false');
            });
            dialog.querySelectorAll('[data-mrbp-panel]').forEach(function (panel) {
                var active = panel.getAttribute('data-mrbp-panel') === gatewayId;
                panel.classList.toggle('is-active', active);
                panel.hidden = !active;
            });
            var hiddenGateway = dialog.querySelector('[data-mrbp-selected-gateway]');
            if (hiddenGateway) hiddenGateway.value = gatewayId;
            var selectedLabel = dialog.querySelector('[data-mrbp-selected-gateway-label]');
            if (selectedLabel) selectedLabel.textContent = gateway.textContent.trim();
            var senderLabel = dialog.querySelector('[data-mrbp-sender-label]');
            var senderHelp = dialog.querySelector('[data-mrbp-sender-help]');
            var senderInput = dialog.querySelector('[name="sender_phone"]');
            if (senderLabel && gateway.dataset.mrbpSenderLabel) senderLabel.textContent = gateway.dataset.mrbpSenderLabel;
            if (senderHelp && gateway.dataset.mrbpSenderHelp) senderHelp.textContent = gateway.dataset.mrbpSenderHelp;
            if (senderInput) senderInput.placeholder = gateway.dataset.mrbpSenderPlaceholder || '';
            return;
        }

        var continueButton = event.target.closest('[data-mrbp-continue]');
        if (continueButton && !continueButton.disabled) {
            var continueDialog = continueButton.closest('.mrbp-payment-dialog');
            var selected = selectedGateway(continueDialog);
            if (selected) {
                var hidden = continueDialog.querySelector('[data-mrbp-selected-gateway]');
                if (hidden) hidden.value = selected.getAttribute('data-mrbp-gateway') || '';
                var label = continueDialog.querySelector('[data-mrbp-selected-gateway-label]');
                if (label) label.textContent = selected.textContent.trim();
            }
            setStep(continueDialog, 2);
            var firstInput = continueDialog.querySelector('[data-mrbp-payment-step="2"] input:not([type="hidden"])');
            if (firstInput) firstInput.focus();
            return;
        }

        var copy = event.target.closest('[data-mrbp-copy]');
        if (copy) {
            var value = copy.getAttribute('data-mrbp-copy') || '';
            var copyDialog = copy.closest('.mrbp-payment-dialog');
            copyText(value).then(function (didCopy) {
                if (!didCopy) return;
                var original = (window.MRBPPaymentPopup && MRBPPaymentPopup.copy) || 'Copy';
                copy.textContent = (window.MRBPPaymentPopup && MRBPPaymentPopup.copied) || 'Number copied';
                showToast(copyDialog, (window.MRBPPaymentPopup && MRBPPaymentPopup.copied) || 'Number copied');
                window.setTimeout(function () { copy.textContent = original; }, 1300);
            });
        }
    });

    document.addEventListener('submit', function (event) {
        var form = event.target.closest('[data-mrbp-payment-form]');
        if (!form) return;

        event.preventDefault();
        if (submittingForms.has(form)) return;
        clearMessage(form);

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        if (!validateForm(form)) return;

        var button = form.querySelector('.mrbp-payment-submit');
        var buttonText = button ? button.querySelector('span') : null;
        var dialog = form.closest('.mrbp-payment-dialog');
        var data = new FormData(form);

        submittingForms.add(form);
        if (button) {
            button.disabled = true;
            button.setAttribute('aria-busy', 'true');
        }
        if (buttonText) buttonText.textContent = MRBPPaymentPopup.submitting || 'Submitting…';

        fetch(MRBPPaymentPopup.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: data
        })
            .then(function (response) { return response.json(); })
            .then(function (response) {
                if (!response || !response.success) {
                    var errorMessage = response && response.data && response.data.message
                        ? response.data.message
                        : MRBPPaymentPopup.networkError;
                    showMessage(form, errorMessage, 'error');
                    return;
                }

                var successMessage = dialog.querySelector('[data-mrbp-success-message]');
                var successTransaction = dialog.querySelector('[data-mrbp-success-transaction]');
                var successStatus = dialog.querySelector('[data-mrbp-success-status]');
                if (successMessage && response.data && response.data.message) successMessage.textContent = response.data.message;
                if (successTransaction) successTransaction.textContent = (response.data && response.data.transaction_id) || data.get('transaction_id') || '—';
                if (successStatus) successStatus.textContent = (response.data && response.data.status_label) || 'Submitted';
                form.reset();
                setStep(dialog, 'success');
            })
            .catch(function () {
                showMessage(form, MRBPPaymentPopup.networkError || 'Could not connect to the server.', 'error');
            })
            .finally(function () {
                submittingForms.delete(form);
                if (button) {
                    button.disabled = false;
                    button.removeAttribute('aria-busy');
                }
                if (buttonText) buttonText.textContent = MRBPPaymentPopup.submit || 'Submit Payment';
            });
    });

    function autoOpenPaymentModal() {
        var modal = document.querySelector('.mrbp-payment-modal[data-mrbp-auto-open="1"]');
        if (!modal || modal.dataset.mrbpOpened === '1') return;
        modal.dataset.mrbpOpened = '1';
        window.setTimeout(function () { openModal(modal); }, 180);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', autoOpenPaymentModal, { once: true });
    } else {
        autoOpenPaymentModal();
    }

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;
        document.querySelectorAll('.mrbp-payment-modal:not([hidden])').forEach(closeModal);
    });
}());
