(function () {
    'use strict';

    function init() {
        const toolbar = document.querySelector('[data-mrbp-gateway-toolbar]');
        if (!toolbar) return;

        const search = toolbar.querySelector('[data-mrbp-gateway-search]');
        const clearSearch = toolbar.querySelector('[data-mrbp-gateway-search-clear]');
        const filters = Array.from(toolbar.querySelectorAll('[data-mrbp-gateway-filter]'));
        const results = toolbar.querySelector('[data-mrbp-gateway-results]');
        const cards = Array.from(document.querySelectorAll('.mrbp-payment-gateway-card'));
        const groups = Array.from(document.querySelectorAll('.mrbp-payment-method-group'));
        const emptyState = document.querySelector('[data-mrbp-gateway-empty]');
        const resetButton = document.querySelector('[data-mrbp-gateway-reset]');
        const unsavedNotice = document.querySelector('[data-mrbp-gateway-unsaved]');
        const gatewaysForm = document.querySelector('.mrbp-payment-gateways-form');
        let activeFilter = 'all';
        let dirty = false;

        const markDirty = () => {
            dirty = true;
            if (unsavedNotice) unsavedNotice.hidden = false;
        };

        const updateCounts = () => {
            const counts = {
                all: cards.length,
                mobile: cards.filter((card) => card.dataset.gatewayType === 'mobile').length,
                bank: cards.filter((card) => card.dataset.gatewayType === 'bank').length,
                disabled: cards.filter((card) => card.dataset.gatewayStatus === 'disabled').length
            };
            Object.keys(counts).forEach((key) => {
                const target = toolbar.querySelector('[data-filter-count="' + key + '"]');
                if (target) target.textContent = '(' + counts[key] + ')';
            });
        };

        const applyFilters = () => {
            const term = (search && search.value ? search.value : '').trim().toLowerCase();
            let visible = 0;

            cards.forEach((card) => {
                const haystack = (card.dataset.gatewaySearchText || card.dataset.gatewayName || '').toLowerCase();
                const type = card.dataset.gatewayType || '';
                const status = card.dataset.gatewayStatus || '';
                const matchesSearch = !term || haystack.includes(term);
                const matchesFilter = activeFilter === 'all' || type === activeFilter || status === activeFilter;
                const show = matchesSearch && matchesFilter;
                card.hidden = !show;
                if (show) visible += 1;
            });

            groups.forEach((group) => {
                const groupCards = Array.from(group.querySelectorAll('.mrbp-payment-gateway-card'));
                const groupVisible = groupCards.filter((card) => !card.hidden).length;
                group.hidden = groupVisible === 0;
                const badge = group.querySelector('.mrbp-payment-method-group__count');
                if (badge) badge.textContent = String(groupVisible);
            });

            if (emptyState) emptyState.hidden = visible !== 0;
            if (clearSearch) clearSearch.hidden = !term;
            if (results) {
                results.textContent = visible === 1 ? '1 payment method shown' : visible + ' payment methods shown';
            }
        };

        if (search) search.addEventListener('input', applyFilters);
        if (clearSearch) clearSearch.addEventListener('click', () => {
            if (search) {
                search.value = '';
                search.focus();
            }
            applyFilters();
        });

        filters.forEach((button) => button.addEventListener('click', () => {
            activeFilter = button.dataset.mrbpGatewayFilter || 'all';
            filters.forEach((item) => {
                const active = item === button;
                item.classList.toggle('is-active', active);
                item.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
            applyFilters();
        }));

        if (resetButton) resetButton.addEventListener('click', () => {
            activeFilter = 'all';
            if (search) search.value = '';
            filters.forEach((item) => {
                const active = item.dataset.mrbpGatewayFilter === 'all';
                item.classList.toggle('is-active', active);
                item.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
            applyFilters();
        });

        document.addEventListener('click', (event) => {
            const choose = event.target.closest('[data-mrbp-media-choose]');
            const remove = event.target.closest('[data-mrbp-media-remove]');
            const field = event.target.closest('[data-mrbp-media-field]');
            if (!field || (!choose && !remove)) return;

            const idInput = field.querySelector('[data-mrbp-media-id]');
            const urlInput = field.querySelector('[data-mrbp-media-url]');
            const preview = field.querySelector('[data-mrbp-media-preview]');

            if (remove) {
                if (idInput) idInput.value = '';
                if (urlInput) urlInput.value = '';
                if (preview) {
                    preview.classList.add('is-empty');
                    preview.innerHTML = '<span class="dashicons dashicons-format-image" aria-hidden="true"></span><small>No image selected</small>';
                }
                remove.classList.add('is-hidden');
                const chooseButton = field.querySelector('[data-mrbp-media-choose]');
                if (chooseButton) chooseButton.textContent = 'Add Image';
                markDirty();
                return;
            }

            if (!window.wp || !wp.media) return;
            const frame = wp.media({
                title: choose.dataset.mediaTitle || 'Choose Image',
                library: { type: 'image' },
                button: { text: 'Use this image' },
                multiple: false
            });
            frame.on('select', () => {
                const attachment = frame.state().get('selection').first().toJSON();
                const imageUrl = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
                if (idInput) idInput.value = String(attachment.id || '');
                if (urlInput) urlInput.value = attachment.url || imageUrl || '';
                if (preview) {
                    preview.classList.remove('is-empty');
                    preview.innerHTML = '<img src="' + imageUrl + '" alt="">';
                }
                choose.textContent = 'Replace Image';
                const removeButton = field.querySelector('[data-mrbp-media-remove]');
                if (removeButton) removeButton.classList.remove('is-hidden');
                markDirty();
            });
            frame.open();
        });

        document.addEventListener('change', (event) => {
            const input = event.target.closest('.mrbp-payment-gateways-form input, .mrbp-payment-gateways-form select, .mrbp-payment-gateways-form textarea');
            if (!input) return;
            const toggle = input.closest('.mrbp-payment-switch input[type="checkbox"]');
            if (toggle) {
                const card = toggle.closest('.mrbp-payment-gateway-card');
                if (card) {
                    card.dataset.gatewayStatus = toggle.checked ? 'enabled' : 'disabled';
                    updateCounts();
                    applyFilters();
                }
            }
            markDirty();
        });

        document.addEventListener('click', (event) => {
            const button = event.target.closest('[data-mrbp-edit-gateway]');
            if (!button) return;
            const card = button.closest('.mrbp-payment-gateway-card');
            if (!card) return;

            const willOpen = !card.classList.contains('is-editing');
            cards.forEach((item) => {
                item.classList.remove('is-editing');
                const itemButton = item.querySelector('[data-mrbp-edit-gateway]');
                const itemLabel = item.querySelector('[data-mrbp-edit-label]');
                if (itemButton) itemButton.setAttribute('aria-expanded', 'false');
                if (itemLabel) itemLabel.textContent = 'Edit';
            });

            if (willOpen) {
                card.classList.add('is-editing');
                button.setAttribute('aria-expanded', 'true');
                const label = button.querySelector('[data-mrbp-edit-label]');
                if (label) label.textContent = 'Close';
                const firstField = card.querySelector('.mrbp-payment-gateway-card__fields input, .mrbp-payment-gateway-card__fields select, .mrbp-payment-gateway-card__fields textarea');
                if (firstField) window.setTimeout(() => firstField.focus({ preventScroll: true }), 80);
                card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        });

        document.querySelectorAll('[data-mrbp-gateway-sortable]').forEach((grid) => {
            let dragged = null;
            grid.addEventListener('dragstart', (event) => {
                const card = event.target.closest('.mrbp-payment-gateway-card');
                if (!card) return;
                dragged = card;
                card.classList.add('is-dragging');
                event.dataTransfer.effectAllowed = 'move';
            });
            grid.addEventListener('dragend', () => {
                if (dragged) dragged.classList.remove('is-dragging');
                dragged = null;
                updateOrder(grid);
                markDirty();
            });
            grid.addEventListener('dragover', (event) => {
                event.preventDefault();
                if (!dragged) return;
                const target = event.target.closest('.mrbp-payment-gateway-card');
                if (!target || target === dragged || target.parentNode !== grid) return;
                const rect = target.getBoundingClientRect();
                const after = event.clientY > rect.top + rect.height / 2 || event.clientX > rect.left + rect.width / 2;
                grid.insertBefore(dragged, after ? target.nextSibling : target);
            });
        });

        function updateOrder(grid) {
            Array.from(grid.querySelectorAll('.mrbp-payment-gateway-card')).forEach((card, index) => {
                const input = card.querySelector('input[name$="[sort_order]"]');
                if (input) input.value = String((index + 1) * 10);
            });
        }

        if (gatewaysForm) gatewaysForm.addEventListener('submit', () => {
            dirty = false;
            if (unsavedNotice) unsavedNotice.hidden = true;
        });
        window.addEventListener('beforeunload', (event) => {
            if (!dirty) return;
            event.preventDefault();
            event.returnValue = '';
        });

        updateCounts();
        filters.forEach((item) => item.setAttribute('aria-pressed', item.classList.contains('is-active') ? 'true' : 'false'));
        applyFilters();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
}());
