<?php

namespace MRBP\Modules\PaymentPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Database\PaymentRequestSchema;
use MRBP\Security\Database;

final class ValidationRepository {
    public function duplicate_transaction( string $transaction_id, int $exclude_id = 0 ): ?array {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $transaction_id = strtoupper( sanitize_text_field( $transaction_id ) );

        if ( '' === $transaction_id ) { return null; }

        $sql = "SELECT id, order_id, status, transaction_id FROM {$table} WHERE transaction_id = %s";
        $args = array( $transaction_id );
        if ( $exclude_id > 0 ) {
            $sql .= ' AND id != %d';
            $args[] = $exclude_id;
        }
        $sql .= ' ORDER BY id DESC LIMIT 1';
        $row = $wpdb->get_row( $wpdb->prepare( $sql, $args ), ARRAY_A );
        return is_array( $row ) ? $row : null;
    }

    public function phone_usage_count( string $phone, int $exclude_id = 0 ): int {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $phone = preg_replace( '/\D+/', '', $phone );
        if ( '' === $phone ) { return 0; }

        $sql = "SELECT COUNT(*) FROM {$table} WHERE sender_phone = %s";
        $args = array( $phone );
        if ( $exclude_id > 0 ) {
            $sql .= ' AND id != %d';
            $args[] = $exclude_id;
        }
        return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
    }
}
