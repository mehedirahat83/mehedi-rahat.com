<?php

namespace MRBP\Modules\PaymentPro\Repositories;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Database\PaymentRequestSchema;
use MRBP\Security\Database;

final class PaymentRequestRepository {

    private const COUNT_CACHE_GROUP = 'mrbp_payment_counts';
    private const COUNT_CACHE_TTL   = 120;

    public function create( array $data ): int {
        global $wpdb;

        $now = current_time( 'mysql', true );
        $record = array(
            'order_id'       => absint( $data['order_id'] ?? 0 ),
            'user_id'        => absint( $data['user_id'] ?? 0 ),
            'gateway'        => sanitize_key( (string) ( $data['gateway'] ?? '' ) ),
            'sender_phone'   => sanitize_text_field( (string) ( $data['sender_phone'] ?? '' ) ),
            'transaction_id' => strtoupper( sanitize_text_field( (string) ( $data['transaction_id'] ?? '' ) ) ),
            'amount'         => number_format( (float) ( $data['amount'] ?? 0 ), 2, '.', '' ),
            'currency'       => strtoupper( sanitize_text_field( (string) ( $data['currency'] ?? 'BDT' ) ) ),
            'status'         => sanitize_key( (string) ( $data['status'] ?? 'pending' ) ),
            'customer_note'  => sanitize_textarea_field( (string) ( $data['customer_note'] ?? '' ) ),
            'admin_note'     => '',
            'submitted_at'   => $data['submitted_at'] ?? $now,
            'reviewed_at'    => null,
            'reviewed_by'    => 0,
            'created_at'     => $now,
            'updated_at'     => $now,
        );

        $inserted = $wpdb->insert(
            PaymentRequestSchema::table_name(),
            $record,
            array( '%d', '%d', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
        );

        if ( false === $inserted ) {
            return 0;
        }

        $this->invalidate_count_cache();

        return (int) $wpdb->insert_id;
    }

    public function find( int $request_id ): ?array {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $users = Database::table_name( $wpdb->users );
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT r.id AS request_id, r.*, u.display_name AS customer_name, u.user_email AS customer_email FROM {$table} r LEFT JOIN {$users} u ON u.ID = r.user_id WHERE r.id = %d LIMIT 1",
                $request_id
            ),
            ARRAY_A
        );
        return is_array( $row ) ? $row : null;
    }


    /**
     * Resolve a request across current and migrated records.
     */
    public function resolve( int $request_id = 0, int $order_id = 0, string $transaction_id = '' ): ?array {
        if ( $request_id > 0 ) {
            $request = $this->find( $request_id );
            if ( $request ) {
                return $request;
            }
        }

        $transaction_id = strtoupper( sanitize_text_field( $transaction_id ) );
        if ( $order_id > 0 && '' !== $transaction_id ) {
            global $wpdb;
            $table = Database::table_name( PaymentRequestSchema::table_name() );
            $users = Database::table_name( $wpdb->users );
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT r.id AS request_id, r.*, u.display_name AS customer_name, u.user_email AS customer_email
                    FROM {$table} r
                    LEFT JOIN {$users} u ON u.ID = r.user_id
                    WHERE r.order_id = %d AND r.transaction_id = %s
                    ORDER BY r.id DESC LIMIT 1",
                    $order_id,
                    $transaction_id
                ),
                ARRAY_A
            );
            if ( is_array( $row ) ) {
                return $row;
            }
        }

        if ( $order_id > 0 && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $order_id );
            if ( $order && ! $order instanceof \WC_Order_Refund ) {
                $meta_request_id = absint( $order->get_meta( '_mrbp_payment_request_id', true ) );
                if ( $meta_request_id > 0 ) {
                    $request = $this->find( $meta_request_id );
                    if ( $request ) {
                        return $request;
                    }
                }
            }

            $rows = $this->for_order( $order_id, 1 );
            if ( isset( $rows[0] ) && is_array( $rows[0] ) ) {
                return $rows[0];
            }
        }

        return null;
    }

    public function transition_status(
        int $request_id,
        string $expected_status,
        string $new_status,
        int $reviewed_by,
        string $admin_note = ''
    ): bool {
        global $wpdb;

        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table}
                SET status = %s,
                    admin_note = %s,
                    reviewed_at = %s,
                    reviewed_by = %d,
                    updated_at = %s
                WHERE id = %d AND status = %s",
                sanitize_key( $new_status ),
                sanitize_textarea_field( $admin_note ),
                current_time( 'mysql', true ),
                absint( $reviewed_by ),
                current_time( 'mysql', true ),
                absint( $request_id ),
                sanitize_key( $expected_status )
            )
        );

        if ( 1 === (int) $updated ) {
            $this->invalidate_count_cache();
            return true;
        }

        return false;
    }

    public function count_by_status( string $status ): int {
        global $wpdb;

        $status    = sanitize_key( $status );
        $cache_key = 'status_' . $status;
        $found     = false;
        $cached    = wp_cache_get( $cache_key, self::COUNT_CACHE_GROUP, false, $found );

        if ( $found ) {
            return (int) $cached;
        }

        $transient_key = 'mrbp_payment_count_' . $status;
        $cached        = get_transient( $transient_key );
        if ( false !== $cached ) {
            wp_cache_set( $cache_key, (int) $cached, self::COUNT_CACHE_GROUP, self::COUNT_CACHE_TTL );
            return (int) $cached;
        }

        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $count = (int) $wpdb->get_var(
            $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $status )
        );

        set_transient( $transient_key, $count, self::COUNT_CACHE_TTL );
        wp_cache_set( $cache_key, $count, self::COUNT_CACHE_GROUP, self::COUNT_CACHE_TTL );

        return $count;
    }

    private function invalidate_count_cache(): void {
        foreach ( array( 'pending', 'submitted', 'under_review', 'verified', 'rejected', 'expired' ) as $status ) {
            delete_transient( 'mrbp_payment_count_' . $status );
            wp_cache_delete( 'status_' . $status, self::COUNT_CACHE_GROUP );
        }
    }

    /**
     * Search payment requests with prepared filters and pagination.
     *
     * @param array<string,mixed> $args Search arguments.
     * @return array{items:array<int,array<string,mixed>>,total:int,page:int,per_page:int,pages:int}
     */
    public function search( array $args = array() ): array {
        global $wpdb;

        $defaults = array(
            'search'   => '',
            'status'   => '',
            'gateway'  => '',
            'date'     => '',
            'page'     => 1,
            'per_page' => 20,
        );
        $args = wp_parse_args( $args, $defaults );

        $table    = Database::table_name( PaymentRequestSchema::table_name() );
        $users    = Database::table_name( $wpdb->users );
        $where    = array( '1=1' );
        $bindings = array();

        $status = sanitize_key( (string) $args['status'] );
        if ( '' !== $status ) {
            $where[]    = 'r.status = %s';
            $bindings[] = $status;
        }

        $gateway = sanitize_key( (string) $args['gateway'] );
        if ( '' !== $gateway ) {
            $where[]    = 'r.gateway = %s';
            $bindings[] = $gateway;
        }

        $search = sanitize_text_field( (string) $args['search'] );
        if ( '' !== $search ) {
            $like       = '%' . $wpdb->esc_like( $search ) . '%';
            $where[]    = '(CAST(r.order_id AS CHAR) LIKE %s OR r.sender_phone LIKE %s OR r.transaction_id LIKE %s OR u.display_name LIKE %s OR u.user_email LIKE %s)';
            $bindings   = array_merge( $bindings, array( $like, $like, $like, $like, $like ) );
        }

        $date = sanitize_key( (string) $args['date'] );
        if ( in_array( $date, array( 'today', 'week', 'month' ), true ) ) {
            $days       = 'today' === $date ? 0 : ( 'week' === $date ? 7 : 30 );
            $start      = 0 === $days ? gmdate( 'Y-m-d 00:00:00' ) : gmdate( 'Y-m-d H:i:s', time() - ( DAY_IN_SECONDS * $days ) );
            $where[]    = 'r.submitted_at >= %s';
            $bindings[] = $start;
        }

        $page     = max( 1, absint( $args['page'] ) );
        $per_page = max( 5, min( 100, absint( $args['per_page'] ) ) );
        $offset   = ( $page - 1 ) * $per_page;
        $where_sql = implode( ' AND ', $where );

        $count_sql = "SELECT COUNT(*) FROM {$table} r LEFT JOIN {$users} u ON u.ID = r.user_id WHERE {$where_sql}";
        if ( array() !== $bindings ) {
            $count_sql = $wpdb->prepare( $count_sql, $bindings );
        }
        $total = (int) $wpdb->get_var( $count_sql );

        $query_sql = "SELECT r.id AS request_id, r.*, u.display_name AS customer_name, u.user_email AS customer_email
            FROM {$table} r
            LEFT JOIN {$users} u ON u.ID = r.user_id
            WHERE {$where_sql}
            ORDER BY r.id DESC
            LIMIT %d OFFSET %d";
        $query_bindings = array_merge( $bindings, array( $per_page, $offset ) );
        $rows = $wpdb->get_results( $wpdb->prepare( $query_sql, $query_bindings ), ARRAY_A );

        return array(
            'items'    => is_array( $rows ) ? $rows : array(),
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'pages'    => max( 1, (int) ceil( $total / $per_page ) ),
        );
    }

    public function recent( int $limit = 20, string $status = '' ): array {
        $result = $this->search(
            array(
                'status'   => $status,
                'per_page' => $limit,
            )
        );

        return $result['items'];
    }

    public function for_user( int $user_id, int $limit = 50 ): array {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $limit = max( 1, min( 200, $limit ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT %d", $user_id, $limit ),
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    public function for_order( int $order_id, int $limit = 20 ): array {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $limit = max( 1, min( 100, $limit ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d ORDER BY id DESC LIMIT %d", $order_id, $limit ),
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    public function latest_for_order( int $order_id ): ?array {
        $rows = $this->for_order( $order_id, 1 );
        return $rows[0] ?? null;
    }

    public function has_open_request_for_order( int $order_id ): bool {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $statuses = array( 'pending', 'submitted', 'under_review' );
        $placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
        $args = array_merge( array( $order_id ), $statuses );

        $sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE order_id = %d AND status IN ({$placeholders})",
            $args
        );

        return (int) $wpdb->get_var( $sql ) > 0;
    }

    public function transaction_exists( string $transaction_id ): bool {
        global $wpdb;
        $table = Database::table_name( PaymentRequestSchema::table_name() );
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE transaction_id = %s",
                strtoupper( sanitize_text_field( $transaction_id ) )
            )
        );

        return (int) $count > 0;
    }
}
