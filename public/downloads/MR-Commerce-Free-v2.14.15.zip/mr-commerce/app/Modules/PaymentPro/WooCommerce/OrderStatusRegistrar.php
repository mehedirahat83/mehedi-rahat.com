<?php

namespace MRBP\Modules\PaymentPro\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Registers the manual-payment verification order status used by MR Payment Pro.
 */
final class OrderStatusRegistrar {

    public const STATUS_KEY  = 'mrbp-verification';
    public const POST_STATUS = 'wc-mrbp-verification';

    public function register(): void {
        add_action( 'init', array( $this, 'register_status' ) );
        add_filter( 'wc_order_statuses', array( $this, 'add_status_to_list' ) );
        add_action( 'admin_head', array( $this, 'print_admin_status_style' ) );
    }

    public function register_status(): void {
        register_post_status(
            self::POST_STATUS,
            array(
                'label'                     => _x( 'Pending Payment Verification', 'Order status', 'mr-commerce' ),
                'public'                    => true,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop(
                    'Pending Payment Verification <span class="count">(%s)</span>',
                    'Pending Payment Verification <span class="count">(%s)</span>',
                    'mr-commerce'
                ),
            )
        );
    }

    /**
     * Place the custom status directly after On hold in WooCommerce status lists.
     *
     * @param array<string,string> $statuses Existing WooCommerce order statuses.
     * @return array<string,string>
     */
    public function add_status_to_list( array $statuses ): array {
        $updated = array();

        foreach ( $statuses as $key => $label ) {
            $updated[ $key ] = $label;

            if ( 'wc-on-hold' === $key ) {
                $updated[ self::POST_STATUS ] = __( 'Pending Payment Verification', 'mr-commerce' );
            }
        }

        if ( ! isset( $updated[ self::POST_STATUS ] ) ) {
            $updated[ self::POST_STATUS ] = __( 'Pending Payment Verification', 'mr-commerce' );
        }

        return $updated;
    }

    /**
     * Give the custom status a clear orange verification badge in wp-admin.
     */
    public function print_admin_status_style(): void {
        if ( ! function_exists( 'get_current_screen' ) ) {
            return;
        }

        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->id, array( 'woocommerce_page_wc-orders', 'edit-shop_order', 'shop_order' ), true ) ) {
            return;
        }

        echo '<style>
            .order-status.status-mrbp-verification,
            mark.order-status.status-mrbp-verification {
                background: #fff4df !important;
                color: #9a5b00 !important;
                border: 1px solid #f2cf8b !important;
            }
        </style>';
    }
}
