<?php

namespace MRBP\Modules\PaymentPro\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;

final class GatewayCashoutFee {
    private const SESSION_KEY = 'mrbp_checkout_gateway';
    private const PAYMENT_METHOD = 'mrbp_manual_payment';

    private ManualGatewaySettings $settings;

    public function __construct( ManualGatewaySettings $settings ) {
        $this->settings = $settings;
    }

    public function register(): void {
        add_action( 'woocommerce_checkout_update_order_review', array( $this, 'capture_selection' ), 10, 1 );
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'add_fee' ), 20, 1 );
        add_action( 'woocommerce_checkout_create_order', array( $this, 'add_order_snapshot' ), 20, 2 );
    }

    public function capture_selection( $posted_data ): void {
        if ( ! function_exists( 'WC' ) || ! WC()->session ) {
            return;
        }

        $posted = array();
        parse_str( is_string( $posted_data ) ? $posted_data : '', $posted );
        $payment_method = sanitize_key( (string) ( $posted['payment_method'] ?? '' ) );
        $gateway = sanitize_key( (string) ( $posted['mrbp_checkout_gateway'] ?? $posted['mrbp_checkout_gateway_value'] ?? '' ) );

        if ( self::PAYMENT_METHOD !== $payment_method || ! isset( $this->settings->enabled_gateways()[ $gateway ] ) ) {
            WC()->session->set( self::SESSION_KEY, null );
            return;
        }

        WC()->session->set( self::SESSION_KEY, $gateway );
    }

    public function add_fee( $cart ): void {
        if ( function_exists( 'mrc_can' ) && ! mrc_can( 'payment.cashout_fee' ) ) {
            return;
        }
        if ( is_admin() && ! wp_doing_ajax() ) {
            return;
        }
        if ( ! function_exists( 'WC' ) || ! WC()->session || ! $cart instanceof \WC_Cart ) {
            return;
        }
        if ( self::PAYMENT_METHOD !== (string) WC()->session->get( 'chosen_payment_method' ) ) {
            return;
        }

        $gateway_id = sanitize_key( (string) WC()->session->get( self::SESSION_KEY ) );
        $gateway    = $this->settings->gateway( $gateway_id );
        if ( empty( $gateway['enabled'] ) || empty( $gateway['cashout_charge_enabled'] ) ) {
            return;
        }

        $value = max( 0, (float) ( $gateway['cashout_charge_value'] ?? 0 ) );
        if ( $value <= 0 ) {
            return;
        }

        $base = (float) $cart->get_cart_contents_total()
            + (float) $cart->get_cart_contents_tax()
            + (float) $cart->get_shipping_total()
            + (float) $cart->get_shipping_tax();
        $type = (string) ( $gateway['cashout_charge_type'] ?? 'percentage' );
        $fee  = 'fixed' === $type ? $value : ( $base * $value / 100 );
        $fee  = round( $fee, wc_get_price_decimals() );

        if ( $fee <= 0 ) {
            return;
        }

        $label = sprintf(
            /* translators: %s: payment gateway name */
            __( 'Cash-out Charge (%s)', 'mr-commerce' ),
            $this->settings->label( $gateway_id )
        );
        $cart->add_fee( $label, $fee, false );
    }

    public function add_order_snapshot( $order, array $data ): void {
        if ( function_exists( 'mrc_can' ) && ! mrc_can( 'payment.cashout_fee' ) ) {
            return;
        }
        if ( ! $order instanceof \WC_Order || self::PAYMENT_METHOD !== (string) ( $data['payment_method'] ?? '' ) || ! function_exists( 'WC' ) || ! WC()->session ) {
            return;
        }

        $gateway_id = sanitize_key( (string) WC()->session->get( self::SESSION_KEY ) );
        $gateway    = $this->settings->gateway( $gateway_id );
        if ( '' === $gateway_id || empty( $gateway['cashout_charge_enabled'] ) ) {
            return;
        }

        $order->update_meta_data( '_mrbp_cashout_gateway', $gateway_id );
        $order->update_meta_data( '_mrbp_cashout_charge_type', (string) ( $gateway['cashout_charge_type'] ?? 'percentage' ) );
        $order->update_meta_data( '_mrbp_cashout_charge_value', (string) ( $gateway['cashout_charge_value'] ?? 0 ) );

        $fee_label = sprintf( __( 'Cash-out Charge (%s)', 'mr-commerce' ), $this->settings->label( $gateway_id ) );
        foreach ( $order->get_items( 'fee' ) as $fee_item ) {
            if ( $fee_label === $fee_item->get_name() ) {
                $order->update_meta_data( '_mrbp_cashout_charge_amount', (string) $fee_item->get_total() );
                break;
            }
        }
    }
}
