<?php

namespace MRBP\Modules\PaymentPro\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Modules\PaymentPro\Services\ManualGatewaySettings;
use MRBP\Modules\PaymentPro\Services\GatewayRegistry;
use MRBP\Modules\PaymentPro\Services\GatewayCatalog;
use MRBP\Modules\PaymentPro\Services\PaymentRequestService;

/**
 * WooCommerce checkout gateway for MR Payment Center manual verification.
 */
final class ManualPaymentGateway extends \WC_Payment_Gateway {

    public const ID = 'mrbp_manual_payment';

    private ManualGatewaySettings $merchant_settings;
    private GatewayRegistry $gateway_registry;
    private GatewayCatalog $gateways;
    private PaymentRequestService $payment_requests;

    public function __construct() {
        $this->id                 = self::ID;
        $this->icon               = '';
        $this->has_fields         = true;
        $this->method_title       = __( 'MR Manual Payment', 'mr-commerce' );
        $this->method_description = __( 'Accept mobile banking and bank transfer payments, then verify submitted transaction references manually from MR Commerce Pro.', 'mr-commerce' );
        $this->supports           = array( 'products' );

        if ( function_exists( 'mrbp' ) && mrbp()->container()->has( 'payment_gateways' ) ) {
            $this->gateways          = mrbp()->gateways();
            $this->gateway_registry  = $this->gateways->registry();
            $this->merchant_settings = $this->gateways->settings();
        } else {
            $this->gateway_registry  = new GatewayRegistry();
            $this->merchant_settings = new ManualGatewaySettings( $this->gateway_registry );
            $this->gateways          = new GatewayCatalog( $this->gateway_registry, $this->merchant_settings );
        }
        $this->payment_requests  = new PaymentRequestService( null, null, $this->merchant_settings );

        $this->init_form_fields();
        $this->init_settings();

        $this->enabled     = $this->get_option( 'enabled', 'no' );
        $this->title       = $this->get_option( 'title', __( 'Pay with MR Commerce Pro', 'mr-commerce' ) );
        if ( 'Mobile Banking Payment' === $this->title ) {
            $this->title = __( 'Pay with MR Commerce Pro', 'mr-commerce' );
        }
        $this->description = $this->get_option(
            'description',
            __( 'Pay securely using mobile banking or bank transfer.', 'mr-commerce' )
        );

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            array( $this, 'process_admin_options' )
        );


        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_assets' ) );
    }

    public function init_form_fields(): void {
        $manage_url = admin_url( 'admin.php?page=mrbp-payment-center&section=gateways' );

        $this->form_fields = array(
            'enabled' => array(
                'title'   => __( 'Enable/Disable', 'mr-commerce' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable MR Manual Payment', 'mr-commerce' ),
                'default' => 'no',
            ),
            'title' => array(
                'title'       => __( 'Title', 'mr-commerce' ),
                'type'        => 'text',
                'description' => __( 'This title is displayed to customers during checkout.', 'mr-commerce' ),
                'default'     => __( 'Pay with MR Commerce Pro', 'mr-commerce' ),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __( 'Description', 'mr-commerce' ),
                'type'        => 'textarea',
                'description' => __( 'This description is displayed to customers during checkout.', 'mr-commerce' ),
                'default'     => __( 'Pay securely using mobile banking or bank transfer.', 'mr-commerce' ),
                'desc_tip'    => true,
            ),
            'merchant_configuration' => array(
                'title'       => __( 'Merchant Numbers', 'mr-commerce' ),
                'type'        => 'title',
                'description' => sprintf(
                    /* translators: %s: opening and closing link markup. */
                    __( 'Merchant names, numbers and instructions are managed once in %sMR Commerce Pro → Payment Center → Gateways%s.', 'mr-commerce' ),
                    '<a href="' . esc_url( $manage_url ) . '">',
                    '</a>'
                ),
            ),
        );
    }

    /**
     * Load checkout-only assets for the branded gateway selector.
     */
    public function enqueue_checkout_assets(): void {
        if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
            return;
        }

        wp_enqueue_style(
            'mrbp-payment-checkout',
            MRBP_URL . 'app/Modules/PaymentPro/Assets/css/payment-checkout.css',
            array(),
            MRBP_VERSION
        );

        wp_enqueue_script(
            'mrbp-payment-checkout',
            MRBP_URL . 'app/Modules/PaymentPro/Assets/js/payment-checkout.js',
            array( 'jquery' ),
            MRBP_VERSION,
            true
        );
    }

    /**
     * Render the branded mobile-banking selector inside WooCommerce checkout.
     */
    public function payment_fields(): void {
        if ( $this->description ) {
            echo '<p class="mrbp-checkout-payment__intro">' . wp_kses_post( wpautop( $this->description ) ) . '</p>';
        }

        $gateways = $this->gateways->enabled();
        if ( empty( $gateways ) ) {
            return;
        }

        $session_selected = function_exists( 'WC' ) && WC()->session
            ? sanitize_key( (string) WC()->session->get( 'mrbp_checkout_gateway' ) )
            : '';
        $selected = isset( $_POST['mrbp_checkout_gateway'] )
            ? sanitize_key( wp_unslash( $_POST['mrbp_checkout_gateway'] ) )
            : ( '' !== $session_selected ? $session_selected : (string) array_key_first( $gateways ) );

        if ( ! isset( $gateways[ $selected ] ) ) {
            $selected = (string) array_key_first( $gateways );
        }

        echo '<div class="mrbp-checkout-payment mrbp-checkout-payment--inline">';
        echo '<input type="hidden" name="mrbp_checkout_gateway_value" value="' . esc_attr( $selected ) . '">';
        echo '<p class="mrbp-checkout-payment__subtitle">' . esc_html__( 'Choose a payment method to view the account details and payment instructions.', 'mr-commerce' ) . '</p>';

        $groups = $this->gateways->grouped( $gateways );

        foreach ( $groups as $group_type => $group ) {
            $group_gateways = isset( $group['gateways'] ) && is_array( $group['gateways'] ) ? $group['gateways'] : array();
            if ( empty( $group_gateways ) ) {
                continue;
            }

            echo '<section class="mrbp-checkout-gateway-group mrbp-checkout-gateway-group--' . esc_attr( sanitize_html_class( (string) $group_type ) ) . '">';
            echo '<div class="mrbp-checkout-gateway-group__heading">';
            echo '<h4>' . esc_html( (string) ( $group['label'] ?? __( 'Payment Methods', 'mr-commerce' ) ) ) . '</h4>';
            echo '<span>' . esc_html( sprintf( _n( '%d method', '%d methods', count( $group_gateways ), 'mr-commerce' ), count( $group_gateways ) ) ) . '</span>';
            echo '</div>';
            echo '<div class="mrbp-checkout-gateways" role="radiogroup" aria-label="' . esc_attr( (string) ( $group['label'] ?? __( 'Payment Methods', 'mr-commerce' ) ) ) . '">';

            foreach ( $group_gateways as $gateway_id => $gateway ) {
                $gateway_id = sanitize_key( (string) $gateway_id );
                $label      = (string) ( $gateway['label'] ?? ucfirst( $gateway_id ) );
                $logo_url   = $this->gateways->logo_url( $gateway_id );
                $input_id   = 'mrbp_checkout_gateway_' . $gateway_id;

                echo '<label class="mrbp-checkout-gateway" for="' . esc_attr( $input_id ) . '" data-gateway="' . esc_attr( $gateway_id ) . '" tabindex="0" role="radio" aria-checked="' . ( $selected === $gateway_id ? 'true' : 'false' ) . '">';
                echo '<input id="' . esc_attr( $input_id ) . '" type="radio" name="mrbp_checkout_gateway" value="' . esc_attr( $gateway_id ) . '" ' . checked( $selected, $gateway_id, false ) . '>';
                echo '<span class="mrbp-checkout-gateway__visual">';
                echo '<span class="mrbp-checkout-gateway__logo">';
                if ( '' !== $logo_url ) {
                    echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $label ) . '">';
                } else {
                    echo '<span aria-hidden="true">' . esc_html( strtoupper( substr( $label, 0, 2 ) ) ) . '</span>';
                }
                echo '</span>';
                echo '<span class="mrbp-checkout-gateway__copy"><strong>' . esc_html( $label ) . '</strong></span>';
                echo '<span class="mrbp-checkout-gateway__check" aria-hidden="true">✓</span>';
                echo '</span>';
                echo '</label>';
            }

            echo '</div>';
            echo '</section>';
        }

        echo '<div class="mrbp-inline-panels">';
        foreach ( $gateways as $gateway_id => $gateway ) {
            $this->render_inline_gateway_panel( (string) $gateway_id, $gateway, $selected === (string) $gateway_id );
        }
        echo '</div>';
        echo '</div>';
    }

    /**
     * Render the Phase A inline checkout panel for one gateway.
     *
     * The approved inline checkout UI is connected to the existing payment-request
     * workflow. Sender and transaction fields are validated during checkout
     * and submitted after WooCommerce creates the on-hold order.
     *
     * @param string               $gateway_id Gateway identifier.
     * @param array<string,mixed>  $gateway    Hydrated gateway settings.
     * @param bool                 $expanded   Whether the panel is initially open.
     */
    private function render_inline_gateway_panel( string $gateway_id, array $gateway, bool $expanded ): void {
        $gateway_id     = sanitize_key( $gateway_id );
        $label          = sanitize_text_field( (string) ( $gateway['label'] ?? ucwords( str_replace( '_', ' ', $gateway_id ) ) ) );
        $type           = sanitize_key( (string) ( $gateway['type'] ?? 'mobile' ) );
        $logo_url       = $this->gateways->logo_url( $gateway_id );
        $account_name   = sanitize_text_field( (string) ( $gateway['account_name'] ?? '' ) );
        $account_number = sanitize_text_field( (string) ( $gateway['account_number'] ?? '' ) );
        $account_type   = sanitize_text_field( (string) ( $gateway['account_type'] ?? '' ) );
        $branch_name    = sanitize_text_field( (string) ( $gateway['branch_name'] ?? '' ) );
        $routing_number = sanitize_text_field( (string) ( $gateway['routing_number'] ?? '' ) );
        $swift_code     = sanitize_text_field( (string) ( $gateway['swift_code'] ?? '' ) );
        $instructions   = sanitize_textarea_field( (string) ( $gateway['instructions'] ?? '' ) );
        $sender_label   = sanitize_text_field( (string) ( $gateway['sender_label'] ?? __( 'Sender Number', 'mr-commerce' ) ) );
        $sender_help    = sanitize_text_field( (string) ( $gateway['sender_help'] ?? '' ) );
        $sender_placeholder = sanitize_text_field( (string) ( $gateway['sender_placeholder'] ?? '' ) );
        $qr_url         = esc_url_raw( (string) ( $gateway['qr_url'] ?? $gateway['qr_image_url'] ?? $gateway['qr_image'] ?? '' ) );
        $method_label   = 'bank' === $type ? __( 'Bank Transfer', 'mr-commerce' ) : __( 'Mobile Banking', 'mr-commerce' );
        $account_label  = sanitize_text_field( (string) ( $gateway['account_label'] ?? ( 'bank' === $type ? __( 'Account Number', 'mr-commerce' ) : __( 'Send Money Number', 'mr-commerce' ) ) ) );
        $instruction_lines = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $instructions ) ?: array() ) ) );

        echo '<section class="mrbp-inline-panel mrbp-rc-checkout' . ( $expanded ? ' is-active' : '' ) . '" data-mrbp-inline-panel="' . esc_attr( $gateway_id ) . '" aria-hidden="' . ( $expanded ? 'false' : 'true' ) . '">';

        echo '<header class="mrbp-rc-header">';
        echo '<div class="mrbp-rc-brand">';
        echo '<span class="mrbp-rc-shield" aria-hidden="true">✓</span>';
        echo '<div><span class="mrbp-rc-eyebrow">' . esc_html__( 'Secure manual checkout', 'mr-commerce' ) . '</span>';
        echo '<h3>' . esc_html__( 'Pay with MR Commerce Pro', 'mr-commerce' ) . '</h3>';
        echo '<p>' . esc_html( $label . ' • ' . $method_label ) . '</p></div>';
        echo '</div>';
        echo '<span class="mrbp-rc-verified"><span aria-hidden="true">✓</span>' . esc_html__( 'Secure & Verified', 'mr-commerce' ) . '</span>';
        echo '</header>';

        echo '<div class="mrbp-rc-body">';
        echo '<div class="mrbp-rc-hero' . ( '' === $qr_url ? ' has-no-qr' : '' ) . '">';
        if ( '' !== $qr_url ) {
            echo '<div class="mrbp-rc-qr">';
            echo '<span>' . esc_html__( 'Scan QR', 'mr-commerce' ) . '</span>';
            echo '<img src="' . esc_url( $qr_url ) . '" alt="' . esc_attr( sprintf( __( '%s QR code', 'mr-commerce' ), $label ) ) . '">';
            echo '<a href="' . esc_url( $qr_url ) . '" download>' . esc_html__( 'Download QR', 'mr-commerce' ) . '</a>';
            echo '</div>';
        }

        echo '<div class="mrbp-rc-number-card">';
        echo '<div class="mrbp-rc-number-head">';
        if ( '' !== $logo_url ) {
            echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $label ) . '">';
        }
        echo '<div><span>' . esc_html( $account_label ) . '</span><strong>' . esc_html( $label ) . '</strong></div>';
        echo '</div>';
        if ( '' !== $account_number ) {
            echo '<div class="mrbp-rc-number-row"><b>' . esc_html( $account_number ) . '</b>';
            echo '<button type="button" class="mrbp-inline-copy mrbp-rc-copy" data-copy-value="' . esc_attr( $account_number ) . '"><span aria-hidden="true">⧉</span>' . esc_html__( 'Copy', 'mr-commerce' ) . '</button></div>';
        }
        if ( '' !== $account_name || '' !== $account_type ) {
            echo '<div class="mrbp-rc-account-meta">';
            if ( '' !== $account_name ) {
                echo '<span><small>' . esc_html__( 'Account Name', 'mr-commerce' ) . '</small><strong>' . esc_html( $account_name ) . '</strong></span>';
            }
            if ( '' !== $account_type ) {
                echo '<span><small>' . esc_html__( 'Account Type', 'mr-commerce' ) . '</small><strong>' . esc_html( ucwords( str_replace( '_', ' ', $account_type ) ) ) . '</strong></span>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';

        if ( 'bank' === $type && ( '' !== $branch_name || '' !== $routing_number || '' !== $swift_code ) ) {
            echo '<div class="mrbp-rc-bank-meta">';
            if ( '' !== $branch_name ) {
                $this->render_inline_detail( __( 'Branch', 'mr-commerce' ), $branch_name );
            }
            if ( '' !== $routing_number ) {
                $this->render_inline_detail( __( 'Routing Number', 'mr-commerce' ), $routing_number );
            }
            if ( '' !== $swift_code ) {
                $this->render_inline_detail( __( 'SWIFT Code', 'mr-commerce' ), $swift_code );
            }
            echo '</div>';
        }

        if ( ! empty( $instruction_lines ) ) {
            echo '<section class="mrbp-rc-instructions">';
            echo '<div class="mrbp-rc-section-title"><span aria-hidden="true">i</span><div><h4>' . esc_html__( 'Payment Instructions', 'mr-commerce' ) . '</h4><p>' . esc_html__( 'Complete these steps before placing the order.', 'mr-commerce' ) . '</p></div></div>';
            echo '<div class="mrbp-rc-steps">';
            foreach ( $instruction_lines as $index => $instruction_line ) {
                echo '<div class="mrbp-rc-step mrbp-rc-step--' . esc_attr( (string) ( ( $index % 4 ) + 1 ) ) . '"><span>' . esc_html( (string) ( $index + 1 ) ) . '</span><p>' . esc_html( $instruction_line ) . '</p></div>';
            }
            echo '</div>';
            echo '</section>';
        }

        echo '<section class="mrbp-rc-customer-form">';
        echo '<div class="mrbp-rc-section-title"><span aria-hidden="true">→</span><div><h4>' . esc_html__( 'Submit Payment Details', 'mr-commerce' ) . '</h4><p>' . esc_html__( 'Use the same information shown in your payment confirmation.', 'mr-commerce' ) . '</p></div></div>';
        echo '<div class="mrbp-inline-panel__fields">';
        echo '<label class="mrbp-inline-field"><span>' . esc_html( $sender_label ) . ' <em>*</em></span><div class="mrbp-inline-field__control"><span class="mrbp-inline-field__icon" aria-hidden="true">↗</span><input type="text" class="input-text" data-mrbp-inline-sender name="mrbp_ui_sender[' . esc_attr( $gateway_id ) . ']" placeholder="' . esc_attr( $sender_placeholder ) . '" autocomplete="tel"></div><small>' . esc_html( $sender_help ) . '</small></label>';
        echo '<label class="mrbp-inline-field"><span>' . esc_html__( 'Transaction ID / Reference', 'mr-commerce' ) . ' <em>*</em></span><div class="mrbp-inline-field__control"><span class="mrbp-inline-field__icon" aria-hidden="true">#</span><input type="text" class="input-text" data-mrbp-inline-transaction name="mrbp_ui_transaction[' . esc_attr( $gateway_id ) . ']" placeholder="' . esc_attr__( 'Enter the transaction reference', 'mr-commerce' ) . '" autocomplete="off"></div></label>';
        echo '</div>';
        echo '</section>';

        echo '<div class="mrbp-inline-panel__notice mrbp-rc-notice"><span aria-hidden="true">✓</span><p>' . esc_html__( 'Payment details are verified manually. Order processing starts only after successful verification.', 'mr-commerce' ) . '</p></div>';
        echo '</div>';
        echo '</section>';
    }

    private function render_inline_detail( string $label, string $value ): void {
        echo '<div class="mrbp-inline-detail"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( $value ) . '</strong></div>';
    }

    /**
     * Validate the selected mobile-banking option.
     */
    public function validate_fields(): bool {
        $gateways       = $this->merchant_settings->enabled_gateways();
        $selected       = $this->posted_gateway();
        $sender_number  = $this->posted_sender_number( $selected );
        $transaction_id = $this->posted_transaction_id( $selected );
        $valid          = true;

        if ( '' === $selected || ! isset( $gateways[ $selected ] ) ) {
            wc_add_notice( __( 'Please select a payment method.', 'mr-commerce' ), 'error' );
            return false;
        }

        if ( ! preg_match( '/^[A-Za-z0-9+ \-]{4,30}$/', $sender_number ) ) {
            wc_add_notice( __( 'Please enter a valid sender number or account reference.', 'mr-commerce' ), 'error' );
            $valid = false;
        }

        if ( ! preg_match( '/^[A-Z0-9-]{6,40}$/', $transaction_id ) ) {
            wc_add_notice( __( 'Please enter a valid transaction ID or reference.', 'mr-commerce' ), 'error' );
            $valid = false;
        } elseif ( $this->payment_requests->repository()->transaction_exists( $transaction_id ) ) {
            wc_add_notice( __( 'This transaction ID has already been submitted.', 'mr-commerce' ), 'error' );
            $valid = false;
        }

        return $valid;
    }

    /**
     * Read and sanitize the checkout gateway from the native radio or its
     * synchronized hidden mirror.
     */
    private function posted_gateway(): string {
        $selected = isset( $_POST['mrbp_checkout_gateway'] )
            ? sanitize_key( wp_unslash( $_POST['mrbp_checkout_gateway'] ) )
            : '';

        if ( '' === $selected && isset( $_POST['mrbp_checkout_gateway_value'] ) ) {
            $selected = sanitize_key( wp_unslash( $_POST['mrbp_checkout_gateway_value'] ) );
        }

        return $selected;
    }


    /**
     * Read the sender number/account reference for the selected gateway.
     */
    private function posted_sender_number( string $gateway ): string {
        $values = isset( $_POST['mrbp_ui_sender'] ) && is_array( $_POST['mrbp_ui_sender'] )
            ? wp_unslash( $_POST['mrbp_ui_sender'] )
            : array();

        $value = isset( $values[ $gateway ] ) ? (string) $values[ $gateway ] : '';

        return trim( preg_replace( '/[^A-Za-z0-9+ \-]/', '', $value ) );
    }

    /**
     * Read the transaction/reference value for the selected gateway.
     */
    private function posted_transaction_id( string $gateway ): string {
        $values = isset( $_POST['mrbp_ui_transaction'] ) && is_array( $_POST['mrbp_ui_transaction'] )
            ? wp_unslash( $_POST['mrbp_ui_transaction'] )
            : array();

        $value = isset( $values[ $gateway ] ) ? (string) $values[ $gateway ] : '';

        return strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', $value ) );
    }

    /**
     * Convert a payment-request error code to a customer-safe checkout notice.
     */
    private function submission_error_message( string $code ): string {
        $messages = array(
            'duplicate_transaction_id' => __( 'This transaction ID has already been submitted.', 'mr-commerce' ),
            'open_request_exists'       => __( 'A payment request already exists for this order.', 'mr-commerce' ),
            'invalid_phone'             => __( 'Please enter a valid sender number or account reference.', 'mr-commerce' ),
            'invalid_transaction_id'    => __( 'Please enter a valid transaction ID or reference.', 'mr-commerce' ),
            'invalid_gateway'           => __( 'Please select a valid payment method.', 'mr-commerce' ),
            'database_error'            => __( 'The payment request could not be saved. Please try again.', 'mr-commerce' ),
        );

        return $messages[ $code ] ?? __( 'The payment details could not be submitted. Please review them and try again.', 'mr-commerce' );
    }

    public function is_available(): bool {
        if ( 'yes' !== $this->enabled ) {
            return false;
        }

        if ( empty( $this->merchant_settings->enabled_gateways() ) ) {
            return false;
        }

        return parent::is_available();
    }

    /**
     * Create the payment request from checkout data, keep the order on hold,
     * and redirect to the normal WooCommerce order-received page.
     *
     * @param int $order_id WooCommerce order ID.
     * @return array{result:string,redirect:string}
     */
    public function process_payment( $order_id ): array {
        $order = wc_get_order( absint( $order_id ) );

        if ( ! $order || $order instanceof \WC_Order_Refund ) {
            wc_add_notice( __( 'The order could not be prepared for payment. Please try again.', 'mr-commerce' ), 'error' );

            return array(
                'result'   => 'failure',
                'redirect' => '',
            );
        }

        $gateways          = $this->merchant_settings->enabled_gateways();
        $selected_gateway  = $this->posted_gateway();
        $sender_number     = $this->posted_sender_number( $selected_gateway );
        $transaction_id    = $this->posted_transaction_id( $selected_gateway );

        if ( ! isset( $gateways[ $selected_gateway ] ) ) {
            wc_add_notice( __( 'Please select a valid payment method.', 'mr-commerce' ), 'error' );
            return array( 'result' => 'failure', 'redirect' => '' );
        }

        $order->update_meta_data( '_mrbp_preferred_gateway', $selected_gateway );
        $order->update_meta_data( '_mrbp_gateway', $selected_gateway );
        $order->update_meta_data( '_mrbp_sender_number', $sender_number );
        $order->update_meta_data( '_mrbp_transaction_id', $transaction_id );
        $order->save();

        $submission = $this->payment_requests->submit(
            array(
                'order_id'       => $order->get_id(),
                'gateway'        => $selected_gateway,
                'sender_phone'   => $sender_number,
                'transaction_id' => $transaction_id,
                'customer_note'  => '',
            )
        );

        if ( empty( $submission['success'] ) ) {
            wc_add_notice( $this->submission_error_message( (string) ( $submission['code'] ?? '' ) ), 'error' );
            return array( 'result' => 'failure', 'redirect' => '' );
        }

        if ( ! $order->is_paid() ) {
            $initial_status = $this->merchant_settings->initial_order_status();
            $status_notes   = array(
                'on-hold'          => __( 'Manual payment details submitted. Order placed on hold pending administrator verification.', 'mr-commerce' ),
                'processing'       => __( 'Manual payment details submitted. Order moved to processing before administrator verification.', 'mr-commerce' ),
                'mrbp-verification'=> __( 'Manual payment details submitted. Payment is pending administrator verification.', 'mr-commerce' ),
            );

            $order->update_status(
                $initial_status,
                $status_notes[ $initial_status ] ?? $status_notes['on-hold']
            );
        }

        wc_reduce_stock_levels( $order->get_id() );

        if ( WC()->cart ) {
            WC()->cart->empty_cart();
        }

        do_action( 'mrbp/payment/gateway_order_created', $order->get_id(), $order, $this );

        return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url( $order ),
        );
    }
}
