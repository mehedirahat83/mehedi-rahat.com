<?php

namespace MRBP\Modules\PaymentPro\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Registers the manual gateway with WooCommerce without coupling the module
 * bootstrap to WooCommerce gateway internals.
 */
final class GatewayRegistrar {

    private bool $registered = false;

    public function register(): void {
        if ( $this->registered || ! class_exists( 'WC_Payment_Gateway' ) ) {
            return;
        }

        $this->registered = true;
        add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
    }

    /**
     * @param array<int,string> $gateways Registered gateway classes.
     * @return array<int,string>
     */
    public function add_gateway( array $gateways ): array {
        if ( ! in_array( ManualPaymentGateway::class, $gateways, true ) ) {
            $gateways[] = ManualPaymentGateway::class;
        }

        return $gateways;
    }
}
