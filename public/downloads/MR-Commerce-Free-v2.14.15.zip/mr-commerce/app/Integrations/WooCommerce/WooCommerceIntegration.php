<?php

namespace MRBP\Integrations\WooCommerce;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use MRBP\Support\Logger;

final class WooCommerceIntegration {

    private Logger $logger;
    private bool $available = false;

    public function __construct( Logger $logger ) {
        $this->logger = $logger;
    }

    public function register_compatibility(): void {
        add_action( 'before_woocommerce_init', array( $this, 'declare_hpos_compatibility' ) );
    }

    public function initialize(): void {
        $this->available = class_exists( 'WooCommerce' );

        if ( ! $this->available ) {
            $this->logger->warning( 'WooCommerce integration was not initialized because WooCommerce is unavailable.' );
            return;
        }

        do_action( 'mrbp/integrations/woocommerce/ready', $this );
        $this->logger->info( 'WooCommerce integration initialized.' );
    }

    public function is_available(): bool {
        return $this->available;
    }

    public function declare_hpos_compatibility(): void {
        $features_util = '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil';

        if ( ! class_exists( $features_util ) ) {
            return;
        }

        $features_util::declare_compatibility(
            'custom_order_tables',
            MRBP_FILE,
            true
        );
    }
}
