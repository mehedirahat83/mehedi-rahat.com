<?php

namespace MRBP\Services;

use DateTimeImmutable;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Shared WooCommerce analytics calculations.
 */
final class Analytics {
    private const WEEKLY_CACHE_KEY = 'mrbp_weekly_sales_completed_sat_v1';
    private const WEEKLY_CACHE_TTL = 300;

    /**
     * Return completed, paid-order net sales for the current and previous week.
     *
     * Weeks start Saturday at 00:00 in the WordPress site timezone.
     * Revenue is order total less refunded amount.
     *
     * @return array<string, int|float|string>
     */
    public static function get_weekly_sales(): array {
        static $request_cache = null;

        if ( is_array( $request_cache ) ) {
            return $request_cache;
        }

        $cached = get_transient( self::WEEKLY_CACHE_KEY );
        if ( is_array( $cached ) ) {
            $request_cache = $cached;
            return $request_cache;
        }

        $timezone = wp_timezone();
        $now = new DateTimeImmutable( 'now', $timezone );
        $today = $now->setTime( 0, 0, 0 );
        $days_since_saturday = ( (int) $today->format( 'N' ) + 1 ) % 7;
        $week_start = $today->modify( '-' . $days_since_saturday . ' days' );
        $previous_week_start = $week_start->modify( '-7 days' );

        $result = array(
            'start'                    => $week_start->format( DATE_ATOM ),
            'end'                      => $now->format( DATE_ATOM ),
            'start_timestamp'          => $week_start->getTimestamp(),
            'end_timestamp'            => $now->getTimestamp(),
            'revenue'                  => 0.0,
            'orders'                   => 0,
            'previous_start_timestamp' => $previous_week_start->getTimestamp(),
            'previous_end_timestamp'   => $week_start->getTimestamp(),
            'previous_revenue'         => 0.0,
            'previous_orders'          => 0,
        );

        if ( ! function_exists( 'wc_get_orders' ) ) {
            $request_cache = $result;
            return $request_cache;
        }

        $orders = wc_get_orders(
            array(
                'limit'   => -1,
                'orderby' => 'date',
                'order'   => 'DESC',
                'status'    => array( 'completed' ),
                'date_paid' => '>=' . $previous_week_start->getTimestamp(),
            )
        );

        foreach ( $orders as $order ) {
            if ( ! $order instanceof WC_Order || ! $order->is_paid() ) {
                continue;
            }

            $date = $order->get_date_paid() ?: $order->get_date_completed() ?: $order->get_date_created();
            if ( ! $date ) {
                continue;
            }

            $sale_timestamp = $date->getTimestamp();
            $net_revenue = max( 0.0, (float) $order->get_total() - (float) $order->get_total_refunded() );

            if ( $sale_timestamp >= $result['start_timestamp'] && $sale_timestamp <= $result['end_timestamp'] ) {
                $result['revenue'] += $net_revenue;
                ++$result['orders'];
                continue;
            }

            if ( $sale_timestamp >= $result['previous_start_timestamp'] && $sale_timestamp < $result['previous_end_timestamp'] ) {
                $result['previous_revenue'] += $net_revenue;
                ++$result['previous_orders'];
            }
        }

        set_transient( self::WEEKLY_CACHE_KEY, $result, self::WEEKLY_CACHE_TTL );
        $request_cache = $result;

        return $request_cache;
    }

    /**
     * Clear the shared weekly analytics cache.
     */
    public static function clear_weekly_cache(): void {
        delete_transient( self::WEEKLY_CACHE_KEY );
    }
}
