=== MR Commerce ===
Contributors: mehedirahat
Tags: woocommerce, crm, payments, customers, orders, reports
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 2.14.15
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A modular WooCommerce operations, payments and growth foundation.

== Description ==

MR Commerce provides a shared Free/Pro foundation for WooCommerce store
operations. Core modules are available in the Free edition with basic
capabilities. MR Commerce Pro unlocks advanced capabilities through a verified
MR License Manager license.

Version 2.5.0 adds retention, provider integrations and production-release foundations:

* One shared source for Free and Pro releases.
* Feature-level Free/Pro entitlements.
* Free fallback when a Pro license is inactive.
* Existing settings, order metadata and business data are preserved.
* Existing MR License Manager product identity and signed licenses remain supported.
* Free and Pro editions cannot run together.
* Free includes basic CRM, customer portal, login, one manual payment method and sequential order numbers.
* Pro adds advanced CRM reports/exports, redirects, unlimited payment methods, payment verification and cash-out fees.
* Membership, activation requests, support tickets and license domains form the Pro Digital Products Pack.
* Physical Store onboarding, fulfilment states, order confirmation and customer tracking.
* Pro conditional COD, risk detection, packing slips, shipping labels and return/restock tools.
* District/city/area checkout data, rule-based shipping and delivery slots.
* Courier assignment, consignment tracking and extensible courier adapters.
* Stock dashboard, alerts, movement history, variation inventory, costing and suppliers.
* Quantity, BOGO, cart and coupon campaigns.
* Bundles, frequently bought together and checkout order bumps.
* Side cart, shipping progress, sticky cart and swatches.
* Wishlist, compare, quick view and recently viewed products.
* Consent-based abandoned-cart recovery and review reminders.
* Reorder, customer segmentation and automated recovery coupons.
* Email, SMS webhook and courier webhook provider architecture.
* Advanced product-cost, refund, margin and gross-profit analytics.

Current modules include:

* WooCommerce CRM and customer portal.
* Manual payment collection and verification foundation.
* Sequential WooCommerce order numbers.

== Installation ==

1. Upload the appropriate MR Commerce or MR Commerce Pro ZIP.
2. Activate the plugin.
3. Open MR Commerce in WordPress administration.
4. Pro customers can activate their existing MR License Manager license from the License screen.

Upgrading from an older MR Commerce Pro or MR Business build preserves the
existing `mrbp_*` settings, tables, hooks and order metadata.

== Frequently Asked Questions ==

= Does the Free edition require a license? =

No. MR Commerce Free runs without license activation or License Manager requests.

= What customer data does cart recovery store? =

Only customers who explicitly select the cart-reminder consent option are
captured. The plugin stores their submitted email/phone, cart product IDs,
quantities, total and recovery state in the WordPress database.

= What happens if a Pro license expires or is deactivated? =

The plugin falls back to Free capabilities. Pro settings and business data are
preserved and become available again after the license is restored.

== External services ==

MR Commerce does not select or contact an SMS or courier vendor by default.
Administrators may configure their own HTTPS provider endpoints in Pro. When
used, the plugin sends the phone/message data needed for SMS delivery or the
order recipient/address/total data needed to create a courier consignment.
Data handling and terms are determined by the administrator's chosen provider.

= Can Free and Pro run together? =

No. Activating Pro safely disables Free while preserving shared data. Free will
not activate while Pro is active.

== Changelog ==

= 2.14.15 =
* Removed the duplicate checkout District field and now uses WooCommerce's Bangladesh-aware State/District field as the canonical district value.
* Preserved legacy district order metadata as a fallback while shipping rules and order admin views use WooCommerce state data first.

= 2.14.14 =
* Restored Shop Manager access to operational dashboards while keeping module toggles, global settings and licensing administrator-only.
* Paginated and cached CRM profit analytics to avoid loading every recent order into memory.
* Clarified the unavailable payment webhook response and completed a Free/Pro package integrity audit.

= 2.14.13 =
* Fixes unreadable WordPress notifications inside MR Commerce operation pages.
* Adds accessible text and background colors for success, error, warning and information notices.
* Corrects notice links and dismiss-icon contrast inside gradient hero areas.

= 2.14.12 =
* Fixes the MR Commerce section gap using container-level spacing.
* Accounts for the shipping builder data element between Shipping Operations and the COD form.

= 2.14.11 =
* Fixes Bengali font rendering in descriptions and help-guide body text.
* Keeps Roboto for English descriptions with bundled Noto Sans Bengali fallback.
* Prevents the general description rule from overriding Bengali guide typography.

= 2.14.10 =
* Adds consistent spacing above the Conditional Cash on Delivery section in MR Commerce.
* Separates the embedded Shipping Operations workspace from the following settings row.

= 2.14.9 =
* Places MR Customer Dashboard first in the module menu section.
* Removes Membership, Activation Requests and Support Tickets from the Customer Dashboard hub.
* Keeps existing digital-product data and services intact for backward compatibility.

= 2.14.8 =
* Registers MR Commerce, MR Growth Suite and MR Fraud Checker under the MR Commerce Pro admin menu.
* Fixes the WordPress "not allowed to access this page" error for those module pages.
* Keeps supporting workspaces registered as hidden pages reachable through module flyouts.
* Removes the destructive submenu-removal workaround.

= 2.14.7 =
* Restores all six enabled modules in the MR Commerce Pro Modules flyout.
* Separates saved navigation visibility from runtime entitlement checks.
* Keeps module execution protected by the existing plan and dependency guards.

= 2.14.6 =
* Removes duplicate MR Commerce custom links from the WooCommerce submenu.
* Keeps all module pages accessible from the MR Commerce Pro module flyout.
* Leaves WooCommerce Core navigation unchanged.

= 2.14.5 =
* Embeds Shipping Operations near the top of the MR Commerce workspace.
* Loads the visual district-rule and delivery-slot builders on the MR Commerce page.
* Keeps the separate Shipping Operations submenu as a secondary shortcut.

= 2.14.4 =
* Moves Profit Analytics from MR Commerce into the CRM Dashboard.
* Removes the redundant Profit Analytics submenu and MR Commerce embedded section.
* Preserves purchase-cost metadata, calculations and Pro license entitlement.

= 2.14.3 =
* Places Review and Reorder beside Abandoned Cart Recovery in the embedded Growth Automation workspace on desktop.
* Preserves a responsive single-column layout on mobile screens.

= 2.14.2 =
* Shows Growth Automation and Retention controls directly inside the MR Growth Suite workspace.
* Shows Courier Integration and Profit Analytics directly inside the MR Commerce workspace.
* Keeps the existing submenu pages as optional shortcuts and preserves all saved settings.

= 2.14.1 =
* Matched every primary module detail-page title to its Module Manager name.
* Renamed the Customer Portal Pro hub and breadcrumbs to MR Customer Dashboard.
* Standardized MR Commerce, MR Growth Suite, MR Fraud Checker, MR Sequential Orders and MR Payment Center admin labels.
* Updated dashboard quick-access labels to use the canonical module names.

= 2.14.0 =
* Merged Retention & Integrations into MR Growth Suite and MR Commerce.
* Moved recovery, reminders, reorder, segmentation and SMS/email automation into MR Growth Suite.
* Moved courier webhook integration and profit analytics into MR Commerce.
* Added dedicated Growth Automation and Courier Integration admin workspaces.
* Removed the standalone Retention module identity while preserving its settings, records and legacy license entitlement.
* Added an upgrade migration that transfers an enabled Retention toggle to Growth and Commerce before removing the obsolete toggle.

= 2.13.1 =
* Renamed MR Commerce module to MR Customer Dashboard.
* Renamed MR Physical Commerce module to MR Commerce.
* Standardized the seven-module order across Module Manager and the Modules flyout.
* Added manifest positions so module order remains stable across Free and Pro builds.

= 2.13.0 =
* Removed the MR Login Pro module, authentication handlers, admin screens, shortcodes, templates and assets.
* Removed Login Pro from the module manifest, feature catalogue, navigation, settings, recovery and license labels.
* Added the missing Manage Module action to MR Fraud Checker.
* Reduced vertical padding on Manage Module buttons.

= 2.12.0 =
* Moved MR Fraud Checker, Retention & Integrations, Growth Suite and Physical Commerce into the Modules flyout.
* Kept MR Fraud Checker as an independent module rather than a Physical Commerce child.
* Added descendant-aware active navigation for Physical Commerce and Retention subpages.
* Kept Settings and License as the final root navigation items.

= 2.11.3 =
* Aligned the Courier name and Consignment endpoint fields on one desktop row.
* Preserved a stacked, full-width layout for mobile screens.

= 2.11.2 =
* Added locally bundled Inter typography for headings across MR Commerce admin screens.
* Added locally bundled Roboto typography for descriptions, body copy and form controls.
* Standardized primary headings at 700 and supporting headings at 600.
* Removed the external Google Fonts request from the admin framework.

= 2.11.1 =
* Bundled Noto Sans Bengali locally for clearer Bengali contextual guides.
* Applied the font only to Bengali help content while preserving the existing dashboard typography.
* Added the font license to both Free and Pro release packages.

= 2.11.0 =
* Added a reusable Bengali contextual-help system for operations modules.
* Added concise Bengali summaries, three-step instructions, examples and safety notes.
* Added guides to Physical Commerce, Fraud Checker, Shipping Operations, Growth Suite and Retention & Integrations.
* Added compact expandable presentation with responsive mobile behavior.

= 2.10.2 =
* Removed the unused right-side gap from Growth Suite settings.
* Changed Growth Suite campaign cards to a full-width, single-column workflow.

= 2.10.1 =
* Kept all BOGO controls on one aligned desktop row with compact number inputs.
* Added responsive wrapping for narrow mobile screens.

= 2.10.0 =
* Replaced the Growth Suite advanced campaign JSON editor with a repeatable visual campaign builder.
* Added percentage and fixed-cart discount types, minimum cart/quantity conditions and maximum discount caps.
* Added product-category and customer-role targeting.
* Added active toggles, priority ordering and safe rule removal.
* Preserved legacy percent-based JSON campaigns and converts them only when an administrator saves.

= 2.9.1 =
* Fixed the Physical Store preset success notification contrast inside the premium Physical Commerce interface.
* Added explicit readable text, heading, link and dismiss-button colors for the success state.

= 2.9.0 =
* Replaced raw shipping-rule JSON with a repeatable visual rule builder containing all 64 Bangladesh districts.
* Added district, area/thana, amount, weight, quantity, cart value, shipping class, rate ID and disable controls.
* Added rule activation, priority ordering and safe removal controls.
* Replaced line-based delivery slots with weekday, time window, label, capacity and cutoff scheduling.
* Added checkout weekday filtering, server-side slot validation and capacity enforcement.
* Preserved and automatically presented legacy JSON rules and line-based slots for data-safe migration.

= 2.8.0 =
* Aligned COD availability with the WooCommerce Core gateway; MR Commerce now adds only conditional availability and fees.
* Replaced the duplicate basic cart-discount implementation with WooCommerce Core coupons while preserving MR auto-apply and advanced campaigns.
* Removed the duplicate checkout order-confirmation note and the retired legacy risk detector.
* Changed returns to an inspection-first workflow that invokes WooCommerce Core stock restoration only when explicitly approved.
* Added Core-powered, MR Enhanced and MR Exclusive capability labels to clarify feature ownership.
* Preserved deprecated settings for safe rollback and added a one-time, non-destructive migration record.

= 2.7.0 =
* Added MR Fraud Checker as a dedicated Bangladesh-focused WooCommerce risk intelligence module.
* Added Bangla/English phone normalization, BD mobile validation, duplicate phone/email screening and trust/block lists.
* Added explainable 0–100 risk scoring, Low/Medium/High/Critical badges, HPOS order-list support and order review actions.
* Added Pro IP, address, COD-value and customer-history signals with safe On-hold automation.
* Added a provider-neutral courier risk adapter foundation without enabling unconfigured external lookups.
* Migrates existing Physical Commerce duplicate-window values safely as Fraud Checker defaults.

= 2.6.0 =
* Introduced a premium, unified dashboard experience for Physical Commerce, Shipping Operations, Growth Suite, Retention and Profit Analytics.
* Added branded workspace headers, responsive cards, polished settings controls and a dedicated profit KPI dashboard.
* Preserved existing module settings, Free/Pro entitlements and MR License Manager behavior.

= 2.5.3 =

* Removed internal Customer/Owner edition identity from the customer-facing dashboard.
* Removed Build Edition from the License Center summary.
* Simplified dashboard and license summary layouts after removing edition metadata.
* Moved Settings and License to the final two positions in MR Commerce navigation.
* Kept all operational suites ahead of global configuration links.

= 2.5.2 =

* Fixed valid MR Commerce Pro licenses incorrectly showing activation prompts for newer features.
* Treats a signed active `mr-commerce-pro` product license as a full-suite entitlement.
* Preserves signature, product, plan, domain, expiry, suspension and revocation validation.
* Keeps inactive, invalid, expired and revoked licenses in graceful Free fallback.
* Retains granular entitlement behavior for non-full-suite/custom license products.

= 2.5.1 =

* Added Manage Module buttons for Retention, Growth Suite and Physical Commerce.
* Added direct MR Commerce sidebar entries for all three operational suites.
* Added Retention links for Recovery & Providers and Profit Analytics.
* Added Physical Commerce links for core settings, Shipping Operations and Stock Dashboard.
* Added Shop Manager visibility for the new operational navigation.
* Added distinct module icons for faster visual identification.

= 2.5.0 =

* Added consent-based Pro abandoned-cart capture and scheduled recovery.
* Added Free review reminders and customer reorder actions.
* Added Free customer segmentation with expanded Pro visibility.
* Added Pro single-use, email-restricted automated recovery coupons.
* Added WordPress email and Pro generic SMS webhook providers.
* Added a Pro authenticated courier webhook adapter with consignment creation.
* Added encrypted-at-rest SMS and courier API tokens.
* Added Pro 30-day revenue, cost, refunds, gross-profit and margin analytics.
* Made the signed Pro update-feed URL externally configurable.
* Added a formal production compatibility matrix and release-gate report.

= 2.4.0 =

* Added a separately toggleable Growth Suite module.
* Added basic Free and advanced Pro entitlements for all 15 growth capabilities.
* Added quantity, same-product BOGO and cart-value discount calculations.
* Added automatic existing-coupon application and Pro multi-coupon support.
* Added product bundles, frequently bought together groups and checkout order bumps.
* Added side cart, free-shipping progress and sticky add-to-cart interfaces.
* Added variation select enhancement and Pro button swatches.
* Added browser-persistent wishlist and compare tools with Free/Pro limits.
* Added secure quick-view requests and Pro quick-add.
* Added cookie-based recently viewed products with Free/Pro history limits.

= 2.3.0 =

* Added District and Area/Thana checkout fields alongside WooCommerce City.
* Added Pro area, weight, quantity, shipping-class and cart-value shipping rules.
* Added conditional rate disabling and delivery date/time slots.
* Added manual courier assignment, consignment IDs and a filterable Pro courier-adapter contract.
* Added a stock dashboard with simple-product and variation inventory.
* Added low/out-of-stock admin alerts.
* Added Pro stock movement auditing with a bounded log.
* Added Pro purchase cost, calculated profit margin and supplier information.
* Integrated Phase 3 return/restock records into the inventory workflow.

= 2.2.0 =

* Added a Physical Store onboarding preset with safe inventory, stock-hold and tax defaults.
* Added Packing, Shipped, Delivered, Delivery Failed and Returned order states.
* Added order confirmation timestamps, order notes and customer shipment tracking.
* Added Pro COD fees and conditional availability by order total and shipping method.
* Added Pro duplicate email/phone and high-value COD risk detection.
* Added printable Pro packing slips and shipping labels.
* Added Pro return reasons and one-time stock restoration protection.
* Added Free previews and data-safe fallback for every Physical Commerce Pro capability.

= 2.1.0 =

* Split every current module into enforceable basic and advanced capabilities.
* Added Pro feature previews and contextual upgrade actions in Free.
* Added Free limits for customer profiles and enabled manual payment gateways.
* Added the Pro Digital Products Pack: membership, activation requests, support and license domains.
* Added runtime guards for reports, exports, advanced redirects, payment verification, cash-out fees and custom order-number formatting.
* Added graceful Free fallback while preserving all Pro settings and business data.

= 2.0.0 =

* Introduced the MR Commerce Free and MR Commerce Pro shared-code architecture.
* Added a central feature catalogue with feature-level plans and limits.
* Added Free fallback for missing, inactive, expired or revoked Pro licenses.
* Preserved MR License Manager signed-license and module-entitlement compatibility.
* Added compatibility helpers: `mrc_can()`, `mrc_limit()` and `mrc_plan()`.
* Added data-safe Free/Pro edition switching and legacy slug recognition.
* Standardized public branding and text domain as MR Commerce.
* Synchronized plugin, build and readme versions.
* Added deterministic Free and Pro release builds with package validation.
