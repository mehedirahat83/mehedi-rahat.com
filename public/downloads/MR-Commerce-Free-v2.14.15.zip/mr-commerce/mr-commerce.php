<?php
/**
 * Plugin Name: MR Commerce
 * Plugin URI: https://mehedirahat.com/mr-commerce/
 * Description: Modular WooCommerce operations, payments and growth foundation.
 * Version: 2.14.15
 * Author: Mehedi Rahat
 * Author URI: https://mehedirahat.com/
 * Text Domain: mr-commerce
 * Domain Path: /languages
 * Requires at least: 6.4
 * Requires PHP: 8.1
 *
 */

defined( 'ABSPATH' ) || exit;

/*
 * These build constants are replaced by scripts/build-release.ps1 when the
 * Free package is generated. Internal MRBP names remain compatibility aliases
 * for existing options, tables, hooks and MR License Manager licenses.
 */
define( 'MRBP_BUILD_PLAN', 'free' );
define( 'MRBP_BUILD_EDITION', 'free' );
define( 'MRBP_PRODUCT_NAME', 'MR Commerce' );
define( 'MRBP_PRODUCT_ID', 'mr-commerce' );

if ( 'pro' === MRBP_BUILD_PLAN
    && ( defined( 'MR_COMMERCE_FREE_EDITION_LOADED' )
        || defined( 'MRBP_FREE_EDITION_LOADED' )
        || ( defined( 'MRBP_BUILD_EDITION_ACTIVE' ) && 'free' === MRBP_BUILD_EDITION_ACTIVE ) ) ) {
    if ( ! function_exists( 'deactivate_plugins' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    deactivate_plugins(
        array(
            'mr-commerce/mr-commerce.php',
            'mr-business/mr-business.php',
            'mr-business-lite/mr-business-pro.php',
        ),
        true,
        is_network_admin()
    );

    update_option( 'mrbp_version', '2.14.15', false );
    set_transient( 'mrbp_edition_notice', 'pro_replaced_free', MINUTE_IN_SECONDS * 5 );
    set_transient( 'mrbp_activation_redirect', true, 30 );
    return;
}

if ( 'free' === MRBP_BUILD_PLAN && ( defined( 'MR_COMMERCE_PRO_EDITION_LOADED' ) || defined( 'MRBP_PRO_EDITION_LOADED' ) ) ) {
    return;
}

if ( 'pro' === MRBP_BUILD_PLAN ) {
    define( 'MR_COMMERCE_PRO_EDITION_LOADED', true );
    define( 'MRBP_PRO_EDITION_LOADED', true );
} else {
    define( 'MR_COMMERCE_FREE_EDITION_LOADED', true );
    define( 'MRBP_FREE_EDITION_LOADED', true );
}

define( 'MRBP_BUILD_EDITION_ACTIVE', MRBP_BUILD_PLAN );
define( 'MRBP_VERSION', '2.14.15' );
define( 'MRBP_DB_VERSION', '1.0.0' );
define( 'MRBP_FILE', __FILE__ );
define( 'MRBP_PATH', plugin_dir_path( __FILE__ ) );
define( 'MRBP_URL', plugin_dir_url( __FILE__ ) );
define( 'MRBP_BASENAME', plugin_basename( __FILE__ ) );
if ( ! defined( 'MRBP_UPDATE_FEED_URL' ) ) {
    define( 'MRBP_UPDATE_FEED_URL', '' );
}
define( 'MRBP_UPDATE_CHANNEL', 'stable' );

require_once MRBP_PATH . 'vendor/autoload.php';
require_once MRBP_PATH . 'app/functions.php';

register_activation_hook( MRBP_FILE, array( \MRBP\Core\Activator::class, 'activate' ) );
register_deactivation_hook( MRBP_FILE, array( \MRBP\Core\Deactivator::class, 'deactivate' ) );

add_action(
    'plugins_loaded',
    static function (): void {
        $requirements = new \MRBP\Core\Requirements();

        if ( ! $requirements->passes() ) {
            $requirements->register_admin_notice();
            return;
        }

        \MRBP\Core\Plugin::instance()->boot();
    },
    20
);
