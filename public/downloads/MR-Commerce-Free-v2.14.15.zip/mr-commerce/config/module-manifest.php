<?php

defined( 'ABSPATH' ) || exit;

use MRBP\Core\PlanManager;
use MRBP\Modules\CustomerPortal\CustomerPortalModule;
use MRBP\Modules\PaymentPro\PaymentProModule;
use MRBP\Modules\SequentialOrders\SequentialOrdersModule;
use MRBP\Modules\PhysicalCommerce\PhysicalCommerceModule;
use MRBP\Modules\GrowthSuite\GrowthSuiteModule;
use MRBP\Modules\FraudChecker\FraudCheckerModule;

/*
 * The single source of truth for shipped modules. All core modules may boot
 * in Free; config/feature-catalogue.php controls capability-level access.
 */
return array(
    'fraud_checker' => array(
        'class' => FraudCheckerModule::class,
        'name' => 'MR Fraud Checker',
        'position' => 40,
        'description' => 'Bangladesh-focused COD risk intelligence, scoring and manual review workflow.',
        'plan' => PlanManager::PLAN_FREE,
        'customer_entitlement' => 'physical_commerce',
        'status' => 'stable',
        'dependencies' => array(
            array( 'type' => 'php', 'min_version' => '8.1' ),
            array( 'type' => 'wordpress', 'min_version' => '6.4' ),
            array( 'type' => 'woocommerce', 'min_version' => '8.0' ),
        ),
    ),
    'growth_suite' => array(
        'class' => GrowthSuiteModule::class,
        'name' => 'MR Growth Suite',
        'position' => 30,
        'description' => 'Conversion, retention, recovery, segmentation and messaging tools for WooCommerce.',
        'plan' => PlanManager::PLAN_FREE,
        'customer_entitlement' => 'growth_suite',
        'status' => 'stable',
        'dependencies' => array(
            array( 'type' => 'php', 'min_version' => '8.1' ),
            array( 'type' => 'wordpress', 'min_version' => '6.4' ),
            array( 'type' => 'woocommerce', 'min_version' => '8.0' ),
        ),
    ),
    'physical_commerce' => array(
        'class'         => PhysicalCommerceModule::class,
        'name'          => 'MR Commerce',
        'position'      => 20,
        'description'   => 'Fulfilment, shipping, inventory and courier integrations.',
        'plan'          => PlanManager::PLAN_FREE,
        'customer_entitlement' => 'physical_commerce',
        'status'        => 'stable',
        'dependencies'  => array(
            array( 'type' => 'php', 'min_version' => '8.1' ),
            array( 'type' => 'wordpress', 'min_version' => '6.4' ),
            array( 'type' => 'woocommerce', 'min_version' => '8.0' ),
        ),
    ),
    'customer_portal' => array(
        'class'         => CustomerPortalModule::class,
        'name'          => 'MR Customer Dashboard',
        'position'      => 10,
        'description'   => 'WooCommerce CRM, customers, orders, reports and portal tools.',
        'plan'          => PlanManager::PLAN_FREE,
        'customer_entitlement' => 'customer_portal',
        'status'        => 'admin-crm',
        'dependencies'  => array(
            array( 'type' => 'php', 'min_version' => '8.1' ),
            array( 'type' => 'wordpress', 'min_version' => '6.4' ),
            array( 'type' => 'php_extension', 'name' => 'json' ),
            array( 'type' => 'woocommerce', 'min_version' => '8.0' ),
        ),
    ),
    'payment_pro' => array(
        'class'         => PaymentProModule::class,
        'name'          => 'MR Payment Center',
        'position'      => 60,
        'description'   => 'Manual payment verification center with API-ready gateway architecture.',
        'plan'          => PlanManager::PLAN_FREE,
        'customer_entitlement' => 'payment_pro',
        'status'        => 'manual-payment-rc',
        'dependencies'  => array(
            array( 'type' => 'php', 'min_version' => '8.1' ),
            array( 'type' => 'wordpress', 'min_version' => '6.4' ),
            array( 'type' => 'php_extension', 'name' => 'json' ),
            array( 'type' => 'php_extension', 'name' => 'openssl' ),
            array( 'type' => 'woocommerce', 'min_version' => '8.0' ),
            array( 'type' => 'class', 'name' => 'WC_Payment_Gateway', 'label' => 'WooCommerce payment gateway API' ),
        ),
    ),
    'sequential_orders' => array(
        'class'         => SequentialOrdersModule::class,
        'name'          => 'MR Sequential Orders',
        'position'      => 50,
        'description'   => 'Sequential WooCommerce order numbers with prefix.',
        'plan'          => PlanManager::PLAN_FREE,
        'customer_entitlement' => 'sequential_orders',
        'status'        => 'stable',
        'dependencies'  => array(
            array( 'type' => 'php', 'min_version' => '8.1' ),
            array( 'type' => 'wordpress', 'min_version' => '6.4' ),
            array( 'type' => 'woocommerce', 'min_version' => '8.0' ),
        ),
    ),
);
