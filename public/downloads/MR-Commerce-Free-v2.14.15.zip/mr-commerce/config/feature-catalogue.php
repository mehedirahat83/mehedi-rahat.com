<?php

defined( 'ABSPATH' ) || exit;

use MRBP\Core\PlanManager;

/*
 * Central Free/Pro feature catalogue.
 *
 * A limit of -1 means unlimited. Existing MR License Manager module
 * entitlements are retained through license_entitlement mappings.
 */
$growth = array(
    'quantity_discount', 'bogo', 'cart_discount', 'product_bundle',
    'frequently_bought_together', 'order_bump', 'auto_coupon', 'side_cart',
    'free_shipping_bar', 'sticky_add_to_cart', 'variation_swatches',
    'wishlist', 'compare', 'quick_view', 'recently_viewed',
);
$growth_catalogue = array(
    'growth_suite' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'growth_suite', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
);
foreach ( $growth as $feature ) {
    $growth_catalogue[ 'growth.' . $feature . '.basic' ] = array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'growth_suite', 'limits' => array( 'free' => 1, 'pro' => -1 ),
    );
    $growth_catalogue[ 'growth.' . $feature . '.advanced' ] = array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'growth_suite', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    );
}

return $growth_catalogue + array(
    'fraud_checker' => array(
        'module' => 'fraud_checker', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'fraud.basic' => array(
        'module' => 'fraud_checker', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 100, 'pro' => -1 ),
    ),
    'fraud.advanced_scoring' => array(
        'module' => 'fraud_checker', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'fraud.automation' => array(
        'module' => 'fraud_checker', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'fraud.courier_intelligence' => array(
        'module' => 'fraud_checker', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'retention.review_reminder' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 1, 'pro' => -1 ),
    ),
    'retention.reorder' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'retention.segmentation' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 3, 'pro' => -1 ),
    ),
    'retention.abandoned_cart' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 0, 'pro' => 5000 ),
    ),
    'retention.automated_coupons' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'integration.sms' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'integration.email' => array(
        'module' => 'growth_suite', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'integration.courier_webhook' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'analytics.profit' => array(
        'module' => 'customer_portal', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'retention_suite', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'shipping.address_fields' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'shipping.area_rules' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'shipping.delivery_slots' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'shipping.courier_assignment' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'shipping.courier_adapters' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'inventory.dashboard' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 50, 'pro' => -1 ),
    ),
    'inventory.alerts' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'inventory.movement_log' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => 1000 ),
    ),
    'inventory.costing' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'inventory.suppliers' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'physical_commerce' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'physical.fulfilment' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'physical.tracking' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_FREE,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => -1, 'pro' => -1 ),
    ),
    'physical.cod_rules' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'physical.shipping_documents' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'physical.returns' => array(
        'module' => 'physical_commerce', 'minimum_plan' => PlanManager::PLAN_PRO,
        'license_entitlement' => 'physical_commerce', 'limits' => array( 'free' => 0, 'pro' => -1 ),
    ),
    'customer_portal' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => -1, 'pro' => -1 ),
    ),
    'crm.basic_dashboard' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => -1, 'pro' => -1 ),
    ),
    'crm.advanced_reports' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'crm.exports' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'customer.basic_profiles' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 20, 'pro' => -1 ),
    ),
    'customer.segmentation' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'payment_pro' => array(
        'module'              => 'payment_pro',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'payment_pro',
        'limits'              => array( 'free' => -1, 'pro' => -1 ),
    ),
    'payment.manual_gateway' => array(
        'module'              => 'payment_pro',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'payment_pro',
        'limits'              => array( 'free' => 1, 'pro' => -1 ),
    ),
    'payment.unlimited_gateways' => array(
        'module'              => 'payment_pro',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'payment_pro',
        'limits'              => array( 'free' => 1, 'pro' => -1 ),
    ),
    'payment.verification' => array(
        'module'              => 'payment_pro',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'payment_pro',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'payment.cashout_fee' => array(
        'module'              => 'payment_pro',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'payment_pro',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'payment.reports' => array(
        'module'              => 'payment_pro',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'payment_pro',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'sequential_orders' => array(
        'module'              => 'sequential_orders',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'sequential_orders',
        'limits'              => array( 'free' => -1, 'pro' => -1 ),
    ),
    'orders.basic_sequence' => array(
        'module'              => 'sequential_orders',
        'minimum_plan'        => PlanManager::PLAN_FREE,
        'license_entitlement' => 'sequential_orders',
        'limits'              => array( 'free' => -1, 'pro' => -1 ),
    ),
    'orders.custom_sequence' => array(
        'module'              => 'sequential_orders',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'sequential_orders',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'digital.membership' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'digital.activation_requests' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'digital.support_tickets' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
    'digital.license_domains' => array(
        'module'              => 'customer_portal',
        'minimum_plan'        => PlanManager::PLAN_PRO,
        'license_entitlement' => 'customer_portal',
        'limits'              => array( 'free' => 0, 'pro' => -1 ),
    ),
);
