(function(){
  'use strict';
  var dataNode=document.getElementById('mrc-shipping-builder-data');
  if(!dataNode)return;
  var data={districts:{},classes:[]};
  try{data=JSON.parse(dataNode.textContent)||data;}catch(e){}
  var dayNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  function read(id){var el=document.getElementById(id);try{return JSON.parse(el.value)||[];}catch(e){return[];}}
  function set(id,value){document.getElementById(id).value=JSON.stringify(value);}
  function option(select,value,label){var o=document.createElement('option');o.value=value;o.textContent=label;select.appendChild(o);}
  function field(label,type,value,key,step){
    var wrap=document.createElement('label');wrap.className='mrc-builder-field';
    var title=document.createElement('span');title.textContent=label;wrap.appendChild(title);
    var input=document.createElement('input');input.type=type;input.value=value==null?'':value;input.dataset.key=key;
    if(step)input.step=step;if(type==='number')input.min='0';wrap.appendChild(input);return wrap;
  }
  function actions(index,list,render){
    var box=document.createElement('div');box.className='mrc-builder-actions';
    [['Up','Move up',-1],['Down','Move down',1]].forEach(function(a){var b=document.createElement('button');b.type='button';b.className='button';b.textContent=a[0];b.title=a[1];b.onclick=function(){var n=index+a[2];if(n<0||n>=list.length)return;var item=list.splice(index,1)[0];list.splice(n,0,item);render();};box.appendChild(b);});
    var del=document.createElement('button');del.type='button';del.className='button mrc-remove';del.textContent='Remove';del.onclick=function(){list.splice(index,1);render();};box.appendChild(del);return box;
  }

  var rules=read('mrc-rules-json'),rulesRoot=document.getElementById('mrc-shipping-rules');
  function renderRules(){
    rulesRoot.innerHTML='';document.querySelector('.mrc-builder-empty').hidden=rules.length>0;
    rules.forEach(function(rule,index){
      rule=Object.assign({enabled:true,district:'',area:'',amount:0,min_weight:0,min_quantity:0,min_value:0,shipping_class:'',rate_id:'',disable:false},rule);rules[index]=rule;
      var row=document.createElement('section');row.className='mrc-builder-row';
      var top=document.createElement('div');top.className='mrc-builder-row-head';
      var title=document.createElement('strong');title.textContent='Rule '+(index+1);top.appendChild(title);
      var enabled=document.createElement('label');enabled.className='mrc-builder-toggle';var check=document.createElement('input');check.type='checkbox';check.checked=!!rule.enabled;check.onchange=function(){rule.enabled=check.checked;syncRules();};enabled.append(check,document.createTextNode(' Active'));top.appendChild(enabled);top.appendChild(actions(index,rules,renderRules));row.appendChild(top);
      var grid=document.createElement('div');grid.className='mrc-builder-grid';
      var districtWrap=document.createElement('label');districtWrap.className='mrc-builder-field';var ds=document.createElement('span');ds.textContent='District';districtWrap.appendChild(ds);var district=document.createElement('select');district.dataset.key='district';option(district,'','All Bangladesh');Object.keys(data.districts||{}).forEach(function(slug){option(district,slug,data.districts[slug]);});district.value=rule.district||'';districtWrap.appendChild(district);grid.appendChild(districtWrap);
      grid.appendChild(field('Area / Thana','text',rule.area,'area'));
      grid.appendChild(field('Shipping amount','number',rule.amount,'amount','0.01'));
      grid.appendChild(field('Minimum weight (kg)','number',rule.min_weight,'min_weight','0.01'));
      grid.appendChild(field('Minimum quantity','number',rule.min_quantity,'min_quantity','1'));
      grid.appendChild(field('Minimum cart value','number',rule.min_value,'min_value','0.01'));
      var classWrap=document.createElement('label');classWrap.className='mrc-builder-field';var cs=document.createElement('span');cs.textContent='Shipping class';classWrap.appendChild(cs);var cls=document.createElement('select');cls.dataset.key='shipping_class';option(cls,'','Any class');(data.classes||[]).forEach(function(c){option(cls,c.slug,c.name);});cls.value=rule.shipping_class||'';classWrap.appendChild(cls);grid.appendChild(classWrap);
      grid.appendChild(field('Shipping rate ID (optional)','text',rule.rate_id,'rate_id'));
      var actionWrap=document.createElement('label');actionWrap.className='mrc-builder-field';var as=document.createElement('span');as.textContent='Action';actionWrap.appendChild(as);var action=document.createElement('select');action.dataset.key='action';option(action,'set','Set shipping amount');option(action,'disable','Disable matched rate');action.value=rule.disable?'disable':'set';actionWrap.appendChild(action);grid.appendChild(actionWrap);
      grid.addEventListener('input',function(e){var k=e.target.dataset.key;if(!k)return;if(k==='action')rule.disable=e.target.value==='disable';else if(e.target.type==='number')rule[k]=Number(e.target.value||0);else rule[k]=e.target.value;syncRules();});grid.addEventListener('change',function(e){e.target.dispatchEvent(new Event('input',{bubbles:true}));});
      row.appendChild(grid);rulesRoot.appendChild(row);
    });syncRules();
  }
  function syncRules(){set('mrc-rules-json',rules);}
  var addRule=document.querySelector('[data-mrc-add-rule]');if(addRule)addRule.onclick=function(){rules.push({enabled:true,district:'',area:'',amount:0,min_weight:0,min_quantity:0,min_value:0,shipping_class:'',rate_id:'',disable:false});renderRules();};

  var slots=read('mrc-slots-json'),slotsRoot=document.getElementById('mrc-delivery-slots');
  function renderSlots(){
    slotsRoot.innerHTML='';document.querySelector('.mrc-slots-empty').hidden=slots.length>0;
    slots.forEach(function(slot,index){
      slot=Object.assign({id:'slot-'+Date.now()+'-'+index,enabled:true,label:'',days:['0','1','2','3','4','5','6'],start:'09:00',end:'12:00',capacity:0,cutoff_hours:0},slot);slot.days=(slot.days||[]).map(String);slots[index]=slot;
      var row=document.createElement('section');row.className='mrc-builder-row';
      var top=document.createElement('div');top.className='mrc-builder-row-head';var title=document.createElement('strong');title.textContent=slot.label||('Time slot '+(index+1));top.appendChild(title);
      var enabled=document.createElement('label');enabled.className='mrc-builder-toggle';var check=document.createElement('input');check.type='checkbox';check.checked=!!slot.enabled;check.onchange=function(){slot.enabled=check.checked;syncSlots();};enabled.append(check,document.createTextNode(' Active'));top.appendChild(enabled);top.appendChild(actions(index,slots,renderSlots));row.appendChild(top);
      var grid=document.createElement('div');grid.className='mrc-builder-grid mrc-slot-grid';grid.appendChild(field('Customer label','text',slot.label,'label'));grid.appendChild(field('Start time','time',slot.start,'start'));grid.appendChild(field('End time','time',slot.end,'end'));grid.appendChild(field('Daily capacity (0 = unlimited)','number',slot.capacity,'capacity','1'));grid.appendChild(field('Order cutoff (hours)','number',slot.cutoff_hours,'cutoff_hours','1'));
      var days=document.createElement('fieldset');days.className='mrc-builder-days';var legend=document.createElement('legend');legend.textContent='Available days';days.appendChild(legend);dayNames.forEach(function(name,d){var l=document.createElement('label');var c=document.createElement('input');c.type='checkbox';c.checked=slot.days.indexOf(String(d))!==-1;c.onchange=function(){slot.days=dayNames.map(function(_,i){return i;}).filter(function(i){return days.querySelectorAll('input')[i].checked;}).map(String);syncSlots();};l.append(c,document.createTextNode(name));days.appendChild(l);});grid.appendChild(days);
      grid.addEventListener('input',function(e){var k=e.target.dataset.key;if(!k)return;slot[k]=e.target.type==='number'?Number(e.target.value||0):e.target.value;if(k==='label')title.textContent=e.target.value||('Time slot '+(index+1));syncSlots();});
      row.appendChild(grid);slotsRoot.appendChild(row);
    });syncSlots();
  }
  function syncSlots(){set('mrc-slots-json',slots);}
  var addSlot=document.querySelector('[data-mrc-add-slot]');if(addSlot)addSlot.onclick=function(){slots.push({id:'slot-'+Date.now(),enabled:true,label:'',days:['0','1','2','3','4','5','6'],start:'09:00',end:'12:00',capacity:0,cutoff_hours:0});renderSlots();};
  renderRules();renderSlots();
})();
