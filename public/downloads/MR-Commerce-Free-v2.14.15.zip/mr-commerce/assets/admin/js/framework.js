(function () {
    'use strict';

    function closeAll(framework, except) {
        framework.querySelectorAll('[data-mrbp-nav-item].is-open').forEach(function (item) {
            if (item !== except) {
                item.classList.remove('is-open');
                var link = item.querySelector(':scope > a[aria-expanded]');
                if (link) link.setAttribute('aria-expanded', 'false');
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-mrbp-framework]').forEach(function (framework) {
            framework.classList.add('is-ready');

            var toggle = framework.querySelector('[data-mrbp-sidebar-toggle]');
            if (toggle) {
                toggle.addEventListener('click', function () {
                    framework.classList.toggle('is-sidebar-open');
                });
            }

            framework.querySelectorAll('[data-mrbp-nav-item].has-flyout > a').forEach(function (link) {
                var item = link.parentElement;

                link.addEventListener('click', function (event) {
                    if (window.matchMedia('(max-width: 960px)').matches) {
                        event.preventDefault();
                        var willOpen = !item.classList.contains('is-open');
                        closeAll(framework, item);
                        item.classList.toggle('is-open', willOpen);
                        link.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
                    }
                });

                link.addEventListener('keydown', function (event) {
                    if (event.key === 'ArrowRight' || event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        closeAll(framework, item);
                        item.classList.add('is-open');
                        link.setAttribute('aria-expanded', 'true');
                        var first = item.querySelector('.mrbp-flyout__item');
                        if (first) first.focus();
                    }
                    if (event.key === 'Escape') {
                        item.classList.remove('is-open');
                        link.setAttribute('aria-expanded', 'false');
                    }
                });
            });

            document.addEventListener('click', function (event) {
                if (!framework.contains(event.target)) {
                    closeAll(framework, null);
                    framework.classList.remove('is-sidebar-open');
                }
            });
        });
    });
}());
