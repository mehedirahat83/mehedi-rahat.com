(function(){
  'use strict';
  var root=document.getElementById('mrc-campaign-rules'),input=document.getElementById('mrc-campaigns-json'),dataNode=document.getElementById('mrc-campaign-builder-data');
  if(!root||!input||!dataNode)return;
  var rules=[],data={categories:[],roles:{}};
  try{rules=JSON.parse(input.value)||[];}catch(e){}
  try{data=JSON.parse(dataNode.textContent)||data;}catch(e){}
  function sync(){input.value=JSON.stringify(rules);}
  function option(select,value,label){var o=document.createElement('option');o.value=String(value);o.textContent=label;select.appendChild(o);}
  function field(label,type,value,key,step){
    var wrap=document.createElement('label');wrap.className='mrc-builder-field';var title=document.createElement('span');title.textContent=label;wrap.appendChild(title);
    var el=document.createElement('input');el.type=type;el.value=value==null?'':value;el.dataset.key=key;if(step)el.step=step;if(type==='number')el.min='0';wrap.appendChild(el);return wrap;
  }
  function selectField(label,key,value,items){
    var wrap=document.createElement('label');wrap.className='mrc-builder-field';var title=document.createElement('span');title.textContent=label;wrap.appendChild(title);
    var select=document.createElement('select');select.dataset.key=key;items.forEach(function(item){option(select,item[0],item[1]);});select.value=String(value==null?'':value);wrap.appendChild(select);return wrap;
  }
  function actions(index){
    var box=document.createElement('div');box.className='mrc-builder-actions';
    [['Up',-1],['Down',1]].forEach(function(a){var b=document.createElement('button');b.type='button';b.className='button';b.textContent=a[0];b.onclick=function(){var n=index+a[1];if(n<0||n>=rules.length)return;var item=rules.splice(index,1)[0];rules.splice(n,0,item);render();};box.appendChild(b);});
    var remove=document.createElement('button');remove.type='button';remove.className='button mrc-remove';remove.textContent='Remove';remove.onclick=function(){rules.splice(index,1);render();};box.appendChild(remove);return box;
  }
  function normalize(rule){
    var amount=rule.amount!=null?rule.amount:(rule.percent||0);
    return Object.assign({enabled:true,label:'Promotional discount',type:'percent',amount:amount,min_value:0,min_quantity:0,max_discount:0,category:0,role:''},rule,{amount:amount,type:rule.type==='fixed'?'fixed':'percent'});
  }
  function render(){
    root.innerHTML='';var empty=document.querySelector('.mrc-campaigns-empty');if(empty)empty.hidden=rules.length>0;
    rules.forEach(function(original,index){
      var rule=normalize(original);rules[index]=rule;
      var row=document.createElement('section');row.className='mrc-builder-row';
      var head=document.createElement('div');head.className='mrc-builder-row-head';var title=document.createElement('strong');title.textContent=rule.label||('Campaign '+(index+1));head.appendChild(title);
      var active=document.createElement('label');active.className='mrc-builder-toggle';var check=document.createElement('input');check.type='checkbox';check.checked=!!rule.enabled;check.onchange=function(){rule.enabled=check.checked;sync();};active.append(check,document.createTextNode(' Active'));head.appendChild(active);head.appendChild(actions(index));row.appendChild(head);
      var grid=document.createElement('div');grid.className='mrc-builder-grid';
      grid.appendChild(field('Campaign name','text',rule.label,'label'));
      grid.appendChild(selectField('Discount type','type',rule.type,[['percent','Percentage'],['fixed','Fixed cart amount']]));
      grid.appendChild(field('Discount amount','number',rule.amount,'amount','0.01'));
      grid.appendChild(field('Minimum cart value','number',rule.min_value,'min_value','0.01'));
      grid.appendChild(field('Minimum quantity','number',rule.min_quantity,'min_quantity','1'));
      grid.appendChild(field('Maximum discount (0 = unlimited)','number',rule.max_discount,'max_discount','0.01'));
      var categories=[['0','Any product category']].concat((data.categories||[]).map(function(c){return[String(c.id),c.name];}));
      grid.appendChild(selectField('Required product category','category',rule.category,categories));
      var roles=[['','All customers']];Object.keys(data.roles||{}).forEach(function(key){roles.push([key,data.roles[key]]);});
      grid.appendChild(selectField('Customer role','role',rule.role,roles));
      grid.addEventListener('input',function(e){var key=e.target.dataset.key;if(!key)return;rule[key]=e.target.type==='number'?Number(e.target.value||0):e.target.value;if(key==='label')title.textContent=e.target.value||('Campaign '+(index+1));sync();});
      grid.addEventListener('change',function(e){e.target.dispatchEvent(new Event('input',{bubbles:true}));});
      row.appendChild(grid);root.appendChild(row);
    });sync();
  }
  var add=document.querySelector('[data-mrc-add-campaign]');if(add)add.onclick=function(){rules.push({enabled:true,label:'New campaign',type:'percent',amount:10,min_value:0,min_quantity:0,max_discount:0,category:0,role:''});render();};
  render();
})();
