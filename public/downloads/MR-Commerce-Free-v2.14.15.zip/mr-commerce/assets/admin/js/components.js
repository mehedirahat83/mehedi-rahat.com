(function () {
    'use strict';

    function activateTab(container, button) {
        var target = button.getAttribute('data-tab-target');
        if (!target) return;

        container.querySelectorAll('[role="tab"]').forEach(function (tab) {
            var active = tab === button;
            tab.classList.toggle('is-active', active);
            tab.setAttribute('aria-selected', active ? 'true' : 'false');
            tab.setAttribute('tabindex', active ? '0' : '-1');
        });

        container.querySelectorAll('[data-tab-panel]').forEach(function (panel) {
            var active = panel.getAttribute('data-tab-panel') === target;
            panel.classList.toggle('is-active', active);
            panel.hidden = !active;
        });
    }

    document.addEventListener('click', function (event) {
        var button = event.target.closest('[data-mrbp-tabs] [role="tab"]');
        if (!button) return;
        activateTab(button.closest('[data-mrbp-tabs]'), button);
    });

    document.addEventListener('keydown', function (event) {
        var button = event.target.closest('[data-mrbp-tabs] [role="tab"]');
        if (!button || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        var tabs = Array.from(button.closest('[data-mrbp-tabs]').querySelectorAll('[role="tab"]'));
        var index = tabs.indexOf(button);
        var next = index;
        if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
        if (event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = tabs.length - 1;
        event.preventDefault();
        tabs[next].focus();
        activateTab(button.closest('[data-mrbp-tabs]'), tabs[next]);
    });
})();

(function () {
    'use strict';
    document.addEventListener('change', function (event) {
        var input = event.target.closest('[data-module-toggle]');
        if (!input) return;
        var card = input.closest('[data-module-card]');
        var label = card ? card.querySelector('[data-toggle-label]') : null;
        var status = card ? card.querySelector('[data-module-status]') : null;
        if (label) label.textContent = input.checked ? 'On' : 'Off';
        if (status) status.textContent = input.checked ? 'Active' : 'Inactive';
        if (card) {
            card.classList.toggle('is-active', input.checked);
            card.classList.toggle('is-inactive', !input.checked);
        }
    });
})();
