(function(){
  'use strict';
  function refresh(){
    var date=document.getElementById('mrc_delivery_date'),select=document.getElementById('mrc_delivery_slot');
    if(!date||!select)return;
    var day=date.value?new Date(date.value+'T12:00:00').getDay():null,visible=0;
    Array.prototype.forEach.call(select.options,function(option,index){
      if(index===0)return;
      var days=(option.dataset.days||'').split(',');
      var show=day!==null&&days.indexOf(String(day))!==-1;
      option.hidden=!show;option.disabled=!show;if(show)visible++;
      if(!show&&option.selected)select.value='';
    });
    select.options[0].textContent=day===null?'Choose a date first':(visible?'Choose a time':'No slots available for this day');
  }
  document.addEventListener('change',function(e){if(e.target&&e.target.id==='mrc_delivery_date')refresh();});
  document.addEventListener('DOMContentLoaded',refresh);
  if(window.jQuery){window.jQuery(document.body).on('updated_checkout',refresh);}
})();
